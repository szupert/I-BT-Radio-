@echo off
call "%~dp0STRESS_TEST\START_ROWS_12MIN.bat"
