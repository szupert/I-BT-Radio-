@echo off
call "%~dp0STRESS_TEST\START_CPU_STAGES_15MIN.bat"
