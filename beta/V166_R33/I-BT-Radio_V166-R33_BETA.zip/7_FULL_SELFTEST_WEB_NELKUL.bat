@echo off
call "%~dp0STRESS_TEST\START_FULL_NO_WEB.bat"
