# V166-R30 – BT + artwork, 60 perces kontroll

Indítás: USER/I-BT-Radio_LATEST/1_FELTOLTES.bat, utána 8_BT_ARTWORK_60PERC.bat. A feltöltést és a mérést a felhasználó végzi. Mentett BT-hangszóró legyen bekapcsolva.

Az automata tester elindítja a mentett internetes adót DAC-on, előkészíti a képet, majd megkeresi az elérhető mentett BT-eszközt. Azonos adó/eszköz, ténylegesen egyeztetett 32000 Hz. WebUI és SD-forrásváltás nincs ebben a kontrollban. Indulási várakozás nincs benne a 60 percben.

| Mérés perce | Artwork |
|---|---|
| 0–10 | Ki |
| 10–20 | Be |
| 20–30 | Ki |
| 30–40 | Be |
| 40–50 | Ki |
| 50–60 | Be |

Egy közös 3600 másodperces időhatárból számolt szakaszok; soros parancs/visszaolvasás késése naplózott. A váltás nem valós idejű hardveres kapcsoló. Be módban a 320×240 kép 4 soros szeletekben, legalább 20 ms várakozással rajzolódik, 30 másodpercenként újradekódolva. A kezelőgombok és diagnosztika a kép fölött látszanak.

Egyetlen, a mérés előtt lefagyasztott JPEG: meglévő borító (`CACHED_COVER`), különben saját kontrollkép (`BUNDLED_CONTROL`). A teljes képpuffer 153600 B PSRAM. A JPEG, dekóderobjektum és kísérleti állapot PSRAM-ban van; kikapcsoláskor a foglalás megmarad a tiszta összevetéshez, session-végén felszabadul. Nincs új borítóletöltés az A/B modultól. Az eredmény a rajzolási/dekódolási hatásról szól; élő artwork-hálózati letöltés hatása NOT_TESTED.

A tester ellenőrzi az artwork állapotát, ON rajzolási/dekódolási előrehaladását, OFF mozdulatlan számlálóit, a BT-rátát és PCM-előrehaladást. Hiba/fagyás/kapcsolatvesztés esetén FAIL napló készül; nem jelöl üres várakozást sikeres hangmérésnek. G jelöli a hallott kihagyást, Q szabályosan megszakítja a mérést. A hibás/hiányzó borító nem ad néma PASS-t.

Naplók: SYSTEM/LOGS/STRESS_TEST. Visszaadható másolat és ZIP: USER/I-BT-Radio_LATEST/RETURN_TO_EVA. `ARTWORK_SUMMARY.csv`: kép terhelése és BT-underrun szakaszonként. `LOAD_SUMMARY.csv`: Core 0–1 terhelés. `RATE_COMPARISON.json`: szakaszonként bemeneti/PCM pufferminimum és első mintában észlelt kifogyás. `SAMPLES.json`, `serial.log`: nyers diagnosztika. A JPEG falideje nem tiszta CPU-idő; a mintában észlelt kifogyás nem a hallható szünet pontos ideje.

Ki és Be szakaszokat hasonlítunk össze, oksági bizonyíték nélkül nem nevezünk meg végleges szakadozási okot. Fizikai hangstabilitás: NOT_RUN a visszaadott mérésekig. A korábban hallott ritka kihagyás miatt GitHub-kiadás HOLD.
