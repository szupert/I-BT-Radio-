@echo off
call "%~dp0STRESS_TEST\START_DEQUANT_6MIN.bat"
