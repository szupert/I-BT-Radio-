@echo off
call "%~dp0STRESS_TEST\START_CPU_BT_10MIN.bat"
