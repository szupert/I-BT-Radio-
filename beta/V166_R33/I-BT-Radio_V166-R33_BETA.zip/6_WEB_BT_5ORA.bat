@echo off
call "%~dp0STRESS_TEST\START_WEB_BT_5H.bat"
