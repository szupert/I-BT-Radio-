﻿# I-BT-Radio V166-R33 BETA

Feltöltés: **1_FELTOLTES.bat**. A BETA alatt V166-R33 jelenjen meg.
Új mérés: **17_CORE_BALANCE_6PERC.bat**. A felhasználó futtatja; a csomagkészítés nem nyit COM-portot.

6 perc mérés: 2 perc eredeti út, 2 perc Core0 MP3-dequantizálás minden granule-ra, 2 perc eredeti út. Budapest Rock, utolsó sikeres mentett BT eszköz, tényleges 32 kHz; WebUI-terhelés és artwork nélkül. A rádió indulási ideje ezen felül van. A teszt előkészíti a worker memóriáját mindhárom szakasz előtt. A kapcsoló RAM-only, végén/lease lejáratakor kikapcsol; nem állít végleges nyertest. A korábbi 16_CORE1_CORE0_AB_6PERC.bat a minden nyolcadik granule kontrollt tartja meg.

A cél a Core1 terhelésének 15 százalékpontos csökkentése. Ez még NEM mért eredmény. Csak az MP3 dequantizálás helye változik a BE szakaszban; a teljes decoder, SBC, TLS, prioritások és DAC út változatlan. Core0 túlterhelés vagy rosszabb hang kizárja a jelöltet. AAC/FLAC nem része ennek az MP3-kísérletnek. Szinkron worker-válasz védi a decoder adatok élettartamát.

Internetes rádió→BT fix 32 kHz. SD→BT tiszta indításkor az ismert forrás szerint 16/32/44,1/48 kHz SBC célt választ, maximum48 kHz; 16 kHz alatti forrásnál SBC minimum16. Ismeretlen forrás a jelenlegi érvényes célt használja. Aktív kapcsolaton új SD számnál nincs automatikus újratárgyalás. A tényleges közös codec-rátát a log mutatja. SD→DAC forrás szerinti, BT→DAC a bejövő kapcsolat szerint; hardverkorlát továbbra érvényes.

R32 KAJON VU megmarad: Beállítások → Kijelző → Felület → KAJON VU. Saját menü/lista, ritka PCM observer; WEB-BT minimal/artwork út változatlan. Media Player alsó mezője és USB tab stílusa javítva. A képadatok teljes RGB565 ellenőrzése PASS.

7_FULL_SELFTEST_WEB_NELKUL.bat: teljes menü/SD/radio/DAC/BT profil, időt bekéri. Naplók RETURN_TO_EVA és SYSTEM/LOGS alatt; G hallott kihagyás, Q leállítás.

Célzott offline ellenőrzések és build PASS; fizikai boot/UI/PCM/BT-hang és CPU-javulás NOT_RUN. BETA, csak tesztelésre. A korábbi ritka kihagyás nincs megoldottnak minősítve.
Feltöltő: élő COM/BOOT/valódi százalék, baud/16MB partíció/hash fail-closed. KAJON GitHub-közzététel a grafika engedélyének tisztázásáig függőben.

## 10 perces menu/stabilitas tesztek
19_MENU_STABILITAS_10PERC.bat: WebUI nelkul. 20_MENU_WEB_STABILITAS_10PERC.bat: WebUI terhelessel. Mindketto automatikus menu/almenu RAM-only tour es all-row render500/200/50ms, SD-DAC/WEB vissza es WEB-BT32 kontroll. A meresi ablak600s a readiness utan, startup es cleanup ezen felul. Hianyzo/tiltott/idokeretbe nem fero szakasz nem PASS. Gyari torles/flash/BT-IN/fizikairotary nem automatizalt. FirmwareR33 eleg.

## 10 perces menu/stabilitas tesztek
19_MENU_STABILITAS_10PERC.bat: WebUI nelkul. 20_MENU_WEB_STABILITAS_10PERC.bat: WebUI terhelessel. Mindketto automatikus menu/almenu RAM-only tour es all-row render500/200/50ms, SD-DAC/WEB vissza es WEB-BT32 kontroll. A meresi ablak600s a readiness utan, startup es cleanup ezen felul. Hianyzo/tiltott/idokeretbe nem fero szakasz nem PASS. Gyari torles/flash/BT-IN/fizikairotary nem automatizalt. FirmwareR33 eleg.

## 10 perces menu/stabilitas tesztek
19_MENU_STABILITAS_10PERC.bat: WebUI nelkul. 20_MENU_WEB_STABILITAS_10PERC.bat: WebUI terhelessel. Mindketto automatikus menu/almenu RAM-only tour es all-row render500/200/50ms, SD-DAC/WEB vissza es WEB-BT32 kontroll. A meresi ablak600s a readiness utan, startup es cleanup ezen felul. Hianyzo/tiltott/idokeretbe nem fero szakasz nem PASS. Gyari torles/flash/BT-IN/fizikairotary nem automatizalt. FirmwareR33 eleg.


## Nonstop full selftest — 18_NONSTOP_FULL_10ORA.bat
Firmware R33 eleg, uj feltoltes nem kell. Maximum 600 perc a teljes inditastol, vagy Q leallitasig. G = hallott kihagyas jelolese. Ha a billentyuzet nem mukodik, RETURN_TO_EVA/STOP_NONSTOP.bat megallitja. Leallitasnal legfeljebb45 masodpercet hagy a gyermek teszt naplomentesere; beragadt tesztfolyamatot bezarja, nem reseteli/flasheli a radiot.
Teljes menu/almenu render es nemrombolo selftest500..50ms, SD/WEB DAC/BT, es WebUI; majd10perces internet-BT szakasz WebUI probakkal. Ismetlodo korok. Hibanal a kor hibas marad, a kovetkezo60s varakozas utan ujra indul es var a radiora. AutoCOM/status/BudapestRock/mentettBT, IPv4 a soros portrol. WebUI elerhetetlenseg NOT_RUN es ujraproba kovetkezo korben; firmware audioguardjait nem keruli meg. BT-IN, valodi fizikai rotary, rombolo beallitas es tiltott menumuvelet nem teljesen automatizalt.
Minden kor kulon RESULT/serial/SAMPLES/CSV/hash a SYSTEM/LOGS/STRESS_TEST/NONSTOP_* es RETURN_TO_EVA/NONSTOP_* alatt; vegul egy osszesitoZIP. Watchdog-bontaskor reszleges log es INCOMPLETE_CHILD, nem PASS. A hangra fizikai PASS-t nem ad automatikusan. Alap audiooffload beallitas, nem kapcsolja be vegleg az R33 diagnosztikai kiserletet.
Offline runner selftest/valos stopdeadline/plan/parser PASS; valodi10oras futas NOT_RUN.
