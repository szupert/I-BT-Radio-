@echo off
call "%~dp0STRESS_TEST\START_NONSTOP_10H.bat"
