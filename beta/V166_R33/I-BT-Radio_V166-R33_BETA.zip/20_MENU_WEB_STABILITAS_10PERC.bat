@echo off
call "%~dp0STRESS_TEST\START_MENU_WEB_10MIN.bat"
