@echo off
call "%~dp0STRESS_TEST\START_BATCH_OFFLOAD_70MIN.bat"
