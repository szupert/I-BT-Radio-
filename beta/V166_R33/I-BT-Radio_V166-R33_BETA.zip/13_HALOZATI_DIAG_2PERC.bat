@echo off
call "%~dp0STRESS_TEST\START_NETWORK_DIAG.bat"
