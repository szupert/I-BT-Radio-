I-BT-Radio V166-R7 BETA — PCM előtöltés előtti BT-adás elkerülése

Kísérleti javítás, fizikai hangstabilitás még nem igazolt.
A BT kapcsolat és codec-egyeztetés felépülhet, de a helyi média START csak legalább félmásodpercnyi PCM után indul. A dekóder/PCM worker a connected+codec állapottól termelhet, nem vár a média indulására. Az első callback megtartja az előre feltöltött PCM-et. CHECK/START visszaigazolás vagy indulási timeout esetén véges hiba és DAC-visszatérés marad.
A meglévő 1 MiB input ring, 512 KiB stream-indulási küszöb, 256 mintás callback, Wi-Fi policy, CPU-magok/prioritások és 16 MB partíció nem változott.
Ez az első médiaindítás kapuja; már futó BT-adás alatti későbbi rebuffer még a meglévő csend/fade viselkedést használja. Távoli eszköz által kezdeményezett START fizikai viselkedése is külön ellenőrzendő.

1. INSTALLER\START_BETA_INSTALLER.bat — kézi feltöltés.
2. Az előző adó szóljon DAC-on; BT OUT KI, a kipróbálandó mentett eszköz BE.
3. STRESS_TEST\START_BT_10MIN.bat — menü/SD/WebUI nélkül.
4. Küldd vissza a RETURN_TO_EVA ZIP-et és írd le, hallottál-e kihagyást.

A futtató már connected=1 állapotnál elkezdi az egyszeri 180s előtöltési keretet. A tízperces zenei mérés továbbra csak növekvő delivered_bytes után indul. A peer neve és kiválasztott index a logban van; a mentett sorrend változhat.
Várt sorrend: codec PASS és kapcsolat, PREBUFFER READY, majd BT-MEDIA-GATE CHECK / START, végül növekvő delivered_bytes. A START előtt a helyi kód nem kér médiaindítást és nem kell csendes PCM-kéréseknek szaporodniuk. Ha így is megáll a töltés, a NET-RX-IO sor mutatja az állapotot; az RF/TCP ok még nincs bizonyítva.
