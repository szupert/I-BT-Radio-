# Core 1 tehermentesítési kontroll — V166-R33
Indító: 16_CORE1_CORE0_AB_6PERC.bat. A jelenlegi R31 firmware elég; új feltöltés nem szükséges.
Automatikus Budapest Rock, mentett BT, tényleges32kHz. WebUI és artwork nincs.
A teszt leállítja a DAC-lejátszást, előkészíti a meglévő MP3 workert, visszaindítja az adót és kapcsolódik BT-re. Memóriaguard nem lazul; DENIED esetén FAIL és visszaadható napló.
2perc KI / 2perc BE / 2perc KI: a BE szakasz minden nyolcadik MP3 dekvantálási munkát Core0-ra küld. Ugyanaz a workerfoglalás végig, valódi munkaszámláló szükséges. AAC-val nem futtatható.
Cél: Core1 tartósan90% alatt, nem romló Core0 és hang. A teszt nem jelent automatikus stabilitási PASS-t. G jelzi a hallott kihagyást, Q leállít. A végén offload KI és DAC visszaállítás.
Napló: SYSTEM/LOGS/STRESS_TEST és USER/I-BT-Radio_LATEST/RETURN_TO_EVA, RESULT/hash/ZIP hibánál is.
