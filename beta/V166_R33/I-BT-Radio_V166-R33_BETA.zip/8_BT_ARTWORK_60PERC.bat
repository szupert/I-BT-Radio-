@echo off
call "%~dp0STRESS_TEST\START_BT_ARTWORK_60.bat"
