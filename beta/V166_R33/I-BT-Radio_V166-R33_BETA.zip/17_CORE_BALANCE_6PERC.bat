@echo off
call "%~dp0STRESS_TEST\START_FULL_DEQUANT_6MIN.bat"
