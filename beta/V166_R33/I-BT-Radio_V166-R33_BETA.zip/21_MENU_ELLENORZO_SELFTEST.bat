@echo off
call "%~dp019_MENU_STABILITAS_10PERC.bat"
