@echo off
call "%~dp0STRESS_TEST\START_SBC_STAGES.bat"
