@echo off
call "%~dp0STRESS_TEST\START_CONNECT_DIAG.bat"
