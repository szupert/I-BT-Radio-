@echo off
call "%~dp0STRESS_TEST\START_BASELINE_20MIN.bat"
