@echo off
chcp 65001 >nul
echo I-BT-Radio R21 - 60 perc BT artwork Ki/Be, WebUI nelkul
echo Automata radio es mentett BT-eszkoz inditas. G: kihagyas, Q: leallitas.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_stress_logged.ps1" -Artwork60 -Minutes 60 -ReturnRoot "%~dp0..\RETURN_TO_EVA"
echo A visszaadhato ZIP a RETURN_TO_EVA mappaba kerul.
pause
