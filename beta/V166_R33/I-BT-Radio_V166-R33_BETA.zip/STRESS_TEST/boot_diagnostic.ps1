﻿param([switch]$ConnectCheck,[switch]$NetworkSnapshot,[int]$Seconds=180,[string]$PortName='', [string]$ReturnRoot=(Join-Path $PSScriptRoot '..\RETURN_TO_EVA'),[switch]$SelfTest,[string]$MockLog='')
$ErrorActionPreference='Stop'
if($ConnectCheck){$NetworkSnapshot=$true}
function SafeLine([string]$line){
 $line=[regex]::Replace($line,'(?i)https?://\S+','<URL>')
 $line=[regex]::Replace($line,'\b(?:\d{1,3}\.){3}\d{1,3}\b','<IP>')
 $line=[regex]::Replace($line,'(?i)\b(?:[0-9a-f]{2}:){5}[0-9a-f]{2}\b','<MAC>')
 return [regex]::Replace($line,'(?i)\b(ssid|password|passwd|token|authorization)\b.*','$1=<redacted>')
}
function BootFinding([string]$text){
 if($text -match 'ADC:\s*CONFLICT|driver_ng is not allowed'){return 'FAIL_ADC_DRIVER_CONFLICT'}
 if($text -match 'Guru Meditation|abort\(\) was called|assert failed|Brownout|watchdog|invalid header|Invalid image|Not enough memory'){return 'FAIL_BOOT_FAULT_CAPTURED'}
 if($text -match '\[BOOT-READY\].*setup=1'){return 'BOOT_READY_CAPTURED_DISPLAY_NOT_VERIFIED'}
 if($text -match 'DOWNLOAD_BOOT|waiting for download'){return 'BOOTLOADER_DOWNLOAD_MODE'}
 if($text -match '\S'){return 'PARTIAL_BOOT_OR_RUNNING_LOG'}
 return 'NO_SERIAL_DATA'
}
function ConnectionDecision([string]$text){
 if($text -notmatch '##CLI.LIST#'){return $null}
 if($text -notmatch '\[R10-CAPS\].*firmware=V166-R33(?:\s|$)'){return $null}
 $net=@([regex]::Matches($text,'(?m)^.*\[WIFI-NET\] ([^\r\n]+)'))
 $state=@([regex]::Matches($text,'(?m)^.*\[PATH-STATE\] ([^\r\n]+)'))
 if(!$net.Count -or !$state.Count){return $null}
 $n=@{};$s=@{}
 foreach($m in [regex]::Matches($net[-1].Groups[1].Value,'(\w+)=(\S+)')){$n[$m.Groups[1].Value]=$m.Groups[2].Value}
 foreach($m in [regex]::Matches($state[-1].Groups[1].Value,'(\w+)=(\S+)')){$s[$m.Groups[1].Value]=$m.Groups[2].Value}
 if($n.connected -ne '1' -or $n.ip_valid -ne '1' -or $n.dns_valid -ne '1' -or $n.sta -ne '1'){return $null}
 if($s.active -ne '0' -or $s.restoring -ne '0' -or $s.route -ne '0' -or $s.idle -ne '1' -or $s.web -ne '1'){return $null}
 $stations=@([regex]::Matches($text,'#CLI.LISTNUM#:\s*(\d+):\s*Budapest\s*Rock\s*,'))
 if($stations.Count -ne 1 -or [int]$stations[0].Groups[1].Value -le 0){return $null}
 return [int]$stations[0].Groups[1].Value
}
function NetworkFinding([string]$text){
 $boot=BootFinding $text
 if($boot -like 'FAIL_*'){return $boot}
 if($text -match '\[WIFI-NET\]'){return 'NETWORK_SNAPSHOT_CAPTURED_NOT_CONNECTIVITY_PASS'}
 return 'NETWORK_SNAPSHOT_MISSING'
}
if($SelfTest){
 foreach($case in @(@('E (2539) ADC: CONFLICT! driver_ng is not allowed to be used with the legacy driver','FAIL_ADC_DRIVER_CONFLICT'),@('[BOOT-READY] firmware=V166-R22 setup=1','BOOT_READY_CAPTURED_DISPLAY_NOT_VERIFIED'),@('[BOOT-READY] setup=1 abort() was called','FAIL_BOOT_FAULT_CAPTURED'),@('waiting for download','BOOTLOADER_DOWNLOAD_MODE'),@('','NO_SERIAL_DATA'))){if((BootFinding $case[0]) -ne $case[1]){throw 'Boot classification failed'}}
 if((SafeLine 'SSID secret password abc 192.168.1.2') -match 'secret|abc|192\.168'){throw 'Redaction failed'}
 Write-Host 'PASS: boot/conflict/crash/ready/ROM/silence classification and privacy; COM NOT_OPENED.';exit 0
}
$stamp='BOOT_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff');$out=Join-Path 'C:\esp32\SYSTEM\LOGS\BOOT' $stamp
$back=Join-Path ([IO.Path]::GetFullPath($ReturnRoot)) $stamp
New-Item -ItemType Directory -Path $out,$back -Force|Out-Null
$writer=$null;$mirror=$null;$serial=$null;$pending='';$errorText='';$count=0;$commandsSent=0;$startupRequested=$false;$stopped=$false;$result='NOT_RUN';$text=New-Object Text.StringBuilder
function BootWrite([string]$line){if($writer){$writer.WriteLine($line)};if($mirror){$mirror.WriteLine($line)}}
$watch=[Diagnostics.Stopwatch]::StartNew()
@{result='RUNNING_OR_INTERRUPTED';master_log=$out;flash=$false;automatic_reset=$false}|ConvertTo-Json|Set-Content (Join-Path $back 'RUN_STATUS.json') -Encoding UTF8
try{
 $writer=New-Object IO.StreamWriter((Join-Path $out 'serial.log'),$false,(New-Object Text.UTF8Encoding($false)));$writer.AutoFlush=$true
 $mirror=New-Object IO.StreamWriter((Join-Path $back 'serial.log'),$false,(New-Object Text.UTF8Encoding($false)));$mirror.AutoFlush=$true
 BootWrite ('[BOOT-DIAG] read_only='+[int](!$ConnectCheck)+' baud=115200 automatic_reset=0 flash=0')
 if($Seconds -lt 10 -or $Seconds -gt 1800){throw 'INVALID_DURATION'}
 if($MockLog){
  foreach($line in (Get-Content -LiteralPath $MockLog)){$safe=SafeLine $line;BootWrite $safe;[void]$text.AppendLine($safe);$count++}
 }else{
  $ports=@([IO.Ports.SerialPort]::GetPortNames()|Sort-Object)
  if(!$ports.Count){throw 'NO_COM_PORT'}
  if(!$PortName){
   if($ports.Count -eq 1){$PortName=$ports[0]}else{
    for($i=0;$i -lt $ports.Count;$i++){Write-Host "$($i+1). $($ports[$i])"}
    $choice=0;if(![int]::TryParse((Read-Host 'Radio COM-port sorszama'),[ref]$choice) -or $choice -lt 1 -or $choice -gt $ports.Count){throw 'INVALID_COM_SELECTION'}
    $PortName=$ports[$choice-1]
   }
  }
  if($PortName -notin $ports){throw 'COM_NOT_PRESENT'}
  $serial=New-Object IO.Ports.SerialPort($PortName,115200)
  $serial.DtrEnable=$false;$serial.RtsEnable=$false;$serial.Encoding=[Text.Encoding]::UTF8;$serial.ReadTimeout=100
  $serial.Open()
  Write-Host ('[COM] '+$PortName+' @115200, csak naploolvasas.')
  if($ConnectCheck){Write-Host 'Budapest Rock automatikus egyszeri inditasa DAC-on, biztonsagos statuszkapuk utan. BT-t nem kapcsol. A vegen nem allitja le a lejatszast.'}elseif($NetworkSnapshot){Write-Host 'Halozati allapot naplozasa; nem kell RESET, nem indit vagy allit le lejatszast.'}else{Write-Host 'MOST nyomj egy rovid RESET/EN gombot a radion. BOOT-ot ne tartsd nyomva.'}
  Write-Host ('Naplozas '+$Seconds+' masodpercig. Q: korabbi befejezes. Semmi nem torlodik vagy toltodik fel.')
  $watch.Restart();$notice=0;$nextNetworkQuery=0
  while($watch.Elapsed.TotalSeconds -lt $Seconds){
   try{if([Console]::KeyAvailable -and [Console]::ReadKey($true).Key -eq 'Q'){$stopped=$true;break}}catch{}
   if($NetworkSnapshot -and $watch.Elapsed.TotalSeconds -ge $nextNetworkQuery){
    if($nextNetworkQuery -eq 0){$serial.Write("r10 caps`n");$commandsSent++;BootWrite '[NET-DIAG] query=r10 caps'}
    $serial.Write("wifi.status`n");$commandsSent++;BootWrite '[NET-DIAG] query=wifi.status';
    if($ConnectCheck){$serial.Write("r10 path status`n");$commandsSent++;if($nextNetworkQuery -eq 0){$serial.Write("list`n");$commandsSent++}}$nextNetworkQuery=$watch.Elapsed.TotalSeconds+30
   }
   $pending+=$serial.ReadExisting()
   while($pending.Contains("`n")){
    $split=$pending.IndexOf("`n");$line=$pending.Substring(0,$split).TrimEnd("`r");$pending=$pending.Substring($split+1)
    $safe=SafeLine $line;BootWrite ('[{0:0.000}s] {1}' -f $watch.Elapsed.TotalSeconds,$safe);[void]$text.AppendLine($safe);$count++
    Write-Host $safe
   }
   if($ConnectCheck -and !$startupRequested){
    $station=ConnectionDecision $text.ToString()
    if($null -ne $station){
     $serial.Write("play $station`n");$commandsSent++;$startupRequested=$true
     BootWrite ('[CONNECT-CHECK] single_play=1 station='+$station+' target=BUDAPEST_ROCK route=DAC; firmware owns subsequent retries')
     Write-Host 'Budapest Rock kapcsolodasi meres indul DAC-on. A firmware ujraprobait naplozom.'
    }
   }
   if($pending.Length -gt 16384){$safe=SafeLine $pending;BootWrite ('[FRAGMENT] '+$safe);[void]$text.AppendLine($safe);$pending=''}
   if($watch.Elapsed.TotalSeconds -ge $notice){Write-Host ('[BOOT-NAPLO] '+[int]$watch.Elapsed.TotalSeconds+'/'+$Seconds+' mp; sorok='+$count);$notice=$watch.Elapsed.TotalSeconds+5}
   Start-Sleep -Milliseconds 50
  }
 }
 $result=if($NetworkSnapshot){NetworkFinding $text.ToString()}else{BootFinding $text.ToString()}
}catch{$errorText=SafeLine $_.Exception.Message;$result='NOT_RUN_OR_SERIAL_ERROR';BootWrite ('[ERROR] '+$errorText);Write-Host ('[HIBA] '+$errorText)}
finally{
 if($pending){$safe=SafeLine $pending;BootWrite ('[FINAL-FRAGMENT] '+$safe);[void]$text.AppendLine($safe)}
 if($serial){if($serial.IsOpen){$serial.Close()};$serial.Dispose()}
 if($writer){$writer.Dispose()}
 if($mirror){$mirror.Dispose()}
 if(!$errorText){$result=if($NetworkSnapshot){NetworkFinding $text.ToString()}else{BootFinding $text.ToString()}}
 $report=@{test=$(if($ConnectCheck){'SINGLE_START_CONNECTION_DIAGNOSTIC'}elseif($NetworkSnapshot){'NETWORK_SNAPSHOT_DIAGNOSTIC'}else{'PASSIVE_BOOT_DIAGNOSTIC'});result=$result;error=$errorText;port=$PortName;seconds=$watch.Elapsed.TotalSeconds;lines=$count;stopped_by_user=$stopped;physical_display='NOT_VERIFIED';flash=$false;commands_sent=$commandsSent;startup_requested=$startupRequested;automatic_reset=$false;mock=[bool]$MockLog}
 $report|ConvertTo-Json|Set-Content (Join-Path $out 'RESULT.json') -Encoding UTF8
 @{result=$result;master_log=$out}|ConvertTo-Json|Set-Content (Join-Path $out 'RUN_STATUS.json') -Encoding UTF8
 Get-ChildItem $out -File|Get-FileHash -Algorithm SHA256|Select-Object @{n='file';e={Split-Path $_.Path -Leaf}},Hash|ConvertTo-Json|Set-Content (Join-Path $out 'HASHES.json') -Encoding UTF8
 Copy-Item -Path (Join-Path $out '*') -Destination $back -Force
 Compress-Archive -Path (Join-Path $out '*') -DestinationPath ($out+'.zip') -Force
 Copy-Item -LiteralPath ($out+'.zip') -Destination ($back+'.zip') -Force
 Write-Host ('[EREDMENY] '+$result);Write-Host ('[VISSZAKULDENDO] '+$back+'.zip')
}
if($errorText){exit 1};exit 0



