﻿$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'full_menu_stress.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Runner syntax error'}
foreach($name in @('ExpectedBtRate','BtPlaybackReady','DeliveredBytes','WaitBtPlayback','Observe')){
 $f=$ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)|Where-Object {$_.Name -eq $name}|Select-Object -First 1
 Invoke-Expression $f.Extent.Text
}
$NoBtHour=$false;$script:ExpectedStation=0;$script:Phase='MOCK_RATE';$script:MockDelivered=0
function Record($text){}
function Status {return @{active='1';web='1';route='1';connected='1';transmitting='1';rate=(ExpectedBtRate);playing='1';input_buffer='32768'}}
function Sample {$script:MockDelivered+=1024;return @{'PATH-STATE'=(Status);'BT-AUDIO'=@{delivered_bytes=[string]$script:MockDelivered;codec_ok='1'}}}
function BtWaitNow {return [DateTime]::UtcNow}
function Pump([int]$ms){if($script:ObserveTest){throw 'MOCK_OBSERVE_END'}}
foreach($rate in @('rate32','rate44')){
 $script:ProbeRate=$rate;$script:ObserveTest=$false;$script:MockDelivered=0
 if(!(BtPlaybackReady (Status))){throw ('Valid rate rejected: '+$rate)}
 $wrong=Status;$wrong.rate=if($rate -eq 'rate32'){'44100'}else{'32000'}
 if(BtPlaybackReady $wrong){throw 'Wrong negotiated rate accepted'}
 WaitBtPlayback
 if($script:MockDelivered -lt 2048){throw 'Readiness without PCM progress'}
 $script:ObserveTest=$true;$ended=$false
 try{Observe 10 1 1}catch{if($_.Exception.Message -eq 'MOCK_OBSERVE_END'){$ended=$true}else{throw}}
 if(!$ended){throw 'Observe did not accept valid first sample'}
}
Write-Host 'PASS: actual readiness, PCM progress and Observe functions accept 32000 and 44100, reject wrong rate; no COM.'
