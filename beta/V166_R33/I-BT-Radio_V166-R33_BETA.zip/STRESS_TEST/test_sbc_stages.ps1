﻿$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'full_menu_stress.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'runner syntax'}
foreach($file in @('run_stress_logged.ps1','sbc_probe.ps1')){[void][Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot $file),[ref]$tokens,[ref]$errors);if($errors.Count){throw $file}}
foreach($name in @('Fields','ValidSbcCpu','SbcStage')){
 $f=$ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)|Where-Object {$_.Name -eq $name}|Select-Object -First 1
 Invoke-Expression $f.Extent.Text
}
$script:cpu='[SBC-CPU] result=PASS frames=2500 valid=2500 wall_us=10000000 task_runtime_us=900000 task_permille=90 core0_permille=200 core1_permille=100 deadline_misses=0 max_late_us=0 scope=DIAG_SHADOW stage=ENCODE route=BT coded_frames=2500 decoded_frames=0 runtime=SCHEDULER_US'
if(!(ValidSbcCpu $script:cpu 'ENCODE' 'BT')){throw 'valid phase rejected'}
foreach($bad in @($script:cpu.Replace('route=BT','route=DAC'),$script:cpu.Replace('coded_frames=2500','coded_frames=0'),$script:cpu.Replace('task_runtime_us=900000','task_runtime_us=20000000'),$script:cpu.Replace('runtime=SCHEDULER_US','runtime=WALL_US'))){if(ValidSbcCpu $bad 'ENCODE' 'BT'){throw 'bad phase accepted'}}
function Ack($cmd){$script:command=$cmd}
function Pump($ms){$script:pumps++}
function MatchAfter($cursor,$regex){if($script:pumps -ge 2){return $script:cpu};return $null}
function Status{$script:beats++;return @{}}
function WaitState($predicate,$seconds){if(!(& $predicate @{sbc_busy='0'})){throw 'busy predicate'};return @{}}
function Record($line){}
function Sample{
 $script:samples++
 return @{'PATH-SOURCE'=@{generation='4'};'PATH-STATE'=@{web='1';playing='1';route=$script:route;transmitting='1';rate='32000';idle='1'};'PATH-TOTAL'=@{decoded_frames=$(if($script:stall){'100'}else{[string](100+$script:samples)})};'BT-AUDIO'=@{underruns=[string]$script:samples}}
}
function ResetMock{$script:Seq=0;$script:pumps=0;$script:beats=0;$script:samples=0;$script:route='1';$script:stall=$false;$script:SbcRows=New-Object 'Collections.Generic.List[object]'}
ResetMock;SbcStage 'BT' 1
if($script:command -ne 'sbc1' -or $script:beats -lt 1 -or $script:SbcRows.Count -ne 1){throw 'stage sequencing/heartbeat'}
ResetMock;$script:stall=$true;$failed=$false;try{SbcStage 'BT' 1}catch{$failed=$_.Exception.Message -eq 'SBC_STAGE_NATIVE_DECODER_STALLED'};if(!$failed){throw 'stall accepted'}
ResetMock;$script:route='0';$failed=$false;try{SbcStage 'BT' 1}catch{$failed=$_.Exception.Message -eq 'SBC_STAGE_BT_RATE_OR_ROUTE_LOST'};if(!$failed){throw 'route lost accepted'}
Write-Host 'PASS: stage counts/runtime, route/rate, native progress, late completion and lease heartbeat; no COM opened'

# Exercise the actual wrapper summarization without invoking serial or child processes.
$wrapper=Get-Content (Join-Path $PSScriptRoot 'run_stress_logged.ps1') -Raw
$start=$wrapper.IndexOf(' if($SbcStages -and (Test-Path')
$end=$wrapper.IndexOf(' if($Baseline){',$start)
$block=$wrapper.Substring($start,$end-$start)
$out='C:\esp32\SYSTEM\TEMP\sbc_summary_fixture'
New-Item -ItemType Directory -Path (Join-Path $out 'CODEC') -Force|Out-Null
$SbcStages=$true
@{result='PARTIAL_REVIEW_REQUIRED';sbc_stages=@(@{route='DAC';stage='BASELINE';result='MEASURED';cpu=@{task_permille='20'}},@{route='DAC';stage='ENCODE';result='MEASURED';cpu=@{task_permille='100'}})}|ConvertTo-Json -Depth 10|Set-Content (Join-Path $out 'RESULT.json')
@{result='PASS_ENCODER_CPU_PROBE';CPU_phases=@{BASELINE='result=PASS task_permille=10';ENCODE='result=PASS task_permille=90';ROUNDTRIP='result=PASS task_permille=180'}}|ConvertTo-Json -Depth 10|Set-Content (Join-Path $out 'CODEC/RESULT.json')
Invoke-Expression $block
$rows=@(Import-Csv (Join-Path $out 'COMPARISON.csv'))
if($rows.Count -ne 9 -or @($rows|Where-Object {$_.route -eq 'BT' -and $_.result -eq 'NOT_RUN'}).Count -ne 3){throw 'missing BT summary'}
if(($rows|Where-Object {$_.route -eq 'DAC' -and $_.stage -eq 'ENCODE'}).task_delta_permille -ne '80'){throw 'CPU comparison delta'}
@{result='FAIL';CPU_phases=@{}}|ConvertTo-Json|Set-Content (Join-Path $out 'CODEC/RESULT.json')
Invoke-Expression $block
if(@(Import-Csv (Join-Path $out 'COMPARISON.csv')|Where-Object {$_.route -eq 'QUIET' -and $_.result -eq 'NOT_RUN'}).Count -ne 3){throw 'quiet failure labeled measured'}
Write-Host 'PASS: actual wrapper nine-stage summary, delta and absent BT/quiet cases; no COM opened'
