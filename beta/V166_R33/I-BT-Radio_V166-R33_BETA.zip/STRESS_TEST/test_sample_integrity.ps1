﻿$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'full_menu_stress.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'syntax'}
foreach($name in @('Fields','MatchAfter','ValidBtSample','SampleOnce','Sample')){
 $f=$ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)|Where-Object {$_.Name -eq $name}|Select-Object -First 1
 Invoke-Expression $f.Extent.Text
}
function ValidState($line){return $true}
function Pump([int]$ms){}
function Record([string]$text){$script:Seq++;$script:Lines.Add(@{seq=$script:Seq;text=$text})}
function ResetMock {
 $script:Seq=0;$script:Calls=0;$script:Phase='MOCK';$script:Lines=New-Object 'Collections.Generic.List[object]';$script:Samples=New-Object 'Collections.Generic.List[object]'
}
function Send($command){
 $script:Calls++
 Record ('[PATH-BEGIN-SAMPLE] seq='+$script:Calls)
 Record '[PATH-STATE] playing=1';Record '[PATH-SOURCE] codec=2'
 if($script:AlwaysBad -or $script:Calls -eq 1){
  Record '[BT-AUDIO] delivered_bytes=70311316 requested_bytes=1306E (971880) BT_L2CAP: l2cab is_cong_cback_context'
 }else{
  Record '[BT-AUDIO] delivered_bytes=70312340 requested_bytes=131124224 codec_ok=1 underruns=342 dropped_bytes=30880 tx_buffer=65536'
 }
 Record ('[PATH-END-SAMPLE] seq='+$script:Calls)
}
ResetMock;$script:AlwaysBad=$false
$row=Sample
if($script:Calls -ne 2 -or $script:Samples.Count -ne 1 -or $row['BT-AUDIO'].codec_ok -ne '1'){throw 'corrupt sample accepted or retry missing'}
ResetMock;$script:AlwaysBad=$true;$failed=$false
try{$null=Sample}catch{if($_.Exception.Message -eq 'MALFORMED_BT_SAMPLE'){$failed=$true}else{throw}}
if(!$failed -or $script:Calls -ne 3 -or $script:Samples.Count -ne 0){throw 'unbounded retry or malformed sample recorded'}
function SampleOnce {throw 'RADIO_RESET_DETECTED'}
$failed=$false;try{$null=Sample}catch{if($_.Exception.Message -eq 'RADIO_RESET_DETECTED'){$failed=$true}else{throw}}
if(!$failed){throw 'real fault swallowed'}
Write-Host 'PASS: actual sampler rejects interleaved telemetry, retries at most three, records only valid samples, preserves radio faults; no COM.'
