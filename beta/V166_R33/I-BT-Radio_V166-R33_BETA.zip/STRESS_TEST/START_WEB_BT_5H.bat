@echo off
cd /d "%~dp0"
echo Internet radio - BT: 5 ora, tenyleges 32 kHz. WebUI nelkul.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_stress_logged.ps1" -Minutes 300 -ReturnRoot "%~dp0..\RETURN_TO_EVA"
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
