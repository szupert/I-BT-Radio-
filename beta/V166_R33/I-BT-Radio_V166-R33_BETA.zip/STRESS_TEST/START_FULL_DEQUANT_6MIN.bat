@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_full_dequant_logged.ps1" -DequantAB -Minutes 6 -ReturnRoot "%~dp0..\RETURN_TO_EVA"
pause
