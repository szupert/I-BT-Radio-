﻿param([string]$PortName='', [string]$MasterDirectory='', [string]$ReturnDirectory='', [switch]$SelfTest)
$ErrorActionPreference='Stop'
function Is-ProbePass([string]$line){return $line -match '\[SBC-PROBE\] result=PASS frames=250 valid=250 hz=32000 frame_bytes=118 '}
function Is-PcmPass([string]$line){return $line -match '^\[SBC-PCM\] decoded=250 silence_peak=\d+ signal_peak=\d+ abs_sum=\d+ samples=14976 channel_error=\d+ period_error=\d+ silence_r=\d+ peak_r=\d+ abs_r=\d+ period_r=\d+ allocation=1 crc_rejected=1 smoke=PASS decode_wall_us=\d+ reference_pcm=NOT_RUN\s*$'}
function Is-CpuPass([string]$line){
 $matched=$line -match '^\[SBC-CPU\] result=PASS frames=2500 valid=2500 hz=32000 audio_us=10000000 wall_us=\d+ task_runtime_us=[1-9]\d* task_permille=\d+ core0_permille=\d+ core1_permille=\d+ deadline_misses=\d+ max_late_us=\d+ encode_wall_us=\d+ stack_min_bytes=\d+ scope=DIAG_SHADOW stage=(BASELINE|ENCODE|ROUNDTRIP) route=QUIET coded_frames=\d+ decoded_frames=\d+ runtime=SCHEDULER_US bt_send=NOT_RUN\s*$'
 if(!$matched){return $false}
 $f=@{};foreach($m in [regex]::Matches($line,'(\w+)=([^\s]+)')){$f[$m.Groups[1].Value]=$m.Groups[2].Value}
 $coded=if($f.stage -eq 'BASELINE'){0}else{2500};$decoded=if($f.stage -eq 'ROUNDTRIP'){2500}else{0}
 return [int]$f.coded_frames -eq $coded -and [int]$f.decoded_frames -eq $decoded -and [long]$f.task_runtime_us -le ([long]$f.wall_us+2000) -and [long]$f.wall_us -gt 0

}
function ProbeComplete([bool]$smoke,[bool]$cpu){return $smoke -and $cpu}
if($SelfTest){
 if(!(Is-ProbePass '[SBC-PROBE] result=PASS frames=250 valid=250 hz=32000 frame_bytes=118 encode_wall_us=1')){throw 'PASS parser'}
 if(Is-ProbePass '[SBC-PROBE] result=FAIL frames=250 valid=249 hz=32000 frame_bytes=118 '){throw 'FAIL accepted'}
 if(Is-ProbePass '[SBC-PROBE] result=PASS frames=250 valid=249 hz=32000 frame_bytes=118 '){throw 'incomplete accepted'}
 $pcm='[SBC-PCM] decoded=250 silence_peak=0 signal_peak=4200 abs_sum=60000000 samples=14976 channel_error=0 period_error=0 silence_r=0 peak_r=4700 abs_r=61000000 period_r=0 allocation=1 crc_rejected=1 smoke=PASS decode_wall_us=1 reference_pcm=NOT_RUN'
 if(!(Is-PcmPass $pcm)){throw 'PCM parser'}
 foreach($bad in @($pcm.Replace('decoded=250','decoded=249'),$pcm.Replace('crc_rejected=1','crc_rejected=0'),$pcm.Replace('smoke=PASS','smoke=FAIL'),$pcm.Replace('allocation=1','allocation=0'),$pcm.Replace(' peak_r=4700',''))){if(Is-PcmPass $bad){throw 'Bad PCM accepted'}}
 $cpu='[SBC-CPU] result=PASS frames=2500 valid=2500 hz=32000 audio_us=10000000 wall_us=10000000 task_runtime_us=900000 task_permille=90 core0_permille=200 core1_permille=100 deadline_misses=0 max_late_us=0 encode_wall_us=900000 stack_min_bytes=2500 scope=DIAG_SHADOW stage=ENCODE route=QUIET coded_frames=2500 decoded_frames=0 runtime=SCHEDULER_US bt_send=NOT_RUN'
 if(!(Is-CpuPass $cpu)){throw 'CPU parser'}
 foreach($bad in @($cpu.Replace('valid=2500','valid=2499'),$cpu.Replace('SCHEDULER_US','WALL_US'),$cpu.Replace('result=PASS','result=FAIL'),$cpu.Replace('task_runtime_us=900000','task_runtime_us=0'))){if(Is-CpuPass $bad){throw 'Invalid CPU accepted'}}
 if((ProbeComplete $true $false) -or (ProbeComplete $false $true) -or !(ProbeComplete $true $true)){throw 'Incomplete probe accepted'}
 Write-Host 'PASS: SBC/PCM/CPU parsers, negative cases, completion gating; no COM opened';exit 0
}
$id='SBC_PROBE_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff')
$master=if($MasterDirectory){$MasterDirectory}else{Join-Path 'C:\esp32\SYSTEM\LOGS\SBC_WORKER_V1' $id}
$ret=if($ReturnDirectory){$ReturnDirectory}else{Join-Path (Split-Path $PSScriptRoot -Parent) ('RETURN_TO_EVA\'+$id)}
New-Item -ItemType Directory -Path $master,$ret -Force | Out-Null
$state='NOT_RUN';$serial=$null;$writer=$null;$pcmPass=$false;$smokePass=$false;$cpuLine=$null;$cpuPhases=@{}
try{
 $writer=New-Object IO.StreamWriter((Join-Path $master 'serial.log'),$false,(New-Object Text.UTF8Encoding($false)))
 $writer.AutoFlush=$true
 if(!$PortName){$ports=@([IO.Ports.SerialPort]::GetPortNames() | Sort-Object);if(!$ports.Count){throw 'Nincs COM-port'}
  for($i=0;$i -lt $ports.Count;$i++){Write-Host ('{0}. {1}' -f ($i+1),$ports[$i])}
  if($ports.Count -eq 1){$PortName=$ports[0]}else{$n=[int](Read-Host 'Radio port sorszama');if($n -lt 1 -or $n -gt $ports.Count){throw 'Hibas port'};$PortName=$ports[$n-1]}}
 Write-Host "Kapcsolodas: $PortName @115200. Nem flashel; kodolo-proba, nem BT hangteszt."
 $serial=New-Object IO.Ports.SerialPort($PortName,115200,'None',8,'One')
 $serial.DtrEnable=$false;$serial.RtsEnable=$false;$serial.ReadTimeout=300;$serial.WriteTimeout=1000;$serial.Open()
 $ready=$false;$deadline=(Get-Date).AddSeconds(60);$next=Get-Date
 while((Get-Date) -lt $deadline -and !$ready){
  if((Get-Date) -ge $next){$serial.WriteLine('r10 caps');$next=(Get-Date).AddSeconds(2)}
  try{$line=$serial.ReadLine()}catch [TimeoutException]{continue}
  $line=$line -replace '\b(?:\d{1,3}\.){3}\d{1,3}\b','[IP]' -replace '(?i)((?:ssid|password|passwd|pwd)\s*[:=]\s*)[^\r\n]*','$1[REDACTED]'
  $writer.WriteLine($line);Copy-Item -LiteralPath (Join-Path $master 'serial.log') -Destination $ret -Force
  if($line -match '\[R10-CAPS\].*firmware=V166-R19(?:\s|$)'){$ready=$true}
 }
 if(!$ready){throw 'A V166-R19 nem jelentkezett 60 masodpercen belul; teszt NOT_RUN'}
 $serial.WriteLine('r10 status');$leaseIdle=$false;$deadline=(Get-Date).AddSeconds(5)
 while((Get-Date) -lt $deadline -and !$leaseIdle){
  try{$line=$serial.ReadLine()}catch [TimeoutException]{continue}
  $line=$line -replace '\b(?:\d{1,3}\.){3}\d{1,3}\b','[IP]' -replace '(?i)((?:ssid|password|passwd|pwd)\s*[:=]\s*)[^\r\n]*','$1[REDACTED]'
  $writer.WriteLine($line)
  if($line -match '\[R10-STATUS\] active=1'){throw 'Masik teszt aktiv; nem allitom le'}
  if($line -match '\[R10-STATUS\] active=0'){$leaseIdle=$true}
 }
 if(!$leaseIdle){throw 'Nem igazolhato az ures teszt-lease; nem allitom le'}
 $serial.WriteLine('S');$serial.WriteLine('r10 bt off')
 $deadline=(Get-Date).AddSeconds(45);$next=(Get-Date).AddSeconds(2);$queued=$false;$finished=$false
 while((Get-Date) -lt $deadline -and !$finished){
  if(!$queued -and (Get-Date) -ge $next){$serial.WriteLine('r10 sbc probe');$next=(Get-Date).AddSeconds(2)}
  try{$line=$serial.ReadLine()}catch [TimeoutException]{continue}
  $line=$line -replace '\b(?:\d{1,3}\.){3}\d{1,3}\b','[IP]' -replace '(?i)((?:ssid|password|passwd|pwd)\s*[:=]\s*)[^\r\n]*','$1[REDACTED]'
  $writer.WriteLine($line);Copy-Item -LiteralPath (Join-Path $master 'serial.log') -Destination $ret -Force
  if($line -match '\[SBC-PROBE\] start=QUEUED'){$queued=$true;$state='RUNNING';Write-Host 'Kodolo-proba elindult.'}
  if($line -match '^\[SBC-PCM\]'){$pcmPass=Is-PcmPass $line}
  if($line -match '\[SBC-PROBE\] result='){$smokePass=(Is-ProbePass $line) -and $pcmPass;Write-Host $line}
  if($line -match '^\[SBC-CPU\] result='){Write-Host $line;if(!(Is-CpuPass $line)){throw 'CPU phase failed'};if($line -match ' stage=(BASELINE|ENCODE|ROUNDTRIP) '){$cpuPhases[$Matches[1]]=$line};$cpuLine=$line;if($cpuPhases.Count -eq 3){$state=if(ProbeComplete $smokePass $true){'PASS_ENCODER_CPU_PROBE'}else{'FAIL'};$finished=$true}}
  if($line -match '\[SBC-PROBE\] start=FAIL'){throw 'Worker allokacios hiba'}
 }
 if(!$finished){throw 'SBC eredmeny timeout'}
}catch{Write-Host $_;$state=if($state -eq 'NOT_RUN'){'NOT_RUN'}else{'FAIL'};$errorText=$_.Exception.Message}
finally{
 if($queued -and !$finished -and $serial -and $serial.IsOpen){try{$serial.WriteLine('r10 sbc stop')}catch{}}
 if($writer){$writer.Dispose()};if($serial){$serial.Dispose()}
 @{result=$state;error=$errorText;physical_audio='NOT_RUN';decoded_pcm=$(if($smokePass){'PASS_SMOKE_ONLY'}else{'NOT_PROVEN'});reference_pcm='NOT_RUN';CPU_time=$(if($state -eq 'PASS_ENCODER_CPU_PROBE'){'SCHEDULER_TASK_RUNTIME_US'}else{'NOT_PROVEN'});CPU_scope='STANDALONE_ENCODER_TASK_INCLUDING_LOOP_CRC_PACING';CPU_log=$cpuLine;CPU_phases=$cpuPhases;firmware='V166-R19'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $master 'RESULT.json') -Encoding UTF8
 Get-ChildItem -LiteralPath $master -File | ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination $ret -Force}
 Get-ChildItem -LiteralPath $ret -File | ForEach-Object {@{file=$_.Name;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $ret 'HASHES.json') -Encoding UTF8
 Compress-Archive -Path (Join-Path $ret '*') -DestinationPath ($ret+'.zip') -Force
 Write-Host "Eredmeny: $state; visszakuldendo: $ret.zip"
}
if($state -ne 'PASS_ENCODER_CPU_PROBE'){exit 1}
