﻿$ErrorActionPreference='Stop'
$p=Join-Path $PSScriptRoot 'full_menu_stress.ps1'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($p,[ref]$tokens,[ref]$errors)
if($errors.Count){throw $errors[0]}
$guard=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'AssertFirmwareCaps'},$true)
Invoke-Expression $guard.Extent.Text
AssertFirmwareCaps '[R10-CAPS] version=1 firmware=V166-R19 limiter=1'
foreach($caps in @('[R10-CAPS] firmware=V166-R13 limiter=1','[R10-CAPS] firmware=V166-R190','[R10-CAPS] version=1')){
 $rejected=$false
 try{AssertFirmwareCaps $caps}catch{if($_.Exception.Message -notlike 'FIRMWARE_MISMATCH:*'){throw};$rejected=$true}
 if(!$rejected){throw 'WRONG_FIRMWARE_ACCEPTED'}
}
$wait=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'WaitBt60Startup'},$true)
if($wait.Extent.Text -notmatch "FIRMWARE_MISMATCH:\*"){throw 'FIRMWARE_MISMATCH_MUST_NOT_RETRY'}
$f=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'AutoStartRadio'},$true)
Invoke-Expression $f.Extent.Text
$script:Commands=New-Object 'System.Collections.Generic.List[string]'
function Send($s){$script:Commands.Add($s)}
function Record($s){}
$s=@{active='0';restoring='0';route='1';idle='0';web='0';playing='0'}
AutoStartRadio $s
$s.route='0';$s.idle='1';AutoStartRadio $s
$s.web='1';AutoStartRadio $s
$s.playing='1';AutoStartRadio $s
$s.active='1';$s.playing='0';AutoStartRadio $s
if(($script:Commands -join ',') -ne 'r10 bt off,mode 0,play'){throw 'AUTO_START_ORDER_FAILED'}
if((Get-Content $p -Raw) -notmatch 'Seconds -ge 60'){throw 'RETRY_TOO_FAST'}
Write-Host 'PASS: automatic BT OFF -> WEB -> Play, no replay while playing, no commands during active lease; no COM opened.'
