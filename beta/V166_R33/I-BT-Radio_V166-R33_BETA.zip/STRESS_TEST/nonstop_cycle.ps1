﻿param([switch]$Menu10,[string]$StopFile="",[string]$DeadlineUtc="",[switch]$ConcurrentWeb,[switch]$DequantAB,[switch]$RowsOnly,[switch]$BatchSweep,[switch]$CpuStages,[switch]$Cpu10,[switch]$Artwork60,[switch]$FullNoWeb,[switch]$Baseline,[switch]$SbcStages,[string]$OutputDirectory='', [string]$ReturnDirectory='', [switch]$RateCompare,[switch]$SelfTest,[switch]$NoBtHour,[switch]$Automatic,[switch]$Bt60,[switch]$FullProfile,[int]$Minutes=0,[int]$Profile=0,[string]$PortName='')
$script:MenuStoppedAt=[DateTime]::MinValue;$script:MenuWindowEnd=[DateTime]::MinValue;$script:MenuWindowStart=[DateTime]::MinValue
$script:DisplayRows=New-Object 'System.Collections.Generic.List[object]'
$script:StageRows=New-Object 'System.Collections.Generic.List[object]'
$script:AudioRows=New-Object 'System.Collections.Generic.List[object]'
$script:ArtRows=New-Object 'System.Collections.Generic.List[object]';$script:ArtExpected='0';
$script:SbcRows=New-Object 'System.Collections.Generic.List[object]';$script:ProbeRate='rate32';$UseBt=$false;$UseWeb=$false;$UseSd=$true
$script:WebAddress='';$script:WebOriginalVolume=0;$script:WebStep=0
$script:WebRestoreError=''
$script:WebDisabled=$false;$script:WebSkippedReason='';$script:SdSkippedReason=''
$script:CurrentTrackName='';$script:SdRejected=New-Object 'System.Collections.Generic.List[object]'
$script:IpCaptureArmed=$false;$script:RadioIpCandidate=''
function WebExercise {
 if(!$script:WebAddress){return}
 $ws=New-Object Net.WebSockets.ClientWebSocket
 $cancel=New-Object Threading.CancellationTokenSource
 $cancel.CancelAfter(3000)
 try{
  try{$ws.ConnectAsync([Uri]('ws://'+$script:WebAddress+'/ws'),$cancel.Token).GetAwaiter().GetResult()}
  catch{throw 'WEB_CONNECT_UNREACHABLE'}
  $script:WebStep++;$target=[Math]::Max(0,$script:WebOriginalVolume-($script:WebStep%3))
  $bytes=[Text.Encoding]::UTF8.GetBytes(('volume='+$target))
  $segment=New-Object 'ArraySegment[byte]' -ArgumentList (,$bytes)
  $ws.SendAsync($segment,[Net.WebSockets.WebSocketMessageType]::Text,$true,$cancel.Token).GetAwaiter().GetResult()
  Pump 300;$state=Status
  if([int]$state.volume -ne $target){throw 'WEB_VOLUME_NOT_APPLIED'}
  Record ('[WEB-TEST] result=PASS volume='+$target)
 }finally{$ws.Abort();$ws.Dispose();$cancel.Dispose()}
}
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2
$script:MirrorWriter=$null; $script:Serial=$null; $script:Writer=$null; $script:Pending=''; $script:Armed=$false
$script:Fatal=''; $script:Phase='START'; $script:Seq=0; $script:Lease=$false
$script:Lines=New-Object 'System.Collections.Generic.List[object]'
$script:Phases=New-Object 'System.Collections.Generic.List[object]'
$script:Samples=New-Object 'System.Collections.Generic.List[object]'
$script:Marks=New-Object 'System.Collections.Generic.List[object]'
$script:LastRx=[DateTime]::UtcNow; $script:Bytes=0
$script:BtNames=@{}
$script:StationMap=@{}; $script:ExpectedStation=0
$script:KnownStreams=@{
 'https://ice5.somafm.com/bootliquor-128-mp3'=128
 'https://stream.radioparadise.com/mp3-192'=192
 'https://ice5.somafm.com/bootliquor-320-mp3'=320
}
function Redact([string]$s){
 $s=[regex]::Replace($s,'(?i)https?://\S+','<URL>')
 $s=[regex]::Replace($s,'\b(?:\d{1,3}\.){3}\d{1,3}\b','<IP>')
 $s=[regex]::Replace($s,'(?i)\b(?:[0-9a-f]{2}:){5}[0-9a-f]{2}\b','<MAC>')
 return [regex]::Replace($s,'(?i)\b(ssid|password|passwd|token|authorization)\b.*','$1=<redacted>')
}
function Fields([string]$s){
 $h=@{};foreach($m in [regex]::Matches($s,'([a-zA-Z0-9_]+)=([^\s]+)')){$h[$m.Groups[1].Value]=$m.Groups[2].Value};return $h
}
function AudioMetricRow([string]$s,[string]$phase){
 if($s -notmatch '^\[LOAD-AUDIO\] id=(\d+) core=([01]) priority=(\d+) cpu_permille=(\d+) stack_min_bytes=(\d+)$'){return $null}
 if([long]$Matches[1] -le 0 -or [long]$Matches[4] -gt 1000){return $null}
 return [pscustomobject]@{utc=[DateTime]::UtcNow.ToString('o');phase=$phase;task_id=[int]$Matches[1];core=[int]$Matches[2];priority=[int]$Matches[3];cpu_permille=[int]$Matches[4];stack_min_bytes=[int]$Matches[5]}
}
function StageMetricRow([string]$s,[string]$phase){
 if($s -notmatch '^\[CPU-STAGES\] '){return $null}
 $f=Fields $s
 foreach($k in @('net_poll','net_read','decode','handoff','audio_other','other_tasks')){if(!$f.ContainsKey($k) -or $f[$k] -notmatch '^\d+$' -or [decimal]$f[$k] -gt 4294967295){return $null}}
 if($f.enabled -ne '1' -or $f.registered -ne '1' -or $f.core -ne '1' -or $f.tick_hz -ne '1000' -or $f.method -ne 'TICK_SAMPLE_ESTIMATE'){return $null}
 $f.phase=$phase;return [pscustomobject]$f
}
function StageSummary($rows){
 $rows=@($rows);if($rows.Count -lt 2){throw 'CPU_STAGE_TOO_FEW_SAMPLES'}
 $first=$rows[0];$last=$rows[-1];$sum=0;$d=@{}
 foreach($k in @('net_poll','net_read','decode','handoff','audio_other','other_tasks')){
  $value=[long]$last.$k-[long]$first.$k;if($value -lt 0){$value+=4294967296};$d[$k]=$value;$sum+=$value
 }
 if($sum -lt 2000){throw 'CPU_STAGE_COUNTERS_NOT_ADVANCING'}
 $r=[ordered]@{phase=$last.phase;method='TICK_SAMPLE_ESTIMATE';ticks=$sum}
 foreach($k in $d.Keys){$r[$k+'_estimated_percent']=[Math]::Round(100*$d[$k]/$sum,3)}
 return [pscustomobject]$r
}
function Record([string]$s){
 if($s -match '^\[DISPLAY-FRAME\] wall_ms=(\d+) max_wall_ms=(\d+) max_row_gap_ms=(\d+) batch_rows=(4|8|16|32|64|128|240)$'){$script:DisplayRows.Add([pscustomobject]@{phase=$script:Phase;wall_ms=[long]$Matches[1];cumulative_max_wall_ms=[long]$Matches[2];cumulative_max_row_gap_ms=[long]$Matches[3];batch_rows=[int]$Matches[4]})}
 $stageRow=StageMetricRow $s $script:Phase;if($null -ne $stageRow){$script:StageRows.Add($stageRow)}
 $audioRow=AudioMetricRow $s $script:Phase;if($null -ne $audioRow){$script:AudioRows.Add($audioRow)}
 if($s -match '^\[PATH-DEVICE\] kind=saved index=(\d+) name=(.*)$'){$script:BtNames[[int]$Matches[1]]=$Matches[2]}

 if($s -match '##CLI.NAMESET#:\s*\d+\s+(.+)$'){$script:CurrentTrackName=$Matches[1]}
 if($script:IpCaptureArmed -and $s -match '^\[R10-TELEM\] tag=status\s'){
  $fields=Fields $s
  if($fields.ContainsKey('ip')){$script:RadioIpCandidate=$fields.ip}
 }
 if($s -match '#CLI.LISTNUM#:\s*(\d+):.*?(https?://[^\s,]+)'){
  $idx=[int]$Matches[1];$url=$Matches[2]
  if($script:KnownStreams.ContainsKey($url)){$script:StationMap[[string]$script:KnownStreams[$url]]=$idx}
 }
 $s=Redact $s; $script:Seq++;$script:LastRx=[DateTime]::UtcNow
 $r=[pscustomobject]@{seq=$script:Seq;utc=[DateTime]::UtcNow.ToString('o');phase=$script:Phase;text=$s}
 $script:Lines.Add($r);if($script:Lines.Count -gt 20000){$script:Lines.RemoveRange(0,10000)}
 if($null -ne $script:Writer){$line=('{0} [{1}] {2}' -f $r.utc,$r.phase,$s);$script:Writer.WriteLine($line);$script:Writer.Flush();$script:Bytes+=$line.Length*2; if($null -ne $script:MirrorWriter){$script:MirrorWriter.WriteLine($line);$script:MirrorWriter.Flush()}}
 if($script:Armed -and $s -match 'Guru Meditation|CORRUPT HEAP|assert failed|abort\(\)|rst:0x|Stack canary|mem_errors=[1-9]'){$script:Fatal=$s}
 if($s -match '^\[(UI-TOUR|UI-STRESS|PATH-BEGIN|PATH-RESTORE|LOAD)\]' -or $script:Fatal){Write-Host $s}
}
function Send([string]$s){$script:Serial.Write($s+"`n")}
function CheckRunControl {
 if($StopFile -and (Test-Path -LiteralPath $StopFile)){throw 'SUPERVISOR_STOP'}
 if($DeadlineUtc -and [DateTime]::UtcNow -ge [DateTime]::Parse($DeadlineUtc).ToUniversalTime()){throw 'SUPERVISOR_DEADLINE'}
}
function Pump([int]$ms=100,[switch]$IgnoreFault){
 if(!$IgnoreFault){CheckRunControl;if($Menu10 -and $script:MenuWindowEnd -ne [DateTime]::MinValue -and [DateTime]::UtcNow -ge $script:MenuWindowEnd){throw 'MENU10_WINDOW_END'}}
 $end=[DateTime]::UtcNow.AddMilliseconds($ms)
 do{
  $data=$script:Serial.ReadExisting()
  if($data){$script:Pending+=$data
   while(($i=$script:Pending.IndexOf("`n")) -ge 0){Record ($script:Pending.Substring(0,$i).TrimEnd("`r"));$script:Pending=$script:Pending.Substring($i+1)}
   if($script:Pending.Length -gt 32768){Record ('[RUNNER] oversized_line '+$script:Pending.Substring(0,256));$script:Pending=''}
  }
  if(!$IgnoreFault){
   if($script:Fatal){throw 'RADIO_FAULT'}
   if($script:Bytes -gt 64MB){throw 'LOG_SIZE_LIMIT'}
   if(![Console]::IsInputRedirected -and [Console]::KeyAvailable){
    $key=[Console]::ReadKey($true).Key
    if($key -eq 'Q'){throw 'USER_STOP'}
    if($key -eq 'G'){$script:Marks.Add([pscustomobject]@{utc=[DateTime]::UtcNow.ToString('o');phase=$script:Phase;event='HEARD_GAP'});Record '[USER] heard_gap=1'}
   }
  }
  Start-Sleep -Milliseconds 30
 }while([DateTime]::UtcNow -lt $end)
}
function MatchAfter([int]$after,[string]$pattern){
 foreach($r in $script:Lines){if($r.seq -gt $after -and $r.text -match $pattern){return $r.text}};return $null
}
function Request([string]$cmd,[string]$pattern,[int]$seconds=8){
 $after=$script:Seq;Send $cmd;$end=[DateTime]::UtcNow.AddSeconds($seconds)
 do{Pump 100;$s=MatchAfter $after $pattern;if($null -ne $s){return $s}}while([DateTime]::UtcNow -lt $end)
 throw ('NO_RESPONSE: '+$cmd)
}
function RestoreWebVolume {
 if(!$script:WebAddress -or $script:WebStep -eq 0){return}
 try{$script:WebStep=2;WebExercise}
 catch{$script:WebRestoreError=Redact $_.Exception.Message;Record ('[WEB-RESTORE] result=FAIL error='+$script:WebRestoreError)}
}
function TryWebExercise {
 if($FullNoWeb){return}
 if($script:WebDisabled){return}
 try{WebExercise}
 catch{
  if((!$FullProfile -and !$ConcurrentWeb) -or $_.Exception.Message -ne 'WEB_CONNECT_UNREACHABLE'){throw}
  $script:WebDisabled=$true;$script:WebSkippedReason='WEB_CONNECT_UNREACHABLE'
  Record '[WEB-TEST] result=NOT_RUN reason=WEB_CONNECT_UNREACHABLE'
  $script:Phases.Add([pscustomobject]@{name='WEBUI_CONTROL';result='NOT_RUN_UNREACHABLE';error='WEB_CONNECT_UNREACHABLE'})
 }
}
function ValidRadioIp([string]$address){
 $parsed=$null
 if(![Net.IPAddress]::TryParse($address,[ref]$parsed) -or $parsed.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork){return $false}
 if($address -eq '0.0.0.0' -or $address -eq '192.168.4.1' -or $address -match '^(127|169\.254)\.') {return $false}
 return $true
}
function DiscoverRadioIp {
 $deadline=[DateTime]::UtcNow.AddSeconds(45)
 do{
 $script:RadioIpCandidate='';$script:IpCaptureArmed=$true
  try{[void](Request 'r10 status' '^\[R10-TELEM\] tag=status\s' 8)}
  catch{if($_.Exception.Message -notlike 'NO_RESPONSE:*'){throw}}
  finally{$script:IpCaptureArmed=$false}
  if(ValidRadioIp $script:RadioIpCandidate){return $script:RadioIpCandidate}
  Pump 2000
 }while([DateTime]::UtcNow -lt $deadline)
 throw 'RADIO_WIFI_IP_NOT_READY'
}
function ValidState([string]$line){
 if($line -notmatch '^\[PATH-STATE\](?: [a-z_]+=\d+)+\s*$'){return $false}
 $f=Fields $line
 foreach($key in @('active','restoring','web','playing','station','route','idle','rate','connected','transmitting','source_rate','player')){if(!$f.ContainsKey($key)){return $false}}
 return $true
}
function Status(){
 $lastFailure='MALFORMED_STATE_REPEATED'
 for($attempt=0;$attempt -lt 3;$attempt++){
  try{$line=Request 'r10 path status' '^\[PATH-STATE\]'}
  catch{
   if($_.Exception.Message -ne 'NO_RESPONSE: r10 path status'){throw}
   $lastFailure=$_.Exception.Message
   if($attempt -eq 2){throw $lastFailure}
   Record ('[RUNNER] status_wait=1 retry='+($attempt+1));Pump 1000
   continue
  }
  if(ValidState $line){return (Fields $line)}
  $lastFailure='MALFORMED_STATE_REPEATED'
  Record '[RUNNER] malformed_state=1 retry=1';Pump 250
 }
 throw $lastFailure
}
function Ack([string]$command){
 $line=Request ('r10 path '+$command) ('^\[PATH-ACK\] command='+[regex]::Escape($command)+' result=')
 if($line -notmatch 'result=PASS'){throw ('COMMAND_DENIED: '+$command)}
}
function WaitState([scriptblock]$predicate,[int]$seconds=60){
 $end=[DateTime]::UtcNow.AddSeconds($seconds)
 do{$s=Status;if(& $predicate $s){return $s};Pump 1000}while([DateTime]::UtcNow -lt $end)
 throw 'STATE_TIMEOUT'
}
function WebDacReady($s){
 return ($s.web -eq '1' -and $s.playing -eq '1' -and $s.route -eq '0' -and $s.idle -eq '1')
}
function SourceDacReady($s,[int]$web){
 return ($s.active -eq '1' -and $s.web -eq [string]$web -and $s.playing -eq '1' -and $s.route -eq '0' -and $s.idle -eq '1' -and [int]$s.input_buffer -gt 0)
}
function SourceProgress($before,$first,$second,[int]$web){
 foreach($row in @($before,$first,$second)){
  if(!$row.ContainsKey('PATH-STATE') -or !$row.ContainsKey('PATH-SOURCE') -or !$row.ContainsKey('PATH-TOTAL')){return $false}
  foreach($field in @('active','web','playing','route','idle','input_buffer')){if(!$row['PATH-STATE'].ContainsKey($field) -or $row['PATH-STATE'][$field] -notmatch '^\d+$'){return $false}}
  if(!$row['PATH-SOURCE'].ContainsKey('generation') -or $row['PATH-SOURCE']['generation'] -notmatch '^\d+$'){return $false}
  if(!$row['PATH-TOTAL'].ContainsKey('decoded_frames') -or $row['PATH-TOTAL']['decoded_frames'] -notmatch '^\d+$'){return $false}
 }
 if(!(SourceDacReady $first['PATH-STATE'] $web) -or !(SourceDacReady $second['PATH-STATE'] $web)){return $false}
 $oldGen=[long]$before['PATH-SOURCE'].generation;$newGen=[long]$first['PATH-SOURCE'].generation
 if($newGen -eq $oldGen -or [long]$second['PATH-SOURCE'].generation -ne $newGen){return $false}
 return ([long]$second['PATH-TOTAL'].decoded_frames -gt [long]$first['PATH-TOTAL'].decoded_frames)
}
function SwitchAndVerifyOnce([string]$source,[int]$resumeStation=0,[int]$sdTrack=0){
 $web=[int]($source -eq 'web');$before=Sample;$after=$script:Seq
 if($sdTrack -gt 0){Ack ('sdtrack='+$sdTrack)}else{Ack ('source'+$source)}
 if($source -eq 'web' -and $resumeStation -gt 0){Send ('play '+$resumeStation)}
 $deadline=[DateTime]::UtcNow.AddSeconds(60)
 do{
  $state=Status
  if($source -eq 'sd' -and (MatchAfter $after 'readAudioHeader\(\): Processing stopped due to invalid audio header')){throw 'SD_AUDIO_HEADER_INVALID'}
  if(SourceDacReady $state $web){break}
  Pump 1000
 }while([DateTime]::UtcNow -lt $deadline)
 if(!(SourceDacReady $state $web)){throw 'STATE_TIMEOUT'}
  $first=Sample
  # Playback can remain behind the 75% prebuffer gate after PATH-STATE first
  # reports playing=1. Wait for decoded-frame progress, not a fixed 5 seconds.
  $progressDeadline=[DateTime]::UtcNow.AddSeconds(90)
  do{
   Pump 2000
   $second=Sample
   if($source -eq 'sd' -and (MatchAfter $after 'readAudioHeader\(\): Processing stopped due to invalid audio header')){throw 'SD_AUDIO_HEADER_INVALID'}
   if(SourceProgress $before $first $second $web){break}
  }while([DateTime]::UtcNow -lt $progressDeadline)
  if(!(SourceProgress $before $first $second $web)){throw ('SOURCE_PROGRESS_TIMEOUT: '+$source)}
 Record ('[SOURCE-CYCLE] source='+$source+' generation='+$second['PATH-SOURCE'].generation+' decoded_delta='+([long]$second['PATH-TOTAL'].decoded_frames-[long]$first['PATH-TOTAL'].decoded_frames))
}
function SwitchAndVerify([string]$source,[int]$resumeStation=0){
 try{SwitchAndVerifyOnce $source $resumeStation;return}
 catch{if($source -ne 'sd' -or $_.Exception.Message -ne 'SD_AUDIO_HEADER_INVALID'){throw}}
 $state=Status
 $catalog=Fields (Request 'r10 sd status' '^\[SD-SELFTEST\]')
 if($catalog.mounted -ne '1' -or $catalog.catalog -ne '1'){throw 'SD_CATALOG_NOT_READY'}
 $count=0
 if(![int]::TryParse($catalog.tracks,[ref]$count) -or $count -lt 1 -or $count -gt 65535){throw 'SD_INVALID_TRACK_COUNT'}
 $first=[int]$state.station
 if($first -lt 1 -or $first -gt $count){throw 'SD_INVALID_TRACK_INDEX'}
 for($offset=0;$offset -lt $count;$offset++){
  $track=(($first-1+$offset)%$count)+1
  if($offset -gt 0){
   try{SwitchAndVerifyOnce 'sd' 0 $track;Record ('[SD-CANDIDATE] result=PLAYING index='+$track+' name='+$script:CurrentTrackName);return}
   catch{if($_.Exception.Message -ne 'SD_AUDIO_HEADER_INVALID'){throw}}
  }
  $rejected=[pscustomobject]@{index=$track;name=$script:CurrentTrackName;reason='SD_AUDIO_HEADER_INVALID'}
  $script:SdRejected.Add($rejected)
  Record ('[SD-CANDIDATE] result=REJECTED index='+$track+' name='+$script:CurrentTrackName+' reason=SD_AUDIO_HEADER_INVALID')
 }
 throw 'SD_NO_PLAYABLE_FILES'
}
function NetworkStartupReady($n){
 return ($null -ne $n -and $n.connected -eq '1' -and $n.ip_valid -eq '1' -and $n.dns_valid -eq '1' -and $n.sta -eq '1')
}
function StartupNetwork(){
 $now=[DateTime]::UtcNow
 if($null -eq $script:StartupNetAt -or ($now-$script:StartupNetAt).TotalSeconds -ge 30){
  $script:StartupNetAt=$now;$script:StartupNet=$null
  try{$line=Request 'wifi.status' '^\[WIFI-NET\]' 5;$script:StartupNet=Fields $line}
  catch{if($_.Exception.Message -notlike 'NO_RESPONSE:*'){throw};Record '[NETWORK-START] status=UNKNOWN; playback command withheld'}
  if(!(NetworkStartupReady $script:StartupNet)){Record '[NETWORK-START] WAIT_WIFI_OR_DNS; no repeated play commands'}
 }
 return (NetworkStartupReady $script:StartupNet)
}
function AutoStartRadio($s){
 if($s.active -eq '1' -or $s.restoring -eq '1'){Record '[AUTO-START] busy=1';return}
 if($s.route -ne '0' -or $s.idle -ne '1'){Send 'r10 bt off';Record '[AUTO-START] action=BT_OFF';return}
 if($s.web -ne '1'){Send 'mode 0';Record '[AUTO-START] action=SOURCE_WEB';return}
 if($s.playing -ne '1'){if($script:StartupPlaySent -or !(StartupNetwork)){return};Send 'play';$script:StartupPlaySent=$true;Record '[AUTO-START] action=PLAY; subsequent reconnects owned by firmware'}
}
function WaitWebDacReady($first,[int]$seconds=90){
 if(WebDacReady $first){return $first}
 $end=[DateTime]::UtcNow.AddSeconds($seconds)
 do{
  Pump 2000
  $s=Status
  if(WebDacReady $s){Record '[RUNNER] web_dac_ready=1';return $s}
 }while([DateTime]::UtcNow -lt $end)
 throw 'RADIO_WEB_DAC_NOT_READY'
}
function StartupPause(){
 CheckRunControl
 for($i=0;$i -lt 20;$i++){
  if(![Console]::IsInputRedirected -and [Console]::KeyAvailable){if([Console]::ReadKey($true).Key -eq 'Q'){throw 'USER_STOP'}}
  Start-Sleep -Milliseconds 100
 }
}
function AssertFirmwareCaps([string]$caps){
 $actual='UNKNOWN'
 if($caps -match '(?:^|\s)firmware=([^\s]+)'){$actual=$Matches[1]}
 if($actual -ne 'V166-R33'){throw ('FIRMWARE_MISMATCH: expected=V166-R33 actual='+$actual+'; Inditsd elobb az 1_FELTOLTES.bat feltoltot.')}
}
function WaitBt60Startup(){
 $lastNotice=[DateTime]::MinValue; $lastAction=[DateTime]::MinValue; $portCursor=0;$identified=$false
 while($true){
  $ports=@([IO.Ports.SerialPort]::GetPortNames() | Sort-Object)
  if(!$ports.Count){
   if(([DateTime]::UtcNow-$lastNotice).TotalSeconds -ge 15){Write-Host '[VARAKOZAS] A radio COM-portjara varok. Q = leallitas.';$lastNotice=[DateTime]::UtcNow}
   StartupPause;continue
  }
  $target=$PortName
  if(!$target){
   if($ports.Count -eq 1){$target=$ports[0]}
   else{
    $target=$ports[$portCursor % $ports.Count];$portCursor++
   }
  }
  if($target -notin $ports){StartupPause;continue}
  try{
   if($null -eq $script:Serial){
    $script:Serial=New-Object IO.Ports.SerialPort($target,115200)
    $script:Serial.DtrEnable=$false;$script:Serial.RtsEnable=$false;$script:Serial.ReadTimeout=100;$script:Serial.WriteTimeout=2000;$script:Serial.Encoding=[Text.Encoding]::UTF8
    $script:Serial.Open();Write-Host ('[COM] '+$target+' @ 115200, reset/flash nelkul');Pump 500
   }
   if(!$identified){
    $caps=Request 'r10 caps' '^\[R10-CAPS\]' 4;Record ('[RUNNER] identified '+$caps)
    if($SbcStages -or $FullProfile -or $Bt60){AssertFirmwareCaps $caps}
    $identified=$true
   }
   $state=Status
   if(([DateTime]::UtcNow-$lastAction).TotalSeconds -ge 60){AutoStartRadio $state;$lastAction=[DateTime]::UtcNow}
   if($state.active -eq '0' -and $state.restoring -eq '0' -and (WebDacReady $state) -and [int]$state.input_buffer -gt 0){Record '[RUNNER] web_dac_ready=1';return $state}
   if(([DateTime]::UtcNow-$lastNotice).TotalSeconds -ge 15){Write-Host '[VARAKOZAS] Radio elerheto; automatikus forrasinditas es elotoltes folyamatban. Q = leallitas.';$lastNotice=[DateTime]::UtcNow}
   Pump 10000
  }catch{
   if($_.Exception.Message -in @('USER_STOP','SUPERVISOR_STOP','SUPERVISOR_DEADLINE','RADIO_FAULT') -or $_.Exception.Message -like 'FIRMWARE_MISMATCH:*'){throw}
   Record ('[RUNNER] startup_retry='+ (Redact $_.Exception.Message))
   $script:StartupNetAt=$null;$script:StartupNet=$null;$script:StartupPlaySent=$false
   if($null -ne $script:Serial -and (!$script:Serial.IsOpen -or $target -notin @([IO.Ports.SerialPort]::GetPortNames()))){try{$script:Serial.Dispose()}catch{};$script:Serial=$null;$identified=$false}
   # A protocol timeout retains the open port; cancellation and radio faults propagate.
   if(([DateTime]::UtcNow-$lastNotice).TotalSeconds -ge 15){Write-Host '[VARAKOZAS] A radio meg indul vagy a COM-port foglalt. Ujraprobalom; Q = leallitas.';$lastNotice=[DateTime]::UtcNow}
   StartupPause
  }
 }
}
function ValidBtSample($fields){
 foreach($key in @('codec_ok','delivered_bytes','requested_bytes','underruns','dropped_bytes','tx_buffer')){
  if(!$fields.ContainsKey($key) -or [string]$fields[$key] -notmatch '^\d+$'){return $false}
 }
 return ([string]$fields['codec_ok'] -in @('0','1'))
}
function SampleOnce(){
 $after=$script:Seq;Send 'r10 path sample';$end=[DateTime]::UtcNow.AddSeconds(8)
 do{Pump 100;$endLine=MatchAfter $after '^\[PATH-END-SAMPLE\]';if($endLine){break}}while([DateTime]::UtcNow -lt $end)
 $startLine=MatchAfter $after '^\[PATH-BEGIN-SAMPLE\]'
 if(!$startLine -or !$endLine -or (Fields $startLine).seq -ne (Fields $endLine).seq){throw 'INCOMPLETE_SAMPLE'}
 $sample=@{utc=[DateTime]::UtcNow.ToString('o');phase=$script:Phase}
 foreach($tag in @('PATH-STATE','PATH-SOURCE','PATH-TOTAL','PATH-DEFER','AUDIO-DEFER','LOAD','LOAD-MEM','BT-AUDIO','ART-AB','MP3-OFFLOAD','R10-TELEM')){
  $line=MatchAfter $after ('^\['+$tag+'\]');if($line){$sample[$tag]=Fields $line}
  if($tag -eq 'PATH-STATE' -and !(ValidState $line)){throw 'MALFORMED_SAMPLE_STATE'}
 }
 if(!$sample.ContainsKey('PATH-STATE') -or !$sample.ContainsKey('BT-AUDIO') -or !$sample.ContainsKey('PATH-SOURCE')){throw 'MISSING_SAMPLE_FIELDS'}
 if(!(ValidBtSample $sample['BT-AUDIO'])){throw 'MALFORMED_BT_SAMPLE'}
 $script:Samples.Add($sample);return $sample
}
function Sample(){
 for($attempt=1;$attempt -le 3;$attempt++){
  try{return (SampleOnce)}catch{
   if($_.Exception.Message -notin @('INCOMPLETE_SAMPLE','MISSING_SAMPLE_FIELDS','MALFORMED_SAMPLE_STATE','MALFORMED_BT_SAMPLE') -or $attempt -eq 3){throw}
   Record ('[SAMPLE-RETRY] attempt='+$attempt+' reason='+$_.Exception.Message)
   Pump 200
  }
 }
}
function ExpectedBtRate([int]$web=1) { if($web -eq 1 -or $script:ProbeRate -eq 'rate32'){return '32000'}; return '44100' }
function BtPlaybackReady($s){
 return ($s.active -eq '1' -and $s.web -eq '1' -and $s.route -eq '1' -and $s.transmitting -eq '1' -and $s.rate -eq (ExpectedBtRate) -and $s.playing -eq '1' -and [int]$s.input_buffer -gt 0)
}
function DeliveredBytes($row){
 if(!$row.ContainsKey('BT-AUDIO') -or !$row['BT-AUDIO'].ContainsKey('delivered_bytes')){throw 'BT_DELIVERED_COUNTER_MISSING'}
 $n=[long]0
 if(![long]::TryParse($row['BT-AUDIO'].delivered_bytes,[ref]$n)){throw 'BT_DELIVERED_COUNTER_INVALID'}
 return $n
}
function BtWaitNow {return [DateTime]::UtcNow}
function WaitBtPlayback(){
 $deadline=(BtWaitNow).AddSeconds(90);$consecutive=0;$previous=$null;$connectedSeen=$false
 do{
  $s=Status
  if($s.connected -eq '1' -and !$connectedSeen){
   $connectedSeen=$true
   # Connection discovery and firmware prebuffer have separate bounded budgets.
   # Extend once only; firmware retries/byte progress must not restart this timer.
   $deadline=(BtWaitNow).AddSeconds(180)
   Record '[RUNNER] bt_connected=1 prebuffer_wait_seconds=180 timer_reset_limit=1'
  }
  if(BtPlaybackReady $s){$consecutive++}else{$consecutive=0}
  if($consecutive -ge 2){
   $row=Sample
   if(BtPlaybackReady $row['PATH-STATE']){
    $delivered=DeliveredBytes $row
    if($null -ne $previous -and $delivered -gt $previous){Record ('[RUNNER] bt_stream_ready=1 delivered_delta='+($delivered-$previous));return}
    $previous=$delivered
   }
  }
  Pump 1000
 }while((BtWaitNow) -lt $deadline)
 if($connectedSeen){throw 'BT_CONNECTED_NO_PCM_PROGRESS'}
 throw 'BT_STREAM_START_TIMEOUT_90S'
}
function ConnectAvailableSaved($indices){
 $connectedNoPcm=$false
 foreach($index in $indices){
  $s=Status
  if($s.route -ne '0' -or $s.idle -ne '1'){
   Ack 'dac'
   [void](WaitState {param($state) $state.route -eq '0' -and $state.idle -eq '1'} 45)
  }
  $peerName=if($script:BtNames.ContainsKey([int]$index)){$script:BtNames[[int]$index]}else{'mentett eszkoz '+$index}
  Write-Host ('Budapest Rock'+[Environment]::NewLine+'Csatlakozas: '+$peerName+'...')
  Record ('[BT-CONNECTING] index='+$index+' name='+$peerName+'...')
  Record ('[RUNNER] bt_saved_probe_index='+$index)
  Ack $script:ProbeRate
  Ack "saved=$index"
  try{
   WaitBtPlayback
   Record ('[RUNNER] bt_saved_selected_index='+$index)
   return [int]$index
  }catch{
   if($_.Exception.Message -eq 'BT_CONNECTED_NO_PCM_PROGRESS'){$connectedNoPcm=$true;Record ('[RUNNER] bt_saved_connected_no_pcm_index='+$index)}
   elseif($_.Exception.Message -eq 'BT_STREAM_START_TIMEOUT_90S'){Record ('[RUNNER] bt_saved_unavailable_index='+$index)}
   else{throw}
  }
 }
 if($connectedNoPcm){throw 'BT_CONNECTED_NO_PCM_PROGRESS'}
 throw 'BT_SAVED_DEVICES_UNAVAILABLE'
}
function MinimumSamples([int]$seconds){
 if($seconds -lt 1){throw 'INVALID_OBSERVE_DURATION'}
 return [Math]::Min(3,[Math]::Max(2,[int][Math]::Ceiling($seconds/10.5)))
}
function AssertActualBtRate($row,[int]$expected){
 if(!$row.ContainsKey('BT-AUDIO') -or !$row['BT-AUDIO'].ContainsKey('rate')){throw 'BT_NEGOTIATED_RATE_MISSING'}
 $actual=0
 if(![int]::TryParse([string]$row['BT-AUDIO'].rate,[ref]$actual) -or $actual -ne $expected){throw 'BT_NEGOTIATED_RATE_MISMATCH'}
 if($row['BT-AUDIO'].codec_ok -ne '1'){throw 'BT_CODEC_NOT_CONFIGURED'}
}
function Observe([int]$seconds,[int]$web,[int]$bt,[bool]$requireActualRate=$false,[DateTime]$Until=[DateTime]::MinValue,[ValidateRange(100,10500)][int]$PollMs=10500){
 $end=if($Until -eq [DateTime]::MinValue){[DateTime]::UtcNow.AddSeconds($seconds)}else{$Until};$count=0;$lastDelivered=$null;$stalled=0
 while([DateTime]::UtcNow -lt $end){
  $row=Sample;$s=$row['PATH-STATE'];$count++;if($Artwork60){AssertArtwork $row $script:ArtExpected}
  if($NoBtHour -and $web -eq 1 -and ($bt -eq 0 -or $ConcurrentWeb)){TryWebExercise}
  if($s.active -ne '1' -or $s.playing -ne '1' -or [int]$s.web -ne $web -or [int]$s.route -ne $bt){throw 'PLAYBACK_OR_ROUTE_LOST'}
  if($NoBtHour -and $bt -eq 0 -and ($s.idle -ne '1' -or $s.connected -ne '0' -or $s.transmitting -ne '0')){throw 'UNEXPECTED_BT_ACTIVITY'}
  if($script:ExpectedStation -gt 0){
   if([int]$s.station -ne $script:ExpectedStation -or $s.source_rate -notin @('44100','48000') -or !$row.ContainsKey('PATH-SOURCE') -or $row['PATH-SOURCE'].codec -ne '2'){throw 'BITRATE_STATION_CODEC_RATE_MISMATCH'}
  }
  if($bt -eq 1){
   if($web -eq 1 -or $requireActualRate){AssertActualBtRate $row ([int](ExpectedBtRate $web))}
   if($s.transmitting -ne '1' -or $s.rate -ne (ExpectedBtRate $web) -or $row['BT-AUDIO'].codec_ok -ne '1'){throw 'BT_LINK_OR_RATE_LOST'}
   $delivered=DeliveredBytes $row
   if($null -ne $lastDelivered){
    if($delivered -lt $lastDelivered){throw 'BT_DELIVERED_COUNTER_RESET'}
    if($delivered -eq $lastDelivered){$stalled++}else{$stalled=0}
    if($stalled -ge 3){throw 'BT_NO_PCM_PROGRESS'}
   }
   $lastDelivered=$delivered
  }
  Write-Host ('[MERES] '+$script:Phase+' meg '+[Math]::Max(0,[int]($end-[DateTime]::UtcNow).TotalSeconds)+' mp')
  $remaining=[int][Math]::Max(0,($end-[DateTime]::UtcNow).TotalMilliseconds)
  if($remaining -gt 0){Pump ([Math]::Min($PollMs,$remaining))}
 }
 if($count -lt (MinimumSamples $seconds)){throw 'INSUFFICIENT_SAMPLES'}
}
function DequantPlan {
 @([pscustomobject]@{name='DQ_01_OFF';enabled='0';end_seconds=120},[pscustomobject]@{name='DQ_02_ON';enabled='1';end_seconds=240},[pscustomobject]@{name='DQ_03_OFF';enabled='0';end_seconds=360})
}
function PrepareDequant([int]$station){
 Ack 'artoff';Ack 'cpuoff';Ack 'dqoff'
 Send 'stop'
 [void](WaitState {param($v) $v.playing -eq '0' -and $v.route -eq '0' -and $v.idle -eq '1'} 30)
 Ack 'dqprepare';Ack 'dqoff';Ack 'dq8'
 Send ('play '+$station)
 [void](WaitWebDacReady (Status) 120)
 Record '[DQ-PREPARE] worker_allocated_before_BT=1 artwork=OFF same_worker_all_phases=1'
}
function AssertDequant($row,[string]$enabled){
 if(!$row.ContainsKey('MP3-OFFLOAD') -or !$row.ContainsKey('PATH-SOURCE')){throw 'DQ_DIAGNOSTICS_MISSING'}
 $d=$row['MP3-OFFLOAD']
 if($d.ready -ne '1' -or $d.enabled -ne $enabled -or $d.core -ne '0' -or $d.fraction -ne '8' -or $d.jobs -notmatch '^\d+$'){throw 'DQ_STATE_INVALID'}
 if($row['PATH-SOURCE'].codec -ne '2'){throw 'DQ_REQUIRES_MP3'}
 if(!$row.ContainsKey('ART-AB') -or $row['ART-AB'].enabled -ne '0'){throw 'DQ_ARTWORK_NOT_OFF'}
 AssertActualBtRate $row 32000
}
function DequantRun {
 $dqMeasureStartUtc=[DateTime]::UtcNow
 foreach($part in @(DequantPlan)){
  Phase $part.name {
   Ack $(if($part.enabled -eq '1'){'dqon'}else{'dqoff'})
   $before=Sample;AssertDequant $before $part.enabled
   Observe 120 1 1 $true ($dqMeasureStartUtc.AddSeconds($part.end_seconds))
   $after=Sample;AssertDequant $after $part.enabled
   if($before['PATH-SOURCE'].generation -ne $after['PATH-SOURCE'].generation){throw 'DQ_SOURCE_CHANGED'}
   $work=[long]$after['MP3-OFFLOAD'].jobs-[long]$before['MP3-OFFLOAD'].jobs
   if(($part.enabled -eq '1' -and $work -lt 2) -or ($part.enabled -eq '0' -and $work -ne 0)){throw 'DQ_PROGRESS_INVALID'}
   Record ('[DQ-PHASE] phase='+$part.name+' enabled='+$part.enabled+' worker_jobs='+$work+' target_core1=BELOW_90_PERCENT measured_gain=REVIEW_REQUIRED')
  }
 }
 Ack 'dqoff'
}

function ArtworkPlan {
 for($i=0;$i -lt 6;$i++){
  $enabled=($i%2);$label=if($enabled){'ON'}else{'OFF'}
  [pscustomobject]@{name=('ART_{0:00}_{1}' -f ($i+1),$label);enabled=[string]$enabled;start_seconds=$i*600;end_seconds=($i+1)*600}
 }
}
function AssertArtwork($row,[string]$expected){
 if(!$row.ContainsKey('ART-AB')){throw 'ARTWORK_DIAGNOSTICS_MISSING'}
 $a=$row['ART-AB']
 foreach($key in @('enabled','ready','frames','decodes','failures','decode_wall_us','draw_wall_us','fetches')){
  if(!$a.ContainsKey($key) -or $a[$key] -notmatch '^\d+$'){throw 'ARTWORK_DIAGNOSTICS_MALFORMED'}
 }
 if($a.ready -ne '1' -or $a.enabled -ne $expected){throw 'ARTWORK_STATE_NOT_APPLIED'}
 if($a.failures -ne '0'){throw 'ARTWORK_DECODE_FAILURE'}
 if($a.fetches -ne '0' -or $a.source -notin @('CACHED_COVER','BUNDLED_CONTROL')){throw 'ARTWORK_CONTROL_NOT_FROZEN'}
}
function CpuArtworkPlan {
 @([pscustomobject]@{name='CPU_01_OFF';enabled='0';start_seconds=0;end_seconds=300},[pscustomobject]@{name='CPU_02_ON';enabled='1';start_seconds=300;end_seconds=600})
}
function StageArtworkPlan {
 if($BatchSweep){
  $index=0
  foreach($offload in $(if($RowsOnly){@('0')}else{@('0','1')})){foreach($rows in $(if($RowsOnly){@(4,8,16,32,64,128)}else{@(4,8,16,32,64,128,240)})){
   $stageSeconds=if($RowsOnly){120}else{300}
   [pscustomobject]@{name=('STAGE_{0:D2}_DQ{1}_ROWS{2}' -f ($index+1),$offload,$rows);enabled='1';offload=$offload;rows=$rows;start_seconds=$index*$stageSeconds;end_seconds=($index+1)*$stageSeconds};$index++
  }}
  return
 }

 @([pscustomobject]@{name='STAGE_01_OFF';enabled='0';start_seconds=0;end_seconds=300},[pscustomobject]@{name='STAGE_02_SLOW';enabled='1';start_seconds=300;end_seconds=600},[pscustomobject]@{name='STAGE_03_FAST';enabled='1';start_seconds=600;end_seconds=900})
}
function ArtworkRun([switch]$Short,[switch]$Stages) {
 if($RowsOnly){Ack 'dqoff'}elseif($BatchSweep){Ack 'dqprepare';Ack 'dqoff';Ack 'dq8'}
 Ack 'artoff';$script:ArtExpected='0';$first=Sample;AssertArtwork $first '0'
 $artMeasureStartUtc=[DateTime]::UtcNow
 $duration=if($RowsOnly){720}elseif($BatchSweep){4200}elseif($Stages){900}elseif($Short){600}else{3600};$plan=if($Stages){@(StageArtworkPlan)}elseif($Short){@(CpuArtworkPlan)}else{@(ArtworkPlan)}
 Record ('[ART-MEASURE] start_utc='+$artMeasureStartUtc.ToString('o')+' duration_s='+$duration+' rate=32000 webui=OFF source='+$first['ART-AB'].source+' fetches=0')
 foreach($part in $plan){
  Phase $part.name {
   $command=if($part.enabled -eq '1'){'arton'}else{'artoff'}
   if($BatchSweep){Ack $(if($part.offload -eq '1'){'dqon'}else{'dqoff'});Ack ('artrows='+$part.rows);Ack 'artfast'}elseif($Stages){Ack $(if($part.name -eq 'STAGE_03_FAST'){'artfast'}else{'artslow'})}
   Ack $command;$script:ArtExpected=$part.enabled;$before=Sample;AssertArtwork $before $part.enabled
   AssertActualBtRate $before 32000
   Record ('[ART-SWITCH] enabled='+$part.enabled+' actual_elapsed_s='+([DateTime]::UtcNow-$artMeasureStartUtc).TotalSeconds+' planned_s='+$part.start_seconds)
   Observe ($part.end_seconds-$part.start_seconds) 1 1 $true ($artMeasureStartUtc.AddSeconds($part.end_seconds))
   $after=Sample;AssertArtwork $after $part.enabled
   if($BatchSweep){
    if(!$before.ContainsKey('MP3-OFFLOAD') -or !$after.ContainsKey('MP3-OFFLOAD')){throw 'OFFLOAD_DIAGNOSTICS_MISSING'}
    $dq=$after['MP3-OFFLOAD'];$previous=$before['MP3-OFFLOAD']
    if($dq.enabled -ne $part.offload -or (!$RowsOnly -and ($dq.ready -ne '1' -or $dq.core -ne '0' -or $dq.fraction -ne '8'))){throw 'OFFLOAD_STATE_NOT_APPLIED'}
    $work=[long]$dq.jobs-[long]$previous.jobs
    if(($part.offload -eq '1' -and $work -lt 2) -or ($part.offload -eq '0' -and $work -gt 1)){throw 'OFFLOAD_PROGRESS_INVALID'}
   }
   $frames=[long]$after['ART-AB'].frames-[long]$before['ART-AB'].frames
   $decodes=[long]$after['ART-AB'].decodes-[long]$before['ART-AB'].decodes
   if($part.enabled -eq '0' -and ($frames -ne 0 -or $decodes -ne 0)){throw 'ARTWORK_OFF_STILL_RENDERING'}
   if($part.enabled -eq '1' -and ($frames -lt 2 -or $decodes -lt 2)){throw 'ARTWORK_ON_NO_PROGRESS'}
   $script:ArtRows.Add([pscustomobject]@{phase=$part.name;enabled=$part.enabled;batch_rows=$part.rows;offload=$part.offload;planned_start_s=$part.start_seconds;planned_end_s=$part.end_seconds;actual_end_s=([DateTime]::UtcNow-$artMeasureStartUtc).TotalSeconds;source=$after['ART-AB'].source;frames=$frames;decodes=$decodes;decode_wall_us=([long]$after['ART-AB'].decode_wall_us-[long]$before['ART-AB'].decode_wall_us);draw_wall_us=([long]$after['ART-AB'].draw_wall_us-[long]$before['ART-AB'].draw_wall_us);underruns=([long]$after['BT-AUDIO'].underruns-[long]$before['BT-AUDIO'].underruns);fetches=0})
   Record ('[ART-PHASE-END] phase='+$part.name+' frames='+$frames+' decodes='+$decodes+' measured_end_s='+([DateTime]::UtcNow-$artMeasureStartUtc).TotalSeconds)
  }
 }
 if($BatchSweep){Ack 'dqoff'}
 Ack 'artoff'
}
function ValidSbcCpu($line,[string]$stage,[string]$route){
 $f=Fields $line
 foreach($key in @('frames','valid','wall_us','task_runtime_us','task_permille','core0_permille','core1_permille','coded_frames','decoded_frames','deadline_misses','max_late_us')){if(!$f.ContainsKey($key) -or $f[$key] -notmatch '^\d+$'){return $false}}
 $coded=if($stage -eq 'BASELINE'){0}else{2500};$decoded=if($stage -eq 'ROUNDTRIP'){2500}else{0}
 return $f.result -eq 'PASS' -and $f.frames -eq '2500' -and $f.valid -eq '2500' -and $f.stage -eq $stage -and $f.route -eq $route -and $f.runtime -eq 'SCHEDULER_US' -and $f.scope -eq 'DIAG_SHADOW' -and [long]$f.task_runtime_us -gt 0 -and [long]$f.wall_us -gt 0 -and [long]$f.task_runtime_us -le ([long]$f.wall_us+2000) -and [int]$f.coded_frames -eq $coded -and [int]$f.decoded_frames -eq $decoded
}
function SbcStage([string]$route,[int]$index){
 $names=@('BASELINE','ENCODE','ROUNDTRIP');$name=$names[$index];$before=Sample;$cursor=$script:Seq
 Ack ('sbc'+$index);$end=[DateTime]::UtcNow.AddSeconds(30);$heartbeat=[DateTime]::UtcNow;$line=$null
 do{
  Pump 200;$line=MatchAfter $cursor ('^\[SBC-CPU\].* stage='+$name+' route='+$route+'(?: |$)')
  if(!$line -and [DateTime]::UtcNow -ge $heartbeat){[void](Status);$heartbeat=[DateTime]::UtcNow.AddSeconds(2)}
 }while(!$line -and [DateTime]::UtcNow -lt $end)
 if(!$line){throw 'SBC_STAGE_TIMEOUT'}
 if(!(ValidSbcCpu $line $name $route)){throw ('SBC_STAGE_FAILED: '+$line)}
 [void](WaitState {param($state) $state.sbc_busy -eq '0'} 5)
 $after=Sample
 if($before['PATH-SOURCE'].generation -ne $after['PATH-SOURCE'].generation -or $after['PATH-STATE'].playing -ne '1'){throw 'SBC_STAGE_NATIVE_SOURCE_CHANGED'}
 foreach($sample in @($before,$after)){
  $state=$sample['PATH-STATE']
  if($state.web -ne '1' -or $state.playing -ne '1'){throw 'SBC_STAGE_WEB_PLAYBACK_LOST'}
  if($route -eq 'BT'){if($state.route -ne '1' -or $state.transmitting -ne '1' -or $state.rate -ne '32000'){throw 'SBC_STAGE_BT_RATE_OR_ROUTE_LOST'}}
  elseif($state.route -ne '0' -or $state.idle -ne '1'){throw 'SBC_STAGE_DAC_ROUTE_LOST'}
  if(!$sample['PATH-TOTAL'].ContainsKey('decoded_frames')){throw 'SBC_STAGE_NATIVE_COUNTER_MISSING'}
 }
 $delta=[long]$after['PATH-TOTAL'].decoded_frames-[long]$before['PATH-TOTAL'].decoded_frames
 if($delta -le 0){throw 'SBC_STAGE_NATIVE_DECODER_STALLED'}
 $row=[ordered]@{route=$route;stage=$name;result='MEASURED';cpu=(Fields $line);native_decoded_delta=$delta;native_underrun_delta=([long]$after['BT-AUDIO'].underruns-[long]$before['BT-AUDIO'].underruns);new_encoder_bt_send='NOT_RUN'}
 $script:SbcRows.Add([pscustomobject]$row);Record ('[SBC-STAGE-NATIVE] route='+$route+' stage='+$name+' decoded_delta='+$delta)
}
function SelectBudapestRock {
 $before=Status
 if($before.active -eq '1' -or $before.restoring -eq '1'){throw 'RADIO_BUSY_OTHER_SESSION'}
 $after=$script:Seq
 [void](Request 'list' '^##CLI.LIST#' 15)
 $stations=@($script:Lines | Where-Object {$_.seq -gt $after -and $_.text -match '#CLI.LISTNUM#:\s*(\d+):\s*Budapest\s*Rock\s*,'})
 if($stations.Count -ne 1){throw 'BUDAPEST_ROCK_MISSING_OR_AMBIGUOUS'}
 $null=$stations[0].text -match '#CLI.LISTNUM#:\s*(\d+):'
 $station=[int]$Matches[1]
 if($station -le 0){throw 'BUDAPEST_ROCK_INVALID_INDEX'}
 if($before.station -eq [string]$station -and (WebDacReady $before) -and [int]$before.input_buffer -gt 0){Record '[COMMON-START] already_playing=BUDAPEST_ROCK; no duplicate PLAY';return $before}
 [void](Request ('play '+$station) '^##CLI.PLAYING#' 120)
 $ready=WaitState {param($v) $v.station -eq [string]$station -and (WebDacReady $v) -and [int]$v.input_buffer -gt 0} 120
 Record ('[COMMON-START] status_checked=1 station=BUDAPEST_ROCK index='+$station+' playback_ready=1 bt_policy=SAVED_AUTOMATIC_WHEN_SELECTED')
 return $ready
}
function PrepareArtwork([int]$station){
 # Firmware PR_STOP runs setDefaults: decoder buffers and TLS connection are released.
 # Keep the diagnostic lease alive via Status; never relax the internal-memory guard.
 Send 'stop'
 [void](WaitState {param($v) $v.playing -eq '0' -and $v.route -eq '0' -and $v.idle -eq '1'} 30)
 Record '[ART-PREPARE-ORDER] stopped=1 guard=UNCHANGED'
 Ack 'artprepare';Ack 'artoff'
 $row=Sample;AssertArtwork $row '0'
 Send ('play '+$station)
 [void](WaitWebDacReady (Status) 90)
 Record '[ART-PREPARE-ORDER] resumed=1 measurement_started=0'
}
function PrepareArtworkOrFallback([int]$station){
 try{PrepareArtwork $station}
 catch{
  # Only the known preparation rejection is optional. COM, panic, decode,
  # malformed samples and memory corruption still abort the measurement.
  if($_.Exception.Message -ne 'COMMAND_DENIED: artprepare' -or $RowsOnly){throw}
  $script:ArtUnavailable=$true
  $script:Phases.Add([pscustomobject]@{name='ARTWORK_OFF_ON';result='NOT_RUN_PREPARE_DENIED';error='artprepare denied; BT-only fallback'})
  Record '[ARTWORK-FALLBACK] artwork=NOT_RUN_PREPARE_DENIED bt_test=CONTINUE_WITHOUT_IMAGE'
  Write-Host '[ARTWORK] A kep elokeszitese elutasitva. A 60 perces BT-meres kep nelkul folytatodik.'
  Send ('play '+$station)
  [void](WaitWebDacReady (Status) 90)
 }
}
function Phase([string]$name,[scriptblock]$body){
 $script:Phase=$name;$start=[DateTime]::UtcNow;Write-Host ('[SZAKASZ] '+$name)
 $r=[ordered]@{name=$name;start_utc=$start.ToString('o');result='RUNNING';error=''}
 try{& $body;$r.result='COMPLETED_REVIEW_METRICS'}catch{$r.result=if($_.Exception.Message -eq 'MENU10_WINDOW_END'){'NOT_RUN_TIME_LIMIT'}else{'FAIL'};$r.error=Redact $_.Exception.Message;throw}finally{
  $r.seconds=([DateTime]::UtcNow-$start).TotalSeconds;$script:Phases.Add([pscustomobject]$r)
 }
}
function MenuPhase([int]$ms,[int]$tour,[bool]$webLoad=$true){
 if($FullNoWeb){$webLoad=$false}
 $script:Phase="MENU_${ms}_TOUR_$tour";$after=$script:Seq
 $line=Request "r10 ui stress start action=$ms draw=$ms tour=$tour" '^\[UI-STRESS\] start='
 if($line -notmatch 'start=PASS'){
  Send 'r10 ui stress status';Pump 500;Send 'r10 status';Pump 500
  $script:Phases.Add([pscustomobject]@{name=$script:Phase;result='NOT_RUN_DENIED';error='Firmware gate: WEB/DAC, playing, input buffer, internal heap, saved settings for tour; see UI-STRESS status and firmware version'});return
 }
 $end=[DateTime]::UtcNow.AddSeconds(75);$guard=$false
 try{
  while([DateTime]::UtcNow -lt $end){
   Send 'r10 ui stress status';Send 'r10 load';if($script:Lease){$null=Status};if($webLoad){TryWebExercise};Pump $(if($FullProfile){2000}else{10000})
   if(MatchAfter $after '^\[UI-STRESS\] stop='){$guard=$true;break}
   if($tour -eq 1 -and (MatchAfter $after '^\[UI-TOUR\] cycle=PASS')){break}
   if($tour -eq 2 -and (MatchAfter $after '^\[UI-MENU-SCAN\] cycle=PASS')){
    $progress=Fields (Request 'r10 ui stress status' '^\[UI-STRESS\] active=')
    if([int]$progress.scan_rendered -ge 111){break}
   }
  }
 }finally{Send 'r10 ui stress stop';Pump 500}
 $state=Fields (Request 'r10 ui stress status' '^\[UI-STRESS\] active=')
 $pages=@('STATIONS','SOUND','BLUETOOTH','BT_INFO','SETTINGS','DISPLAY')
 $missing=@($pages | Where-Object {!(MatchAfter $after ('^\[UI-TOUR\] step=\d+ result=PASS .* to='+$_+':'))})
 $webRequests=@($script:Lines | Where-Object {$_.seq -gt $after -and $_.text -match '^\[WEB-TEST\] result=PASS'}).Count
 $result='COMPLETED'
 if($guard){$result='GUARD_STOP'}
 elseif($state.active -ne '0' -or [int]$state.actions -eq 0){$result='FAIL_NO_ACTIONS'}
 elseif($tour -eq 1 -and ($state.restored -ne '1' -or [int]$state.cycles -lt 1 -or [int]$state.edits -lt 1)){$result='FAIL_TOUR_OR_RESTORE'}
 elseif($tour -eq 1 -and $missing.Count){$result='FAIL_SUBMENU_COVERAGE'}
 elseif($tour -eq 2 -and ($state.restored -ne '1' -or [int]$state.scan_rendered -lt 111 -or [int]$state.cycles -lt 1)){$result='FAIL_FULL_MENU_RENDER_COVERAGE_OR_RESTORE'}
 elseif($FullProfile -and $webLoad -and !$script:WebDisabled -and $webRequests -lt 3){$result='FAIL_WEBUI_NOT_EXERCISED_WITH_MENU'}
 $visited=if($tour -eq 2){
  @($script:Lines | Where-Object {$_.seq -gt $after -and $_.text -match '^\[UI-MENU-SCAN\] page=\d+ item=0 result=RENDERED'} |
   ForEach-Object {[int]([regex]::Match($_.text,'page=(\d+)').Groups[1].Value)} | Sort-Object -Unique)
 }else{@($pages | Where-Object {$_ -notin $missing})}
 $script:Phases.Add([pscustomobject]@{name=$script:Phase;result=$result;state=$state;submenus_visited=$visited;web_requests=$webRequests;web_status=$(if(!$webLoad){'DISABLED_FOR_THIS_PHASE'}elseif($script:WebDisabled){'NOT_RUN_UNREACHABLE'}else{'ACTIVE'})})
 if($state.active -ne '0' -or ($tour -gt 0 -and $state.restored -ne '1')){throw 'MENU_RESTORE_UNCONFIRMED'}
 if($result -like 'FAIL*'){throw $result}
}
if($SelfTest){
 $testBytes=[Text.Encoding]::UTF8.GetBytes('volume=0')
 $testSegment=New-Object 'ArraySegment[byte]' -ArgumentList (,$testBytes)
 if($testSegment.Count -ne 8){throw 'websocket payload construction'}
 if((Redact 'ip=192.168.1.5 password=secret') -ne 'ip=<IP> password=<redacted>'){throw 'redaction'}
 if((Fields '[PATH-STATE] playing=1 web=0').web -ne '0'){throw 'parser'}
 if((ValidRadioIp '0.0.0.0') -or (ValidRadioIp '192.168.4.1') -or !(ValidRadioIp '192.168.1.5')){throw 'radio ip validation'}
 $script:IpCaptureArmed=$true
 Record '[R10-TELEM] tag=status active=0 ip=192.168.1.5 heap_internal=40000'
 $script:IpCaptureArmed=$false
 if($script:RadioIpCandidate -ne '192.168.1.5' -or !(($script:Lines | Select-Object -Last 1).text -match 'ip=<IP>')){throw 'radio ip capture/redaction'}
 Record '[UI-STRESS] start=PASS';$mark=$script:Seq
 if($null -ne (MatchAfter $mark 'start=PASS')){throw 'stale reply accepted'}
 Record '[UI-STRESS] start=DENIED'
 if(!(MatchAfter $mark 'start=DENIED')){throw 'fresh reply lost'}
 $script:Armed=$true;Record 'Guru Meditation Error';if(!$script:Fatal){throw 'panic missed'}
 $script:Fatal='';Record 'rst:0xc';if(!$script:Fatal){throw 'reset missed'}
 $script:Fatal='';$script:Armed=$false
 Record '#CLI.LISTNUM#: 9: test, https://ice5.somafm.com/bootliquor-128-mp3'
 if($script:StationMap['128'] -ne 9){throw 'station mapping'}
 $script:Serial=New-Object PSObject
 $script:Serial | Add-Member ScriptMethod Write {param($command)
  if($command -match 'sample'){
   Record '[PATH-BEGIN-SAMPLE] seq=7';Record '[PATH-STATE] active=1 restoring=0 playing=1 web=1 station=6 route=0 idle=1 rate=32000 connected=0 transmitting=0 source_rate=44100 player=1'
   Record '[PATH-SOURCE] codec=2 generation=3';Record '[BT-AUDIO] codec_ok=0 delivered_bytes=0 requested_bytes=0 underruns=0 dropped_bytes=0 tx_buffer=0'
   Record '[PATH-END-SAMPLE] seq=7'
  }elseif($command -match '^r10 status'){
   Record '[R10-TELEM] tag=status active=0 ip=192.168.1.5 heap_internal=40000'
  }else{Record '[PATH-ACK] command=on result=DENIED'}
 }
 function Pump {param([int]$ms,[switch]$IgnoreFault)}
 if((DiscoverRadioIp) -ne '192.168.1.5'){throw 'serial ip discovery'}
 $denied=$false;try{Ack 'on'}catch{if($_.Exception.Message -eq 'COMMAND_DENIED: on'){$denied=$true}else{throw}}
 if(!$denied){throw 'denied command accepted'}
 $row=Sample;if($row['PATH-SOURCE'].generation -ne '3'){throw 'sample parsing'}
 $script:Serial | Add-Member ScriptMethod Write {param($command) Record '[PATH-BEGIN-SAMPLE] seq=8';Record '[PATH-END-SAMPLE] seq=9'} -Force
 $rejected=$false;try{$null=Sample}catch{if($_.Exception.Message -eq 'INCOMPLETE_SAMPLE'){$rejected=$true}else{throw}}
 if(!$rejected){throw 'mismatched sample accepted'}
 $good='[PATH-STATE] active=1 restoring=0 profile=1 web=1 playing=0 station=6 volume=239 route=1 idle=0 rate=32000 saved=2 scanning=0 connected=0 transmitting=0 input_buffer=0 source_rate=44100 vu_ms=100 player=1'
 $bad='[PATH-STATE] active=1 restoring=0 profile=1 web=1 playing=0 station=6 volume=239 route=1 idle=0 rate=32000 saved=2 scanning=0 coW (738143) BT_APPL: reset flags'
 if(!(ValidState $good) -or (ValidState $bad)){throw 'interleaved state validation'}
 $script:MockGood=$good;$script:MockBad=$bad;$script:MockCount=0
 $script:Serial | Add-Member ScriptMethod Write {param($command) $script:MockCount++;if($script:MockCount -eq 1){Record $script:MockBad}else{Record $script:MockGood}} -Force
 $state=Status;if($state.transmitting -ne '0' -or $script:MockCount -ne 2){throw 'state retry failed'}
 $groups=@(@(@{phase='a'},@{phase='b'},@{phase='a'}) | Group-Object {$_['phase']})
 if($groups.Count -ne 2){throw 'phase grouping failed'}
 $state=Fields $good
 $state.transmitting='1';$state.connected='1'
 if(BtPlaybackReady $state){throw 'link-only accepted as playback'}
 $state.playing='1';$state.input_buffer='32768'
 if(!(BtPlaybackReady $state)){throw 'playing stream rejected'}
 $state.input_buffer='0'
 if(BtPlaybackReady $state){throw 'empty source accepted'}
 $dac=Fields $good;$dac.route='0';$dac.idle='1'
 if(WebDacReady $dac){throw 'idle web dac accepted'}
 $dac.playing='1'
 if(!(WebDacReady $dac)){throw 'playing web dac rejected'}
 $script:MockCount=0
 $script:Serial | Add-Member ScriptMethod Write {param($command)
  $script:MockCount++
  if($script:MockCount -lt 3){Record '[PATH-STATE] active=0 restoring=0 web=1 playing=0 station=6 route=0 idle=1 rate=32000 connected=0 transmitting=0 source_rate=44100 player=1'}
  else{Record '[PATH-STATE] active=0 restoring=0 web=1 playing=1 station=6 route=0 idle=1 rate=32000 connected=0 transmitting=0 source_rate=44100 player=1'}
 } -Force
 $ready=WaitWebDacReady (Fields $good) 5
 if(!(WebDacReady $ready) -or $script:MockCount -ne 3){throw 'bounded startup wait'}
 $script:Serial | Add-Member ScriptMethod Write {param($command) Record '[PATH-STATE] active=0 restoring=0 web=1 playing=0 station=6 route=0 idle=1 rate=32000 connected=0 transmitting=0 source_rate=44100 player=1'} -Force
 $timedOut=$false
 try{$null=WaitWebDacReady (Fields $good) 0}catch{if($_.Exception.Message -eq 'RADIO_WEB_DAC_NOT_READY'){$timedOut=$true}else{throw}}
 if(!$timedOut){throw 'startup timeout missing'}
 if((DeliveredBytes @{'BT-AUDIO'=@{delivered_bytes='2048'}}) -ne 2048){throw 'delivered counter parse'}
 $missing=$false;try{$null=DeliveredBytes @{'BT-AUDIO'=@{}}}catch{if($_.Exception.Message -eq 'BT_DELIVERED_COUNTER_MISSING'){$missing=$true}else{throw}}
 if(!$missing){throw 'missing delivered counter accepted'}
 $script:MockDelivered=0
  function Status {return @{active='1';web='1';route='1';connected='1';transmitting='1';rate='32000';playing='1';input_buffer='32768'}}
 function Sample {$script:MockDelivered+=1024;return @{'PATH-STATE'=(Status);'BT-AUDIO'=@{delivered_bytes=[string]$script:MockDelivered}}}
 function Pump {param([int]$ms,[switch]$IgnoreFault)}
 WaitBtPlayback
 if($script:MockDelivered -lt 2048){throw 'BT playback accepted without PCM progress'}
 function Sample {return @{'PATH-STATE'=(Status);'BT-AUDIO'=@{delivered_bytes='2048';codec_ok='1';rate='32000'}}}
 $stalled=$false;try{Observe 10 1 1}catch{if($_.Exception.Message -eq 'BT_NO_PCM_PROGRESS'){$stalled=$true}else{throw}}
 if(!$stalled){throw 'stalled PCM accepted'}
 $script:ProbeCommands=New-Object 'System.Collections.Generic.List[string]';$script:MockProbeIndex=-1
 function Status {return @{route='0';idle='1'}}
 function Ack {param([string]$command) $script:ProbeCommands.Add($command);if($command -match '^saved=(\d+)$'){$script:MockProbeIndex=[int]$Matches[1]}}
 function WaitBtPlayback {if($script:MockProbeIndex -eq 0){throw 'BT_STREAM_START_TIMEOUT_90S'}}
 function Record {param([string]$s)}
  if((ConnectAvailableSaved @(0,1)) -ne 1 -or ($script:ProbeCommands -join ',') -ne 'rate32,saved=0,rate32,saved=1'){throw 'saved peer fallback order'}
  function WaitBtPlayback {throw 'BT_CONNECTED_NO_PCM_PROGRESS'}
   $noPcm=$false;try{$null=ConnectAvailableSaved @(0,1)}catch{if($_.Exception.Message -eq 'BT_CONNECTED_NO_PCM_PROGRESS'){$noPcm=$true}else{throw}}
   if(!$noPcm){throw 'connected peer without PCM misclassified as unavailable'}
   function WaitBtPlayback {if($script:MockProbeIndex -eq 0){throw 'BT_STREAM_START_TIMEOUT_90S'}}
 if((MinimumSamples 20) -ne 2 -or (MinimumSamples 30) -ne 3 -or (MinimumSamples 90) -ne 3){throw 'short observe sample threshold'}
 $old=@{'PATH-STATE'=@{active='1';web='1';playing='1';route='0';idle='1';input_buffer='100'};'PATH-SOURCE'=@{generation='10'};'PATH-TOTAL'=@{decoded_frames='1000'}}
 $first=@{'PATH-STATE'=@{active='1';web='0';playing='1';route='0';idle='1';input_buffer='100'};'PATH-SOURCE'=@{generation='11'};'PATH-TOTAL'=@{decoded_frames='2000'}}
 $second=@{'PATH-STATE'=@{active='1';web='0';playing='1';route='0';idle='1';input_buffer='100'};'PATH-SOURCE'=@{generation='11'};'PATH-TOTAL'=@{decoded_frames='3000'}}
 if(!(SourceProgress $old $first $second 0)){throw 'source progress rejected'}
 $second['PATH-TOTAL'].decoded_frames='2000';if(SourceProgress $old $first $second 0){throw 'stalled source accepted'}
 $second['PATH-TOTAL'].decoded_frames='3000';$second['PATH-STATE'].input_buffer='0';if(SourceProgress $old $first $second 0){throw 'empty source accepted'}
 $script:selectedIndex=-1;Phase 'MOCK_BT_CONNECT' {$script:selectedIndex=ConnectAvailableSaved @(0,1)}
 if($script:selectedIndex -ne 1){throw 'selected peer lost across phase scope'}
 $script:WebAddress='';$script:WebStep=0;WebExercise
 if($script:WebStep -ne 0){throw 'no-web profile touched WebUI'}
 $script:WebAddress='192.0.2.1';$script:WebStep=0;RestoreWebVolume
 if($script:WebStep -ne 0 -or $script:WebRestoreError){throw 'untouched WebUI restore attempted'}
 $script:WebDisabled=$true;TryWebExercise
 if($script:WebSkippedReason){throw 'disabled WebUI was retried'}
 $script:WebDisabled=$false;$script:WebSkippedReason='';$FullProfile=$true
 function WebExercise {throw 'WEB_CONNECT_UNREACHABLE'}
 TryWebExercise
 if(!$script:WebDisabled -or $script:WebSkippedReason -ne 'WEB_CONNECT_UNREACHABLE'){throw 'unreachable WebUI did not skip'}
 $script:WebDisabled=$false
 function WebExercise {throw 'WEB_VOLUME_NOT_APPLIED'}
 $webFault=$false;try{TryWebExercise}catch{if($_.Exception.Message -eq 'WEB_VOLUME_NOT_APPLIED'){$webFault=$true}else{throw}}
 if(!$webFault){throw 'WebUI protocol error was skipped'}
 $script:Lines.Add([pscustomobject]@{seq=999;utc='';phase='';text='[E][Audio.cpp:1227] readAudioHeader(): Processing stopped due to invalid audio header'})
 if(!(MatchAfter 0 'readAudioHeader\(\): Processing stopped due to invalid audio header')){throw 'SD header fault not recognized'}
 $sdFault=$false
 try{SwitchAndVerifyOnce 'sd'}catch{if($_.Exception.Message -eq 'SD_AUDIO_HEADER_INVALID'){$sdFault=$true}else{throw}}
 if(!$sdFault){throw 'SD header fault did not abort source preflight'}
 $script:Lines.Clear()
 $script:ResumeCommand=''
 function Send {param([string]$s) $script:ResumeCommand=$s}
 function Sample {return @{}}
 function Status {throw 'STOP_AFTER_SEND'}
  try{SwitchAndVerify 'web' 8}catch{if($_.Exception.Message -ne 'STOP_AFTER_SEND'){throw}}
  if($script:ResumeCommand -ne 'play 8'){throw 'WEB recovery did not restart the original station'}
  $script:MockSamples=@(
   @{'PATH-STATE'=@{active='1';web='0';playing='0';route='0';idle='1';input_buffer='0'};'PATH-SOURCE'=@{generation='20'};'PATH-TOTAL'=@{decoded_frames='1000'}},
   @{'PATH-STATE'=@{active='1';web='1';playing='1';route='0';idle='1';input_buffer='12000'};'PATH-SOURCE'=@{generation='21'};'PATH-TOTAL'=@{decoded_frames='1000'}},
   @{'PATH-STATE'=@{active='1';web='1';playing='1';route='0';idle='1';input_buffer='105000'};'PATH-SOURCE'=@{generation='21'};'PATH-TOTAL'=@{decoded_frames='1000'}},
   @{'PATH-STATE'=@{active='1';web='1';playing='1';route='0';idle='1';input_buffer='250000'};'PATH-SOURCE'=@{generation='21'};'PATH-TOTAL'=@{decoded_frames='2300'}}
  );$script:MockSampleIndex=0
  function Sample {$row=$script:MockSamples[$script:MockSampleIndex];$script:MockSampleIndex++;return $row}
  function Status {return @{active='1';web='1';playing='1';route='0';idle='1';input_buffer='12000'}}
  function Ack {param([string]$command)}
  function Pump {param([int]$milliseconds)}
  function MatchAfter {return $false}
  SwitchAndVerify 'web' 8
  if($script:MockSampleIndex -ne 4){throw 'prebuffer gate rejected delayed decoded progress'}
 Write-Host 'PASS: parser, redaction, saved-device fallback, source progress, short-phase samples, PCM progress/stall, denial and fault detection; no COM opened.';exit 0
}
if(!$SelfTest){
 if($Menu10){$FullProfile=$true;$Automatic=$true;$Minutes=10}
if($Baseline){$FullProfile=$true;$Automatic=$true;$Minutes=20;$script:ProbeRate='rate32'}
 if($SbcStages){$Automatic=$true;$NoBtHour=$true;$Profile=6;$Minutes=1;$script:ProbeRate='rate32'}
 if($DequantAB){$RateCompare=$true;$Minutes=6};if($RowsOnly){$BatchSweep=$true};if($BatchSweep){$CpuStages=$true};if($CpuStages){$Cpu10=$true};if($Cpu10){$RateCompare=$true;$Minutes=if($RowsOnly){12}elseif($BatchSweep){70}elseif($CpuStages){15}else{10}}; if($Artwork60){$RateCompare=$true;$Minutes=60}; if($RateCompare){$Bt60=$true}; if($Bt60){$Automatic=$true;$NoBtHour=$true;$Profile=6;if($Minutes -eq 0){$Minutes=60}}
 if($FullProfile){$Automatic=$true;$NoBtHour=$true;$Profile=4}
 if($FullNoWeb){$FullProfile=$true;$Automatic=$true;$NoBtHour=$true;$Profile=2;$script:ProbeRate='rate32'}
 $NoBtHour=$true
 Write-Host '1. Full + DAC (BT es webes vezerles NELKUL)'
 Write-Host '2. Full + DAC + BT (webes vezerles nelkul)'
 Write-Host '3. Full + DAC + web (BT nelkul)'
 Write-Host '4. Full + DAC + BT + web (web csak DAC fazisban)'
 Write-Host '5. Internet + DAC + menu + web (SD es BT nelkul)'
 Write-Host '6. Internet + DAC + menu + BT (SD es web nelkul)'
 Write-Host '7. MAX terheles: internet + SD + DAC + BT + menu (WebUI nelkul)'
 if($Profile -eq 0 -and $Automatic){$Profile=4}
 if($Profile -eq 0){if(![int]::TryParse((Read-Host 'Tesztprofil 1-7'),[ref]$Profile)){throw 'INVALID_PROFILE'}}
 if($Profile -lt 1 -or $Profile -gt 7){throw 'INVALID_PROFILE'}
 $UseBt=$Profile -in @(2,4,6,7);$UseWeb=$Profile -in @(3,4,5);$UseSd=$Profile -le 4 -or $Profile -eq 7
}
$out=if($OutputDirectory){$OutputDirectory}else{Join-Path 'C:\esp32\SYSTEM\LOGS\STRESS_TEST' ('STRESS_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'))}
$back=if($ReturnDirectory){$ReturnDirectory}else{Join-Path ([IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\RETURN_TO_EVA'))) (Split-Path $out -Leaf)}
New-Item -ItemType Directory -Path $back -Force | Out-Null
$script:MirrorWriter=New-Object IO.StreamWriter((Join-Path $back 'serial.log'),$false,(New-Object Text.UTF8Encoding($false)))
@{result='RUNNING_OR_INTERRUPTED';physical_audio='NOT_EVALUATED';master_log=$out} | ConvertTo-Json | Set-Content (Join-Path $back 'RUN_STATUS.json') -Encoding UTF8
New-Item -ItemType Directory -Path $out -Force | Out-Null
$script:Writer=New-Object IO.StreamWriter((Join-Path $out 'serial.log'),$false,(New-Object Text.UTF8Encoding($false)))
$script:ArtUnavailable=$false
$result='NOT_RUN';$errorText='';$restore='NOT_NEEDED';$initial=$null;$peer='';$selectedIndex=-1;$savedIndices=@()
try{
 Write-Host 'A teszt automatikusan inditja az internetes radiot DAC-on.'
 if($UseSd){Write-Host 'Legyen SD-n lejatszhato MP3/FLAC.'}
 if($UseBt){Write-Host 'Kapcsold be a korabban parositott BT eszkozt. A teszt a mentetteket sorban probalja.'};Write-Host 'Ne indits mas COM-programot.'
 Write-Host 'Teszt kozben G = hallott kihagyas jelolese; Q = leallitas. Hangerot most allitsd be.'
 if(!$Automatic){[void](Read-Host 'Ha kesz, Enter')}
 if($NoBtHour){
  if($Automatic -and $Minutes -eq 0){$Minutes=20}
  if($Minutes -eq 0){if(![int]::TryParse((Read-Host 'Futasi ido percben (1-1440)'),[ref]$Minutes)){throw 'INVALID_DURATION'}}
  if($Minutes -lt 1 -or $Minutes -gt 1440){throw 'INVALID_DURATION'}
 }
 $Automatic=$true
 $initial=WaitBt60Startup
 $initial=SelectBudapestRock
 if($UseWeb -or $ConcurrentWeb){try{$script:WebAddress=DiscoverRadioIp;Write-Host '[WEB] IPv4 soros portrol felismerve.'}catch{$script:WebDisabled=$true;$script:WebSkippedReason='IP_DISCOVERY_FAILED';Record ('[WEB-TEST] NOT_RUN '+$_.Exception.Message)}}
 $script:WebOriginalVolume=[int]$initial.volume
 $script:Armed=$true
 if($UseBt){
 [void](Request 'list' '^##CLI.LIST#' 15)
 Write-Host ('[BITRATA] Felismert tesztadok: '+($script:StationMap.Keys -join ', '))
 $after=$script:Seq;[void](Request 'r10 path devices' '^\[PATH-DEVICES-END\]')
 $devices=@($script:Lines | Where-Object {$_.seq -gt $after -and $_.text -match '^\[PATH-DEVICE\] kind=saved'})
 foreach($d in $devices){Write-Host $d.text}
 if($devices.Count){
  $savedIndices=@($devices | ForEach-Object {
   $value=0;$field=(Fields $_.text).index
   if(![int]::TryParse($field,[ref]$value) -or $value -lt 0 -or $value -gt 3){throw 'INVALID_SAVED_DEVICE_LIST'}
   $value
  } | Sort-Object -Unique)
  Record '[RUNNER] preferred_saved_device=LAST_SUCCESS history_index=0'
  if(!$Automatic -and $Profile -ne 7){
   $answer=Read-Host 'BT teszthez a mentett eszkoz indexe; ures = BT kihagyasa'
   if($answer -ne ''){
    if(![int]::TryParse($answer,[ref]$selectedIndex) -or $selectedIndex -notin $savedIndices){throw 'INVALID_SAVED_DEVICE'}
    $savedIndices=@($selectedIndex)
   }else{$savedIndices=@()}
  }
 }
 }
 if($UseBt -and !$savedIndices.Count -and !$SbcStages){throw 'BT_SAVED_DEVICE_REQUIRED'}
 if(!$NoBtHour){foreach($ms in @(500,250,100,50,20,10)){MenuPhase $ms ([int]($ms -ge 250))}}
 [void](WaitWebDacReady (Status) 120)
 $begin=Request 'r10 path begin' '^\[PATH-BEGIN\]';if($begin -notmatch 'result=PASS'){throw 'PATH_BEGIN_DENIED'};$script:Lease=$true
 Ack 'on'
 if($FullProfile -and !$Menu10){
  :preflight for($round=1;$round -le 10;$round++){
   $step=0
   foreach($source in @('sd','web','sd','web')){
    $step++
    try{Phase "PREFLIGHT_${round}_${step}_$source" {SwitchAndVerify $source}}
    catch{
     if($source -ne 'sd' -or $_.Exception.Message -ne 'SD_NO_PLAYABLE_FILES'){throw}
     $failed=$script:Phases[$script:Phases.Count-1]
     $failed.result='NOT_RUN_INVALID_SD_FILE'
     $script:SdSkippedReason='SD_NO_PLAYABLE_FILES';$UseSd=$false
     Record '[SD-SKIP] reason=SD_NO_PLAYABLE_FILES remaining_sd_phases=NOT_RUN'
     Phase 'PREFLIGHT_WEB_RECOVER' {SwitchAndVerify 'web' ([int]$initial.station)}
     break preflight
    }
   }
  }
  if($UseSd){Record '[PREFLIGHT] result=PASS cycles=10 transitions=40 route=DAC'}
  else{Record '[PREFLIGHT] result=PARTIAL sd=NOT_RUN_INVALID_SD_FILE route=DAC'}
 }
 if($Menu10){
  $script:MenuWindowStart=[DateTime]::UtcNow;$script:MenuWindowEnd=$script:MenuWindowStart.AddMinutes(10)
  Record '[MENU10] active_seconds=600 startup_excluded=1 cleanup_excluded=1 web_bt_hz=32000'
  # Navigation/edit/return tour, then complete render scans: do not mistake rendering for functional activation.
  MenuPhase 500 1 $UseWeb
  foreach($speed in @(500,200,50)){MenuPhase $speed 2 $UseWeb}
  if($UseSd){
   try{Phase 'MENU10_SD_DAC' {SwitchAndVerify 'sd';Observe 20 0 0}}
   catch{if($_.Exception.Message -ne 'SD_NO_PLAYABLE_FILES'){throw};$script:SdSkippedReason='SD_NO_PLAYABLE_FILES';$UseSd=$false}
   Phase 'MENU10_WEB_RETURN' {SwitchAndVerify 'web' ([int]$initial.station);Observe 20 1 0}
  }
  if($UseBt){
   Phase 'MENU10_BT_CONNECT' {$script:selectedIndex=ConnectAvailableSaved $savedIndices}
   Phase 'MENU10_WEB_BT' {Observe 30 1 1 $true}
  }
  while([DateTime]::UtcNow -lt $script:MenuWindowEnd.AddSeconds(-12)){
   Phase 'MENU10_MONITOR' {Observe 10 1 ([int]$UseBt) $UseBt -PollMs 2000}
  }
  while([DateTime]::UtcNow -lt $script:MenuWindowEnd){Pump 100}
 }elseif($SbcStages){
  foreach($route in @('DAC','BT')){
   try{
    Ack 'dac';[void](WaitState {param($v) $v.route -eq '0' -and $v.idle -eq '1'} 45)
    Send ('play '+$initial.station);[void](WaitWebDacReady (Status) 90)
    if($route -eq 'BT'){
     if(!$savedIndices.Count){throw 'BT_SAVED_DEVICE_REQUIRED'}
     $script:selectedIndex=ConnectAvailableSaved $savedIndices
    }
   }catch{
    if($script:Fatal){throw}
    $script:Phases.Add([pscustomobject]@{name=('SBC_'+$route);result='NOT_RUN';error=Redact $_.Exception.Message});continue
   }
   foreach($index in 0..2){
    $names=@('BASELINE','ENCODE','ROUNDTRIP')
    try{Phase ('SBC_'+$route+'_'+$names[$index]) {SbcStage $route $index}}
    catch{
     if($script:Fatal){throw}
     $failure=$_.Exception.Message
     Ack 'sbcstop';[void](WaitState {param($v) $v.sbc_busy -eq '0'} 5)
     Record ('[SBC-STAGE-FAILED] route='+$route+' stage='+$names[$index]+' reason='+(Redact $failure))
    }
   }
  }
 }elseif($Bt60){
  if($RateCompare){
   if($CpuStages){Ack 'cpuon'};if($Cpu10){Ack 'artoff';Record ('[CPU-CONTROL] seconds='+($(if($RowsOnly){720}elseif($BatchSweep){4200}elseif($CpuStages){900}else{600}))+$(if($RowsOnly){' artwork=ON_ROWS_SWEEP webui=OFF actual_rate=32000'}else{' artwork=OFF_ON webui=OFF actual_rate=32000'}))}
   $station=[int]$initial.station
   foreach($trial in @(@{command='rate32';rate=32000})){
    Ack 'dac';[void](WaitState {param($v) $v.route -eq '0' -and $v.idle -eq '1'} 45)
    Send ('play '+$station);[void](WaitWebDacReady (Status) 90)
    if($DequantAB){Phase 'DQ_PREPARE' {PrepareDequant $station}}elseif($Artwork60 -or $Cpu10){Phase 'ART_PREPARE' {PrepareArtworkOrFallback $station}}
    $script:ProbeRate=$trial.command
    Phase ('RATE_CONNECT_'+$trial.rate) {
     if($script:selectedIndex -lt 0){$script:selectedIndex=ConnectAvailableSaved $savedIndices}
     else{Ack $trial.command;Ack ('saved='+$script:selectedIndex);WaitBtPlayback}
     $v=Status
     if([int]$v.rate -ne $trial.rate -or [int]$v.station -ne $station){throw 'RATE_OR_STATION_MISMATCH'}
     AssertActualBtRate (Sample) $trial.rate
     [void](Request 'r10 path devices' '^\[PATH-DEVICES-END\]')
     Record ('[RATE-AB] rate='+$trial.rate+' station='+$station+' index='+$script:selectedIndex)
    }
    if($DequantAB){DequantRun}elseif($CpuStages -and !$script:ArtUnavailable){ArtworkRun -Stages}elseif($Cpu10 -and !$script:ArtUnavailable){ArtworkRun -Short}elseif($Artwork60 -and !$script:ArtUnavailable){ArtworkRun}else{Phase ('WEB_BT_'+$trial.rate) {Observe ($Minutes*60) 1 1 $true}}
   }
  }else{
   Phase 'BT_CONNECT_SAVED' {$script:selectedIndex=ConnectAvailableSaved $savedIndices}
   Phase 'BT_WEB_CONTROL' {Observe ($Minutes*60) 1 1}
  }
  Record ('[BT-CONTROL-END] selected_index='+$selectedIndex+' seconds='+($Minutes*60))
 }elseif($Profile -eq 7){
  $heavyStart=[DateTime]::UtcNow;$deadline=$heavyStart.AddMinutes($Minutes);$round=0
  while([DateTime]::UtcNow -lt $deadline){
   $round++
   Phase "HEAVY_WEB_DAC_$round" {Observe 30 1 0}
   if([DateTime]::UtcNow -ge $deadline){break}
   $speeds=@(500,250,100,50,20,10);$speed=$speeds[($round-1)%$speeds.Count]
   MenuPhase $speed ([int]($speed -ge 250))
   if([DateTime]::UtcNow -ge $deadline){break}
   Phase "HEAVY_SD_DAC_$round" {
    Ack 'sourcesd'
    [void](WaitState {param($s) $s.web -eq '0' -and $s.playing -eq '1' -and $s.route -eq '0' -and $s.idle -eq '1'})
    Observe 30 0 0
   }
   if([DateTime]::UtcNow -ge $deadline){break}
   Phase "HEAVY_WEB_DAC_RETURN_$round" {
    Ack 'sourceweb'
    [void](WaitState {param($s) $s.web -eq '1' -and $s.playing -eq '1' -and $s.route -eq '0' -and $s.idle -eq '1'})
    Observe 20 1 0
   }
   if([DateTime]::UtcNow -ge $deadline){break}
   Phase "HEAVY_BT_CONNECT_$round" {
    if($selectedIndex -lt 0){$script:selectedIndex=ConnectAvailableSaved $savedIndices}
    else{Ack $script:ProbeRate;Ack "saved=$selectedIndex";WaitBtPlayback}
   }
   Phase "HEAVY_WEB_BT_$round" {Observe 90 1 1}
   if([DateTime]::UtcNow -lt $deadline){
    Phase "HEAVY_SD_BT_$round" {
     Ack 'sourcesd'
     [void](WaitState {param($s) $s.web -eq '0' -and $s.playing -eq '1' -and $s.route -eq '1' -and $s.transmitting -eq '1'})
     Observe 40 0 1
    }
   }
   if([DateTime]::UtcNow -lt $deadline){
    Phase "HEAVY_WEB_BT_RETURN_$round" {
     Ack 'sourceweb'
     [void](WaitState {param($s) $s.web -eq '1' -and $s.playing -eq '1' -and $s.route -eq '1' -and $s.transmitting -eq '1'})
     Observe 40 1 1
    }
   }
   Ack 'sourceweb';Ack 'dac'
   [void](WaitState {param($s) $s.web -eq '1' -and $s.playing -eq '1' -and $s.route -eq '0' -and $s.idle -eq '1'})
  }
  Record ('[HEAVY-END] seconds='+[int]([DateTime]::UtcNow-$heavyStart).TotalSeconds+' rounds='+$round+' webui=0')
 }elseif($NoBtHour){
  $hourStart=[DateTime]::UtcNow;$deadline=$hourStart.AddMinutes($Minutes);$round=0
  while([DateTime]::UtcNow -lt $deadline){
   $round++
   Phase "WEB_DAC_$round" {Observe 60 1 0}
   if($FullProfile -and $round -eq 1){MenuPhase 500 1}
   if([DateTime]::UtcNow -ge $deadline){break}
    $menuSpeeds=if($FullProfile){@(500,400,300,200,100,50)}else{@(500,250,100,50,20,10)}
   foreach($speed in $menuSpeeds){
    if([DateTime]::UtcNow -ge $deadline){break}
     MenuPhase $speed $(if($FullProfile){2}else{[int]($speed -ge 250)})
   }
   if([DateTime]::UtcNow -ge $deadline){break}
   if($UseSd){foreach($source in @('sd','web')){
    Phase "HOUR_DAC_${source}_$round" {
     Ack ('source'+$source);$want=[int]($source -eq 'web')
     [void](WaitState {param($s) [int]$s.web -eq $want -and $s.playing -eq '1' -and $s.route -eq '0' -and $s.idle -eq '1'})
     Observe 45 $want 0
     if($FullProfile -and $source -eq 'sd'){MenuPhase 50 2 $true}
    }
   }}
   if($UseBt -and [DateTime]::UtcNow -lt $deadline){
    Phase 'BT_CONNECT' {if($selectedIndex -lt 0){$script:selectedIndex=ConnectAvailableSaved $savedIndices}else{Ack $script:ProbeRate;Ack "saved=$selectedIndex";WaitBtPlayback}}
    Phase 'BT_WEB_PLAYBACK' {Observe 60 1 1;if($FullProfile){MenuPhase 50 2 $false}}
    if($UseSd){
     Phase 'BT_SD_PLAYBACK' {
      Ack 'sourcesd';[void](WaitState {param($s) $s.web -eq '0' -and $s.playing -eq '1' -and $s.transmitting -eq '1'})
      Observe 45 0 1
      if($FullProfile -or $RateCompare){MenuPhase 50 2 $false}
     }
    }
    Ack 'sourceweb';Ack 'dac'
    [void](WaitState {param($s) $s.web -eq '1' -and $s.playing -eq '1' -and $s.route -eq '0' -and $s.idle -eq '1'})
   }
  }
  Record ('[HOUR-END] seconds='+[int]([DateTime]::UtcNow-$hourStart).TotalSeconds+' profile='+$Profile)
 }else{
 Phase 'WEB_DAC_BASELINE' {Observe 90 1 0}
 foreach($round in 1..2){foreach($source in @('sd','web')){
  Phase "DAC_${source}_$round" {
   Ack ('source'+$source);$want=[int]($source -eq 'web')
   [void](WaitState {param($s) [int]$s.web -eq $want -and $s.playing -eq '1' -and $s.route -eq '0'})
   Pump 1500;Observe 45 $want 0
  }
 }}
 if($selectedIndex -ge 0){
  Phase 'BT_CONNECT_44100' {$script:selectedIndex=ConnectAvailableSaved $savedIndices}
  Phase 'WEB_BT_LONG' {Observe 600 1 1}
  foreach($round in 1..2){foreach($source in @('sd','web')){
   Phase "BT_${source}_$round" {
    Ack ('source'+$source);$want=[int]($source -eq 'web')
    [void](WaitState {param($s) [int]$s.web -eq $want -and $s.playing -eq '1' -and $s.transmitting -eq '1'})
    Pump 1500;Observe 45 $want 1
   }
  }}
 }else{$script:Phases.Add([pscustomobject]@{name='BT_TESTS';result='NOT_RUN_NO_SELECTED_DEVICE'})}
 if($script:StationMap.Count -eq 3){
  foreach($route in @(0,1)){
   if($route -eq 1 -and $selectedIndex -lt 0){continue}
   Ack 'dac';[void](WaitState {param($s) $s.idle -eq '1' -and $s.route -eq '0'})
   if($route -eq 1){Ack $script:ProbeRate;Ack "saved=$selectedIndex";WaitBtPlayback}
   foreach($kbps in @(128,192,320)){
    Phase "BITRATE_${kbps}_ROUTE_$route" {
     $before=Sample;$script:ExpectedStation=[int]$script:StationMap["$kbps"]
     Send ('play '+$script:ExpectedStation)
     [void](WaitState {param($s) [int]$s.station -eq $script:ExpectedStation -and $s.playing -eq '1' -and $s.source_rate -in @('44100','48000')} 60)
     $after=Sample
     if(!$after.ContainsKey('PATH-SOURCE') -or !$before.ContainsKey('PATH-SOURCE') -or $after['PATH-SOURCE'].generation -eq $before['PATH-SOURCE'].generation){throw 'STATION_GENERATION_UNCHANGED'}
     Pump 15000;[void](Status);Pump 10000
     Observe 90 1 $route
     $script:ExpectedStation=0
    }
   }
  }
 }else{$script:Phases.Add([pscustomobject]@{name='BITRATE_SWEEP';result='NOT_RUN_MISSING_TEST_STATIONS'})}
 }
 if($Menu10){$script:MenuStoppedAt=[DateTime]::UtcNow}
 $result=if($script:ArtUnavailable){'PARTIAL_BT_COMPLETED_ARTWORK_NOT_RUN'}else{'COMPLETED_LISTENING_AND_METRICS_REVIEW_REQUIRED'}
}catch{if($Menu10){$script:MenuStoppedAt=[DateTime]::UtcNow};$errorText=Redact $_.Exception.Message;$result=if($errorText -eq 'USER_STOP'){'ABORTED_USER'}elseif($errorText -in @('NO_COM_PORT','RADIO_WEB_DAC_NOT_READY','RADIO_WIFI_IP_NOT_READY','BT_SAVED_DEVICE_REQUIRED')){'NOT_RUN_STARTUP'}elseif($errorText -eq 'MENU10_WINDOW_END'){'COMPLETED_LISTENING_AND_METRICS_REVIEW_REQUIRED'}elseif($errorText -eq 'BT_SAVED_DEVICES_UNAVAILABLE'){'NOT_RUN_BT_NO_PEER'}else{'FAIL'};Write-Host ('[HIBA] '+$errorText)
 if($null -ne $script:Serial -and $script:Serial.IsOpen){try{Pump $(if($Menu10 -and $errorText -eq 'MENU10_WINDOW_END'){0}else{10000}) -IgnoreFault}catch{}}
}finally{
 $script:Phase='CLEANUP'
 if($null -ne $script:Serial -and $script:Serial.IsOpen){
  if(!$script:Fatal){try{
   Send 'r10 ui stress stop';Pump 300 -IgnoreFault
   if($script:Lease){Ack 'sourceweb';Ack 'dac'
    [void](WaitState {param($s) $s.active -eq '1' -and $s.route -eq '0' -and $s.idle -eq '1' -and $s.web -eq '1'} 50)
    if($null -ne $initial){
     RestoreWebVolume
     $beforeRestore=Sample;Send ('play '+$initial.station);$restoreDeadline=[DateTime]::UtcNow.AddSeconds(60);$stable=0
     do{
      $fresh=Sample;$st=$fresh['PATH-STATE']
      if($fresh['PATH-SOURCE'].generation -ne $beforeRestore['PATH-SOURCE'].generation -and $st.web -eq '1' -and $st.playing -eq '1' -and $st.station -eq $initial.station -and [int]$st.input_buffer -gt 0){$stable++}else{$stable=0}
      if($stable -ge 2){break};Pump 1500
     }while([DateTime]::UtcNow -lt $restoreDeadline)
     if($stable -lt 2){throw 'RESTORE_PLAYBACK_NOT_CONFIRMED'}
    }
    [void](Request 'r10 path end' '^\[PATH-RESTORE\] result=');$script:Lease=$false
    [void](WaitState {param($s) $s.active -eq '0' -and $s.restoring -eq '0' -and $s.route -eq '0' -and $s.idle -eq '1' -and $s.web -eq '1' -and $s.playing -eq '1' -and $s.station -eq $initial.station -and [int]$s.input_buffer -gt 0} 50)
    $restore=if($script:WebRestoreError){'DAC_WEB_ORIGINAL_STATION_CONFIRMED_WEB_VOLUME_UNCONFIRMED: '+$script:WebRestoreError}else{'DAC_WEB_ORIGINAL_STATION_CONFIRMED'}
   }
  }catch{
   $restore='UNCONFIRMED: '+(Redact $_.Exception.Message)
   if($script:Lease){try{Send 'r10 path end';Pump 500 -IgnoreFault}catch{};$script:Lease=$false}
  }}else{$restore='UNCONFIRMED_RADIO_FAULT'}
  if($script:Pending){Record ('[PARTIAL] '+$script:Pending)};$script:Serial.Close();$script:Serial.Dispose()
 }
 $script:Writer.Dispose();$script:Writer=$null; if($null -ne $script:MirrorWriter){$script:MirrorWriter.Dispose();$script:MirrorWriter=$null}
 if($result -like 'COMPLETED*' -and (@($script:Phases | Where-Object {$_.result -notlike 'COMPLETED*'}).Count -gt 0 -or $restore -like 'UNCONFIRMED*')){$result='PARTIAL_REVIEW_REQUIRED'}
 if($FullProfile -and $script:WebDisabled -and $result -like 'COMPLETED*'){$result='PARTIAL_REVIEW_REQUIRED'}
 if($script:SdRejected.Count -gt 0 -and $result -like 'COMPLETED*'){$result='PARTIAL_REVIEW_REQUIRED'}
 $report=[ordered]@{test=$(if($Artwork60){'IBT_ARTWORK_BT_60MIN'}elseif($RateCompare){'IBT_WEB_BT_32K_POLICY_CONTROL'}elseif($FullProfile){'IBT_V166_R7_FULL_MENU_TEST'}elseif($Bt60){'IBT_BT_SAVED_CONTROL'}elseif($Profile -eq 7){'IBT_HEAVY_NO_WEBUI'}elseif($NoBtHour){'IBT_SELECTABLE_STRESS_4'}else{'IBT_STRESS_3'});result=$result;error=$errorText;fatal=$script:Fatal;initial=$initial;restore=$restore;phases=@($script:Phases.ToArray());heard_gaps=@($script:Marks.ToArray());physical_audio='USER_REVIEW_REQUIRED';selected_saved_index=$selectedIndex;bitrate_station_mapping=$script:StationMap;bitrate_note='MP3 headers verified on PC; source rate/codec checked on radio; different broadcasts are not a controlled encoder comparison';flash=$false}
 if($Menu10){
  $required=@('MENU_500_TOUR_1','MENU_500_TOUR_2','MENU_200_TOUR_2','MENU_50_TOUR_2','MENU10_BT_CONNECT','MENU10_WEB_BT')
  if($UseSd){$required+=@('MENU10_SD_DAC','MENU10_WEB_RETURN')}
  $missing=@($required|Where-Object {$name=$_;!@($script:Phases|Where-Object {$_.name -eq $name -and $_.result -in @('COMPLETED','COMPLETED_REVIEW_METRICS')}).Count})
  $report.test='IBT_MENU_STABILITY_10MIN';$report.target_seconds=600;$report.required_missing=$missing
  $report.active_seconds=if($script:MenuWindowStart -eq [DateTime]::MinValue){0}else{[int]($script:MenuStoppedAt-$script:MenuWindowStart).TotalSeconds}
  $report.scope='RAM-only navigation/edit/return tour and all-row rendering; destructive actions, physical rotary and BT-IN excluded. BT menu denials are not passes.'
  if($missing.Count -and $report.result -like 'COMPLETED*'){$report.result='PARTIAL_REQUIRED_PHASES_MISSING';$result=$report.result}
 }
 $report.offload_stats_complete=(@($script:Samples | Where-Object {$_.ContainsKey('PATH-DEFER') -and $_['PATH-DEFER'].complete -ne '1'}).Count -eq 0 -and @($script:Samples | Where-Object {$_.ContainsKey('PATH-DEFER')}).Count -gt 0)
 $report.sd_rejected_files=@($script:SdRejected.ToArray())
 if($Artwork60){$report.artwork_result=if($script:ArtUnavailable){'NOT_RUN_PREPARE_DENIED'}else{'REVIEW_METRICS_REQUIRED'};$report.bt_only_fallback=[bool]$script:ArtUnavailable;$report.artwork_phases=@($script:ArtRows.ToArray());$report.artwork_scope='Frozen JPEG decoded and painted repeatedly; no cover download during BT measurement';$report.target_seconds=3600;$report.artwork_control='Same PSRAM allocation OFF/ON';$script:ArtRows.ToArray() | Export-Csv (Join-Path $out 'ARTWORK_SUMMARY.csv') -NoTypeInformation -Encoding UTF8}
 if($SbcStages){$report.test='IBT_SBC_STAGED_ROUTES';$report.sbc_stages=@($script:SbcRows.ToArray());$report.external_sbc_bt_send='NOT_RUN';$report.scope='Native WEB-DAC/WEB-BT32 controls with switchable synthetic baseline/encode/roundtrip shadow load; no WebUI';$report.firmware='V166-R33'}
 if($Cpu10){
  $cpu=@($script:AudioRows.ToArray()|Where-Object {($_.phase -like 'STAGE_*' -or $_.phase -in @('WEB_BT_32000','CPU_01_OFF','CPU_02_ON'))})
  $report.test='IBT_CPU_WEB_BT_10MIN';$report.audio_cpu_samples=$cpu.Count;$report.artwork=if($script:ArtUnavailable){'NOT_RUN_PREPARE_DENIED'}elseif($RowsOnly){'ON_FROZEN_ROWS_SWEEP'}else{'OFF_ON_FROZEN'};$report.artwork_phases=@($script:ArtRows.ToArray());$report.webui='OFF'
  $script:ArtRows.ToArray()|Export-Csv (Join-Path $out 'ARTWORK_SUMMARY.csv') -NoTypeInformation -Encoding UTF8
  if($result -eq 'COMPLETED_LISTENING_AND_METRICS_REVIEW_REQUIRED' -and $cpu.Count -lt 2){$result='FAIL_DIAGNOSTICS';$report.result=$result;$report.error='AUDIO_CPU_SAMPLES_MISSING'}
  if(!$script:ArtUnavailable -and $result -eq 'COMPLETED_LISTENING_AND_METRICS_REVIEW_REQUIRED'){foreach($phase in $(if($CpuStages){@((StageArtworkPlan).name)}else{@('CPU_01_OFF','CPU_02_ON')})){if(@($cpu|Where-Object {$_.phase -eq $phase}).Count -lt 2){$result='FAIL_DIAGNOSTICS';$report.result=$result;$report.error='AUDIO_CPU_PHASE_MISSING'}}}
  if($script:ArtUnavailable -and $result -eq 'COMPLETED_LISTENING_AND_METRICS_REVIEW_REQUIRED'){$result='PARTIAL_BT_COMPLETED_ARTWORK_NOT_RUN';$report.result=$result}
  $script:AudioRows.ToArray()|Export-Csv (Join-Path $out 'AUDIO_CPU_SUMMARY.csv') -NoTypeInformation -Encoding UTF8
 }
 if($CpuStages){
  $script:DisplayRows.ToArray() | Export-Csv (Join-Path $out 'DISPLAY_FRAME_SAMPLES.csv') -NoTypeInformation -Encoding UTF8
  $report.test=if($RowsOnly){'IBT_ROWS_6X120S_CORE_UNCHANGED'}elseif($BatchSweep){'IBT_BATCH_OFFLOAD_2X7_70MIN'}else{'IBT_CPU_STAGES_DISPLAY_AB_15MIN'};$report.target_seconds=if($RowsOnly){720}elseif($BatchSweep){4200}else{900};$report.cpu_stage_method='TICK_SAMPLE_ESTIMATE_NOT_EXACT_RUNTIME';$report.offload=if($RowsOnly){'DISABLED_ALL_STAGES'}elseif($BatchSweep){'MP3_DEQUANT_1_IN_8_SYNCHRONOUS'}else{'NOT_RUN_PENDING_MEASURED_STAGE_SELECTION'}
  $stageSummary=New-Object 'System.Collections.Generic.List[object]'
  $script:StageRows.ToArray() | Export-Csv (Join-Path $out 'CPU_STAGE_SAMPLES.csv') -NoTypeInformation -Encoding UTF8
  if(!$script:ArtUnavailable -and $report.result -like 'COMPLETED*'){foreach($name in @((StageArtworkPlan).name)){
   $valid=@($script:StageRows | Where-Object {$_.phase -eq $name -and $_.enabled -eq '1' -and $_.registered -eq '1' -and $_.method -eq 'TICK_SAMPLE_ESTIMATE'})
   try{$stageSummary.Add((StageSummary $valid))}catch{$valid=@()}
   if($valid.Count -lt 2){$report.result='FAIL_DIAGNOSTICS';$report.error='CPU_STAGE_SAMPLES_MISSING';$result=$report.result}
  }}
  $stageSummary.ToArray() | Export-Csv (Join-Path $out 'CPU_STAGE_SUMMARY.csv') -NoTypeInformation -Encoding UTF8
 }
 if($DequantAB){
  $report.test='IBT_MP3_DEQUANT_CORE_AB_6MIN';$report.target_seconds=360;$report.target_core1='BELOW_90_PERCENT';$report.artwork='OFF_NO_PREPARE';$report.webui='OFF';$report.offload='MP3_DEQUANT_1_IN_8_OFF_ON_OFF';$report.performance_pass='NOT_AUTOMATIC_AUDIO_REVIEW_REQUIRED'
  $script:AudioRows.ToArray()|Export-Csv (Join-Path $out 'AUDIO_CPU_SUMMARY.csv') -NoTypeInformation -Encoding UTF8
  if($result -like 'COMPLETED*'){foreach($part in @(DequantPlan)){if(@($script:AudioRows|Where-Object {$_.phase -eq $part.name}).Count -lt 2){$result='FAIL_DIAGNOSTICS';$report.result=$result;$report.error='DQ_AUDIO_CPU_PHASE_MISSING'}}}
 }

 $report | ConvertTo-Json -Depth 12 | Set-Content (Join-Path $out 'RESULT.json') -Encoding UTF8
 if($NoBtHour){
  $report.requested_minutes=$Minutes;$report.profile=$Profile;$report.bt_enabled=$UseBt;$report.web_enabled=$UseWeb;$report.sd_enabled=$UseSd
  $report.sd_requested=$(if($FullProfile){$true}else{$UseSd});$report.sd_skipped_reason=$script:SdSkippedReason
  $report.web_skipped_reason=$script:WebSkippedReason
  $report.web_test=$(if($ConcurrentWeb -and !$script:WebDisabled){'WebSocket volume probes including BT; firmware guards retained'}elseif($FullNoWeb){'DISABLED_BY_REQUEST'}elseif(!$UseWeb){'NOT_SELECTED'}elseif($script:WebDisabled){'NOT_RUN_UNREACHABLE'}else{'WebSocket volume, DAC phases only'})
   $report.physical_rotary='NOT_AUTOMATED';$report.scope=$(if($FullNoWeb){'R18 full menu rendering 111 rows 500..50ms, non-destructive menu tour, WEB/SD DAC/BT; WebUI disabled; BT-IN and destructive actions not automated'}elseif($FullProfile){'V166-R7: all 111 menu rows render-scanned at 500..50 ms; no menu actions; DAC/SD/WEB/BT and WebUI only on DAC'}elseif($Bt60){'WEB to saved BT hold for requested minutes; no menu, SD or WebUI control'}elseif($Profile -eq 7){'Timed WEB/SD, DAC/BT and menu stress; WebUI disabled; firmware guards retained'}else{'Menu injection, DAC, WEB/SD, web volume; not every feature'})
  if($FullProfile -or $RateCompare){$report.source_preflight_cycles=if($UseSd){10}else{0};$report.source_preflight_transitions=if($UseSd){40}else{0}}
  $report | ConvertTo-Json -Depth 12 | Set-Content (Join-Path $out 'RESULT.json') -Encoding UTF8
 }
 if($SbcStages){$report.scope='Native WEB-DAC/WEB-BT32 controls with switchable synthetic baseline/encode/roundtrip shadow load; no WebUI';$report | ConvertTo-Json -Depth 12 | Set-Content (Join-Path $out 'RESULT.json') -Encoding UTF8}
 @($script:Samples.ToArray()) | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $out 'SAMPLES.json') -Encoding UTF8
 $summary=@(foreach($group in ($script:Samples | Group-Object {$_['phase']})){
  $loads=@($group.Group | Where-Object {$_.ContainsKey('LOAD') -and $_['LOAD'].result -eq 'OK'})
  $r=[ordered]@{phase=$group.Name;samples=$group.Count;load_samples=$loads.Count;core0_percent=$null;core1_percent=$null;underruns_delta=$null;dropped_bytes_delta=$null;counter_reset=$false}
  if($loads.Count){foreach($core in 0..1){$r["core${core}_percent"]=[Math]::Round((($loads | ForEach-Object {[double]$_['LOAD']["core${core}_permille"]} | Measure-Object -Average).Average/10),2)}}
  $first=$group.Group[0]['BT-AUDIO'];$last=$group.Group[-1]['BT-AUDIO']
  foreach($key in @('underruns','dropped_bytes')){if($first.ContainsKey($key) -and $last.ContainsKey($key)){
   $delta=[double]$last[$key]-[double]$first[$key];if($delta -lt 0){$r.counter_reset=$true}else{$r[$key+'_delta']=$delta}
  }}
  [pscustomobject]$r
 })
 $rateReport=@(foreach($g in ($script:Samples | Where-Object {$_['phase'] -match '^(WEB_BT_(32000|44100)|ART_0[1-6]_(OFF|ON))$'} | Group-Object {$_['phase']})){
  $rows=@($g.Group);$base=$rows[0];$last=$rows[-1];$start=[datetime]$base.utc
  $firstUnder=@($rows | Where-Object {[long]$_['BT-AUDIO'].underruns -gt [long]$base['BT-AUDIO'].underruns} | Select-Object -First 1)
  $firstEmpty=@($rows | Where-Object {[long]$_['PATH-STATE'].input_buffer -eq 0} | Select-Object -First 1)
  [pscustomobject]@{phase=$g.Name;sample_seconds=([datetime]$last.utc-$start).TotalSeconds;first_underrun_observed_seconds=$(if($firstUnder.Count){([datetime]$firstUnder[0].utc-$start).TotalSeconds}else{$null});first_empty_input_observed_seconds=$(if($firstEmpty.Count){([datetime]$firstEmpty[0].utc-$start).TotalSeconds}else{$null});input_min=($rows | ForEach-Object {[long]$_['PATH-STATE'].input_buffer}|Measure-Object -Minimum).Minimum;pcm_min=($rows|ForEach-Object {[long]$_['BT-AUDIO'].tx_buffer}|Measure-Object -Minimum).Minimum;requested_delta=([long]$last['BT-AUDIO'].requested_bytes-[long]$base['BT-AUDIO'].requested_bytes);delivered_delta=([long]$last['BT-AUDIO'].delivered_bytes-[long]$base['BT-AUDIO'].delivered_bytes);underruns_delta=([long]$last['BT-AUDIO'].underruns-[long]$base['BT-AUDIO'].underruns);note='First observed in periodic sample, not exact acoustic gap time; Wi-Fi on; SD-BT Wi-Fi-off and BT-IN-DAC NOT_RUN'}
 })
 $rateReport | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $out 'RATE_COMPARISON.json') -Encoding UTF8
 $summary | Export-Csv (Join-Path $out 'LOAD_SUMMARY.csv') -NoTypeInformation -Encoding UTF8
 # The parent owns launcher.log and is still writing it. It adds final hashes
 # and the complete archive after closing its writers.
 $closedFiles=@(Get-ChildItem $out -File | Where-Object {$_.Name -notin @('launcher.log','stdout.log','stderr.log','HASHES.json')})
 $closedFiles | Get-FileHash -Algorithm SHA256 | Select-Object @{n='file';e={Split-Path $_.Path -Leaf}},Hash | ConvertTo-Json | Set-Content (Join-Path $out 'HASHES.json') -Encoding UTF8
 $closedPaths=@($closedFiles.FullName)+(Join-Path $out 'HASHES.json')
 Compress-Archive -LiteralPath $closedPaths -DestinationPath ($out+'.zip') -Force
 Copy-Item -LiteralPath $closedPaths -Destination $back -Force
 Copy-Item -LiteralPath ($out+'.zip') -Destination ($back+'.zip') -Force
 Write-Host ('[KESZ] '+$result);Write-Host ('Visszakuldendo: '+$back+'.zip')
}
if($Automatic){if($result -eq 'ABORTED_USER'){exit 2};if($result -eq 'NOT_RUN_STARTUP'){exit 3};if($result -eq 'COMPLETED_LISTENING_AND_METRICS_REVIEW_REQUIRED'){exit 0};exit 1}




