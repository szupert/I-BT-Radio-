@echo off
chcp 65001 >nul
echo I-BT-Radio R30 - 12 perc artwork sorcsomag kontroll
echo 4 / 8 / 16 / 32 / 64 / 128 sor; 2 perc meretenkent.
echo Artwork vegig BE. MP3 offload vegig KI. WebUI nincs. BT 32kHz.
echo G: hallott kihagyas, Q: leallitas. Indulas kulon ido.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_stress_logged.ps1" -RowsOnly -Minutes 12 -ReturnRoot "%~dp0..\RETURN_TO_EVA"
echo A naplo es ZIP a RETURN_TO_EVA mappaban talalhato.
pause
