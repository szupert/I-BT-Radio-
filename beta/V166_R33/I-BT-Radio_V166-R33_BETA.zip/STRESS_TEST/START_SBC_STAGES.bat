@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_stress_logged.ps1" -SbcStages -ReturnRoot "%~dp0..\RETURN_TO_EVA"
pause
