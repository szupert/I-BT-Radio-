@echo off
chcp 65001 >nul
echo I-BT-Radio R25 - 10 perc CPU kontroll: Budapest Rock / BT 32kHz
echo 5 perc artwork KI, majd 5 perc BE; WebUI nelkul. G: hallott kihagyas, Q: leallitas.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_stress_logged.ps1" -Cpu10 -Minutes 10 -ReturnRoot "%~dp0..\RETURN_TO_EVA"
echo A naplo es ZIP a RETURN_TO_EVA mappaban talalhato.
pause
