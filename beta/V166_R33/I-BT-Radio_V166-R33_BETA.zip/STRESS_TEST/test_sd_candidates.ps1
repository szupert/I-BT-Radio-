﻿$ErrorActionPreference='Stop'
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'full_menu_stress.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Runner syntax error'}
$f=$ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)|Where-Object {$_.Name -eq 'SwitchAndVerify'}|Select-Object -First 1
Invoke-Expression $f.Extent.Text
function Status {return @{station=[string]$script:StartIndex}}
function Request($command,$pattern){return 'catalog'}
function Fields($text){return @{mounted='1';catalog='1';tracks=[string]$script:Count}}
function Record($text){}
function SwitchAndVerifyOnce($source,$resumeStation=0,$sdTrack=0){
 $index=if($sdTrack){$sdTrack}else{$script:StartIndex}
 $script:Calls.Add($index);$script:CurrentTrackName='track'+$index+'.wav'
 if($script:Fault){throw $script:Fault}
 if($index -ne $script:Playable){throw 'SD_AUDIO_HEADER_INVALID'}
}
function ResetMock($count,$playable){
 $script:Count=$count;$script:Playable=$playable;$script:Fault='';$script:StartIndex=3
 $script:Calls=New-Object 'System.Collections.Generic.List[int]'
 $script:SdRejected=New-Object 'System.Collections.Generic.List[object]'
}
ResetMock 7 3;SwitchAndVerify 'sd'
if($script:Calls.Count -ne 1 -or $script:SdRejected.Count){throw 'Initial success changed'}
ResetMock 7 5;SwitchAndVerify 'sd'
if(($script:Calls -join ',') -ne '3,4,5' -or $script:SdRejected.Count -ne 2 -or $script:SdRejected[1].name -ne 'track4.wav'){throw 'Candidate order/name failure'}
ResetMock 7 0;$caught=$false
try{SwitchAndVerify 'sd'}catch{if($_.Exception.Message -eq 'SD_NO_PLAYABLE_FILES'){$caught=$true}else{throw}}
if(!$caught -or ($script:Calls -join ',') -ne '3,4,5,6,7,1,2'){throw 'Not exactly one catalog pass'}
ResetMock 1 0;$script:StartIndex=1;$caught=$false
try{SwitchAndVerify 'sd'}catch{if($_.Exception.Message -eq 'SD_NO_PLAYABLE_FILES'){$caught=$true}else{throw}}
if(!$caught -or $script:Calls.Count -ne 1){throw 'Single file repeated'}
foreach($caseFault in @('RADIO_FAULT','SOURCE_PROGRESS_TIMEOUT')){
 ResetMock 7 0;$script:Fault=$caseFault;$caught=$false
 try{SwitchAndVerify 'sd'}catch{if($_.Exception.Message -eq $caseFault){$caught=$true}else{throw}}
 if(!$caught -or $script:Calls.Count -ne 1){throw 'Unrelated failure swallowed'}
}
ResetMock 7 0;$caught=$false
try{SwitchAndVerify 'web'}catch{if($_.Exception.Message -eq 'SD_AUDIO_HEADER_INVALID'){$caught=$true}else{throw}}
if(!$caught -or $script:Calls.Count -ne 1){throw 'Web retried as SD'}
Write-Host 'PASS: real SD fallback function, file names, bounded wrap and unrelated faults; no COM.'

