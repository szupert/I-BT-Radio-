﻿$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Utility') -ErrorAction Stop
Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Archive') -ErrorAction Stop
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'full_menu_stress.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Runner syntax error'}
$f=$ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)|Where-Object Name -eq 'Status'|Select-Object -First 1
Invoke-Expression $f.Extent.Text
function Record($s){}
function Pump($ms){if($script:PumpFault){throw $script:PumpFault}}
function ValidState($s){return $s -eq 'VALID'}
function Fields($s){return @{playing='1'}}
function Request($cmd,$pattern){
 $script:Calls++;$v=$script:Replies[[Math]::Min($script:Calls-1,$script:Replies.Count-1)]
 if($v -ne 'VALID' -and $v -ne 'MALFORMED'){throw $v};return $v
}
function Reset($replies){$script:Replies=$replies;$script:Calls=0;$script:PumpFault=''}
Reset @('NO_RESPONSE: r10 path status','VALID');$s=Status
if($s.playing -ne '1' -or $script:Calls -ne 2){throw 'Delayed ready failed'}
Reset @('NO_RESPONSE: r10 path status');$caught=$false
try{Status}catch{if($_.Exception.Message -eq 'NO_RESPONSE: r10 path status'){$caught=$true}else{throw}}
if(!$caught -or $script:Calls -ne 3){throw 'Unbounded silence'}
foreach($fault in @('RADIO_FAULT','USER_STOP','LOG_SIZE_LIMIT','COMMAND_DENIED')){
 Reset @($fault);$caught=$false
 try{Status}catch{if($_.Exception.Message -eq $fault){$caught=$true}else{throw}}
 if(!$caught -or $script:Calls -ne 1){throw 'Real fault retried'}
}
Reset @('NO_RESPONSE: r10 path status');$script:PumpFault='RADIO_FAULT';$caught=$false
try{Status}catch{if($_.Exception.Message -eq 'RADIO_FAULT'){$caught=$true}else{throw}}
if(!$caught -or $script:Calls -ne 1){throw 'Fault during wait swallowed'}
Reset @('MALFORMED');$caught=$false
try{Status}catch{if($_.Exception.Message -eq 'MALFORMED_STATE_REPEATED'){$caught=$true}else{throw}}
if(!$caught -or $script:Calls -ne 3){throw 'Malformed accepted'}
# Reproduce the real parent transcript lock and exercise the child exclusion.
$dir=Join-Path ([IO.Path]::GetTempPath()) ('ibt-log-'+[guid]::NewGuid())
New-Item -ItemType Directory $dir|Out-Null
$writer=[IO.StreamWriter]::new((Join-Path $dir 'launcher.log'))
try{
 'closed'|Set-Content (Join-Path $dir 'serial.log')
 $closedFiles=@(Get-ChildItem $dir -File|Where-Object {$_.Name -notin @('launcher.log','HASHES.json')})
 if($closedFiles.Count -ne 1){throw 'Open transcript included'}
 $closedFiles|Get-FileHash|Out-Null
 Compress-Archive -LiteralPath $closedFiles.FullName -DestinationPath (Join-Path $dir 'test.zip')
}finally{$writer.Dispose()}
# Nonrecursive exact paths only; no user data involved.
foreach($name in @('launcher.log','serial.log','test.zip')){Remove-Item -LiteralPath (Join-Path $dir $name)}
Remove-Item -LiteralPath $dir
Write-Host 'PASS: delayed state, bounded silence, real faults, malformed replies and open transcript exclusion; no COM.'
