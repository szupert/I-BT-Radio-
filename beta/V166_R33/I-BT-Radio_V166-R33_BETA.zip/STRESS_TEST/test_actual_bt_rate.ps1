﻿$ErrorActionPreference='Stop'
$t=$null;$e=$null
$a=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'full_menu_stress.ps1'),[ref]$t,[ref]$e)
if($e.Count){throw 'Syntax error'}
$f=$a.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)|Where-Object Name -eq 'AssertActualBtRate'|Select-Object -First 1
Invoke-Expression $f.Extent.Text
AssertActualBtRate @{'BT-AUDIO'=@{rate='32000';codec_ok='1'}} 32000
foreach($case in @(@{rate='44100';codec_ok='1'},@{rate='48000';codec_ok='1'},@{rate='bad';codec_ok='1'},@{codec_ok='1'},@{rate='32000';codec_ok='0'})){
 $rejected=$false
 try{AssertActualBtRate @{'BT-AUDIO'=$case} 32000}catch{$rejected=$true}
 if(!$rejected){throw 'Invalid actual rate accepted'}
}
Write-Host 'PASS: negotiated 32000 only; 44100/48000/malformed/missing/codec failure rejected. No COM.'

# Execute the real Observe path: a requested 32k state cannot hide an actual 44.1k connection.
foreach($name in @('Observe','ExpectedBtRate')){
 $f=$a.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$true)|Where-Object Name -eq $name|Select-Object -First 1
 Invoke-Expression $f.Extent.Text
}
$NoBtHour=$false;$script:ExpectedStation=0;$script:ProbeRate='rate32';$script:Phase='MOCK'
function Sample {return @{'PATH-STATE'=@{active='1';playing='1';web='1';route='1';rate='32000';transmitting='1'};'BT-AUDIO'=@{rate='44100';codec_ok='1'}}}
function Pump($ms){throw 'Invalid rate was not rejected before polling'}
$rejected=$false
try{Observe 18000 1 1 $true}catch{if($_.Exception.Message -eq 'BT_NEGOTIATED_RATE_MISMATCH'){$rejected=$true}else{throw}}
if(!$rejected){throw '5h actual Observe gate bypassed'}
Write-Host 'PASS: actual five-hour Observe rejects requested32/negotiated44100 before polling; no COM.'
