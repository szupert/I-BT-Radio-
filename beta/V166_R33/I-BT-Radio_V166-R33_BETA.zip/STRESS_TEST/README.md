﻿# I-BT-Radio R18 tesztelők

A főmappa 6_WEB_BT_5ORA.bat fájlja 300 perc internetes rádió → Bluetooth-kimenet kontrollt indít, WebUI nélkül. A rádióra várakozás, előtöltés és kapcsolódás ezen felül van. Előbb az R18 firmware-t töltsd fel.

A teszt elindítja az internetes lejátszást, megkeresi a mentett, elérhető BT-eszközt, és ellenőrzi a tényleges 32 kHz-et, a PCM haladását és az útvonalat. A kért32/tényleges44,1 kapcsolat nem érvényes mérés. Hibát, újraindulást és PCM megállást nem rejt el.

G: hallható kihagyás megjelölése. Q: leállítás. Napló: SYSTEM/LOGS/STRESS_TEST, visszaadható másolat és ZIP: a főmappa RETURN_TO_EVA könyvtára. A teljes futás önmagában nem bizonyít szakadásmentes hangot. Statisztikai sorvesztés esetén offload_stats_complete=false.

A többi indító megmarad: rövid rátaellenőrzés, külön SBC-diagnosztika, útvonalkontroll, 20 perces baseline. A service/jelgenerátor az ötórás kontroll alatt nem aktív. Fizikai eredmény: NOT_RUN.

## Teljes stresszteszt WebUI nélkül

7_FULL_SELFTEST_WEB_NELKUL.bat: időt kér percben (60 vagy 300), automatikus rádióindítás, mentett JBL előnyben, internet/SD és DAC/BT váltás, teljes menüsor-kirajzolás 500–50 ms. Nincs WebUI-kérés és IP-bekérés. A készülék BT alatt tiltott menüköreit NOT_RUN-ként jelzi; BT-IN, fizikai rotary és romboló menüműveletek nem automatizáltak. Firmware R18 változatlan. G: hallott kihagyás; Q: leállítás. Napló és ZIP: RETURN_TO_EVA, tartós példány SYSTEM/LOGS/STRESS_TEST. Indulási/előellenőrzési idő a megadott mérési időn felül; szakasz lezárása kis túlfutást okozhat.
