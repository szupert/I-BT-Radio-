@echo off
setlocal
echo I-BT-Radio V166-R17 - kulon SBC kodolo proba
echo A teszt leallitja a lejatszast es a BT-t. Firmware-t nem tolt.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0sbc_probe.ps1" %*
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
