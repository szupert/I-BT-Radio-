@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0boot_diagnostic.ps1" -NetworkSnapshot -Seconds 120
echo.
pause
