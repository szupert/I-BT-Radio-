@echo off
chcp 65001 >nul
echo I-BT-Radio - bootdiagnosztika, 3 perc
echo Zarj be minden feltoltot es tesztet, ami a COM-portot hasznalja.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0boot_diagnostic.ps1" -Seconds 180 -ReturnRoot "%~dp0..\RETURN_TO_EVA"
echo A visszaadhato ZIP a RETURN_TO_EVA mappaba kerul.
pause
