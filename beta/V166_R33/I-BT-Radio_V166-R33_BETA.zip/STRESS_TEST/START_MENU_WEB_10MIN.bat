﻿@echo off
chcp 65001 >nul
echo I-BT-Radio R33 - menu es stabilitas 10 perc WebUI terhelessel
echo Automatikus radioinditas, menu/almenu, SD-DAC es WEB-BT32.
echo A 10 perc a radio keszenlete utan indul. Q = leallitas.
echo Naplo: SYSTEM es RETURN_TO_EVA. Firmware-feltoltes nincs.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0nonstop_cycle.ps1" -Menu10 -ConcurrentWeb -Automatic -Minutes 10
pause
