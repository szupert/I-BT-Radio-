param([switch]$DequantAB,[switch]$RowsOnly,[switch]$BatchSweep,[switch]$CpuStages,[switch]$Cpu10,[switch]$Artwork60,[switch]$FullNoWeb,[switch]$Baseline,[switch]$SbcStages,[string]$RunnerPath=(Join-Path $PSScriptRoot 'full_menu_stress.ps1'),[int]$Minutes=10,[string]$ReturnRoot=(Join-Path $PSScriptRoot '..\RETURN_TO_EVA'))
$ErrorActionPreference='Stop'
$stamp='STRESS_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff')
$out=Join-Path 'C:\esp32\SYSTEM\LOGS\STRESS_TEST' $stamp
$back=Join-Path ([IO.Path]::GetFullPath($ReturnRoot)) $stamp
New-Item -ItemType Directory -Path $out,$back -Force|Out-Null
$utf8=New-Object Text.UTF8Encoding($false)
$writers=@((New-Object IO.StreamWriter((Join-Path $out 'launcher.log'),$false,$utf8)),(New-Object IO.StreamWriter((Join-Path $back 'launcher.log'),$false,$utf8)))
foreach($w in $writers){$w.AutoFlush=$true}
$code=1;$reason='';$previous=$ErrorActionPreference
try{
 foreach($w in $writers){$w.WriteLine('START: master='+$out+'; return='+$back)}
 @{result='RUNNING_OR_INTERRUPTED';master_log=$out;flash=$false}|ConvertTo-Json|Set-Content (Join-Path $back 'RUN_STATUS.json') -Encoding UTF8
 Write-Host ('[NAPLO] '+$back)
 if($FullNoWeb -and !$PSBoundParameters.ContainsKey('Minutes')){
  $Minutes=0
  while($Minutes -lt 1 -or $Minutes -gt 1440){
   $answer=Read-Host 'Hany percig fusson? (1-1440; 5 ora = 300)'
   if(![int]::TryParse($answer,[ref]$Minutes)){$Minutes=0}
  }
 }
 # Child errors must be captured, including parameter/parser errors before its try/finally.
 $ErrorActionPreference='Continue'
 if($SbcStages){
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'sbc_probe.ps1') -MasterDirectory (Join-Path $out 'CODEC') -ReturnDirectory (Join-Path $back 'CODEC')
  if($LASTEXITCODE -ne 0){throw 'QUIET_CODEC_PREFLIGHT_FAILED'}
  $arguments=@('-SbcStages','-Automatic','-Minutes','1')
 }elseif($DequantAB){$arguments=@('-DequantAB','-Automatic','-Minutes','6')}elseif($RowsOnly){$arguments=@('-RowsOnly','-Automatic','-Minutes','12')}elseif($BatchSweep){$arguments=@('-BatchSweep','-Automatic','-Minutes','70')}elseif($CpuStages){$arguments=@('-CpuStages','-Automatic','-Minutes','15')}elseif($Cpu10){$arguments=@('-Cpu10','-Automatic','-Minutes','10')}elseif($Artwork60){$arguments=@('-Artwork60','-Automatic','-Minutes','60')}elseif($FullNoWeb){$arguments=@('-FullNoWeb','-Automatic','-Minutes',"$Minutes")}elseif($Baseline){$arguments=@('-Baseline','-FullProfile','-Automatic','-Minutes','20')}else{$arguments=@('-RateCompare','-Automatic','-Minutes',"$Minutes")}
 & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $RunnerPath @arguments -OutputDirectory $out -ReturnDirectory $back 2>&1 | ForEach-Object {
  $line=[string]$_
  $line=[regex]::Replace($line,'\b(?:\d{1,3}\.){3}\d{1,3}\b','<IP>')
  $line=[regex]::Replace($line,'(?i)\b(ssid|password|passwd|token|authorization)\b.*','$1=<redacted>')
  foreach($w in $writers){$w.WriteLine($line)}
  Write-Host $line
 }
 $code=$LASTEXITCODE
 if($code -ne 0){$reason='RUNNER_EXIT_'+$code}
}catch{$reason=$_.Exception.Message;$code=1;foreach($w in $writers){$w.WriteLine('[LAUNCHER_ERROR] '+$reason)}}
finally{
 $ErrorActionPreference='Stop'
 foreach($w in $writers){$w.Dispose()}
 if(!(Test-Path (Join-Path $out 'RESULT.json'))){
  @{result='INCOMPLETE_RUNNER';error=$reason;exit_code=$code;physical_audio='NOT_EVALUATED';flash=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'RESULT.json') -Encoding UTF8
 }
 if($SbcStages -and (Test-Path (Join-Path $out 'CODEC/RESULT.json'))){
  $result=Get-Content (Join-Path $out 'RESULT.json') -Raw|ConvertFrom-Json
  $quiet=Get-Content (Join-Path $out 'CODEC/RESULT.json') -Raw|ConvertFrom-Json
  $result|Add-Member -Force NoteProperty quiet_codec $quiet
  $rows=New-Object 'Collections.Generic.List[object]'
  foreach($stage in @('BASELINE','ENCODE','ROUNDTRIP')){
   $f=@{};foreach($m in [regex]::Matches([string]$quiet.CPU_phases.$stage,'(\w+)=([^\s]+)')){$f[$m.Groups[1].Value]=$m.Groups[2].Value}
   $rows.Add([pscustomobject]@{route='QUIET';stage=$stage;result=$(if($f.result){$f.result}else{'NOT_RUN'});task_permille=$f.task_permille;core0_permille=$f.core0_permille;core1_permille=$f.core1_permille;deadline_misses=$f.deadline_misses;native_underrun_delta='';external_bt_send='NOT_RUN'})
  }
  foreach($route in @('DAC','BT')){foreach($stage in @('BASELINE','ENCODE','ROUNDTRIP')){
   $r=@($result.sbc_stages|Where-Object {$_.route -eq $route -and $_.stage -eq $stage})|Select-Object -First 1
   $rows.Add([pscustomobject]@{route=$route;stage=$stage;result=$(if($r){$r.result}else{'NOT_RUN'});task_permille=$r.cpu.task_permille;core0_permille=$r.cpu.core0_permille;core1_permille=$r.cpu.core1_permille;deadline_misses=$r.cpu.deadline_misses;native_underrun_delta=$r.native_underrun_delta;external_bt_send='NOT_RUN'})
  }}
  foreach($row in $rows){
   $routeControl=@($rows|Where-Object {$_.route -eq $row.route -and $_.stage -eq 'BASELINE'})|Select-Object -First 1
   $delta=$null
   if($row.result -ne 'NOT_RUN' -and $routeControl.result -ne 'NOT_RUN'){$delta=[int]$row.task_permille-[int]$routeControl.task_permille}
   $row|Add-Member NoteProperty task_delta_permille $delta
  }
  $rows|Export-Csv (Join-Path $out 'COMPARISON.csv') -NoTypeInformation -Encoding UTF8
  $result|ConvertTo-Json -Depth 16|Set-Content (Join-Path $out 'RESULT.json') -Encoding UTF8
 }
 if($Baseline){
  $report=Get-Content (Join-Path $out 'RESULT.json') -Raw|ConvertFrom-Json
  $inventory=Get-Content (Join-Path $PSScriptRoot 'NETWORK_FEATURE_MATRIX.json') -Raw|ConvertFrom-Json
  $report|Add-Member -Force NoteProperty runner_revision 'R19_PREBUFFER25_FULL_NO_WEB'
  $report|Add-Member -Force NoteProperty runner_sha256 (Get-FileHash -LiteralPath $RunnerPath -Algorithm SHA256).Hash
  $report|Add-Member -Force NoteProperty build_id (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot '..\INSTALLER\firmware.bin') -Algorithm SHA256).Hash
  $report|Add-Member -Force NoteProperty roadmap_revision 'R06-DRAFT'
  $report|Add-Member -Force NoteProperty network_profile 'IPV4_MINIMAL_R14'
  $report|Add-Member -Force NoteProperty firmware_version 'V166-R22'
  $report|Add-Member -Force NoteProperty framework_version '3.3.11'
  $report|Add-Member -Force NoteProperty sdk_idf_version '5.5.5'
  $report|Add-Member -Force NoteProperty qualification 'PARTIAL_COVERAGE_NOT_FULL_R06_QUALIFICATION'
  $report|Add-Member -Force NoteProperty coverage_limits @('BT-IN not automated','Codec testpack not integrated','BT WebUI blocked by existing firmware','Menu rendering tour is not every destructive menu action','Requested20min measurement excludes startup/preflight; phase boundaries may overrun')
  $report|ConvertTo-Json -Depth 16|Set-Content (Join-Path $out 'RESULT.json') -Encoding UTF8
  Copy-Item (Join-Path $PSScriptRoot 'NETWORK_FEATURE_MATRIX.json') $out -Force
 }
 $finished=Get-Content (Join-Path $out 'RESULT.json') -Raw|ConvertFrom-Json
 @{result=$finished.result;exit_code=$code;master_log=$out}|ConvertTo-Json|Set-Content (Join-Path $out 'RUN_STATUS.json') -Encoding UTF8
 @{exit_code=$code;error=$reason;completed_utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'LAUNCHER_RESULT.json') -Encoding UTF8
 Get-ChildItem $out -File -Recurse|Where-Object {$_.Name -ne 'HASHES.json'}|Get-FileHash -Algorithm SHA256|Select-Object @{n='file';e={$_.Path.Substring($out.Length+1)}},Hash|ConvertTo-Json|Set-Content (Join-Path $out 'HASHES.json') -Encoding UTF8
 Copy-Item -Path (Join-Path $out '*') -Destination $back -Force -Recurse
 Compress-Archive -Path (Join-Path $out '*') -DestinationPath ($out+'.zip') -Force
 Copy-Item -LiteralPath ($out+'.zip') -Destination ($back+'.zip') -Force
 Write-Host ('[VISSZAKULDENDO] '+$back+'.zip')
 $ErrorActionPreference=$previous
}
exit $code

