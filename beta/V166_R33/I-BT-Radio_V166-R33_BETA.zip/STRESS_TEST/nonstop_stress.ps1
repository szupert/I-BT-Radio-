﻿param([ValidateRange(1,600)][int]$Minutes=600,[switch]$SelfTest,[string]$ReturnRoot=(Join-Path $PSScriptRoot '..\RETURN_TO_EVA'))
$ErrorActionPreference='Stop'
function CyclePlan([int]$number){if($number%2 -eq 1){return @{name='FULL_SELFTEST_WEB_BT_SD_DAC';args=@('-FullProfile','-Automatic','-ConcurrentWeb','-Minutes','10');cap=2100}};return @{name='WEB_BT_WEBUI_HOLD';args=@('-Bt60','-Automatic','-ConcurrentWeb','-Minutes','10');cap=900}}
function RetryAllowed([DateTime]$now,[DateTime]$end,[bool]$stopped){return !$stopped -and $now -lt $end}
function Mask([string]$line){$line=[regex]::Replace($line,'\b(?:\d{1,3}\.){3}\d{1,3}\b','<IP>');return [regex]::Replace($line,'(?i)\b(ssid|password|passwd|token|authorization)\b.*','$1=<redacted>')}
if($SelfTest){
 $a=CyclePlan 1;$c=CyclePlan 2;if($a.args -notcontains '-FullProfile' -or $c.args -notcontains '-Bt60' -or $a.args -notcontains '-ConcurrentWeb' -or $c.args -notcontains '-ConcurrentWeb'){throw 'PLAN'}
 $now=[DateTime]::UtcNow;if(!(RetryAllowed $now ($now.AddSeconds(1)) $false) -or (RetryAllowed $now $now $false) -or (RetryAllowed $now ($now.AddHours(10)) $true)){throw 'STOP_POLICY'}
 if((Mask 'ssid=private password=secret 192.168.1.12') -match 'private|secret|192.168'){throw 'REDACTION'}
 Write-Output 'PASS nonstop plan, continue-after-error policy, stop/deadline and redaction; no COM.';exit 0
}
# Refuse overlapping hardware runners. This process never opens COM itself.
$others=@(Get-CimInstance Win32_Process | Where-Object {$_.ProcessId -ne $PID -and $_.Name -match 'powershell|python' -and $_.CommandLine -match '(-File\s+.*(full_menu_stress|full_dequant_stress|nonstop_cycle|nonstop_stress)|update\.py)'})
if($others.Count){throw 'ANOTHER_RADIO_RUNNER_ACTIVE'}
$stamp='NONSTOP_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff');$master=Join-Path 'C:\esp32\SYSTEM\LOGS\STRESS_TEST' $stamp;$back=Join-Path ([IO.Path]::GetFullPath($ReturnRoot)) $stamp
New-Item -ItemType Directory -Force -Path $master,$back|Out-Null
$stop=Join-Path $back 'STOP_REQUEST';$stopper=Join-Path ([IO.Path]::GetFullPath($ReturnRoot)) 'STOP_NONSTOP.bat'
[IO.File]::WriteAllText($stopper,"@echo off`r`necho stop> `"$stop`"`r`n",[Text.Encoding]::ASCII)
$start=[DateTime]::UtcNow;$end=$start.AddMinutes($Minutes);$cycles=New-Object 'Collections.Generic.List[object]';$reason='MAX_DURATION';$n=0;$process=$null;$stopping=$false
function Note($s){$line=[DateTime]::UtcNow.ToString('o')+' '+(Mask $s);Add-Content -LiteralPath (Join-Path $master 'supervisor.log') -Value $line -Encoding UTF8;Add-Content -LiteralPath (Join-Path $back 'supervisor.log') -Value $line -Encoding UTF8;Write-Host $line}
function SaveCycle($folder,$dest){
 foreach($file in @('stdout.log','stderr.log')){$p=Join-Path $folder $file;if(Test-Path $p){$lines=Get-Content $p | ForEach-Object {Mask ([string]$_)};[IO.File]::WriteAllLines($p,[string[]]$lines,(New-Object Text.UTF8Encoding($false)))}}
 if(!(Test-Path (Join-Path $folder 'RESULT.json'))){@{result='INCOMPLETE_CHILD';physical_audio='NOT_EVALUATED';flash=$false}|ConvertTo-Json|Set-Content (Join-Path $folder 'RESULT.json') -Encoding UTF8}
 Get-ChildItem -LiteralPath $folder -File | Where-Object {$_.Name -ne 'HASHES.json'} | ForEach-Object {[pscustomobject]@{file=$_.Name;sha256=(Get-FileHash $_.FullName -Algorithm SHA256).Hash}} | ConvertTo-Json | Set-Content (Join-Path $folder 'HASHES.json') -Encoding UTF8
 New-Item -ItemType Directory -Force -Path $dest|Out-Null;Get-ChildItem -LiteralPath $folder -File | Copy-Item -Destination $dest -Force
}
try{
 Note ('START max_minutes='+$Minutes+' Q=stop; stop_bat='+$stopper+'; return='+$back)
 @{result='RUNNING';deadline_utc=$end.ToString('o');flash=$false}|ConvertTo-Json|Set-Content (Join-Path $back 'RUN_STATUS.json') -Encoding UTF8
 while(RetryAllowed ([DateTime]::UtcNow) $end $stopping){
  if(Test-Path $stop){$reason='USER_STOP';break}
  $n++;$plan=CyclePlan $n;$folder=Join-Path $master ('CYCLE_{0:D4}' -f $n);$dest=Join-Path $back ('CYCLE_{0:D4}' -f $n);New-Item -ItemType Directory -Force -Path $folder,$dest|Out-Null
  $cap=[DateTime]::UtcNow.AddSeconds($plan.cap);if($cap -gt $end){$cap=$end};$soft=$cap.AddSeconds(-45)
  if($soft -le [DateTime]::UtcNow){$reason='MAX_DURATION';break}
  $cycleStop=Join-Path $folder 'STOP_REQUEST';$child=Join-Path $PSScriptRoot 'nonstop_cycle.ps1'
  $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$child+'"'))+$plan.args+@('-StopFile',('"'+$cycleStop+'"'),'-DeadlineUtc',$soft.ToString('o'),'-OutputDirectory',('"'+$folder+'"'),'-ReturnDirectory',('"'+$dest+'"'))
  Note ('CYCLE '+$n+' '+$plan.name+' deadline='+$cap.ToString('o'))
  $process=Start-Process powershell.exe -ArgumentList $arguments -WindowStyle Hidden -RedirectStandardOutput (Join-Path $folder 'stdout.log') -RedirectStandardError (Join-Path $folder 'stderr.log') -PassThru
  $childHandle=$process.Handle # Cache native handle before the child exits; ExitCode otherwise may be null.
  $last='';$forced=$false
  while(!$process.HasExited){
   if(Test-Path $stop){if(!$stopping){$cancelCap=[DateTime]::UtcNow.AddSeconds(45);if($cancelCap -lt $cap){$cap=$cancelCap}};$stopping=$true;$reason='USER_STOP';Set-Content -LiteralPath $cycleStop -Value stop}
   if(!$stopping -and ![Console]::IsInputRedirected -and [Console]::KeyAvailable){$key=[Console]::ReadKey($true);if($key.Key -eq 'G'){Note ('HEARD_GAP cycle='+$n)};if($key.Key -eq 'Q'){$cancelCap=[DateTime]::UtcNow.AddSeconds(45);if($cancelCap -lt $cap){$cap=$cancelCap};$stopping=$true;$reason='USER_STOP';Set-Content $cycleStop stop}}
   if([DateTime]::UtcNow -ge $soft -or $stopping){if(!(Test-Path $cycleStop)){Set-Content $cycleStop stop}}
   if([DateTime]::UtcNow -ge $cap){$forced=$true;Stop-Process -Id $process.Id -Force;break}
   $line=Get-Content (Join-Path $folder 'stdout.log') -Tail 1 -ErrorAction SilentlyContinue;if($line -and $line -ne $last){$last=$line;Write-Host (Mask $line)}
   Start-Sleep -Milliseconds 500;$process.Refresh()
  }
  $process.WaitForExit();$exitCode=$process.ExitCode;if($null -eq $exitCode){throw 'CHILD_EXIT_CODE_UNAVAILABLE'};$process.Dispose();$process=$null
  SaveCycle $folder $dest;$result=Get-Content (Join-Path $folder 'RESULT.json') -Raw|ConvertFrom-Json
  $cycles.Add([pscustomobject]@{cycle=$n;plan=$plan.name;exit_code=$exitCode;forced=$forced;result=$result.result;error=$result.error;path=(Split-Path $dest -Leaf)})
  Note ('CYCLE_END '+$n+' result='+$result.result+' forced='+$forced+'; next cycle continues even after error')
  $cycles|ConvertTo-Json -Depth 6|Set-Content (Join-Path $back 'CYCLES.json') -Encoding UTF8
  # 60s backoff also permits a firmware diagnostic lease to expire after a killed child.
  for($i=0;$i -lt 120 -and (RetryAllowed ([DateTime]::UtcNow) $end $stopping);$i++){
   if(Test-Path $stop){$stopping=$true;$reason='USER_STOP';break}
   if(![Console]::IsInputRedirected -and [Console]::KeyAvailable){if([Console]::ReadKey($true).Key -eq 'Q'){$stopping=$true;$reason='USER_STOP';break}}
   Start-Sleep -Milliseconds 500
  }
 }
}catch{$reason='SUPERVISOR_ERROR';Note ('ERROR '+$_.Exception.Message)}
finally{
 if($process -and !$process.HasExited){Set-Content $cycleStop stop;if(!$process.WaitForExit(10000)){Stop-Process -Id $process.Id -Force};SaveCycle $folder $dest}
 $summary=@{result=$(if($reason -eq 'SUPERVISOR_ERROR'){'FAIL_SUPERVISOR'}else{'COMPLETED_REVIEW_REQUIRED'});stop_reason=$reason;elapsed_seconds=[int]([DateTime]::UtcNow-$start).TotalSeconds;limit_minutes=$Minutes;cycles=@($cycles.ToArray());physical_audio='USER_REVIEW_REQUIRED';flash=$false;scope='Menu/submenu render selftest 500..50ms, SD/WEB DAC/BT and WebUI probes; destructive actions and BT-IN not automated; failed cycles remain failed'}
 $summary|ConvertTo-Json -Depth 10|Set-Content (Join-Path $master 'RESULT.json') -Encoding UTF8;Copy-Item (Join-Path $master 'RESULT.json') $back -Force
 Copy-Item (Join-Path $master 'RESULT.json') (Join-Path $back 'RUN_STATUS.json') -Force
 Get-ChildItem -LiteralPath $back -Recurse -File | Where-Object {$_.Name -ne 'HASHES.json'} | ForEach-Object {[pscustomobject]@{file=$_.FullName.Substring($back.Length+1);sha256=(Get-FileHash $_.FullName -Algorithm SHA256).Hash}} | ConvertTo-Json | Set-Content (Join-Path $back 'HASHES.json') -Encoding UTF8
 try{Add-Type -AssemblyName System.IO.Compression.FileSystem;[IO.Compression.ZipFile]::CreateFromDirectory($back,$back+'.zip')}catch{Note ('ZIP_ERROR '+$_.Exception.Message)}
 Write-Host ('VEGE: '+$reason+'; eredmeny='+$back)
}
