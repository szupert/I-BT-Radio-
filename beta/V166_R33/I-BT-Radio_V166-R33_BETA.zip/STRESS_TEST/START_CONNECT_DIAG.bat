@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0boot_diagnostic.ps1" -ConnectCheck -Seconds 180
echo.
pause
