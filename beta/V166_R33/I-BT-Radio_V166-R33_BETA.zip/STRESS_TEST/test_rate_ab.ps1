﻿$ErrorActionPreference='Stop'
$s=Get-Content (Join-Path $PSScriptRoot 'full_menu_stress.ps1') -Raw
$a=$s.IndexOf('  if($RateCompare){');$b=$s.IndexOf('  }else{',$a)
$block=$s.Substring($a,$b-$a)+'  }'
$RateCompare=$true;$initial=@{station=8};$script:selectedIndex=-1;$savedIndices=@(0,1);$Minutes=10;$script:rate=0
$script:commands=New-Object 'System.Collections.Generic.List[string]'
$script:phases=New-Object 'System.Collections.Generic.List[string]'
function Ack($v){$script:commands.Add($v);if($v -eq 'rate32'){$script:rate=32000};if($v -eq 'rate44'){$script:rate=44100}}
function Send($v){$script:commands.Add($v)}
function WaitState($predicate,$seconds){return @{route=0;idle=1}}
function Status {return @{rate=$script:rate;station=8}}
function WaitWebDacReady($s,$seconds){return $s}
function WaitBtPlayback{}
function Request($cmd,$pattern){}
function Record($text){}
function Phase($name,$body){$script:phases.Add($name);& $body}
function Sample {return @{'BT-AUDIO'=@{rate='32000';codec_ok='1'}}}
function AssertActualBtRate($row,$rate){if($row['BT-AUDIO'].rate -ne $rate){throw 'Rate gate'}}
function Observe($seconds,$web,$bt,$strict){if($seconds -ne ($Minutes*60) -or $web -ne 1 -or $bt -ne 1 -or !$strict){throw 'Wrong duration/route'}}
function ConnectAvailableSaved($indices){Ack $script:ProbeRate;Ack 'saved=0';return 0}
Invoke-Expression $block
if(($script:phases -join ',') -ne 'RATE_CONNECT_32000,WEB_BT_32000'){throw 'WEB-BT exceeded 32k policy'}
if(($script:commands -join ',') -ne 'dac,play 8,rate32,saved=0'){throw 'Wrong rate/source/peer order'}
# Same actual measurement branch at five hours, without sleeping or COM.
$Minutes=300;$script:commands.Clear();$script:phases.Clear();$script:selectedIndex=-1
Invoke-Expression $block
if(($script:phases -join ',') -ne 'RATE_CONNECT_32000,WEB_BT_32000'){throw '5h route changed'}
Write-Host 'PASS: 300 minutes ->18000 seconds; actual branch and strict rate gate; no COM.'
Write-Host 'PASS: actual WEB-BT branch limited to 32k, DAC before rate change, 600-second observation; no COM.'

# Execute the actual repeated-connect phase, not a copied policy implementation.
$line=($s -split "`n"|Where-Object {$_.Contains("Phase 'BT_CONNECT' {if($"+'selectedIndex -lt 0)')})|Select-Object -First 1
if(!$line){throw 'Repeated connection branch not found'}
$selectedIndex=0;$script:ProbeRate='rate32';$script:commands.Clear()
Invoke-Expression $line
Invoke-Expression $line
if(($script:commands -join ',') -ne 'rate32,saved=0,rate32,saved=0'){throw 'Repeated BT connection changed baseline rate'}
$script:commands.Clear();$script:ProbeRate='rate44';Invoke-Expression $line
if(($script:commands -join ',') -ne 'rate44,saved=0'){throw 'Explicit 44.1 control no longer supported'}
Write-Host 'PASS: actual repeated baseline connection stays32k; explicit44.1 retained; no COM'
