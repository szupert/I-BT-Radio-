﻿@echo off
chcp 65001 >nul
echo I-BT-Radio R26 - 15 perc CPU es kijelzo meres; Budapest Rock, mentett BT, 32kHz
echo 5 perc kep nelkul / 5 perc regi rajzolas / 5 perc tombos SPI rajzolas.
echo WebUI nincs. G: hallott kihagyas, Q: leallitas. A csatlakozas kulon ido.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_stress_logged.ps1" -CpuStages -Minutes 15 -ReturnRoot "%~dp0..\RETURN_TO_EVA"
echo A naplo es ZIP a RETURN_TO_EVA mappaban talalhato.
pause
