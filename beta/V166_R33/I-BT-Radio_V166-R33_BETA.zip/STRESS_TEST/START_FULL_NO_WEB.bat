@echo off
echo I-BT-Radio R18 - teljes stresszteszt WebUI nelkul
echo Internetes radio, SD, DAC, mentett BT eszkoz es menu 500-50ms.
echo A futasi idot percben adhatod meg. Nem tolt firmware-t.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_stress_logged.ps1" -FullNoWeb -ReturnRoot "%~dp0..\RETURN_TO_EVA"
pause
