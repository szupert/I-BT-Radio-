@echo off
cd /d "%~dp0"
for %%I in ("%~dp0..\RETURN_TO_EVA") do set "RETURN_DIR=%%~fI"
if not exist "%RETURN_DIR%" mkdir "%RETURN_DIR%"
echo Visszaadhato naplok: %RETURN_DIR%
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_stress_logged.ps1" -Minutes 10 -ReturnRoot "%RETURN_DIR%"
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
