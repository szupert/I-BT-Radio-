@echo off
chcp 65001 >nul
echo I-BT-Radio NONSTOP: maximum 10 ora, Q leallitas, G hallott kihagyas.
echo Full selftest + SD + DAC + internet + BT + WebUI.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0nonstop_stress.ps1" -Minutes 600 -ReturnRoot "%~dp0..\RETURN_TO_EVA"
echo A naplok a RETURN_TO_EVA es SYSTEM mappaban vannak.
pause
