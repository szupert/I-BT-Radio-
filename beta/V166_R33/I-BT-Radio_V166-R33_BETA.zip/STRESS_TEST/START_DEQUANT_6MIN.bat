@echo off
chcp 65001 >nul
echo I-BT-Radio R31 - Core1 tehermentesites, 6 perc
echo MP3 reszfeladat Core0: KI 2 perc, BE 2 perc, KI 2 perc.
echo Ugyanaz az ado, BT 32kHz, artwork es WebUI nelkul.
echo Az indulas kulon ido. G: hallott kihagyas, Q: stop.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_stress_logged.ps1" -DequantAB -Minutes 6 -ReturnRoot "%~dp0..\RETURN_TO_EVA"
echo Naplo es ZIP: RETURN_TO_EVA. Cel: Core1 tartosan 90 szazalek alatt.
pause
