@echo off
chcp 65001 >nul
echo I-BT-Radio R27 - 70 perc: 2 kor x 4/8/16/32/64/128/240 sor
echo Elso kor: jelenlegi Core1 dekoder. Masodik kor: 1/8 MP3 reszfeladat Core0.
echo Budapest Rock, utolso sikeres mentett BT, 32kHz. WebUI nincs.
echo G: hallott kihagyas, Q: leallitas. Indulas kulon ido.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_stress_logged.ps1" -BatchSweep -Minutes 70 -ReturnRoot "%~dp0..\RETURN_TO_EVA"
echo A naplo es ZIP a RETURN_TO_EVA mappaban talalhato.
pause
