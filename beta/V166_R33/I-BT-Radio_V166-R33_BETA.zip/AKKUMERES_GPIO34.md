# Akkumulátormérés – SMALL / GPIO34

## Bekötés

Egyetlen, legfeljebb **4,2 V-ra tölthető Li-ion/LiPo cellához** készült. Nem 2S/3S csomaghoz és nem LiFePO4-hez. Az akkumulátor nem csatlakozhat közvetlenül a GPIO-ra.

```text
Akku + ── R1: 100 kΩ, 1% ──┬── GPIO34
                           │
                       R2: 100 kΩ, 1%
                           │
Akku − / rádió GND ─────────┴── GND

GPIO34 és GND közé: 100 nF kondenzátor, R2-vel párhuzamosan.
```

Ez felezi a feszültséget: 4,20 V-os cellánál a GPIO-n körülbelül 2,10 V legyen. Az osztó árama ekkor 21 µA. A föld közös. A rádió tápellátását és a cella töltését/védelmét külön, megfelelő áramkör biztosítja; ez csak mérőbemenet.

**A panel eredeti fényérzékelő-osztóját le kell választani GPIO34-ről.** A fényérzékelő és a hozzá tartozó ellenállás ágát is ellenőrizni kell: a megmaradó 3,3 V-os felhúzás vagy föld felé húzás meghamisítaná az új osztót. A pontos alkatrészpozíció panelváltozattól függ, ezért fotó és folytonosságmérés nélkül nincs végleges leszedési jelölés. Kikapcsolt, feszültségmentes panelen dolgozz.

A menükapcsoló **nem kapcsolja át fizikailag a vezetékeket**. Akkumérés után az eredeti LDR-funkció csak visszakötött LDR-osztóval használható. Ha mindkettőt meg akarod tartani, egy fizikai váltókapcsoló válassza ki, melyik osztó kimenete csatlakozik GPIO34-re; a két osztót ne kösd össze.

Csatlakoztatás előtt multiméterrel ellenőrizd az osztó kimenetét és a polaritást. A feszültségküszöbök szoftveres ellenőrzése nem túlfeszültség-védelem. Ha a rádió tápja lekapcsolható, a mérővezeték se táplálja vissza a kikapcsolt ESP-t: az osztó akkumulátor felőli tápját is szakítsd meg a kikapcsolással.

## Menü

- **Beállítások → Hardver → Fény / Akku mérés:** Ki → LDR → Akku. Alap: Ki. LDR módban a GPIO feszültsége jelenik meg; nem luxmérés és nem automatikus háttérvilágítás.
- **Hardver → Speciális beállítások:** az öt pont a GPIO-n mért **mV**, nem a cella feszültsége. 0%, 25%, 50%, 75%, 100%. Kiválasztás után rotaryval vagy a képernyő −/+ gombjaival 10 mV-os lépésekben módosítható, középső/vissza gombbal kilépés.
- **Beállítások → Kijelző → Akkumulátor:** Kijelzés Ki/Be; Lépték 1/5/10/25%; Megjelenítés Százalék/Ikon/Mindkettő. Alap: Ki, 1%, Százalék.

Az induló pontok: 1500 / 1650 / 1800 / 1950 / 2100 mV a GPIO-n. A 100k/100k osztóval ez 3,00 / 3,30 / 3,60 / 3,90 / 4,20 V-os cellafeszültség. **Ez induló beállítás, nem hitelesített cellagörbe.** Saját terheléses mérés alapján állítsd be; a töltés, terhelés, hőmérséklet és cellatípus befolyásolja az eredményt.

A pontoknak szigorúan emelkedniük kell. Hibás sorrend, azonos pontok vagy 2450 mV feletti kalibráció esetén nincs százalék; `--`/`?` látszik. A szoftver nem cseréli ki csendben a hibás mentett görbét. Az egyes pontok közötti becslés egyenes szakaszokból áll; a kijelzési lépték lefelé kerekít, a 100%-ot külön megőrzi.

`Akku: ~67%` becslés, nem pontos töltöttségmérés. Ikon módban ugyanezt a becslést mutatja a töltéscsík. Ki vagy LDR mérési mód mellett a bekapcsolt akkujelző is ismeretlen értéket mutat. Nem vezérel töltést, védelmet vagy automatikus leállítást.

## Terhelés és ellenőrzés

Legfeljebb kétmásodpercenként három ADC-minta, medián és enyhe szűrés; a UI/Core0 végzi. Nincs mérés az audio/BT callbackben és nincs saját, mintánkénti pufferallokáció. Az Arduino ADC-driver első használata egyszeri inicializálást végezhet; első bekapcsolást leállított lejátszás mellett próbálj. Kikapcsolt mód nem olvas ADC-t. Az akkujelző csak megváltozott értéknél vagy újrarajzolt háttérnél frissül. A beállítások mentése a meglévő, leállított lejátszás melletti mentési kaput követi.

GPIO34 ADC1_CH6; az Espressif a nagy csillapításnál 150–2450 mV-os hatásos kalibrációs tartományt ad meg. Az ADC és az osztó hibáját multiméterrel ellenőrizni kell.

Forrás: [Espressif ESP32-WROOM-32 adatlap](https://documentation.espressif.com/esp32-wroom-32_datasheet_en.html), [ESP32-WROOM-32E ADC kalibrációs tartomány](https://documentation.espressif.com/esp32-wroom-32e_esp32-wroom-32ue_datasheet_en.html).

Szoftverteszt és fordítás nem bizonyít fizikai bekötést vagy mérési pontosságot. Fizikai állapot: **NOT_RUN**.
