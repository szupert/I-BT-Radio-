@echo off
call "%~dp0STRESS_TEST\START_WEB_BT_32_44_AB.bat"
