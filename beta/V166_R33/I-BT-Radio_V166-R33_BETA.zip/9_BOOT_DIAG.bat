@echo off
call "%~dp0STRESS_TEST\START_BOOT_DIAG.bat"
