@echo off
call "%~dp0STRESS_TEST\START_MENU_10MIN.bat"
