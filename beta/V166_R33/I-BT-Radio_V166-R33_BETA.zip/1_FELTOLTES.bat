@echo off
call "%~dp0INSTALLER\START_BETA_INSTALLER.bat"
