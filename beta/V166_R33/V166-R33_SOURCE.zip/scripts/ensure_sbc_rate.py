from pathlib import Path
import runpy
Import('env')
project=Path(env.subst('$PROJECT_DIR'))
sdk=Path(env.PioPlatform().get_package_dir('framework-espidf'))/'components/bt/host/bluedroid/btc/profile/std/a2dp'
module=runpy.run_path(str(project/'scripts/sbc_rate_patch.py'))
module['apply'](sdk,project/'scripts/sdk_control')
