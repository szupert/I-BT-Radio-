@echo off
call "%~dp0AUTO\1_FELTOLTES.bat" %*
exit /b %ERRORLEVEL%
