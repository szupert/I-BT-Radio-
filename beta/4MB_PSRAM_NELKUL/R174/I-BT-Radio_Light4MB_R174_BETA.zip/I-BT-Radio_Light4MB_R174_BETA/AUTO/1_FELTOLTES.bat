@echo off
setlocal
cd /d "%~dp0"
title I-BT-Radio R174 LIGHT4 AUTOMATA FLASH + PSRAM
:retry
if exist "C:\esp32\SYSTEM\TOOLS\platformio\core\penv\Scripts\python.exe" (
  set "PYTHON_CMD=C:\esp32\SYSTEM\TOOLS\platformio\core\penv\Scripts\python.exe"
  goto python_found
)
where py >nul 2>&1
if not errorlevel 1 (
  set "PYTHON_CMD=py -3"
  goto python_found
)
where python >nul 2>&1
if not errorlevel 1 (
  set "PYTHON_CMD=python"
  goto python_found
)
echo HIBA: Python 3.9 vagy ujabb kell.
goto failed
:python_found
call %PYTHON_CMD% -c "import sys; raise SystemExit(0 if sys.version_info >= (3,9) else 1)"
if errorlevel 1 goto failed
call %PYTHON_CMD% -c "import serial, esptool; assert esptool.__version__ == '5.3.0' and serial.__version__ == '3.5'" >nul 2>&1
if errorlevel 1 (
  call %PYTHON_CMD% -m pip install -r INSTALLER\requirements.txt
  if errorlevel 1 goto failed
)
call %PYTHON_CMD% -B -X utf8 -u run_upload.py %*
set "RC=%ERRORLEVEL%"
if "%RC%"=="130" exit /b 130
if not "%RC%"=="0" goto failed
if "%~1"=="--verify-only" exit /b 0
echo Kesz. A naplo a RETURN_TO_EVA mappaban van.
pause
exit /b 0
:failed
echo HIBA: a reszletek fent olvashatok. Nincs automatikus ujrairas.
choice /C RQ /M "R: kezi ujraproba; Q: kilepes"
if errorlevel 2 exit /b 2
goto retry
