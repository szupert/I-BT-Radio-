I-BT-Radio V159 HTTPS BETA — source materials

This archive contains the V157 source snapshot used as the V159 base, the upstream GPL-3.0 license, and the V159 HTTPS restoration patch. Apply patches/V159_https_restore.patch from this directory to reconstruct the V159 source change. The patch restores direct HTTPS client use while keeping HLS disabled.

The firmware was built and package-tested in the private build workspace. This archive has not been independently rebuilt, so it is not a bit-for-bit reproducibility claim. The public release notes state the V159 firmware hash and known test status.

Upstream project: https://github.com/e2002/yoradio
I-BT-Radio project: https://github.com/szupert/I-BT-Radio-
