#pragma once
#include "../dual/core.h"
namespace front {
bool begin();
#if defined(BOARD_CYD28)
bool cassetteReady();
void skinPreview(int index);
bool skinPreviewActive();
bool skinPreviewInput(dual::Action action);
#endif
dual::Size nativeSize();
void render(const dual::Snapshot &s,unsigned page,unsigned selected,bool force);
void renderBtMinimal(const dual::Snapshot &s,unsigned page,unsigned selected,bool force);
void invalidate();
void service();
void setRotation(uint8_t rotation);
void calibrationTarget(int x,int y,unsigned step);
void calibrationDone(bool ok);
bool artworkBegin(int width,int height);
void artworkTile(int x,int y,int width,int height,int stride,const uint16_t *pixels);
void artworkEnd();
void artworkClear();
}
