#include "../../dual/v026_probe.h"
#include "../../dual/bt_audio.h"
#include "../../dual/vu_probe.h"
#include <Preferences.h>
#include <math.h>
#include "../../core/options.h"
#if defined(BOARD_CYD28)
#include "../frontend.h"
#include "../content.h"
#include "../fonts.h"
#include "../../dual/artwork.h"
#include "../../dual/online_artwork.h"
#include "../../core/config.h"
#include "../../core/player.h"
#include "../../core/network.h"
#if FEATURE_SD
#include <SD.h>
#include "../../core/sdmanager.h"
#endif
#include "../../dual/v027_himem.h"
namespace board {
int rotaryDebugClk(); int rotaryDebugDt(); int rotaryDebugSw();
uint32_t rotaryDebugClkChanges(); uint32_t rotaryDebugDtChanges(); uint32_t rotaryDebugSwChanges();
uint32_t rotaryDebugClkRise(); uint32_t rotaryDebugClkFall();
uint32_t rotaryDebugDtRise(); uint32_t rotaryDebugDtFall();
uint32_t rotaryDebugCW(); uint32_t rotaryDebugCCW();
int rotaryDebugDirection();
}
#include <Adafruit_ST7789.h>
#include "bootlogo_rle.h"
#include "cassette_photo.h"
#include "skin_assets.h"
#include "winamp_assets.h"
#include "../../dual/sd_bt_ui_policy.h"
#include "boot_rgba32.h"
#include "rgba_pixel.h"
#include "skin_gallery.h"
#include <time.h>
#include "../cassette_layout.h"
#include "../../dual/resource_limiter.h"
#include "../../dual/backup_sd.h"
#include <SPIFFS.h>
#include <esp_heap_caps.h>
namespace front {
static SPIClass lcdSPI(HSPI);
static Adafruit_ST7789 lcd(&lcdSPI,TFT_CS,TFT_DC,TFT_RST);
static uint16_t bg=0x0841,fg=0xffff,accent=0x05da,muted=0x7bef;
static bool previousDark=true,valid=false;
static bool overloadDotPainted=false;
static bool previousCassette=true,cassetteRequested=true;
static bool previousWinamp=false,winampRequested=false;
static unsigned previousPage=99;
static bool previousSetup=false,artDirty=true;
static dual::Language previousLanguage=dual::Language::HU;
static uint32_t previousGeneration=0;
static int artX=8,artY=62,artW=0,artH=0;
static char rows[16][200]={};
static int widths[16]={},rowX[16]={},rowY[16]={};
static SkinGallery gallery;
static void drawSkin(unsigned index){
    if(index>=7)return;
    uint16_t scan[320];
    const int w=lcd.width(),h=lcd.height();
    if(w>320||h>320||w<1||h<1)return;
    const uint16_t* pixels=skinAssets[index];
    for(int y=0;y<h;++y){
        for(int x=0;x<w;++x){
            const unsigned offset=(y*240/h)*320+x*320/w;
            scan[x]=index==0?bootRgbaTo565(bootRgba32+offset*4):pixels[offset];
        }
        lcd.drawRGBBitmap(0,y,scan,w,1);
        if((y&7)==7)vTaskDelay(1);
    }
}
static void drawWinamp(const uint16_t *pixels){
    uint16_t scan[320];
    const int w=lcd.width(),h=lcd.height();
    if(w>320||h>320||w<1||h<1)return;
    for(int y=0;y<h;y++){
        for(int x=0;x<w;x++)scan[x]=pixels[(y*240/h)*320+x*320/w];
        lcd.drawRGBBitmap(0,y,scan,w,1);
        if((y&15)==15)vTaskDelay(1);
    }
}
// Match dynamic fields to the offline 4/2/2/5 crop of the static Winamp art.
static constexpr int winX(int x){return ((x-4)*320+157)/314;}
static constexpr int winY(int y){return ((y-2)*240+116)/233;}
static constexpr int winW(int x,int w){return winX(x+w)-winX(x);}
static constexpr int winH(int y,int h){return winY(y+h)-winY(y);}
void skinPreview(int index){gallery.select(index);valid=false;}
bool skinPreviewActive(){return gallery.active();}
bool skinPreviewInput(dual::Action a){bool used=gallery.input(a);if(used)valid=false;return used;}
static uint16_t rowColor[16]={};
dual::Size nativeSize(){return {320,240};}
static void text(int x,int y,int maxWidth,const char *value,uint16_t color) {
    const fonts::Font &font=fonts::font16;const char *p=value;
    uint16_t glyphPixels[32*24];int start=x;
    while(*p) {
        const auto &g=fonts::find(font,dual::nextUtf8(p));
        if(x-start+g.w>maxWidth||g.w>32||g.h>24)break;
        const uint8_t *bitmap=font.data+g.offset;
        for(unsigned j=0;j<unsigned(g.w)*g.h;j++)glyphPixels[j]=(bitmap[j/8]&(0x80>>(j&7)))?color:bg;
        lcd.drawRGBBitmap(x+g.x,y,glyphPixels,g.w,g.h);x+=g.advance;
    }
}
// Reuse the existing Unicode glyphs at half size for finer station text.
static void textSmall(int x,int y,int maxWidth,const char *value,uint16_t color,uint16_t background){
    const fonts::Font &font=fonts::font16;const char *p=value;
    uint16_t glyphPixels[16*12];const int start=x;
    while(*p){
        const auto &g=fonts::find(font,dual::nextUtf8(p));
        const int w=(int(g.w)+1)/2,h=(int(g.h)+1)/2;
        if(x-start+w>maxWidth||w>16||h>12)break;
        const uint8_t *bitmap=font.data+g.offset;
        for(int yy=0;yy<h;yy++)for(int xx=0;xx<w;xx++){
            bool ink=false;
            for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++){
                const int sx=xx*2+dx,sy=yy*2+dy;
                if(sx<int(g.w)&&sy<int(g.h)){
                    const int bit=sy*int(g.w)+sx;
                    ink|=(bitmap[bit/8]&(0x80>>(bit&7)))!=0;
                }
            }
            glyphPixels[yy*w+xx]=ink?color:background;
        }
        lcd.drawRGBBitmap(x+g.x/2,y,glyphPixels,w,h);
        x+=(int(g.advance)+1)/2;
    }
}
// Eight rows using native font16; no bitmap thickening or scaling.
// The home view keeps its existing typography.
static void winampListText(int x,int y,int maxWidth,const char *value,uint16_t color,uint16_t background){
    const fonts::Font &font=fonts::font16;const char *p=value;
    // This page is optional UI work; keep the enlarged glyph scratch out of
    // scarce internal DRAM and leave the audio path untouched.
    static uint16_t *glyphPixels=nullptr;
    if(!glyphPixels)glyphPixels=(uint16_t*)heap_caps_malloc(24*21*sizeof(uint16_t),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!glyphPixels)return;
    const int start=x;
    while(*p){
        const auto &g=fonts::find(font,dual::nextUtf8(p));
        const int w=int(g.w),h=int(g.h);
        if(w<1||h<1||w>24||h>21||x-start+w>maxWidth)break;
        const uint8_t *bitmap=font.data+g.offset;
        for(int yy=0;yy<h;yy++)for(int xx=0;xx<w;xx++){
            const int bit=yy*w+xx;
            const bool ink=(bitmap[bit/8]&(0x80>>(bit&7)))!=0;
            glyphPixels[yy*w+xx]=ink?color:background;
        }
        lcd.drawRGBBitmap(x+g.x,y,glyphPixels,w,h);
        x+=g.advance;
    }
}
static void line(unsigned id,int x,int y,int w,const char *s,uint16_t color,bool force) {
    if(id>=16||w<1)return;
    if(force||widths[id]!=w||rowX[id]!=x||rowY[id]!=y||rowColor[id]!=color||strcmp(rows[id],s)) {
        lcd.fillRect(x,y,w,22,bg);text(x,y,w,s,color);
        dual::textCopy(rows[id],sizeof(rows[id]),s);widths[id]=w;rowX[id]=x;rowY[id]=y;rowColor[id]=color;
    }
}
static void winampField(char *cache,size_t cap,int x,int y,int w,int h,const char *value,uint16_t color,bool force){
    if(!force&&!strcmp(cache,value))return;
    // The baked example glyphs are absent; clear the whole black well.
    lcd.fillRect(x,y,w,h,0x0000);
    textSmall(x+1,y+1,w-2,value,color,0x0000);
    dual::textCopy(cache,cap,value);
}
// Compact, fixed-width Winamp numerals stay inside their own bitmap well.
static void winampNumber(char *cache,size_t cap,int x,int y,int w,int h,const char *value,int scale,bool force){
    if(!force&&!strcmp(cache,value))return;
    static const uint8_t digits[10][7]={
        {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},
        {14,17,1,2,4,8,31},{30,1,1,14,1,1,30},
        {2,6,10,18,31,2,2},{31,16,16,30,1,1,30},
        {14,16,16,30,17,17,14},{31,1,2,4,8,8,8},
        {14,17,17,14,17,17,14},{14,17,17,15,1,1,14}};
    static uint16_t pixels[82*21];
    if(w>82||h>21)return;
    for(int i=0;i<w*h;i++)pixels[i]=0;
    int pen=1,top=(h-7*scale)/2;
    for(const char *c=value;*c&&pen+5*scale<=w;c++){
        for(int row=0;row<7;row++){
            uint8_t bits=(*c>='0'&&*c<='9')?digits[*c-'0'][row]:
                (*c==':'&&(row==2||row==5)?4:0);
            for(int col=0;col<5;col++)if(bits&(16>>col))
                for(int sy=0;sy<scale;sy++)for(int sx=0;sx<scale;sx++)
                    pixels[(top+row*scale+sy)*w+pen+col*scale+sx]=0x07e0;
        }
        pen+=5*scale+1;
    }
    lcd.drawRGBBitmap(x,y,pixels,w,h);
    dual::textCopy(cache,cap,value);
}
static void restoreWinampVolume(int volume){
    // One hue for the whole track, interpolated at Winamp-style volume marks.
    // Match the inverse floor mapping used by the offline bitmap crop, not
    // rounded forward bounds: source row 68 occupies TWO display rows.
    // Keep the lower border neutral; the old bitmap edge had a green cast.
    static const uint8_t colors[5][3]={{0,132,0},{0,210,0},{230,210,0},
                                       {255,130,0},{235,20,12}};
    const int section=volume>=100?3:volume/25;
    const int offset=volume>=100?25:volume%25;
    uint8_t tint[3];
    for(int c=0;c<3;c++)tint[c]=uint8_t((int(colors[section][c])*(25-offset)+
                                          int(colors[section+1][c])*offset+12)/25);
    uint16_t row[82];
    const int x0=winX(126),x1=winX(200);
    for(int y=winY(60);y<winY(76);y++){
        const int sourceY=2+(y*233)/240;
        for(int x=x0;x<x1;x++){
            const uint16_t base=winampPlayerEq[y*320+x];
            const unsigned r=(base>>11)&31,g=(base>>5)&63,b=base&31;
            const bool greenTrack=g>24&&g>r*2&&g>b*2;
            if(sourceY>=65&&sourceY<=68&&greenTrack){
                const unsigned red=std::min(31u,(unsigned(tint[0])*31*g+5355u)/(255u*42u));
                const unsigned green=std::min(63u,(unsigned(tint[1])*63*g+5355u)/(255u*42u));
                const unsigned blue=std::min(31u,(unsigned(tint[2])*31*g+5355u)/(255u*42u));
                row[x-x0]=uint16_t((red<<11)|(green<<5)|blue);
            }else if(sourceY==69&&greenTrack){
                const unsigned gray=(g*31u+31u)/63u;
                row[x-x0]=uint16_t((gray<<11)|(g<<5)|gray);
            }else row[x-x0]=base;
        }
        lcd.drawRGBBitmap(x0,y,row,x1-x0,1);
    }
}
static void drawWinampVolumeThumb(int x){
    // Apply the same inverse crop mapping as the baked balance thumb.
    // Display rows 68/69 both use source row 68; otherwise the bottom is 1 px high.
    for(int y=winY(60);y<winY(76);++y){
        const int sourceY=2+(y*233)/240;
        lcd.drawRGBBitmap(x,y,winampSliderThumb+(sourceY-60)*14,14,1);
    }
}
// Twelve measured frequency bands, computed on the UI core at <=10 Hz.
// The audio core only publishes one in eight DAC PCM samples and never waits.
static void winampSpectrum(uint8_t bars[12]){
    const uint32_t end=vuprobe::dacPcmWrite.load(std::memory_order_acquire);
    if(end<128)return;
    int16_t samples[128];
    for(unsigned i=0;i<128;i++)
        samples[i]=vuprobe::dacPcm[(end-128+i)&127u].load(std::memory_order_relaxed);
    static const uint8_t bins[12]={3,4,5,7,9,12,16,21,27,35,45,58};
    for(unsigned band=0;band<12;band++){
        const float coeff=2.0f*cosf(6.2831853f*float(bins[band])/128.0f);
        float q1=0,q2=0;
        for(unsigned i=0;i<128;i++){
            const float q0=float(samples[i])+coeff*q1-q2;
            q2=q1;q1=q0;
        }
        const float power=q1*q1+q2*q2-coeff*q1*q2;
        const float magnitude=sqrtf(power>0?power:0)/128.0f;
        float threshold=45.0f;
        while(bars[band]<16&&magnitude>threshold){bars[band]++;threshold*=1.35f;}
    }
}
static void winampHome(const dual::Snapshot& s,bool layout){
    static char oldStation[352]={},oldTime[20]={},oldBitrate[30]={},oldRate[12]={};
    static int oldVolume=-1,oldBuffer=-1,oldPlaying=-1,oldBt=-1;
    if(layout){drawWinamp(winampPlayerEq);oldStation[0]=oldTime[0]=oldBitrate[0]=oldRate[0]=0;
        oldVolume=oldBuffer=oldPlaying=-1;
        // BT-OUT lettering is baked into the original metallic button.
    }
    // The Classic Winamp art is cropped offline; dynamic fields use the same transform.
    char stationTitle[352];
    if(s.title[0])snprintf(stationTitle,sizeof(stationTitle),"%s - %s",s.station[0]?s.station:"I-BT-Radio",s.title);
    else snprintf(stationTitle,sizeof(stationTitle),"%s",s.station[0]?s.station:"I-BT-Radio");
    winampField(oldStation,sizeof(oldStation),winX(129),winY(25),winW(129,176),winH(25,14),stationTitle,0x07e0,layout);
    char value[30];
    snprintf(value,sizeof(value),"%lu:%02lu",(unsigned long)(s.elapsed/60),(unsigned long)(s.elapsed%60));
    const bool counterChanged=layout||strcmp(oldTime,value)!=0;
    const bool bt=ibtsdui::classic(btaudio::transmitting(),s.sd,s.settings.winampEnabled);
    winampNumber(oldTime,sizeof(oldTime),winX(44),winY(25),winW(44,77),winH(25,19),value,2,layout||int(bt)!=oldBt);
    if(bt&&(counterChanged||int(bt)!=oldBt)){
        // Reserve the tail of the counter well for a small static blue BT mark.
        // Repaint after counter updates; no animation and no extra timer/task.
        const int x=winX(112),y=winY(27);
        lcd.fillRect(x,y,winW(112,9),winH(27,15),0);
        lcd.drawLine(x+4,y,x+4,y+14,0x041f);
        lcd.drawLine(x+4,y,x+8,y+4,0x041f);
        lcd.drawLine(x+8,y+4,x,y+10,0x041f);
        lcd.drawLine(x,y+4,x+8,y+10,0x041f);
        lcd.drawLine(x+8,y+10,x+4,y+14,0x041f);
    }
    oldBt=int(bt);
    // Keep the original white kbps/kHz labels; only numbers are dynamic.
    snprintf(value,sizeof(value),"%u",unsigned(s.bitrate));
    winampNumber(oldBitrate,sizeof(oldBitrate),winX(129),winY(44),winW(129,21),winH(44,11),value,1,layout);
    if(s.sampleRate)snprintf(value,sizeof(value),"%u",unsigned((s.sampleRate+500)/1000));
    else value[0]=0;
    winampNumber(oldRate,sizeof(oldRate),winX(183),winY(44),winW(183,17),winH(44,11),value,1,layout);
    const int volume=(int(s.volume)*100+127)/254;
    if(layout||volume!=oldVolume){
        restoreWinampVolume(volume);
        const int thumb=winX(126+60*volume/100);
        drawWinampVolumeThumb(thumb);
        oldVolume=volume;
    }
    const int fill=s.bufferCapacity?int((uint64_t(s.buffer)*100)/s.bufferCapacity):0;
    const int bounded=fill<0?0:fill>100?100:fill;
    if(layout||bounded!=oldBuffer){
        // The long separator is a live compressed-input buffer, not a timer.
        lcd.fillRect(winX(13),winY(77),winW(13,294),winH(77,4),0x2144);
        lcd.fillRect(winX(13),winY(77),winW(13,294)*bounded/100,3,0xc5e7);
        oldBuffer=bounded;
    }
    if(layout||int(s.playing)!=oldPlaying){
        lcd.fillRect(winX(24),winY(28),winW(24,13),winH(28,12),0x0020);
        if(s.playing)lcd.fillTriangle(winX(26),winY(29),winX(26),winY(38),winX(34),winY(33),0x07e0);
        else lcd.fillRect(winX(27),winY(31),winW(27,7),winH(31,7),0xa244);
        oldPlaying=int(s.playing);
    }
    // Classic Winamp analyzer: true measured bands, not a decorative animation.
    static uint8_t oldBands[12]={};
    uint8_t bands[12]={};
    if(s.playing&&vuprobe::dacEnabled.load(std::memory_order_relaxed))winampSpectrum(bands);
    if(layout||memcmp(oldBands,bands,sizeof(bands))){
        // This also covers the old baked indicator just above the first bars.
        lcd.fillRect(winX(15),winY(45),winW(15,99),winH(45,25),0x0020);
        for(unsigned band=0;band<12;band++){
            for(unsigned h=0;h<bands[band];h+=3){
                const uint16_t color=h<10?0x07e0:h<14?0xffe0:0xf800;
                lcd.fillRect(winX(15+band*8),winY(66-h),winW(15+band*8,6),2,color);
            }
        }
        memcpy(oldBands,bands,sizeof(bands));
    }
}
static void winampStationList(const dual::Snapshot& s,unsigned selected,bool layout){
    static unsigned oldSelected=0;static uint32_t paintedAt=0;
    if(!layout&&selected==oldSelected)return;
    if(!layout&&uint32_t(millis()-paintedAt)<100)return;
    paintedAt=millis();oldSelected=selected;
    if(layout)drawWinamp(winampPlaylist);
    lcd.fillRect(winX(10),winY(24),winW(10,290),winH(24,178),0x0020);
    const uint16_t total=config.playlistLength();
    if(!total){textSmall(winX(15),winY(40),winW(15,270),s.sd?"Nincs MP3/FLAC":"Nincs állomás",0x9e29,0x0020);return;}
    int first=int(selected)-3;
    while(first<1)first+=total;
    for(int row=0;row<8;row++){
        int n=first+row;while(n>total)n-=total;
        const int y=25+row*22;
        if(unsigned(n)==selected)lcd.fillRect(winX(12),winY(y-1),winW(12,286),winH(y-1,22),0x4228);
        char label[190];
        snprintf(label,sizeof(label),"%u. %s",unsigned(n),config.stationByNum(uint16_t(n)));
        winampListText(winX(15),winY(y),winW(15,277),label,unsigned(n)==selected?0xe6d6:0x9e29,
                  unsigned(n)==selected?0x4228:0x0020);
    }
}
void invalidate(){valid=false;}
void renderBtMinimal(const dual::Snapshot& s,unsigned page,unsigned selected,bool force){
    // Audio-first BT view: no time, spectrum, artwork, buffer or status polling.
    static bool active=false;static unsigned oldPage=99,oldSelected=0;
    static uint8_t oldVolume=255;
    struct TextCache { char station[170]; char title[170]; char device[64]; };
    static TextCache *cache=nullptr;
    static bool cacheAttempted=false;
    if(!cacheAttempted){
        cacheAttempted=true;
        cache=(TextCache*)heap_caps_calloc(1,sizeof(TextCache),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    }
    const bool list=page==4;
    const bool layout=force||!active||oldPage!=page;
    if(layout){
        bg=0x18c3;
        lcd.fillScreen(0x18c3);
        lcd.drawRoundRect(5,5,310,230,4,0x8c71);
        lcd.drawFastHLine(11,31,298,0xb596);
        textSmall(15,12,290,"I-BT-RADIO",0xc638,0x18c3);
        lcd.drawRoundRect(11,list?42:48,298,list?186:166,3,0x6b8d);
        active=true;oldPage=page;if(cache){cache->station[0]=0;cache->title[0]=0;cache->device[0]=0;}oldVolume=255;oldSelected=0;
    }
    if(list){
        if(layout||oldSelected!=selected){
            lcd.fillRect(15,44,290,180,0x0020);
            const uint16_t total=config.playlistLength();
            if(total){
                int first=int(selected)-3;while(first<1)first+=total;
                for(int row=0;row<8;row++){
                    int n=first+row;while(n>total)n-=total;
                    const int y=46+row*22;
                    const bool chosen=unsigned(n)==selected;
                    if(chosen)lcd.fillRect(17,y,286,22,0x4228);
                    char label[190];snprintf(label,sizeof(label),"%u. %s",unsigned(n),config.stationByNum(uint16_t(n)));
                    winampListText(21,y+1,276,label,chosen?0xe6d6:0x9e29,chosen?0x4228:0x0020);
                }
            }
            oldSelected=selected;
        }
        return;
    }
    if(layout){
        text(20,51,278,"Bluetooth mód",0x9e29);
        lcd.drawRoundRect(20,116,130,32,3,0xc638);
        textSmall(43,126,100,"BT / OFF",0xe6d6,0x18c3);
        lcd.drawRoundRect(164,116,136,32,3,0xc638);
        char rateLabel[26];
        const unsigned hz=btaudio::outputRate();
        snprintf(rateLabel,sizeof(rateLabel),"%s kHz >",hz==16000?"16":hz==32000?"32":hz==44100?"44.1":"48");
        textSmall(182,126,112,rateLabel,0xe6d6,0x18c3);
        lcd.drawFastHLine(20,157,280,0x4a69);
    }
    if(layout||(cache&&strcmp(cache->station,s.station))){
        lcd.fillRect(20,73,280,21,0x18c3);
        text(20,73,278,s.station[0]?s.station:"I-BT-Radio",0xe6d6);
        if(cache)dual::textCopy(cache->station,sizeof(cache->station),s.station);
    }
    // No scrolling, artwork fetch or periodic animation; repaint on change only.
    if(layout||(cache&&strcmp(cache->title,s.title))){
        lcd.fillRect(20,94,280,21,0x18c3);
        text(20,94,278,s.title,0xb596);
        if(cache)dual::textCopy(cache->title,sizeof(cache->title),s.title);
    }
    btaudio::Device outputDevice{};
    const bool hasOutput=btaudio::connectedDevice(outputDevice);
    const char* outputName=hasOutput?outputDevice.name:"";
    if(layout||(cache&&strcmp(cache->device,outputName))){
        lcd.fillRect(20,216,280,16,0x18c3);
        textSmall(20,218,278,outputName,0xb596,0x18c3);
        if(cache)dual::textCopy(cache->device,sizeof(cache->device),outputName);
    }
    if(layout||oldVolume!=s.volume){
        const unsigned raw=s.volume>254?254:s.volume;
        const unsigned percent=(raw*100u+127u)/254u;
        char label[32];snprintf(label,sizeof(label),"Hangerő: %u%%",percent);
        lcd.fillRect(20,163,280,21,0x18c3);
        text(20,163,278,label,0xe6d6);
        lcd.fillRoundRect(20,188,280,15,4,0x4a69);
        const int filled=int((280u*percent)/100u);
        if(filled>0)lcd.fillRect(20,191,filled,9,0xad28);
        oldVolume=s.volume;
    }
}
static void wifiPasswordScreen(unsigned selected,bool layout,dual::Language lang){
    const auto& entry=dual::wifiPasswordUi();
    const int w=lcd.width(),h=lcd.height();
    line(0,8,4,w-16,content::pick(lang,"Wi-Fi jelszó","Wi-Fi password","WLAN-Passwort"),accent,layout);
    line(1,8,27,w-16,entry.ssid,fg,layout);
    const size_t count=strlen(entry.password);
    char masked[30]={};
    const size_t shown=count<24?count:24;
    memset(masked,'*',shown);masked[shown]=0;
    char value[64];snprintf(value,sizeof(value),"%u: %s",unsigned(count),masked);
    line(2,8,50,w-16,value,accent,layout);
    const char* modes[]={"abc","ABC","#+="};
    if(entry.error[0])snprintf(value,sizeof(value),"%s",entry.error);
    else if(entry.submitted&&network.setupFailed())snprintf(value,sizeof(value),"Kapcsolat sikertelen: javítsd");
    else if(entry.submitted)snprintf(value,sizeof(value),"Kapcsolódás...");
    else snprintf(value,sizeof(value),"%s  %s",modes[entry.mode],content::pick(lang,"OK: csatlakozás","OK: connect","OK: verbinden"));
    line(3,8,68,w-16,value,entry.error[0]||(entry.submitted&&network.setupFailed())?0xf800:muted,layout);
    static int previousKey=-1,previousMode=-1;
    if(layout){previousKey=-1;previousMode=-1;}
    const int cellW=(w-16)/8,cellH=(h-99)/5;
    auto drawKey=[&](unsigned key){
        const int x=8+int(key%8)*cellW,y=91+int(key/8)*cellH;
        const int kw=cellW-2,kh=cellH-2;
        lcd.fillRect(x,y,kw,kh,bg);
        const uint16_t color=selected==key?accent:muted;
        lcd.drawRoundRect(x,y,kw,kh,3,color);
        char label[5]={};
        if(key<36){const char c=dual::wifiPasswordKeyChar(entry.mode,key);if(c==' ')strlcpy(label,"SP",sizeof(label));else if(c)label[0]=c;}
        else strlcpy(label,key==36?"M":key==37?"<":key==38?"OK":"X",sizeof(label));
        const int labelX=x+(kw-(int(strlen(label))*9))/2;
        text(labelX< x+2?x+2:labelX,y+(kh-17)/2,kw-4,label,color);
    };
    if(layout||previousMode!=entry.mode){for(unsigned key=0;key<40;key++)drawKey(key);}
    else if(previousKey!=int(selected)){
        if(previousKey>=0)drawKey(unsigned(previousKey));
        drawKey(selected);
    }
    previousKey=int(selected);previousMode=entry.mode;
}
// Static asset and decoded cover live exclusively in PSRAM; no large internal fallback.
static const uint16_t *cassettePixels=cassettePhoto;
static uint16_t *coverPixels=nullptr;
static unsigned reelPhase=0;
// Two degrees per step; fixed-point lookup avoids trigonometry in pixel drawing.
static const int16_t reelCos[180]={
    256,256,255,255,254,252,250,248,246,243,241,237,234,230,226,
    222,217,212,207,202,196,190,184,178,171,165,158,150,143,136,
    128,120,112,104,96,88,79,71,62,53,44,36,27,18,9,
    0,-9,-18,-27,-36,-44,-53,-62,-71,-79,-88,-96,-104,-112,-120,
    -128,-136,-143,-150,-158,-165,-171,-178,-184,-190,-196,-202,-207,-212,-217,
    -222,-226,-230,-234,-237,-241,-243,-246,-248,-250,-252,-254,-255,-255,-256,
    -256,-256,-255,-255,-254,-252,-250,-248,-246,-243,-241,-237,-234,-230,-226,
    -222,-217,-212,-207,-202,-196,-190,-184,-178,-171,-165,-158,-150,-143,-136,
    -128,-120,-112,-104,-96,-88,-79,-71,-62,-53,-44,-36,-27,-18,-9,
    0,9,18,27,36,44,53,62,71,79,88,96,104,112,120,
    128,136,143,150,158,165,171,178,184,190,196,202,207,212,217,
    222,226,230,234,237,241,243,246,248,250,252,254,255,255,256
};
static const int16_t reelSin[180]={
    0,9,18,27,36,44,53,62,71,79,88,96,104,112,120,
    128,136,143,150,158,165,171,178,184,190,196,202,207,212,217,
    222,226,230,234,237,241,243,246,248,250,252,254,255,255,256,
    256,256,255,255,254,252,250,248,246,243,241,237,234,230,226,
    222,217,212,207,202,196,190,184,178,171,165,158,150,143,136,
    128,120,112,104,96,88,79,71,62,53,44,36,27,18,9,
    0,-9,-18,-27,-36,-44,-53,-62,-71,-79,-88,-96,-104,-112,-120,
    -128,-136,-143,-150,-158,-165,-171,-178,-184,-190,-196,-202,-207,-212,-217,
    -222,-226,-230,-234,-237,-241,-243,-246,-248,-250,-252,-254,-255,-255,-256,
    -256,-256,-255,-255,-254,-252,-250,-248,-246,-243,-241,-237,-234,-230,-226,
    -222,-217,-212,-207,-202,-196,-190,-184,-178,-171,-165,-158,-150,-143,-136,
    -128,-120,-112,-104,-96,-88,-79,-71,-62,-53,-44,-36,-27,-18,-9
};
static bool coverVisible=false,cassetteDirty=false;

static cassette::View cassetteView={0,13,320,213};
static uint16_t cassettePixel(int x,int y){
    if(!cassettePixels||x<0||x>=320||y<0||y>=213)return bg;
    if(coverVisible&&cassette::sticker(x,y)){
        // Cover fills the wide sticker: crop vertically, retaining the image aspect.
        int sx=(x-18)*artW/284;
        int sy=(y-21)*artW/284+(artH-(122*artW/284))/2;
        sx=constrain(sx,0,artW-1);sy=constrain(sy,0,artH-1);
        return coverPixels[sy*112+sx];
    }
    // Rotate only the hub interior; fixed body and label are never animated.
    if(reelPhase){
        for(int cx : {88,229}){int dx=x-cx,dy=y-91;
            if(dx*dx+dy*dy<=19*19){
                int sx=cx+(dx*reelCos[reelPhase]+dy*reelSin[reelPhase])/256;
                int sy=91+(-dx*reelSin[reelPhase]+dy*reelCos[reelPhase])/256;
                return cassettePixels[sy*320+sx];
            }
        }
    }
    return cassettePixels[y*320+x];
}
static void cassetteRect(int x,int y,int w,int h){
    uint16_t scan[320];const auto v=cassetteView;
    int left=v.x+x*v.w/320,right=v.x+(x+w)*v.w/320;
    int top=v.y+y*v.h/213,bottom=v.y+(y+h)*v.h/213;
    for(int dy=top;dy<bottom;dy++){
        for(int dx=left;dx<right;dx++)scan[dx-left]=cassettePixel((dx-v.x)*320/v.w,(dy-v.y)*213/v.h);
        lcd.drawRGBBitmap(left,dy,scan,right-left,1);
        if((dy&7)==0)vTaskDelay(1);
    }
}
static void cassetteLine(unsigned id,int x,int y,int w,const char* value,bool force){
    if(!force&&widths[id]==w&&!strcmp(rows[id],value))return;
    cassetteRect(x,y,w,20);
    const char *p=value;int cursor=x;const auto& font=fonts::font16;
    while(*p){const auto& g=fonts::find(font,dual::nextUtf8(p));if(cursor+g.w>x+w)break;
        const uint8_t* bits=font.data+g.offset;
        for(int yy=0;yy<g.h;yy++)for(int xx=0;xx<g.w;xx++)if(bits[(yy*g.w+xx)/8]&(0x80>>((yy*g.w+xx)&7))){
            int px=cursor+g.x+xx,py=y+g.y+yy;
            const auto v=cassetteView;int dx=v.x+px*v.w/320,dy=v.y+py*v.h/213;
            // A shadow retains legibility on bright cover images without opaque glyph boxes.
            lcd.drawPixel(dx+1,dy+1,0x0000);lcd.drawPixel(dx,dy,coverVisible?0xffff:0x1082);
        }
        cursor+=g.advance;
    }
    dual::textCopy(rows[id],sizeof(rows[id]),value);widths[id]=w;
}
bool cassetteReady(){return !gallery.active()&&cassetteRequested&&cassettePixels&&valid&&previousPage==0&&network.status!=SOFT_AP;}
static void cassetteHome(const dual::Snapshot& s,bool layout){
    if(!cassettePixels){line(1,8,40,304,s.station,fg,layout);line(2,8,66,304,s.title,fg,layout);line(3,8,104,304,"Kazettakep feltoltesre var",accent,layout);return;}
    cassetteView=cassette::view({lcd.width(),lcd.height()});
    static uint32_t lastReel=0;
    bool animate=s.settings.reelAnimation&&s.playing&&s.freeHeap>=32768&&s.buffer>=16384;
    bool hubChanged=false;
    if(!s.settings.reelAnimation&&reelPhase){reelPhase=0;hubChanged=true;}
    if(animate&&uint32_t(millis()-lastReel)>=200){lastReel=millis();reelPhase=(reelPhase+1)%180;hubChanged=true;}
    if(layout)cassetteRect(0,0,320,213);
    else if(cassetteDirty)cassetteRect(18,21,284,122);
    if(hubChanged&&!layout){cassetteRect(68,71,40,40);cassetteRect(209,71,40,40);}
    bool labels=layout||cassetteDirty;cassetteDirty=false;
    cassetteLine(1,30,24,260,s.station,labels);
    cassetteLine(2,30,44,260,s.notice[0]?s.notice:s.title,labels);
    char value[40];snprintf(value,sizeof(value),"%s %u%%",s.playing?"LIVE":"STOP",unsigned(s.volume)*100/254);
    cassetteLine(3,208,128,90,value,labels);
    // Only the centre window changes on pause; both mechanical reels remain untouched.
    static int previousPlaying=-1;
    if(labels||previousPlaying!=int(s.playing)){
        cassetteRect(144,80,32,32);auto v=cassetteView;
        int x=v.x+152*v.w/320,y=v.y+88*v.h/213;
        if(s.playing){lcd.fillRect(x,y,3,14,0xffff);lcd.fillRect(x+8,y,3,14,0xffff);}
        else lcd.fillTriangle(x,y,x,y+14,x+12,y+7,0xffff);
        previousPlaying=s.playing;
    }
    // Small source-buffer bar in the unused margin; update changed fill only.
    static int oldFill=-1,oldSignal=-2;static bool oldBar=false,oldWifi=false;
    auto v=cassetteView;int barX=v.x+v.w/16,barW=v.w*7/8;
    int barY=v.y+v.h+4,barH=3;
    int fill=s.bufferCapacity?int(uint64_t(s.buffer)*barW/s.bufferCapacity):0;
    fill=constrain(fill,0,barW);
    if(barY+barH<=lcd.height()&&(layout||oldBar!=s.settings.bufferIndicator||oldFill!=fill)){
        lcd.fillRect(barX,barY,barW,barH,bg);
        if(s.settings.bufferIndicator){lcd.fillRect(barX,barY,barW,barH,0x2104);if(fill)lcd.fillRect(barX,barY,fill,barH,0x6c71);}
        oldFill=fill;oldBar=s.settings.bufferIndicator;
    }
    int signal=s.connected?(s.rssi>=-55?4:s.rssi>=-67?3:s.rssi>=-75?2:s.rssi>=-85?1:0):0;
    if(labels||oldWifi!=s.settings.wifiIndicator||oldSignal!=signal){
        cassetteRect(30,131,22,11);
        if(s.settings.wifiIndicator)for(int i=0;i<4;i++){
            int x=v.x+(31+i*5)*v.w/320,y=v.y+(140-(i+1)*2)*v.h/213;
            if(i<signal)lcd.fillRect(x,y,max(1,3*v.w/320),max(1,(i+1)*2*v.h/213),0x8410);
            else lcd.drawFastHLine(x,v.y+140*v.h/213,max(1,3*v.w/320),0xad55);
        }
        oldSignal=signal;oldWifi=s.settings.wifiIndicator;
    }
    // Disconnected shortcut stays on the opposite corner of the blue link icon.
    static int oldBt=-1,oldQuick=-1;
    const bool bt=btaudio::connected();
    const bool quick=s.settings.btQuickScan&&!bt;
    if(layout||oldQuick!=int(quick)){
        cassetteRect(8,5,24,22);
        if(quick){
            static constexpr uint8_t glyph[]={8,12,10,41,26,12,26,41,10,12,8};
            for(int y=0;y<11;y++)for(int x=0;x<6;x++)if(glyph[y]&(1<<(5-x)))
                lcd.fillRect(v.x+(15+x)*v.w/320,v.y+(10+y)*v.h/213,
                    max(1,v.w/320),max(1,v.h/213),0xf800);
        }
        oldQuick=int(quick);
    }
    // Restore only this small corner when the actual A2DP link changes.
    if(layout||oldBt!=int(bt)){
        cassetteRect(297,5,12,15);
        if(bt){
            static constexpr uint8_t glyph[]={8,12,10,41,26,12,26,41,10,12,8};
            for(int y=0;y<11;y++)for(int x=0;x<6;x++)if(glyph[y]&(1<<(5-x)))
                lcd.fillRect(v.x+(300+x)*v.w/320,v.y+(7+y)*v.h/213,
                    max(1,v.w/320),max(1,v.h/213),0x249f);
        }
        oldBt=int(bt);
    }
}
static void plainHome(const dual::Snapshot& s,bool layout){
    line(1,8,35,lcd.width()-16,s.station,accent,layout);
    auto v=cassette::view({lcd.width(),lcd.height()});
    static int previousPlainPlaying=-1;
    if(layout||previousPlainPlaying!=int(s.playing)){
        const int left[]={53,133,192},right[]={128,187,267};
        const char* labels[]={"<<",s.playing?"||":">",">>"};
        for(int i=0;i<3;i++){
            int x=v.x+left[i]*v.w/320,y=v.y+65*v.h/213;
            int width=(right[i]-left[i])*v.w/320,height=64*v.h/213;
            lcd.fillRect(x,y,width,height,bg);
            lcd.drawRoundRect(x,y,width,height,6,accent);
            text(x+max(2,(width-25)/2),y+max(2,(height-18)/2),width-4,labels[i],accent);
        }
        previousPlainPlaying=s.playing;
    }
    int titleY=v.y+135*v.h/213+8;
    line(2,8,titleY,lcd.width()-16,s.notice[0]?s.notice:s.title,fg,layout);
    char value[80];
    snprintf(value,sizeof(value),"%s  %u%%",s.playing?"LIVE":"STOP",unsigned(s.volume)*100/254);
    line(5,8,lcd.height()-53,lcd.width()-16,value,s.playing?accent:fg,layout);
    content::progress(value,sizeof(value),s);
    line(6,8,lcd.height()-27,lcd.width()-16,value,fg,layout);
}

static const uint8_t wifiQr[33][5]={
{0xfe,0x44,0xe7,0x3f,0x80},{0x82,0x98,0x20,0xa0,0x80},{0xba,0xfb,0x0f,0xae,0x80},{0xba,0xd2,0xab,0xae,0x80},
{0xba,0x0f,0xca,0x2e,0x80},{0x82,0x3d,0x31,0xa0,0x80},{0xfe,0xaa,0xaa,0xbf,0x80},{0x00,0xa3,0x9b,0x00,0x00},
{0x82,0xa2,0xd1,0x67,0x00},{0x80,0x25,0x77,0xf9,0x00},{0x2e,0x8f,0xca,0x5e,0x00},{0xc8,0xf4,0xe5,0xef,0x00},
{0xdb,0x9d,0x55,0xe7,0x80},{0x70,0x14,0x64,0xe2,0x00},{0x8a,0x7f,0xce,0x59,0x00},{0x0d,0x92,0x89,0xdb,0x00},
{0xb6,0xa3,0xe7,0x4d,0x00},{0x04,0xb7,0xb8,0x47,0x80},{0xb7,0xb9,0xff,0x5d,0x80},{0xc9,0x1c,0x93,0x96,0x80},
{0x3b,0x45,0x25,0x0a,0x80},{0xd9,0x6c,0x41,0xcb,0x80},{0xb2,0x7e,0x10,0x05,0x00},{0xbd,0x5f,0x99,0x93,0x80},
{0xe6,0x86,0x44,0xf9,0x00},{0x00,0xc7,0xcf,0x89,0x80},{0xfe,0x01,0xcb,0xae,0x00},{0x82,0x08,0x66,0x8a,0x80},
{0xba,0x0b,0x9e,0xfc,0x00},{0xba,0x6a,0x21,0xd6,0x80},{0xba,0x53,0x35,0xef,0x80},{0x82,0x28,0x01,0x2a,0x00},
{0xfe,0xb7,0x40,0xdd,0x00}};
static bool qrBit(int x,int y){return wifiQr[y][x>>3]&(0x80>>(x&7));}
static bool renderWifiQr(){
    const int scale=5,quiet=2,total=(33+quiet*2)*scale;
    int ox=(lcd.width()-total)/2,oy=30+(lcd.height()-70-total)/2;
    lcd.fillRect(ox,oy,total,total,0xffff);
    for(int y=0;y<33;y++)for(int x=0;x<33;x++)if(qrBit(x,y))
        lcd.fillRect(ox+(x+quiet)*scale,oy+(y+quiet)*scale,scale,scale,0x0000);
    return true;
}
static bool bootDisplayReady=false;
bool earlyBoot() {
    if(bootDisplayReady)return true;
    lcdSPI.begin(DUAL_TFT_SCK,DUAL_TFT_MISO,DUAL_TFT_MOSI,TFT_CS);
    // Physical SMALL panel: ST7789 320x240, native controller memory 240x320.
    lcd.init(240,320);
    // Read the same saved orientation used by the normal UI before boot art.
    uint8_t rotation=0;Preferences bootPrefs;
    if(bootPrefs.begin("yo-dual-v1",true)){
        rotation=bootPrefs.getUChar("rotate",0)&3u;bootPrefs.end();
    }
    lcd.setRotation((rotation+1)&3);
    lcd.invertDisplay(false); // Physical panel: correct RGB confirmed with V076 test.
    lcd.fillScreen(bg);
    // Original yoRadio RGB565 boot asset, enlarged2x with a248-byte scanline.
    // No filesystem, JPEG decoder, PSRAM or network is required at boot.
    pinMode(BRIGHTNESS_PIN,OUTPUT);digitalWrite(BRIGHTNESS_PIN,HIGH);
#if IBT_BOOT_RGB_TEST
    bootDisplayReady=true;
    return true;
#endif
    drawSkin(0);
    // Label this unfinished test build without replacing the approved boot artwork.
    lcd.setFont(nullptr);lcd.setTextSize(2);lcd.setTextWrap(false);lcd.setTextColor(0xf800);
    lcd.setCursor(136,190);lcd.print("BETA");
    bootDisplayReady=true;
    return true;
}
#if IBT_BOOT_RGB_TEST
void rgbBootTestTick(){
    static uint32_t changedAt=0;static unsigned phase=0;static bool first=true;
    uint32_t now=millis();
    if(!first&&uint32_t(now-changedAt)<3000)return;
    if(!first)phase=(phase+1)%3;
    first=false;changedAt=now;
    static const uint16_t colors[]={0xf800,0x07e0,0x001f};
    static const char* names[]={"R - PIROS","G - ZOLD","B - KEK"};
    lcd.fillScreen(colors[phase]);
    lcd.setFont(nullptr);lcd.setTextSize(3);lcd.setTextWrap(false);lcd.setTextColor(0x0000);
    int16_t x,y;uint16_t w,h;
    lcd.getTextBounds(names[phase],0,0,&x,&y,&w,&h);
    lcd.setCursor((lcd.width()-int(w))/2-x,(lcd.height()-int(h))/2-y);
    lcd.print(names[phase]);
    Serial.printf("[RGB-TEST] phase=%u rgb565=%04x size=%dx%d\n",phase,colors[phase],lcd.width(),lcd.height());
}
#endif
bool begin() { return earlyBoot(); }
void setRotation(uint8_t r) {lcd.setRotation((r+1)&3);valid=false;}
void calibrationTarget(int x,int y,unsigned step){lcd.fillScreen(bg);char b[48];snprintf(b,sizeof(b),"TOUCH CAL %u/4",step);text(8,8,300,b,fg);text(8,30,300,"Erintsd meg a keresztet",accent);lcd.drawCircle(x,y,10,accent);lcd.drawFastHLine(x-16,y,33,fg);lcd.drawFastVLine(x,y-16,33,fg);}
void calibrationDone(bool ok){lcd.fillScreen(bg);text(8,90,300,ok?"Touch kalibracio OK":"Touch kalibracio sikertelen",ok?accent:fg);delay(700);valid=false;}
void service(){
    const bool pressured=dual::uiOverloadActive();
    if(pressured&&!overloadDotPainted){
        lcd.fillCircle(lcd.width()-7,7,4,0xF800);
        overloadDotPainted=true;
    }else if(!pressured&&overloadDotPainted){
        overloadDotPainted=false;
        valid=false; // Restore the pixels under the dot on the next render.
    }
}
void artworkClear(){coverVisible=false;artW=artH=0;artDirty=true;cassetteDirty=true;}
bool artworkBegin(int w,int h){
    if(gallery.active())return false;
    if(w<=0||h<=0||w>112||h>112||!cassetteRequested||winampRequested||!cassettePixels||previousPage||network.status==SOFT_AP)return false;
    if(!coverPixels)coverPixels=(uint16_t*)heap_caps_malloc(112*112*2,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!coverPixels)return false;coverVisible=false;artW=w;artH=h;return true;
}
void artworkTile(int x,int y,int w,int h,int stride,const uint16_t *p){
    if(!coverPixels||!p||x<0||y<0||w<=0||h<=0||stride<w||x+w>artW||y+h>artH)return;
    for(int row=0;row<h;row++)memcpy(coverPixels+(y+row)*112+x,p+row*stride,w*2);
}
void artworkEnd(){coverVisible=true;cassetteDirty=true;}
void render(const dual::Snapshot &s,unsigned page,unsigned selected,bool force) {
    if(gallery.active()){
        if(gallery.painted!=gallery.index){drawSkin(gallery.index);gallery.painted=gallery.index;overloadDotPainted=false;}
        return;
    }
    time_t now=time(nullptr);tm local={};localtime_r(&now,&local);
    bool dark=dual::isDark(s.settings,local.tm_hour,now>1600000000);
    winampRequested=s.settings.winampEnabled&&lcd.width()==320&&lcd.height()==240;
    cassetteRequested=s.settings.cassetteEnabled&&!winampRequested;
    const bool setup=network.status==SOFT_AP;
    char connectingName[WIFI_SSID_CAP]={0};uint8_t connectingTry=0;
    const bool connecting=network.connectingInfo(connectingName,sizeof(connectingName),&connectingTry);
    static bool previousConnecting=false;
    // AP has only onboarding and QR layouts, independent of the underlying menu.
    if(setup)page=(page==17||page==28||page==42)?page:0;
    // A redraw request schedules inspection of changed rows; only structural
    // transitions invalidate the whole screen. Station/artwork changes are local.
    (void)force;
    bool layout=!valid||dark!=previousDark||page!=previousPage||setup!=previousSetup||connecting!=previousConnecting||s.settings.language!=previousLanguage||cassetteRequested!=previousCassette||winampRequested!=previousWinamp;
    if(s.generation!=previousGeneration){coverVisible=false;artW=artH=0;artDirty=true;cassetteDirty=true;}
    previousGeneration=s.generation;
    if(layout) {
        bg=dark?0x0841:0xef7d;fg=dark?0xffff:0x1082;accent=dark?0x05da:0x0290;muted=dark?0x7bef:0x8410;
        lcd.fillScreen(bg);overloadDotPainted=false;memset(rows,0,sizeof(rows));memset(widths,0,sizeof(widths));
        valid=true;previousDark=dark;previousPage=page;previousSetup=setup;previousConnecting=connecting;previousLanguage=s.settings.language;previousCassette=cassetteRequested;previousWinamp=winampRequested;artDirty=true;
        if(cassetteRequested){if(s.sd)artwork::redraw(s.generation);else onlineart::redraw(s.generation);}
    }
    int w=lcd.width(),h=lcd.height();const auto lang=s.settings.language;
    char buffer[200];
    uint16_t stressAction=0,stressDraw=0;uint32_t stressActions=0,stressFrames=0;
    const bool showStress=page==1&&dual::r10UiStressInfo(stressAction,stressDraw,stressActions,stressFrames);

    if(!setup&&connecting){
        line(0,8,25,w-16,content::pick(lang,"Csatlakozás...","Connecting...","Verbinden..."),accent,layout);
        line(1,8,75,w-16,connectingName,fg,layout);
        if(connectingTry){snprintf(buffer,sizeof(buffer),"%s %u/3",content::pick(lang,"Próba","Attempt","Versuch"),connectingTry);line(2,8,112,w-16,buffer,muted,layout);}
        else line(2,8,112,w-16,content::pick(lang,"Mentett hálózat keresése","Searching saved networks","Gespeicherte Netze suchen"),muted,layout);
        return;
    }

    // Mandatory Wi-Fi onboarding screen. While setup AP is active normal menus are hidden,
    // but no feature is deleted: after successful STA connect the ordinary UI returns.
    if(network.status==SOFT_AP){
        if(page==42){wifiPasswordScreen(selected,layout,lang);return;}
        if(page==17)snprintf(buffer,sizeof(buffer),"Wi-Fi QR");
        else if(page==28)snprintf(buffer,sizeof(buffer),"Wi-Fi scan");
        else snprintf(buffer,sizeof(buffer),"%s",content::pick(lang,"Wi-Fi beállítás","Wi-Fi setup","Wi-Fi Setup"));
        line(0,8,4,w-16,buffer,accent,layout);
        if(page==17){
            if(layout&&!renderWifiQr())line(1,8,92,w-16,"QR generation failed",fg,true);
            line(14,8,h-30,w-16,content::pick(lang,"Vissza","Back","Zurück"),accent,layout);
            return;
        }
        if(page==28){
            if(layout){lcd.drawRoundRect(w-83,3,75,28,5,accent);text(w-73,10,65,"FRISS",accent);}
            const uint8_t phase=network.scanStatus();
            const unsigned count=network.scanCount();
            if(phase==1)line(1,8,42,w-16,content::pick(lang,"Keresés...","Scanning...","Suche..."),fg,layout);
            else if(phase==3)line(1,8,42,w-16,content::pick(lang,"Keresés sikertelen","Scan failed","Suche fehlgeschlagen"),fg,layout);
            else if(!count)line(1,8,42,w-16,content::pick(lang,"Nincs hálózat","No networks","Keine Netze"),fg,layout);
            else {
                const unsigned rows=6;
                unsigned first=selected>=rows/2?selected-rows/2:0;
                if(count>rows&&first>count-rows)first=count-rows;
                for(unsigned row=0;row<rows;row++){
                    char ssid[WIFI_SSID_CAP];int rssi=0;
                    const unsigned index=first+row;
                    if(index<count&&network.scanEntry(index,ssid,sizeof(ssid),&rssi)){
                        snprintf(buffer,sizeof(buffer),"%c %s  %d",index==selected?'>':' ',ssid,rssi);
                        line(1+row,8,39+row*26,w-16,buffer,index==selected?accent:fg,layout);
                    }else line(1+row,8,39+row*26,w-16,"",fg,layout);
                }
            }
            if(layout){lcd.drawRoundRect(8,h-38,106,30,4,accent);text(18,h-32,88,"JELSZO",accent);}
            return;
        }
        if(layout){lcd.drawRoundRect(w-92,3,84,28,5,accent);text(w-80,10,72,"SCAN",accent);}
        if(connecting)snprintf(buffer,sizeof(buffer),"Connecting: %.28s",connectingName);
        else snprintf(buffer,sizeof(buffer),"%s",content::pick(lang,"Nincs Wi-Fi kapcsolat","No Wi-Fi connection","Keine Wi-Fi Verbindung"));
        line(1,8,34,w-16,buffer,fg,layout);
        line(2,8,60,w-16,content::pick(lang,"1. Csatlakozz ehhez:","1. Connect to:","1. Verbinde mit:"),fg,layout);
        line(3,8,84,w-16,network.setupSsid(),accent,layout);
        snprintf(buffer,sizeof(buffer),"%s: %s",content::pick(lang,"2. Jelszó","2. Password","2. Passwort"),apPassword);
        line(4,8,110,w-16,buffer,fg,layout);
        line(5,8,136,w-16,content::pick(lang,"3. Nyisd meg: 192.168.4.1","3. Open: 192.168.4.1","3. Öffne: 192.168.4.1"),fg,layout);
        char selectedName[WIFI_SSID_CAP];
        if(network.selectedSetupSsid(selectedName,sizeof(selectedName))){
            snprintf(buffer,sizeof(buffer),"Hotspot: %s",selectedName);line(6,8,162,w-16,buffer,accent,layout);
            line(7,8,186,w-95,content::pick(lang,"Jelszó a telefonon","Password on phone","Passwort am Handy"),muted,layout);
        }else line(6,8,162,w-16,content::pick(lang,"Add meg az otthoni Wi-Fi adatait","Enter home Wi-Fi name/password","Heim-Wi-Fi Daten eingeben"),fg,layout);
        if(layout){lcd.drawRoundRect(w-74,h-47,66,39,5,accent);text(w-57,h-36,48,"QR",accent);}
        return;
    }

    if(page==42){wifiPasswordScreen(selected,layout,lang);return;}

    if(!page){if(winampRequested)winampHome(s,layout);else if(cassetteRequested)cassetteHome(s,layout);else plainHome(s,layout);return;}

    if(page==41){
        const bool toSd=dual::sourcePendingSd();
        const auto status=player.sdPrepareState();
        line(0,8,8,w-16,content::pick(lang,"Forrásváltás","Changing source","Quelle wechseln"),accent,layout);
        if(!toSd){
            line(1,8,62,w-16,content::pick(lang,"Internetrádióra váltás","Switching to internet radio","Wechsel zum Internetradio"),fg,layout);
            line(2,8,100,w-16,content::pick(lang,"Kérlek várj...","Please wait...","Bitte warten..."),muted,layout);
        }else if(status==SdPrepareState::Indexing){
            snprintf(buffer,sizeof(buffer),"SD: %lu %s",(unsigned long)sdman.indexedTracks.load(),
              content::pick(lang,"fájl beolvasva","files indexed","Dateien gelesen"));
            line(1,8,62,w-16,buffer,fg,layout);
            line(2,8,100,w-16,content::pick(lang,"A hangfeladat szabad","Audio task remains free","Audioaufgabe bleibt frei"),muted,layout);
        }else if(status==SdPrepareState::Failed || status==SdPrepareState::Cancelled){
            line(1,8,62,w-16,status==SdPrepareState::Failed?
              content::pick(lang,"SD hiba vagy üres lista","SD error or empty list","SD Fehler oder leere Liste"):
              content::pick(lang,"SD beolvasás megszakítva","SD indexing cancelled","SD Lesen abgebrochen"),fg,layout);
        }else line(1,8,62,w-16,content::pick(lang,"Folyamatban...","Working...","Bitte warten..."),fg,layout);
        if(toSd)line(6,8,h-32,w-16,content::pick(lang,"Vissza: megszakítás","Back: cancel","Zurück: Abbrechen"),accent,layout);
        return;
    }

    if(page==44){
        line(0,8,4,w-16,content::pageTitle(lang,page),accent,layout);
        const unsigned saved=btaudio::savedDeviceCount();
        for(unsigned i=0;i<4;++i){
            btaudio::Device d{};
            if(i<saved&&btaudio::savedDevice(i,d))
                snprintf(buffer,sizeof(buffer),"%s%u. %s",selected==i?"> ":"  ",i+1,d.name);
            else snprintf(buffer,sizeof(buffer),"  %u. --",i+1);
            line(i+1,8,36+i*30,w-16,buffer,selected==i?accent:i<saved?fg:muted,layout);
        }
        snprintf(buffer,sizeof(buffer),"%s%s",selected==4?"> ":"  ",
            content::pick(lang,"Eszköz keresése...","Search for devices...","Geräte suchen..."));
        line(5,8,36+4*30,w-16,buffer,selected==4?accent:fg,layout);
        line(7,8,h-30,w-16,btaudio::connecting()||btaudio::linkFailed()?btaudio::status():"",
            btaudio::linkFailed()?0xF800:accent,layout);
        return;
    }

    if(page==40){
        // Deliberately only the list and scan indicator; no heading or help text.
        static int shownScan=-1;
        bool scan=btaudio::scanning();
        const bool waiting=btaudio::connecting();
        const int marker=scan?1:waiting&&((millis()/400)&1)?2:0;
        if(layout||shownScan!=marker){
            lcd.fillRect(w-28,4,24,24,bg);
            if(marker==1)lcd.fillCircle(w-16,16,7,0x07E0);
            else if(marker==2)lcd.fillCircle(w-16,16,7,0xFFE0);
            else lcd.drawCircle(w-16,16,7,fg);
            shownScan=marker;
        }
        unsigned n=btaudio::deviceCount(),rows=unsigned((h-36)/26);
        unsigned first=selected>=rows/2?selected-rows/2:0;
        if(n>rows&&first>n-rows)first=n-rows;
        for(unsigned row=0;row<rows;++row){
            unsigned i=first+row;btaudio::Device d{};
            if(btaudio::device(i,d))snprintf(buffer,sizeof(buffer),"%s%u. %s",selected==i?(btaudio::linkFailed()?"! ":"> "):"  ",i+1,d.name);
            else buffer[0]=0;
            line(1+row,8,36+row*26,w-16,buffer,selected==i?(btaudio::linkFailed()?0xF800:accent):fg,layout);
        }
        return;
    }
    if(page==39){
        line(0,8,4,w-16,content::pick(lang,"Bluetooth-bemenet","Bluetooth input","Bluetooth-Eingang"),accent,layout);
        line(1,8,28,w-16,btaudio::controlStatus(),fg,layout);
        snprintf(buffer,sizeof(buffer),"VOL %u%%",unsigned(s.volume)*100/254);
        line(2,8,48,w-16,buffer,fg,layout);
        if(layout){
            const char* labels[]={"<<",">",">>","VOL -","||","VOL +"};
            int cw=(w-16)/3,ch=(h-80)/2;
            for(unsigned i=0;i<6;++i){int x=8+(i%3)*cw,y=70+(i/3)*ch;
                lcd.drawRoundRect(x,y,cw-4,ch-4,6,accent);
                text(x+8,y+(ch-20)/2,cw-16,labels[i],fg);
            }
        }
        return;
    }

    if(showStress)snprintf(buffer,sizeof(buffer),"SELFTEST %u/%u ms",unsigned(stressAction),unsigned(stressDraw));
    line(0,8,4,w-16,showStress?buffer:page==37&&dual::backupRestoreArmed()?content::pick(lang,"Koppints újra 5 mp-en belül","Tap again within 5 s","Binnen 5 s erneut tippen"):content::pageTitle(lang,page),accent,layout);

    if(page==38){
        const char* operation="";
        switch(backupsd::lastOperation()){
          case backupsd::Operation::SavePlaylist:operation=content::pick(lang,"Állomások mentése","Save stations","Sender sichern");break;
          case backupsd::Operation::RestorePlaylist:operation=content::pick(lang,"Állomások visszaállítása","Restore stations","Sender wiederherstellen");break;
          case backupsd::Operation::SaveWifi:operation=content::pick(lang,"Wi-Fi mentése","Save Wi-Fi","Wi-Fi sichern");break;
          case backupsd::Operation::RestoreWifi:operation=content::pick(lang,"Wi-Fi visszaállítása","Restore Wi-Fi","Wi-Fi wiederherstellen");break;
        }
        line(1,8,48,w-16,operation,accent,layout);
        const char* status="ERROR";
        switch(backupsd::lastResult()){
          case backupsd::Result::Pass:status="PASS";break;
          case backupsd::Result::Busy:status=content::pick(lang,"Stop / NetRádió mód","Stop / Web radio mode","Stopp / Webradio-Modus");break;
          case backupsd::Result::NoCard:status=content::pick(lang,"Nincs SD kártya","No SD card","Keine SD Karte");break;
          case backupsd::Result::NoSource:status=content::pick(lang,"Nincs menthető adat","No source data","Keine Quelldaten");break;
          case backupsd::Result::NoBackup:status=content::pick(lang,"Nincs mentés","No backup","Keine Sicherung");break;
          case backupsd::Result::Full:status=content::pick(lang,"Megtelt a mentési lista","Backup slots full","Sicherungsplätze voll");break;
          case backupsd::Result::Invalid:status=content::pick(lang,"Sérült mentés","Invalid backup","Ungültige Sicherung");break;
          case backupsd::Result::WriteFailed:status=content::pick(lang,"SD írási hiba","SD write failed","SD Schreibfehler");break;
          case backupsd::Result::RestoreFailed:status=content::pick(lang,"Visszaállítási hiba","Restore failed","Wiederherstellung fehlgeschlagen");break;
          default:break;
        }
        line(2,8,80,w-16,status,backupsd::lastResult()==backupsd::Result::Pass?accent:fg,layout);
        line(3,8,120,w-16,backupsd::lastOperation()==backupsd::Operation::SaveWifi?content::pick(lang,"Wi-Fi jelszó az SD-n","Password stored on SD","Passwort auf SD gespeichert"):content::pick(lang,"Adatok: állomások / Wi-Fi","Data: stations / Wi-Fi","Daten: Sender / Wi-Fi"),muted,layout);
        line(7,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }

    if(page==5) {
        snprintf(buffer,sizeof(buffer),"CLK GPIO26 RAW = %d",board::rotaryDebugClk());line(1,8,34,w-16,buffer,fg,layout);
        snprintf(buffer,sizeof(buffer),"DT  GPIO35 RAW = %d",board::rotaryDebugDt());line(2,8,58,w-16,buffer,fg,layout);
        snprintf(buffer,sizeof(buffer),"SW  GPIO4  RAW = %d",board::rotaryDebugSw());line(3,8,82,w-16,buffer,fg,layout);
        snprintf(buffer,sizeof(buffer),"CLK chg %lu  R%lu F%lu",(unsigned long)board::rotaryDebugClkChanges(),(unsigned long)board::rotaryDebugClkRise(),(unsigned long)board::rotaryDebugClkFall());line(4,8,112,w-16,buffer,accent,layout);
        snprintf(buffer,sizeof(buffer),"DT  chg %lu  R%lu F%lu",(unsigned long)board::rotaryDebugDtChanges(),(unsigned long)board::rotaryDebugDtRise(),(unsigned long)board::rotaryDebugDtFall());line(5,8,136,w-16,buffer,accent,layout);
        snprintf(buffer,sizeof(buffer),"SW changes = %lu",(unsigned long)board::rotaryDebugSwChanges());line(6,8,160,w-16,buffer,fg,layout);
        const int d=board::rotaryDebugDirection();
        snprintf(buffer,sizeof(buffer),"CW %lu  CCW %lu  LAST %s",(unsigned long)board::rotaryDebugCW(),(unsigned long)board::rotaryDebugCCW(),d>0?"CW":d<0?"CCW":"NONE");line(7,8,190,w-16,buffer,accent,layout);
        line(8,8,216,w-16,content::pick(lang,"Nyomás: vissza","Press: back","Drücken: zurück"),fg,layout);return;
    }

    if(content::isMenuPage(page)){
        if(showStress){snprintf(buffer,sizeof(buffer),"L%lu K%lu B%luK",(unsigned long)stressActions,(unsigned long)stressFrames,(unsigned long)(s.buffer/1024));line(1,8,24,w-16,buffer,fg,layout);}
        else if(s.pendingSave)line(1,8,24,w-16,dual::tr(lang,dual::Text::SavePending),fg,layout);
        else line(1,8,24,w-16,"",fg,layout);
        unsigned count=content::itemCount(page);
        unsigned visible=page==10?8:count;
        unsigned first=page==10&&selected>=4?selected-4:0;
        if(first+visible>count)first=count-visible;
        int rowHeight=page==10?23:(h-52)/int(count);
        for(unsigned i=0;i<visible;i++){
            const unsigned item=first+i;
            char label[170];bool enabled=content::menuItem(label,sizeof(label),s,page,item);
            snprintf(buffer,sizeof(buffer),"%s%s",selected==item?"> ":"  ",label);
            uint16_t color=enabled?(selected==item?accent:fg):muted;
            line(i+2,8,44+i*rowHeight,w-16,buffer,color,layout);
        }
        return;
    }

    if(page==31){
        snprintf(buffer,sizeof(buffer),"%s: %s",content::pick(lang,"Név","Name","Name"),dual::stationSearchQuery());
        line(1,8,31,w-16,buffer,accent,layout);
        static int previousKey=-1;
        if(layout)previousKey=-1;
        auto drawKey=[&](unsigned key){
            int keyW=(w-20)/6,keyH=(h-90)/5;
            int x=10+int(key%6)*keyW,y=65+int(key/6)*keyH;
            lcd.fillRect(x,y,keyW-2,keyH-2,bg);
            uint16_t color=selected==key?accent:fg;
            lcd.drawRoundRect(x,y,keyW-2,keyH-2,4,color);
            char label[5]={};
            if(key<26){label[0]=char('A'+key);}
            else snprintf(label,sizeof(label),"%s",key==26?"SP":key==27?"DEL":key==28?"OK":"X");
            text(x+(key<26?keyW/2-7:3),y+(keyH-20)/2,keyW-5,label,color);
        };
        if(layout){for(unsigned i=0;i<30;i++)drawKey(i);}
        else if(previousKey!=int(selected)){
            if(previousKey>=0)drawKey(unsigned(previousKey));
            drawKey(selected);
        }
        previousKey=int(selected);
        const char* status="";
        switch(dual::stationSearchStatus()){
          case 1:status=content::pick(lang,"Állítsd le a rádiót","Stop radio first","Radio zuerst stoppen");break;
          case 2:status=content::pick(lang,"Lista hibás vagy hiányzik","Playlist missing/invalid","Liste fehlt/ungültig");break;
          case 3:status=content::pick(lang,"Nincs találat","No matches","Keine Treffer");break;
          case 4:status=content::pick(lang,"Válts internet rádióra","Switch to internet radio","Internetradio wählen");break;
          default:if(s.playing)status=content::pick(lang,"Kereséshez állítsd le","Stop to search","Zum Suchen stoppen");break;
        }
        line(15,8,h-24,w-16,status,muted,layout);return;
    }
    if(page==32){
        unsigned total=dual::stationSearchCount();
        snprintf(buffer,sizeof(buffer),"%s: %u  %s",content::pick(lang,"Találat","Results","Treffer"),total,dual::stationSearchQuery());
        line(1,8,30,w-16,buffer,accent,layout);
        unsigned first=selected>=2?selected-2:0;
        if(total>6&&first>total-6)first=total-6;
        for(unsigned row=0;row<6;row++){
            unsigned i=first+row;uint16_t station=dual::stationSearchResult(i);
            if(station){
                char name[170];
                dual::stationSearchResultName(i,name,sizeof(name));
                snprintf(buffer,sizeof(buffer),"%s%u %s",i==selected?"> ":"  ",station,name);
                line(2+row,8,56+row*23,w-16,buffer,i==selected?accent:fg,layout);
            }else line(2+row,8,56+row*23,w-16,"",fg,layout);
        }
        line(10,8,h-25,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==33){
        if(!s.connected)line(1,8,44,w-16,content::pick(lang,"Wi-Fi kapcsolat szükséges","Wi-Fi connection required","Wi-Fi Verbindung nötig"),fg,layout);
        else if(config.emptyFS)line(1,8,44,w-16,content::pick(lang,"WebUI fájlok hiányoznak","WebUI files missing","WebUI Dateien fehlen"),fg,layout);
        else {
            snprintf(buffer,sizeof(buffer),"http://%s/",s.ip);
            line(1,8,44,w-16,buffer,accent,layout);
            line(2,8,78,w-16,content::pick(lang,"Böngésző: Playlist Editor","Browser: Playlist Editor","Browser: Playlist Editor"),fg,layout);
            line(3,8,108,w-16,content::pick(lang,"Szerkesztés és mentés","Edit and save","Bearbeiten und speichern"),fg,layout);
            line(4,8,138,w-16,content::pick(lang,"Import / export: CSV","Import / export: CSV","Import / Export: CSV"),fg,layout);
        }
        line(8,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==34){
        line(1,8,42,w-16,content::pick(lang,"Csak leállított lejátszásnál","Playback must be stopped","Wiedergabe muss stoppen"),fg,layout);
        line(2,8,72,w-16,content::pick(lang,"Érintés: teljes HiMem próba","Tap: full HiMem check","Tippen: voller HiMem Test"),accent,layout);
        const auto& m=v027::memoryReport();
        const char* status="KÉSZ";
        switch(dual::memoryStressStatus()){
          case 1:status="PASS";break;
          case 2:status="FAIL / NOT_RUN";break;
          case 3:status="LIMITER: BUSY / LOW HEAP";break;
          case 4:status="STOP RADIO FIRST";break;
        }
        snprintf(buffer,sizeof(buffer),"%s: %s",content::pick(lang,"Eredmény","Result","Ergebnis"),status);
        line(3,8,110,w-16,buffer,dual::memoryStressStatus()==1?accent:fg,layout);
        snprintf(buffer,sizeof(buffer),"HiMem %u / %u KiB",unsigned(m.highTested/1024),unsigned(m.highTotal/1024));
        line(4,8,140,w-16,buffer,fg,layout);
        snprintf(buffer,sizeof(buffer),"Errors: %lu",(unsigned long)m.errors);
        line(5,8,170,w-16,buffer,fg,layout);
        line(8,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }

    if(page==4&&winampRequested){winampStationList(s,selected,layout);return;}
    if(page==4||page==29) {
        bool favorites=page==29;uint16_t total=favorites?dual::favoritesCount():config.playlistLength();
        if(favorites)snprintf(buffer,sizeof(buffer),"%s: %u  #%u",content::pick(lang,"Kedvencek","Favorites","Favoriten"),total,selected);
        else snprintf(buffer,sizeof(buffer),"%s %u / %u",s.sd?content::pick(lang,"Fájl","File","Datei"):content::pick(lang,"Állomás","Station","Sender"),selected,total);
        line(1,8,30,w-16,buffer,accent,layout);
        if(total) {
            int first=int(selected)-3;uint16_t favStation=uint16_t(selected);
            for(int i=0;i<7&&(!favorites||i<total);i++) {
                int n;
                if(favorites){n=favStation;favStation=dual::nextFavorite(favStation,true);}
                else {n=first+i;while(n<1)n+=total;while(n>total)n-=total;}
                const char *name=config.stationByNum((uint16_t)n);
                snprintf(buffer,sizeof(buffer),"%s%u%s %s",n==(int)selected?"> ":"  ",n,!s.sd&&dual::favorite((uint16_t)n)?"*":"",name?name:"");
                line(2+i,8,56+i*23,w-16,buffer,n==(int)selected?accent:fg,layout);
            }
        } else line(2,8,70,w-16,s.sd?content::pick(lang,"Nincs MP3/FLAC fájl","No MP3/FLAC files","Keine MP3/FLAC-Dateien"):content::pick(lang,favorites?"Nincs kedvenc":"Nincs állomáslista",favorites?"No favorites":"No station list",favorites?"Keine Favoriten":"Keine Senderliste"),fg,layout);
        return;
    }

    if(page==2) {
        const auto& m=v027::memoryReport();
        snprintf(buffer,sizeof(buffer),"IP %s",s.ip);line(1,8,32,w-16,buffer,fg,layout);
        snprintf(buffer,sizeof(buffer),"PSRAM chip: %u KiB",unsigned(m.physical/1024));line(2,8,56,w-16,buffer,accent,layout);
        snprintf(buffer,sizeof(buffer),"Heap %u / %u KiB used",unsigned((ESP.getPsramSize()-ESP.getFreePsram())/1024),unsigned(ESP.getPsramSize()/1024));line(3,8,80,w-16,buffer,fg,layout);
        snprintf(buffer,sizeof(buffer),"HiMem free %u / %u KiB",unsigned(m.highFree/1024),unsigned(m.highTotal/1024));line(4,8,104,w-16,buffer,fg,layout);
        snprintf(buffer,sizeof(buffer),"Map window: %u KiB",unsigned(m.mapWindow/1024));line(5,8,128,w-16,buffer,fg,layout);
        snprintf(buffer,sizeof(buffer),"HiMem test %s %u KiB",m.highResult?m.highResult:"NOT_RUN",unsigned(m.highTested/1024));line(6,8,152,w-16,buffer,accent,layout);
        snprintf(buffer,sizeof(buffer),"Internal free %lu",(unsigned long)s.freeHeap);line(7,8,176,w-16,buffer,fg,layout);
        line(8,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==20){
        line(0,8,20,w-16,"BETA RELEASE",0xf800,layout);
        line(1,8,47,w-16,IBT_FW_VERSION,accent,layout);
        line(2,8,74,w-16,"ESP32 / ST7789 320x240",fg,layout);
        line(3,8,101,w-16,"PCM5102 / I2S",fg,layout);
        const auto& m=v027::memoryReport();
        snprintf(buffer,sizeof(buffer),"PSRAM chip: %u KiB",unsigned(m.physical/1024));line(4,8,128,w-16,buffer,fg,layout);
        line(5,8,155,w-16,"Developed by Kisst\"on\"Tour",fg,layout);
        line(6,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==18){
        snprintf(buffer,sizeof(buffer),"%s: %s",content::pick(lang,"Állapot","Status","Status"),s.connected?content::pick(lang,"csatlakozva","connected","verbunden"):content::pick(lang,"offline","offline","offline"));line(1,8,44,w-16,buffer,s.connected?accent:fg,layout);
        snprintf(buffer,sizeof(buffer),"IP: %s",s.ip);line(2,8,72,w-16,buffer,fg,layout);
        if(s.connected){snprintf(buffer,sizeof(buffer),"RSSI: %d dBm",s.rssi);line(3,8,100,w-16,buffer,fg,layout);}
        snprintf(buffer,sizeof(buffer),"Setup AP: %s",network.setupSsid());line(4,8,128,w-16,buffer,muted,layout);
        line(5,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==21){
        for(unsigned i=0;i<5;i++)line(1+i,8,46+i*28,w-16,i<config.ssidsCount?config.ssids[i].ssid:"",fg,layout);
        line(7,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==28){
        if(s.playing)line(1,8,46,w-16,content::pick(lang,"Állítsd le a rádiót","Stop playback to scan","Radio zum Scannen stoppen"),fg,layout);
        else if(s.freeHeap<48000||s.largestHeap<16000)line(1,8,46,w-16,content::pick(lang,"Kevés szabad memória","Low free memory","Wenig freier Speicher"),fg,layout);
        else {
            const uint8_t phase=network.scanStatus();
            const unsigned count=network.scanCount();
            if(phase==1)line(1,8,46,w-16,content::pick(lang,"Keresés...","Scanning...","Suche..."),fg,layout);
            else if(phase==3)line(1,8,46,w-16,content::pick(lang,"Keresés sikertelen","Scan failed","Suche fehlgeschlagen"),fg,layout);
            else if(!count)line(1,8,46,w-16,content::pick(lang,"Nincs hálózat","No networks found","Keine Netzwerke"),fg,layout);
            else {
                const unsigned visible=5;
                unsigned first=selected>=visible/2?selected-visible/2:0;
                if(count>visible&&first>count-visible)first=count-visible;
                for(unsigned row=0;row<visible;row++){
                    char ssid[WIFI_SSID_CAP];int rssi=0;
                    const unsigned index=first+row;
                    if(index<count&&network.scanEntry(index,ssid,sizeof(ssid),&rssi)){
                        snprintf(buffer,sizeof(buffer),"%c %s  %d dBm",index==selected?'>':' ',ssid,rssi);
                        line(1+row,8,46+row*28,w-16,buffer,index==selected?accent:fg,layout);
                    }else line(1+row,8,46+row*28,w-16,"",fg,layout);
                }
            }
        }
        if(layout){lcd.drawRoundRect(8,h-38,106,30,4,accent);text(18,h-32,88,"JELSZO",accent);}
        return;
    }
    if(page==22||page==23){
        line(1,8,48,w-16,page==22?btaudio::status():"PCM5102A / I2S",fg,layout);
        line(2,8,84,w-16,page==22?(btaudio::inputSelected()?"Phone -> PCM5102A":"Radio -> Fej/Ful/Box"):"Fixed audio output",muted,layout);
        line(3,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==24){
        line(1,8,48,w-16,config.emptyFS?"Web files: missing":"Web files: present",config.emptyFS?muted:fg,layout);
        static size_t used=0,total=0;
        if(layout){used=SPIFFS.usedBytes()/1024;total=SPIFFS.totalBytes()/1024;}
        snprintf(buffer,sizeof(buffer),"SPIFFS %lu / %lu KiB",(unsigned long)used,(unsigned long)total);
        line(2,8,84,w-16,buffer,fg,layout);
        line(3,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==25){
        auto cache=onlineart::cacheStatus(s.generation);
        snprintf(buffer,sizeof(buffer),"Cover JPEG: %lu bytes",(unsigned long)cache.bytes);line(1,8,48,w-16,buffer,fg,layout);
        snprintf(buffer,sizeof(buffer),"Pending: %u  Failures: %u",cache.pending?1:0,cache.failures);line(2,8,84,w-16,buffer,fg,layout);
        line(3,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==30){
#if FEATURE_SD
        line(1,8,48,w-16,sdman.ready?content::pick(lang,"SD csatolva","SD mounted","SD eingebunden"):content::pick(lang,"SD nincs csatolva","SD not mounted","SD nicht eingebunden"),sdman.ready?accent:muted,layout);
        line(2,8,84,w-16,s.sd?content::pick(lang,"SD lejátszás aktív","SD playback active","SD Wiedergabe aktiv"):content::pick(lang,"Internet rádió aktív","Internet radio active","Internetradio aktiv"),fg,layout);
#endif
        line(3,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==26){
        if(s.connected)snprintf(buffer,sizeof(buffer),"http://%s/emergency",s.ip);
        else snprintf(buffer,sizeof(buffer),"Wi-Fi offline");
        line(1,8,48,w-16,buffer,fg,layout);
        line(2,8,84,w-16,"Upload firmware in browser",muted,layout);
        line(3,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }
    if(page==27){
        line(1,8,44,w-16,s.settings.rotaryMode==1?"Rotary: hangerő":"Rotary: állomás",fg,layout);
        line(2,8,74,w-16,"Nyomás: választ / pause",fg,layout);
        line(3,8,104,w-16,"Hosszú: vissza / lista",fg,layout);
        line(4,8,134,w-16,"Tekercsek: előző / következő",fg,layout);
        line(5,8,h-30,w-16,dual::tr(lang,dual::Text::Back),accent,layout);return;
    }

}
}
#endif
