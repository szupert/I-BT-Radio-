#pragma once
#include "../dual/core.h"
#include "../dual/bt_audio.h"
#include <stdio.h>
#include "../dual/vu_probe.h"
namespace content {
inline const char* pick(dual::Language l,const char* hu,const char* en,const char* de){
    return unsigned(l)==0?hu:unsigned(l)==1?en:de;
}
inline unsigned itemCount(unsigned page){
    switch(page){
      case 1:return 4;   // root
      case 3:return 6;   // Bluetooth input, output, DAC, status, rate, back
      case 45:return 8;
      case 46:return 6;
      case 43:return 5;  // four standard SBC rates and back
      case 6:return 5;   // sound
      case 7:return 9;   // settings
      case 8:return 6;   // stations
      case 9:return 5;   // wifi
      case 10:return 11;  // display
      case 11:return 5;  // controls
      case 12:return 5;  // storage
      case 13:return 6;  // diagnostics
      case 19:return 6;  // system
      case 14:return 4;  // volume/stream
      case 15:return 5;  // eq
      case 16:return 5;  // outputs
      case 37:return 5;  // SD data backup / restore
      default:return 0;
    }
}
inline bool isMenuPage(unsigned page){return itemCount(page)!=0;}
inline const char* pageTitle(dual::Language l,unsigned page){
    switch(page){
      case 1:return pick(l,"Menü","Menu","Menü");
      case 2:return pick(l,"Memória","Memory","Speicher");
      case 3:return "Bluetooth";
      case 46:return pick(l,"VU frissítés","VU refresh","VU Aktualisierung");
      case 45:return pick(l,"Tétlenség","Inactivity","Inaktivität");
      case 44:return pick(l,"Bluetooth-kimenet","Bluetooth output","Bluetooth-Ausgang");
      case 43:return pick(l,"BT kimeneti frekvencia","BT output rate","BT-Ausgangsrate");
      case 4:return pick(l,"Állomások","Stations","Sender");
      case 5:return "Rotary debug";
      case 6:return pick(l,"Hang","Sound","Klang");
      case 7:return pick(l,"Beállítások","Settings","Einstellungen");
      case 8:return pick(l,"Állomások","Stations","Sender");
      case 9:return "Wi-Fi";
      case 10:return pick(l,"Kijelző","Display","Anzeige");
      case 11:return pick(l,"Vezérlés","Controls","Steuerung");
      case 12:return pick(l,"Tárhely","Storage","Speicher");
      case 13:return pick(l,"Diagnosztika","Diagnostics","Diagnose");
      case 20:return pick(l,"Firmware információ","Firmware info","Firmware Info");
      case 19:return pick(l,"Rendszer","System","System");
      case 14:return pick(l,"Hangerő / Stream","Volume / Stream","Lautstärke / Stream");
      case 15:return "EQ";
      case 16:return pick(l,"Kimenetek","Outputs","Ausgänge");
      case 18:return pick(l,"Hálózat","Network","Netzwerk");
      case 21:return pick(l,"Mentett Wi-Fi","Saved Wi-Fi","Gespeichertes Wi-Fi");
      case 22:return "Bluetooth";
      case 23:return "PCM5102A";
      case 24:return pick(l,"Fájlrendszer","Filesystem","Dateisystem");
      case 25:return "Artwork cache";
      case 26:return pick(l,"Webes frissítés","Web update","Web-Update");
      case 27:return pick(l,"Gombkiosztás","Button mapping","Tastenbelegung");
      case 28:return pick(l,"Hálózatok","Networks","Netzwerke");
      case 29:return pick(l,"Kedvencek","Favorites","Favoriten");
      case 30:return pick(l,"SD kártya","SD card","SD Karte");
      case 31:return pick(l,"Állomáskeresés","Station search","Sendersuche");
      case 32:return pick(l,"Találatok","Results","Treffer");
      case 33:return pick(l,"Playlist kezelés","Playlist editor","Playlist Verwaltung");
      case 34:return pick(l,"PSRAM stresszteszt","PSRAM stress test","PSRAM Stresstest");
      case 37:return pick(l,"Mentés / vissza SD","SD backup / restore","SD Sichern / Zurück");
      case 38:return pick(l,"Adatmentés eredménye","Backup result","Sicherungsergebnis");
      default:return "?";
    }
}
inline bool menuItem(char *out,size_t cap,const dual::Snapshot &s,unsigned page,unsigned item){
    const auto l=s.settings.language; const char* label="?"; char value[48]={}; bool enabled=false;
    switch(page){
    case 1:
        {static const char* hu[]={"Állomások","Hang","Bluetooth","Beállítások"};
         static const char* en[]={"Stations","Sound","Bluetooth","Settings"};
         static const char* de[]={"Sender","Klang","Bluetooth","Einstellungen"};
         if(item<4){label=unsigned(l)==0?hu[item]:unsigned(l)==1?en[item]:de[item];enabled=true;}}
        break;
    case 8:
        switch(item){
          case 0:label=pick(l,"Internet rádió","Internet radio","Internetradio");enabled=true;break;
          case 1:label=pick(l,"Kedvencek","Favorites","Favoriten");enabled=true;break;
          case 2:label=pick(l,"Keresés","Search","Suche");enabled=true;break;
          case 3:label=pick(l,"SD lejátszás","SD playback","SD Wiedergabe");
#if FEATURE_SD
              enabled=true;
#endif
              break;
          case 4:label=pick(l,"Playlist kezelés","Playlist editor","Playlist Verwaltung");enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 6:
        switch(item){
          case 0:label=pick(l,"Hangerő / Stream","Volume / Stream","Lautstärke / Stream");enabled=true;break;
          case 1:label=pick(l,"Hangszín / EQ","Tone / EQ","Klang / EQ");enabled=true;break;
          case 2:label=pick(l,"Kimenetek","Outputs","Ausgänge");enabled=true;break;
          case 3:label=pick(l,"Bluetooth-hang","Bluetooth audio","Bluetooth Audio");enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 14:
        switch(item){
          case 0:label=pick(l,"Hangerő lépés","Volume step","Lautstärke Schritt");snprintf(value,sizeof(value),"%u",s.settings.volumeStep);enabled=true;break;
          case 1:label=pick(l,"Stream limit","Stream limit","Stream Limit");if(s.settings.maxKbps)snprintf(value,sizeof(value),"%u k",s.settings.maxKbps);else snprintf(value,sizeof(value),"MAX");enabled=true;break;
          case 2:label="Balance";snprintf(value,sizeof(value),"%+d",int(s.balance));enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 15:
        switch(item){
          case 0:label="Bass";snprintf(value,sizeof(value),"OFF");enabled=false;break;
          case 1:label=pick(l,"Közép","Middle","Mitten");snprintf(value,sizeof(value),"OFF");enabled=false;break;
          case 2:label="Treble";snprintf(value,sizeof(value),"OFF");enabled=false;break;
          case 3:label="PEQ / DSP";break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 16:
        switch(item){
          case 0:label="PCM5102A";enabled=true;break;
          case 1:label=pick(l,"Belső DAC","Internal DAC","Interner DAC");break;
          case 2:label=pick(l,"Bluetooth-kimenet","Bluetooth output","Bluetooth-Ausgang");enabled=true;break;
          case 3:label=pick(l,"Bluetooth-bemenet","Bluetooth input","Bluetooth-Eingang");enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 3:
        switch(item){
          case 0:label=pick(l,"Bluetooth-bemenet","Bluetooth input","Bluetooth-Eingang");enabled=true;break;
          case 1:label=pick(l,"Bluetooth-kimenet","Bluetooth output","Bluetooth-Ausgang");enabled=true;break;
          case 2:label=pick(l,"Vissza a DAC-ra","Return to DAC","Zurück zum DAC");enabled=true;break;
          case 3:label=pick(l,"Állapot","Status","Status");enabled=true;break;
          case 4:label=pick(l,"BT kimenet kHz","BT output kHz","BT-Ausgang kHz");snprintf(value,sizeof(value),"%u%s",btaudio::outputRate()==44100?44:btaudio::outputRate()/1000,btaudio::outputRate()==44100?",1":"");enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 43:
        if(item<4){static const unsigned rates[]={16000,32000,44100,48000};
            const unsigned hz=rates[item];snprintf(value,sizeof(value),"%s",btaudio::outputRate()==hz?"*":"");
            label=hz==16000?"16 kHz":hz==32000?"32 kHz":hz==44100?"44,1 kHz":"48 kHz";enabled=true;
        }else{label=dual::tr(l,dual::Text::Back);enabled=true;}
        break;
    case 46:{
        static const char* labels[]={"100 ms","200 ms","250 ms","500 ms","1000 ms"};
        if(item<5){label=labels[item];if(vuprobe::refreshMs.load(std::memory_order_relaxed)==vuprobe::refreshOptions[item])snprintf(value,sizeof(value),"*");}
        else label=dual::tr(l,dual::Text::Back);
        enabled=true;break;
    }
    case 45:{
        static const uint16_t seconds[]={10,20,30,60,120,300,0};
        static const char* labels[]={"10 mp","20 mp","30 mp","1 perc","2 perc","5 perc","Végtelen"};
        if(item<7){label=labels[item];if(s.settings.menuIdleSeconds==seconds[item])snprintf(value,sizeof(value),"*");}
        else label=dual::tr(l,dual::Text::Back);
        enabled=true;break;
    }
    case 7:
        switch(item){
          case 0:label="Wi-Fi";enabled=true;break;
          case 1:label=pick(l,"Kijelző","Display","Anzeige");enabled=true;break;
          case 2:label=pick(l,"Vezérlés","Controls","Steuerung");enabled=true;break;
          case 3:label=pick(l,"Tárhely","Storage","Speicher");enabled=true;break;
          case 4:label=pick(l,"Rendszer","System","System");enabled=true;break;
          case 5:label=pick(l,"Diagnosztika","Diagnostics","Diagnose");enabled=true;break;
          case 6:label=pick(l,"Tétlenség","Inactivity","Inaktivität");enabled=true;break;
          case 7:label=pick(l,"VU frissítés","VU refresh","VU Aktualisierung");enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 9:
        switch(item){
          case 0:label=pick(l,"Állapot","Status","Status");snprintf(value,sizeof(value),"%s",s.connected?pick(l,"csatlakozva","connected","verbunden"):pick(l,"nincs kapcsolat","offline","offline"));enabled=true;break;
          case 1:label=pick(l,"Új Wi-Fi beállítása","Set up new Wi-Fi","Neues Wi-Fi einrichten");enabled=true;break;
          case 2:label=pick(l,"Mentett hálózatok","Saved networks","Gespeicherte Netze");enabled=true;break;
          case 3:label=pick(l,"Hálózat keresése","Scan networks","Netze suchen");enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 10:
        switch(item){
          case 0:{label=dual::tr(l,dual::Text::Theme);const char* v[3][3]={{"Sötét","Világos","Auto"},{"Dark","Light","Auto"},{"Dunkel","Hell","Auto"}};snprintf(value,sizeof(value),"%s",v[unsigned(l)][unsigned(s.settings.theme)]);enabled=true;break;}
          case 1:label=dual::tr(l,dual::Text::Rotation);snprintf(value,sizeof(value),"%u°",s.settings.rotation*90);enabled=true;break;
          case 2:label=dual::tr(l,dual::Text::Brightness);snprintf(value,sizeof(value),"%u%%",s.settings.brightness);enabled=true;break;
          case 3:label=pick(l,"Borítókép / Artwork","Artwork","Cover");snprintf(value,sizeof(value),"%s",s.settings.artworkEnabled?pick(l,"Be","On","Ein"):pick(l,"Ki","Off","Aus"));enabled=true;break;
          case 4:label=pick(l,"Kazetta nézet","Cassette view","Kassettenansicht");snprintf(value,sizeof(value),"%s",s.settings.cassetteEnabled?pick(l,"Be","On","Ein"):pick(l,"Ki","Off","Aus"));enabled=true;break;
          case 5:label=pick(l,"Pufferjelző","Buffer bar","Pufferanzeige");snprintf(value,sizeof(value),"%s",s.settings.bufferIndicator?pick(l,"Be","On","Ein"):pick(l,"Ki","Off","Aus"));enabled=true;break;
          case 6:label=pick(l,"Orsóforgás","Reel animation","Spulenanimation");snprintf(value,sizeof(value),"%s",s.settings.reelAnimation?pick(l,"Be","On","Ein"):pick(l,"Ki","Off","Aus"));enabled=true;break;
          case 7:label=pick(l,"Wi-Fi térerő","Wi-Fi signal","Wi-Fi Signal");snprintf(value,sizeof(value),"%s",s.settings.wifiIndicator?pick(l,"Be","On","Ein"):pick(l,"Ki","Off","Aus"));enabled=true;break;
          case 8:label=pick(l,"BT gyorskereső","BT quick scan","BT-Schnellsuche");snprintf(value,sizeof(value),"%s",s.settings.btQuickScan?pick(l,"Be","On","Ein"):pick(l,"Ki","Off","Aus"));enabled=true;break;
          case 9:label=pick(l,"Winamp nézet","Winamp view","Winamp Ansicht");snprintf(value,sizeof(value),"%s",s.settings.winampEnabled?pick(l,"Be","On","Ein"):pick(l,"Ki","Off","Aus"));enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 11:
        switch(item){
          case 0:label="Rotary";snprintf(value,sizeof(value),"%s",s.settings.rotaryMode==1?pick(l,"hangerő","volume","Lautstärke"):pick(l,"állomás","station","Sender"));enabled=true;break;
          case 1:label=pick(l,"Touch kalibráció (stop)","Touch calibration (stop)","Touch Kalibrierung (Stopp)");enabled=true;break;
          case 2:label=pick(l,"Gombkiosztás","Button mapping","Tastenbelegung");enabled=true;break;
          case 3:label="IR / Remote";break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 12:
        switch(item){
          case 0:label="PSRAM / HiMem";enabled=true;break;
          case 1:label=pick(l,"SD kártya","SD card","SD Karte");
#if FEATURE_SD
              enabled=true;
#endif
              break;
          case 2:label=pick(l,"Artwork cache","Artwork cache","Artwork Cache");enabled=true;break;
          case 3:label=pick(l,"Fájlrendszer","Filesystem","Dateisystem");enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 19:
        switch(item){
          case 0:label=dual::tr(l,dual::Text::Language);snprintf(value,sizeof(value),"%s",unsigned(l)==0?"Magyar":unsigned(l)==1?"English":"Deutsch");enabled=true;break;
          case 1:label=pick(l,"Firmware információ","Firmware info","Firmware Info");enabled=true;break;
          case 2:label=pick(l,"Webes frissítés","Web update","Web-Update");enabled=true;break;
          case 3:label=pick(l,"Újraindítás (2×, stop)","Restart (twice, stop)","Neustart (2×, Stopp)");enabled=true;break;
          case 4:label=pick(l,"Mentés / vissza SD","SD backup / restore","SD Sichern / Zurück");
#if FEATURE_SD
              enabled=true;
#endif
              break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 13:
        switch(item){
          case 0:label="Debug";snprintf(value,sizeof(value),"%s",s.settings.debug?pick(l,"Be","On","Ein"):pick(l,"Ki","Off","Aus"));enabled=true;break;
          case 1:label=pick(l,"Memória / PSRAM","Memory / PSRAM","Speicher / PSRAM");enabled=true;break;
          case 2:label=pick(l,"Hálózat","Network","Netzwerk");enabled=true;break;
          case 3:label="Rotary debug";enabled=true;break;
          case 4:label=pick(l,"PSRAM stresszteszt","PSRAM stress test","PSRAM Stresstest");enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    case 37:
        switch(item){
          case 0:label=pick(l,"Állomások mentése","Save stations","Sender sichern");enabled=true;break;
          case 1:label=pick(l,"Állomások vissza (2×)","Restore stations (2x)","Sender zurück (2x)");enabled=true;break;
          case 2:label=pick(l,"Wi-Fi mentése","Save Wi-Fi","Wi-Fi sichern");enabled=true;break;
          case 3:label=pick(l,"Wi-Fi vissza (2×)","Restore Wi-Fi (2x)","Wi-Fi zurück (2x)");enabled=true;break;
          default:label=dual::tr(l,dual::Text::Back);enabled=true;break;
        } break;
    default: break;
    }
    snprintf(out,cap,"%s%s%s",label,*value?": ":"",value);
    return enabled;
}
inline void progress(char *out,size_t cap,const dual::Snapshot &s) {
    if(s.sd)snprintf(out,cap,"%02lu:%02lu / %02lu:%02lu",(unsigned long)(s.elapsed/60),(unsigned long)(s.elapsed%60),(unsigned long)(s.duration/60),(unsigned long)(s.duration%60));
    else snprintf(out,cap,"%u kbit/s  %lu Hz",s.bitrate,(unsigned long)s.sampleRate);
}
}
