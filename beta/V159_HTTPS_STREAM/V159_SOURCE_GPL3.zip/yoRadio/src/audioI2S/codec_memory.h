#pragma once
#include <cstddef>
#include <cstdint>
#include <esp_heap_caps.h>
// Decoder workspaces must not consume the internal reserve needed by Wi-Fi/BT.
// Retain fast internal allocation when there is ample room; otherwise use PSRAM.
static inline void* ibtCodecAlloc(size_t bytes) {
    constexpr size_t reserve = 65536;
    if (bytes <= SIZE_MAX-reserve &&
        heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT) >= bytes+reserve) {
        if (void* p=heap_caps_malloc(bytes,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)) return p;
    }
    return heap_caps_malloc(bytes,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
}
