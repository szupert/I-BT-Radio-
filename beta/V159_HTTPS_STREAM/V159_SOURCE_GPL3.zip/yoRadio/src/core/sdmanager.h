#ifndef sdmanager_h
#define sdmanager_h
#include <atomic>

class SDManager : public SDFS {
  public:
    bool ready;
    std::atomic<bool> catalogReady{false};
    std::atomic<uint32_t> indexedTracks{0};
  public:
    SDManager(FSImplPtr impl) : SDFS(impl) {}
    bool start();
    bool selectPath(const char* path,size_t length);
    const char* selectedPath() const;
    void stop();
    bool cardPresent();
    void listSD(File &plSDfile, File &plSDindex, const char * dirname, uint8_t levels);
    bool indexSDPlaylist();
    void cancelIndex(){indexCancel.store(true);}
    void clearIndexCancel(){indexCancel.store(false);}
    bool indexWasCancelled() const {return indexCancel.load();}
  private:
    uint32_t _sdFCount;
    std::atomic<bool> indexCancel{false};
    uint32_t indexStarted=0;
    bool indexExpired() const;
  private:
    bool _checkNoMedia(const char* path);
    bool _endsWith (const char* base, const char* str);
};

extern SDManager sdman;
#if defined(SD_SPIPINS) || SD_HSPI
extern SPIClass  SDSPI;
#endif
#endif
