#ifndef netserver_h
#define netserver_h
#include "../AsyncWebServer/ESPAsyncWebServer.h"
#define APPEND_GROUP(name) strcat(nsBuf, "\"" name "\",")

enum requestType_e : uint8_t  { PLAYLIST=1, STATION=2, STATIONNAME=3, ITEM=4, TITLE=5, VOLUME=6, NRSSI=7, BITRATE=8, MODE=9, EQUALIZER=10, BALANCE=11, PLAYLISTSAVED=12, STARTUP=13, GETINDEX=14, GETACTIVE=15, GETSYSTEM=16, GETSCREEN=17, GETTIMEZONE=18, GETWEATHER=19, GETCONTROLS=20, DSPON=21, SDPOS=22, SDLEN=23, SDSNUFFLE=24, SDINIT=25, GETPLAYERMODE=26, CHANGEMODE=27 };
enum import_e      : uint8_t  { IMDONE=0, IMPL=1, IMWIFI=2 };
const char wifi_setup_html[] PROGMEM = R"(
<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>I-BT-Radio Wi-Fi</title><style>
body{font-family:system-ui,sans-serif;background:#111;color:#eee;margin:0;padding:22px}
main{max-width:520px;margin:auto}h2{color:#e3d25f}label{display:block;margin:14px 0 5px}
input{box-sizing:border-box;width:100%;font-size:18px;padding:11px;border-radius:8px;border:1px solid #555;background:#222;color:#fff}
button{margin-top:20px;width:100%;padding:13px;font-size:18px;font-weight:700;border:0;border-radius:9px;background:#e3d25f;color:#111}
small{color:#aaa}.box{border:1px solid #444;border-radius:10px;padding:15px;margin-top:16px}
</style></head><body><main>
<h2>I-BT-Radio Wi-Fi beállítás</h2>
<div class="box">Csatlakozva: <b>I-BT-Radio-Setup</b><br>Setup cím: <b>192.168.4.1</b></div>
__ERROR__
<form method="post" action="/">
<label for="ssid">Wi-Fi neve (SSID)</label><input id="ssid" name="ssid" maxlength="32" required autocomplete="off" value="__SELECTED__">
<label for="pass">Wi-Fi jelszó</label><input id="pass" name="pass" type="password" maxlength="63" autocomplete="off">
<button type="submit">Csatlakozás</button></form>
<p><small>A setup hálózat addig marad aktív, amíg az I-BT-Radio ténylegesen fel nem csatlakozik az otthoni Wi-Fi-re.</small></p>
</main></body></html>
)";
const char wifi_setup_saved_html[] PROGMEM = R"(
<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="3;url=http://192.168.4.1/">
<title>I-BT-Radio Wi-Fi</title><style>body{font-family:system-ui,sans-serif;background:#111;color:#eee;padding:22px}main{max-width:520px;margin:auto}h2{color:#e3d25f}.box{border:1px solid #444;border-radius:10px;padding:15px}</style></head>
<body><main><h2>Csatlakozás folyamatban</h2><div class="box">A rádió próbál csatlakozni a megadott hálózathoz. Ez legfeljebb 20 másodpercig tarthat. Az oldal automatikusan ellenőrzi az eredményt; nem kell újraindítani a rádiót.<br><br>
Ha nem sikerül, visszakapod a beállító űrlapot hibaüzenettel. Siker esetén az I-BT-Radio-Setup hálózat megszűnik, a jelszó akkor mentődik.</div></main></body></html>
)";
const char emptyfs_html[] PROGMEM = R"(
<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>I-BT-Radio recovery</title><style>body{font:18px system-ui;background:#111;color:#eee;max-width:540px;margin:24px auto;padding:0 14px}h2,a{color:#e3d25f}form{border:1px solid #555;padding:14px;margin:16px 0}label,input{display:block;margin:8px 0}input{max-width:100%}button,input[type=submit]{background:#e3d25f;border:0;padding:10px}footer{font-size:12px}</style>
<script src="/variables.js"></script></head><body><h2>I-BT-Radio recovery</h2>
<p>Upload all files from <b>data/www/</b>. A playlist.csv file is optional. Restore Wi-Fi through the setup page or the separate /upload endpoint.</p>
<form action="/webboard" method="post" enctype="multipart/form-data"><label for="www">Web files</label><input type="file" name="www" id="www" multiple><label for="data">Optional data files</label><input type="file" name="data" id="data" multiple><input type="submit" value="Upload files"></form>
<form name="wifiform" method="post" enctype="multipart/form-data"><label for="ssid">Wi-Fi SSID</label><input type="text" id="ssid" name="ssid" maxlength="30"><label for="pass">Wi-Fi password</label><input type="password" id="pass" name="pass" maxlength="40"><input type="submit" value="Save credentials"></form>
<p><a href="/emergency">Emergency firmware uploader</a></p>
<footer>Sourced by <a href="https://github.com/e2002/yoradio/">Yoradio</a></footer>
<script>document.wifiform.action=`/${formAction}`;if(playMode=='player')document.wifiform.hidden=true;</script>
</body></html>
)";
const char index_html[] PROGMEM = R"(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>I-BT-Radio V029</title>
  <script src="/ibt-branding.js?v=V029"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="theme-color" content="#e3d25f">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="default">
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 64 64%27%3E%3Crect width=%2764%27 height=%2764%27 rx=%2710%27 fill=%27%23222%27/%3E%3Ctext x=%2732%27 y=%2740%27 text-anchor=%27middle%27 font-family=%27sans-serif%27 font-size=%2724%27 fill=%27white%27%3EIBT%3C/text%3E%3C/svg%3E">
  <link rel="stylesheet" href="theme.css" type="text/css" />
  <link rel="stylesheet" href="style.css" type="text/css" />
  <script type="text/javascript" src="variables.js"></script>
  <script type="text/javascript" src="script.js"></script>
  <script type="text/javascript" src="dragpl.js"></script>
  </head>
<body>
<div id="content" class="hidden progmem">
</div><!--content-->
<div id="progress"><span id="loader"></span></div>
<div id="heap"></div>
</body>
</html>
)";
const char emergency_form[] PROGMEM = R"(
<meta charset="UTF-8"><title>I-BT-Radio V029</title><script src="/ibt-branding.js?v=V029"></script>
<h2>I-BT-Radio V029</h2>
<form method="POST" action="/update" enctype="multipart/form-data">
  <input type="hidden" name="updatetarget" value="fw" />
  <label for="uploadfile">upload firmware</label>
  <input type="file" id="uploadfile" accept=".bin,.hex" name="update" />
  <input type="submit" value="Update" />
</form>
)";
struct nsRequestParams_t
{
  requestType_e type;
  uint8_t clientId;
};

class NetServer {
  public:
    import_e importRequest;
    bool resumePlay;
    char chunkedPathBuffer[40];
    char nsBuf[BUFLEN], nsBuf2[BUFLEN];
  public:
    NetServer() {};
    bool begin(bool quiet=false);
    void loop();
    void requestOnChange(requestType_e request, uint8_t clientId);
    void setRSSI(int val) { rssi = val; };
    int  getRSSI()        { return rssi; };
    void chunkedHtmlPage(const String& contentType, AsyncWebServerRequest *request, const char * path);
    void onWsMessage(void *arg, uint8_t *data, size_t len, uint8_t clientId);
    bool irRecordEnable;
#if IR_PIN!=255
    void irToWs(const char* protocol, uint64_t irvalue);
    void irValsToWs(); 
#endif
    void resetQueue();
    // The legacy /webboard multipart path commits a validated staged playlist.
    bool importPlaylist();
  private:
    requestType_e request;
    QueueHandle_t nsQueue;
    char _wscmd[65], _wsval[65];
    char wsBuf[BUFLEN*2];
    int rssi;
    uint32_t playerBufMax;
    void getPlaylist(uint8_t clientId);
    static size_t chunkedHtmlPageCallback(uint8_t* buffer, size_t maxLen, size_t index);
    void processQueue();
    int _readPlaylistLine(File &file, char * line, size_t size);
};

extern NetServer netserver;
extern AsyncWebSocket websocket;

#endif
