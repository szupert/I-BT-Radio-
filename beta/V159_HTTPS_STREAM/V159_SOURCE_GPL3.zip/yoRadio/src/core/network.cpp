#include "options.h"
#include <ESPmDNS.h>
#include <DNSServer.h>
#include "time.h"
#include "rtcsupport.h"
#include "network.h"
#include "display.h"
#include "config.h"
#include "telnet.h"
#include "netserver.h"
#include "player.h"
#include "mqtt.h"
#include "timekeeper.h"
#include "../pluginsManager/pluginsManager.h"
#include <esp_wifi.h>
#include "../dual/bt_audio.h"
#include "../dual/wifi_bt_policy.h"

#ifndef WIFI_ATTEMPTS
  #define WIFI_ATTEMPTS  16
#endif

#ifndef SEARCH_WIFI_CORE_ID
  #define SEARCH_WIFI_CORE_ID  0
#endif
MyNetwork network;
static bool btRadioReserved(){return btaudio::wanted()||!btaudio::idle();}
static void serviceBtWifiPolicy(){
  static ibtcoex::Policy policy;
  const bool staReady=WiFi.getMode()==WIFI_STA&&WiFi.status()==WL_CONNECTED;
  policy.tick(millis(),staReady,btRadioReserved(),[](bool bt){
    wifi_ps_type_t actual=WIFI_PS_NONE;
    const wifi_ps_type_t target=bt?WIFI_PS_MIN_MODEM:WIFI_PS_NONE;
    const esp_err_t read=esp_wifi_get_ps(&actual);
    if(read!=ESP_OK)return false;
    if(actual==target)return true;
    const esp_err_t result=esp_wifi_set_ps(target);
    Serial.printf("[WIFI-BT] ps=%s result=%d\n",bt?"MIN_MODEM":"NONE",int(result));
    return result==ESP_OK;
  });
}


void MyNetwork::WiFiReconnected(WiFiEvent_t event, WiFiEventInfo_t info){
  if(network.status==SOFT_AP)return; // setup service owns stable STA-to-AP transition
  network.beginReconnect = false;
  player.lockOutput = false;
  delay(100);
  display.putRequest(NEWMODE, PLAYER);
  if(config.getMode()==PM_SDCARD) {
    network.status=CONNECTED;
    display.putRequest(NEWIP, 0);
  }else{
    display.putRequest(NEWMODE, PLAYER);
    if (network.lostPlaying) player.sendCommand({PR_PLAY, config.lastStation()});
  }
  #ifdef MQTT_ROOT_TOPIC
    connectToMqtt();
  #endif
}

void MyNetwork::WiFiLostConnection(WiFiEvent_t event, WiFiEventInfo_t info){
  if(network.status==SOFT_AP)return; // setup portal owns Wi-Fi until valid STA credentials exist
  if(!network.beginReconnect){
    uint8_t idx=(config.store.lastSSID>0 && config.store.lastSSID<=config.ssidsCount)?config.store.lastSSID-1:0;
    Serial.printf("Lost connection, reconnecting to %s...\n", config.ssidsCount?config.ssids[idx].ssid:"known Wi-Fi");
    if(config.getMode()==PM_SDCARD) {
      network.status=SDREADY;
      display.putRequest(NEWIP, 0);
    }else{
      network.lostPlaying = player.isRunning();
      if (network.lostPlaying) { player.lockOutput = true; player.sendCommand({PR_STOP, 0}); }
      display.putRequest(NEWMODE, LOST);
    }
  }
  network.beginReconnect = true;
  WiFi.reconnect();
}

static volatile uint16_t v027DisconnectReason=0;
static bool v027EventsRegistered=false;
static bool v027ReconnectCallbacks=false;
static uint8_t v027RecoveryIndex=0;
static char v027SetupSsid[32]="I-BT-Radio-Setup";
static DNSServer v15CaptiveDns;
static bool v15CaptiveDnsStarted=false;
static uint32_t v15StaConnectedAt=0;
static uint32_t v16StaAttemptAt=0;
static bool v16StaAttemptActive=false;
static bool v16SetupFailed=false;
static uint32_t recoveryStarted=0;
static bool recoveryWaiting=false;
static portMUX_TYPE wifiStateMux=portMUX_INITIALIZER_UNLOCKED;
static char connectingSsid[WIFI_SSID_CAP]={0};
static uint8_t connectingAttempt=0;
static char selectedSetupSsidValue[WIFI_SSID_CAP]={0};
static char pendingSsid[WIFI_SSID_CAP]={0},pendingPass[WIFI_PASS_CAP]={0};
static char activeSsid[WIFI_SSID_CAP]={0},activePass[WIFI_PASS_CAP]={0};
static bool setupRequest=false,setupBusy=false;
static uint32_t setupQueuedAt=0;
struct ScanEntry {char ssid[WIFI_SSID_CAP];int16_t rssi;};
static ScanEntry scanEntries[12]={};
static uint8_t scanEntryCount=0,scanPhase=0; // idle, searching, ready, failed
static bool scanRequested=false,scanCancelRequested=false;
static uint32_t scanStarted=0;
static void showConnecting(const char* ssid,uint8_t attempt){
  portENTER_CRITICAL(&wifiStateMux);
  strlcpy(connectingSsid,ssid?ssid:"",sizeof(connectingSsid));
  connectingAttempt=attempt;
  portEXIT_CRITICAL(&wifiStateMux);
}
bool MyNetwork::connectingInfo(char* ssid,size_t capacity,uint8_t* attempt) const{
  if(!ssid||!capacity)return false;
  portENTER_CRITICAL(&wifiStateMux);
  strlcpy(ssid,connectingSsid,capacity);
  if(attempt)*attempt=connectingAttempt;
  portEXIT_CRITICAL(&wifiStateMux);
  return ssid[0]!=0;
}
bool MyNetwork::selectedSetupSsid(char* ssid,size_t capacity) const{
  if(!ssid||!capacity)return false;
  portENTER_CRITICAL(&wifiStateMux);
  strlcpy(ssid,selectedSetupSsidValue,capacity);
  portEXIT_CRITICAL(&wifiStateMux);
  return ssid[0]!=0;
}
bool MyNetwork::requestScan(){
  if(btRadioReserved())return false;
  if(status!=SOFT_AP && (player.isRunning()||player.status()!=STOPPED))return false;
  portENTER_CRITICAL(&wifiStateMux);
  const bool accepted=!setupBusy;
  if(accepted){scanRequested=true;scanCancelRequested=false;scanPhase=1;scanEntryCount=0;}
  portEXIT_CRITICAL(&wifiStateMux);
  return accepted;
}
void MyNetwork::cancelScan(){
  portENTER_CRITICAL(&wifiStateMux);
  scanCancelRequested=true;scanRequested=false;
  portEXIT_CRITICAL(&wifiStateMux);
}
uint8_t MyNetwork::scanStatus() const{
  portENTER_CRITICAL(&wifiStateMux);
  const uint8_t result=scanPhase;
  portEXIT_CRITICAL(&wifiStateMux);
  return result;
}
unsigned MyNetwork::scanCount() const{
  portENTER_CRITICAL(&wifiStateMux);
  const unsigned result=scanEntryCount;
  portEXIT_CRITICAL(&wifiStateMux);
  return result;
}
bool MyNetwork::scanEntry(unsigned index,char* ssid,size_t capacity,int* rssi) const{
  if(!ssid||!capacity)return false;
  portENTER_CRITICAL(&wifiStateMux);
  const bool valid=scanPhase==2&&index<scanEntryCount;
  if(valid){strlcpy(ssid,scanEntries[index].ssid,capacity);if(rssi)*rssi=scanEntries[index].rssi;}
  else ssid[0]=0;
  portEXIT_CRITICAL(&wifiStateMux);
  return valid;
}
int MyNetwork::selectSetupNetwork(unsigned index){
  char ssid[WIFI_SSID_CAP];
  if(!scanEntry(index,ssid,sizeof(ssid)))return 0;
  portENTER_CRITICAL(&wifiStateMux);
  strlcpy(selectedSetupSsidValue,ssid,sizeof(selectedSetupSsidValue));
  portEXIT_CRITICAL(&wifiStateMux);
  for(unsigned i=0;i<config.ssidsCount;i++)if(strcmp(config.ssids[i].ssid,ssid)==0){
    if(v16SetupFailed)return 2; // stale saved password can be replaced locally
    return connectScannedNetwork(ssid,config.ssids[i].password)?1:0;
  }
  return 2;
}
static const char* reasonName(uint16_t r){
  switch(r){
    case 201:return "NO_AP_FOUND"; case 202:return "AUTH_FAIL";
    case 203:return "ASSOC_FAIL"; case 204:return "HANDSHAKE_TIMEOUT";
    case 205:return "CONNECTION_FAIL"; case 200:return "BEACON_TIMEOUT";
    case 15:return "4WAY_HANDSHAKE_TIMEOUT"; case 2:return "AUTH_EXPIRE";
    default:return "SEE_ESP_REASON_CODE";
  }
}
static void observeWiFi(WiFiEvent_t event,WiFiEventInfo_t info){
  if(event==ARDUINO_EVENT_WIFI_STA_DISCONNECTED){
    v027DisconnectReason=info.wifi_sta_disconnected.reason;
    Serial.printf("[WIFI] DISCONNECTED reason=%u name=%s\n",unsigned(v027DisconnectReason),reasonName(v027DisconnectReason));
  } else if(event==ARDUINO_EVENT_WIFI_STA_GOT_IP){
    Serial.printf("[WIFI] GOT_IP ip=%s rssi=%d\n",WiFi.localIP().toString().c_str(),WiFi.RSSI());
  }
}
bool MyNetwork::wifiBegin(bool silent){
  if(config.ssidsCount==0){Serial.println("[WIFI] NO_SAVED_CREDENTIALS");return false;}
  if(!v027EventsRegistered){WiFi.onEvent(observeWiFi);v027EventsRegistered=true;}
  WiFi.persistent(false); // Do not rewrite the SDK's credential storage on each retry.
  WiFi.setAutoReconnect(false); // Only one bounded boot attempt may own the STA at a time.
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  const unsigned first=(config.store.lastSSID>0 && config.store.lastSSID<=config.ssidsCount)?config.store.lastSSID-1:0;
  showConnecting(config.ssids[first].ssid,0);
  // One initial bounded scan: report ONLY matches to saved networks, not passwords
  // or neighbouring SSIDs. No auth/security threshold is silently weakened.
  const int networks=WiFi.scanNetworks(false,true,false,200);
  for(unsigned n=0;n<config.ssidsCount;n++){
    bool found=false;
    for(int i=0;i<networks;i++)if(WiFi.SSID(i)==config.ssids[n].ssid){
      found=true;Serial.printf("[WIFI] SAVED_AP slot=%u visible=1 channel=%d rssi=%d auth=%d\n",n+1,WiFi.channel(i),WiFi.RSSI(i),int(WiFi.encryptionType(i)));
    }
    if(!found)Serial.printf("[WIFI] SAVED_AP slot=%u visible=0 scan_result=%d\n",n+1,networks);
  }
  WiFi.scanDelete();
  if(networks==0){showConnecting(nullptr,0);Serial.println("[WIFI] NO_AP_VISIBLE SETUP_REQUIRED");return false;}
  for(unsigned slot=0;slot<config.ssidsCount;slot++){
    const unsigned index=(first+slot)%config.ssidsCount;
    for(unsigned attempt=1;attempt<=3;attempt++){
      WiFi.disconnect(false,false); // Never erase saved credentials.
      delay(100);v027DisconnectReason=0;
      showConnecting(config.ssids[index].ssid,attempt);
      Serial.printf("[WIFI] CONNECT slot=%u attempt=%u/3 budget_ms=5000 credentials=UNCHANGED\n",index+1,attempt);
      if(!silent)display.putRequest(BOOTSTRING,index);
      v027RecoveryIndex=index;
      WiFi.begin(config.ssids[index].ssid,config.ssids[index].password);
      const uint32_t started=millis();
      while(WiFi.status()!=WL_CONNECTED && uint32_t(millis()-started)<5000){delay(100);}
      if(WiFi.status()==WL_CONNECTED){
        config.setLastSSID(index+1);
        WiFi.setAutoReconnect(true);
        showConnecting(nullptr,0);
        Serial.printf("[WIFI] CONNECT=PASS slot=%u attempt=%u ip=%s rssi=%d\n",index+1,attempt,WiFi.localIP().toString().c_str(),WiFi.RSSI());return true;
      }
      Serial.printf("[WIFI] CONNECT=FAIL slot=%u attempt=%u/3 reason=%u name=%s\n",index+1,attempt,unsigned(v027DisconnectReason),reasonName(v027DisconnectReason));
    }
    Serial.printf("[WIFI] NEXT_SAVED_AP after=3 slot=%u\n",index+1);
  }
  showConnecting(nullptr,0);
  return false;
}

static void serviceScan(){
  static bool active=false;
  bool requested=false,cancel=false,busy=false;
  portENTER_CRITICAL(&wifiStateMux);
  requested=scanRequested;scanRequested=false;
  cancel=scanCancelRequested;scanCancelRequested=false;
  busy=setupBusy;
  portEXIT_CRITICAL(&wifiStateMux);
  if(cancel||busy||btRadioReserved()||(active&&(player.isRunning()||player.status()!=STOPPED))){
    if(active)esp_wifi_scan_stop();
    if(active||cancel)WiFi.scanDelete();
    active=false;
    portENTER_CRITICAL(&wifiStateMux);
    scanPhase=0;scanEntryCount=0;
    portEXIT_CRITICAL(&wifiStateMux);
    if(!requested||busy||btRadioReserved())return;
  }
  if(requested){
    if(active){esp_wifi_scan_stop();WiFi.scanDelete();active=false;}
    if(player.isRunning()||player.status()!=STOPPED){
      portENTER_CRITICAL(&wifiStateMux);scanPhase=3;portEXIT_CRITICAL(&wifiStateMux);
      return;
    }
    const int result=WiFi.scanNetworks(true,false,false,120);
    active=result==-1||result>=0;
    scanStarted=millis();
    if(result<-1){portENTER_CRITICAL(&wifiStateMux);scanPhase=3;portEXIT_CRITICAL(&wifiStateMux);return;}
  }
  if(!active)return;
  const int count=WiFi.scanComplete();
  if(count==-1&&uint32_t(millis()-scanStarted)<10000)return;
  if(count<0){
    esp_wifi_scan_stop();WiFi.scanDelete();active=false;
    portENTER_CRITICAL(&wifiStateMux);scanPhase=3;scanEntryCount=0;portEXIT_CRITICAL(&wifiStateMux);
    return;
  }
  ScanEntry found[12]={};unsigned kept=0;
  for(int i=0;i<count&&kept<12;i++){
    String name=WiFi.SSID(i);
    if(!name.length()||name.length()>=WIFI_SSID_CAP)continue;
    bool duplicate=false;
    for(unsigned j=0;j<kept;j++)if(name==found[j].ssid){duplicate=true;break;}
    if(duplicate)continue;
    strlcpy(found[kept].ssid,name.c_str(),sizeof(found[kept].ssid));
    found[kept].rssi=WiFi.RSSI(i);kept++;
  }
  WiFi.scanDelete();active=false;
  portENTER_CRITICAL(&wifiStateMux);
  memcpy(scanEntries,found,kept*sizeof(ScanEntry));
  scanEntryCount=kept;scanPhase=2;
  portEXIT_CRITICAL(&wifiStateMux);
  Serial.printf("[WIFI] SCAN=PASS visible=%u shown=%u\n",unsigned(count),kept);
}

// Setup AP is intentionally quiet: no repeated background reconnect storm.
// Captive DNS + HTTP stay alive while credentials are entered and while STA connects.
// AP is stopped only after STA has been continuously connected for 3 seconds.
void MyNetwork::service(){
  serviceBtWifiPolicy();
  bool startSetupAttempt=false;
  if(status==SOFT_AP){
    portENTER_CRITICAL(&wifiStateMux);
    // Let the HTTP acknowledgement reach the phone before Wi-Fi retunes to
    // the home AP's channel. The setup AP remains available throughout.
    if(setupRequest && uint32_t(millis()-setupQueuedAt)>=1200){
      strlcpy(activeSsid,pendingSsid,sizeof(activeSsid));
      strlcpy(activePass,pendingPass,sizeof(activePass));
      setupRequest=false;startSetupAttempt=true;
    }
    portEXIT_CRITICAL(&wifiStateMux);
  }
  if(startSetupAttempt){
    cancelScan();serviceScan(); // Scan and connect never own the STA concurrently.
    WiFi.setAutoReconnect(false);
    WiFi.disconnect(false,false);
    v027DisconnectReason=0;v15StaConnectedAt=0;v16SetupFailed=false;
    v16StaAttemptAt=millis();v16StaAttemptActive=true;
    showConnecting(activeSsid,1);
    Serial.printf("[WIFI-SETUP] STA_CONNECT=START ssid=%s AP_RETAINED=YES\n",activeSsid);
    WiFi.begin(activeSsid,activePass);
  }
  serviceScan();
  if(status!=SOFT_AP){
    if(WiFi.status()==WL_CONNECTED){recoveryWaiting=false;return;}
    if(status!=CONNECTED&&status!=SDREADY)return;
    if(!recoveryWaiting){recoveryStarted=millis();recoveryWaiting=true;return;}
    if(uint32_t(millis()-recoveryStarted)<30000)return;
    recoveryWaiting=false;
    Serial.println("[WIFI] RECOVERY_TIMEOUT SETUP_AP=START credentials=UNCHANGED");
    startSetup();return;
  }
  if(v15CaptiveDnsStarted)v15CaptiveDns.processNextRequest();
  if(!v16StaAttemptActive)return; // AP remains available until a queued credential is tested.
  if(WiFi.status()!=WL_CONNECTED){
    v15StaConnectedAt=0;
    if(v16StaAttemptActive && uint32_t(millis()-v16StaAttemptAt)>=20000){
      WiFi.disconnect(false,false);
      v16StaAttemptActive=false;v16SetupFailed=true;
      showConnecting(nullptr,0);
      portENTER_CRITICAL(&wifiStateMux);setupBusy=false;portEXIT_CRITICAL(&wifiStateMux);
      Serial.printf("[WIFI-SETUP] STA_CONNECT=FAIL reason=%u name=%s AP_RETAINED=YES\n",
                    unsigned(v027DisconnectReason),reasonName(v027DisconnectReason));
    }
    return;
  }
  if(v15StaConnectedAt==0){
    v15StaConnectedAt=millis();
    Serial.printf("[WIFI-SETUP] STA_CONNECTED_PENDING ip=%s keep_ap_ms=3000\n",WiFi.localIP().toString().c_str());
    return;
  }
  if(uint32_t(millis()-v15StaConnectedAt)<5000)return;
  if(v16StaAttemptActive){
    uint8_t slot=0;
    if(!config.rememberVerifiedWifi(activeSsid,activePass,&slot)){
      Serial.println("[WIFI-SETUP] SAVE=FAIL AP_RETAINED=YES credentials=UNCHANGED");
      WiFi.disconnect(false,false);v15StaConnectedAt=0;
      v16StaAttemptActive=false;v16SetupFailed=true;
      showConnecting(nullptr,0);
      portENTER_CRITICAL(&wifiStateMux);setupBusy=false;portEXIT_CRITICAL(&wifiStateMux);
      return;
    }
    config.setLastSSID(slot);
  }
  v16StaAttemptActive=false;v16SetupFailed=false;
  showConnecting(nullptr,0);
  portENTER_CRITICAL(&wifiStateMux);setupBusy=false;portEXIT_CRITICAL(&wifiStateMux);
  if(v15CaptiveDnsStarted){v15CaptiveDns.stop();v15CaptiveDnsStarted=false;}
  status=CONNECTED;player.lockOutput=false;
  WiFi.softAPdisconnect(false);
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  setWifiParams();
  config.initPlaylistMode();
  telnet.begin(true);
  display.putRequest(NEWIP,0);display.putRequest(NEWMODE,PLAYER);
  Serial.printf("[WIFI-SETUP] STA_CONNECT=PASS ip=%s AP_STOPPED=YES\n",WiFi.localIP().toString().c_str());
  player.sendCommand({PR_PLAY,-65001});
}

bool MyNetwork::applySetupCredentials(const char* ssid,const char* pass){
  if(status!=SOFT_AP || ssid==nullptr || pass==nullptr)return false;
  const size_t sl=strlen(ssid),pl=strlen(pass);
  if(sl==0 || sl>=WIFI_SSID_CAP || pl>=WIFI_PASS_CAP ||
     strpbrk(ssid,"\t\r\n") || strpbrk(pass,"\t\r\n"))return false;
  portENTER_CRITICAL(&wifiStateMux);
  const bool accepted=!setupBusy;
  if(accepted){
    strlcpy(pendingSsid,ssid,sizeof(pendingSsid));
    strlcpy(pendingPass,pass,sizeof(pendingPass));
    strlcpy(selectedSetupSsidValue,ssid,sizeof(selectedSetupSsidValue));
    setupRequest=true;setupBusy=true;
    setupQueuedAt=millis();
  }
  portEXIT_CRITICAL(&wifiStateMux);
  if(!accepted)return false;
  v16SetupFailed=false;
  if(!v027EventsRegistered){WiFi.onEvent(observeWiFi);v027EventsRegistered=true;}
  Serial.printf("[WIFI-SETUP] STA_CONNECT=QUEUED ssid_len=%u password_len=%u AP_RETAINED=YES\n",unsigned(sl),unsigned(pl));
  return true;
}

bool MyNetwork::connectScannedNetwork(const char* ssid,const char* pass){
  if(btRadioReserved())return false;
  if(!ssid||!pass)return false;
  const size_t sl=strlen(ssid),pl=strlen(pass);
  if(!sl||sl>=WIFI_SSID_CAP||pl>=WIFI_PASS_CAP||(pl>0&&pl<8)||
     strpbrk(ssid,"\t\r\n")||strpbrk(pass,"\t\r\n"))return false;
  if(status!=SOFT_AP){
    // The normal Wi-Fi scanner is available only with playback stopped.
    if(player.isRunning()||player.status()!=STOPPED)return false;
    startSetup();
  }
  return applySetupCredentials(ssid,pass);
}

void searchWiFi(void * pvParameters){
  (void)pvParameters;
  if(!network.wifiBegin(true)){network.startSetup();netserver.begin(true);vTaskDelete(NULL);return;}
  network.status = CONNECTED;
  netserver.begin(true);
  telnet.begin(true);
  network.setWifiParams();
  display.putRequest(NEWIP, 0);
  #ifdef MQTT_ROOT_TOPIC
    mqttInit();
  #endif
  vTaskDelete(NULL);
}

#define DBGAP false

void MyNetwork::begin() {
  BOOTLOG("network.begin");
  config.initNetwork();
  if (config.ssidsCount == 0 || DBGAP) {
    raiseSoftAP();
    return;
  }
  if(config.getMode()!=PM_SDCARD){
    if(!wifiBegin()){
      raiseSoftAP();
      Serial.println("##[BOOT]#\tdone");
      return;
    }
    Serial.println(".");
    status = CONNECTED;
    setWifiParams();
    #ifdef MQTT_ROOT_TOPIC
      mqttInit();
    #endif
  }else{
    status = SDREADY;
    xTaskCreatePinnedToCore(searchWiFi, "searchWiFi", 1024 * 4, NULL, 0, NULL, SEARCH_WIFI_CORE_ID);
  }
  
  Serial.println("##[BOOT]#\tdone");
  if(REAL_LEDBUILTIN!=255) digitalWrite(REAL_LEDBUILTIN, LOW);
  
#if RTCSUPPORTED
  if(config.isRTCFound()){
    rtc.getTime(&network.timeinfo);
    mktime(&network.timeinfo);
    display.putRequest(CLOCK);
  }
#endif
  if (network_on_connect) network_on_connect();
  pm.on_connect();
}

void MyNetwork::setWifiParams(){
  WiFi.setSleep(false);
  if(!v027ReconnectCallbacks){
    WiFi.onEvent(WiFiReconnected, WiFiEvent_t::ARDUINO_EVENT_WIFI_STA_GOT_IP);
    WiFi.onEvent(WiFiLostConnection, WiFiEvent_t::ARDUINO_EVENT_WIFI_STA_DISCONNECTED);
    v027ReconnectCallbacks=true;
  }
  //config.setTimeConf(); //??
  // RADIO_RESCUE_V53_20260911: mDNS disabled temporarily to return heap to radio audio.
  // Re-enable after PSRAM/coexistence validation.
}

void MyNetwork::requestTimeSync(bool withTelnetOutput, uint8_t clientId) {
  if (withTelnetOutput) {
    char timeStringBuff[50];
    strftime(timeStringBuff, sizeof(timeStringBuff), "%Y-%m-%dT%H:%M:%S", &timeinfo);
    if (config.store.tzHour < 0) {
      telnet.printf(clientId, "##SYS.DATE#: %s%03d:%02d\n> ", timeStringBuff, config.store.tzHour, config.store.tzMin);
    } else {
      telnet.printf(clientId, "##SYS.DATE#: %s+%02d:%02d\n> ", timeStringBuff, config.store.tzHour, config.store.tzMin);
    }
  }
}

void rebootTime() {
  ESP.restart();
}

bool MyNetwork::setupFailed() const {return v16SetupFailed;}
bool MyNetwork::setupInProgress() const {
  portENTER_CRITICAL(&wifiStateMux);
  const bool busy=setupBusy;
  portEXIT_CRITICAL(&wifiStateMux);
  return status==SOFT_AP && busy;
}
const char* MyNetwork::setupSsid() const {return v027SetupSsid;}
void MyNetwork::startSetup(){
  beginReconnect=true;
  status=SOFT_AP;
  WiFi.setAutoReconnect(false);
  WiFi.disconnect(false,false); // preserve stored credentials
  delay(100);
  raiseSoftAP();
}
void MyNetwork::raiseSoftAP() {
  snprintf(v027SetupSsid,sizeof(v027SetupSsid),"I-BT-Radio-Setup");
  recoveryWaiting=false;status = SOFT_AP;v15StaConnectedAt=0;
  v16StaAttemptAt=0;v16StaAttemptActive=false;v16SetupFailed=false;
  showConnecting(nullptr,0);
  portENTER_CRITICAL(&wifiStateMux);
  setupRequest=false;setupBusy=false;scanRequested=false;scanCancelRequested=true;
  portEXIT_CRITICAL(&wifiStateMux);
  WiFi.setAutoReconnect(false);
  WiFi.mode(WIFI_AP_STA); // V15: portal must survive a subsequent WiFi.begin()
  IPAddress apIP(192,168,4,1),mask(255,255,255,0);
  WiFi.softAPConfig(apIP,apIP,mask);
  const bool apOK=WiFi.softAP(v027SetupSsid, apPassword);
  if(v15CaptiveDnsStarted)v15CaptiveDns.stop();
  v15CaptiveDnsStarted=v15CaptiveDns.start(53,"*",WiFi.softAPIP());
  Serial.println("##[BOOT]#");
  BOOTLOG("************************************************");
  BOOTLOG("Running in AP setup mode");
  BOOTLOG("Connect to AP %s with password %s", v027SetupSsid, apPassword);
  BOOTLOG("Open http://192.168.4.1/ and enter home Wi-Fi SSID/password");
  BOOTLOG("************************************************");
  Serial.printf("[WIFI-SETUP] AP=%s password=%s ip=192.168.4.1 result=%s\n",v027SetupSsid,apPassword,apOK?"PASS":"FAIL");
}

void MyNetwork::requestWeatherSync(){
  display.putRequest(NEWWEATHER);
}
