#include "../dual/v026_probe.h"
#include "options.h"
#include "player.h"
#include "config.h"
#include "telnet.h"
#include "display.h"
#include "sdmanager.h"
#include "netserver.h"
#include "timekeeper.h"
#include "../displays/tools/l10n.h"
#include "../pluginsManager/pluginsManager.h"
#include "../dual/core.h"
#include "../dual/bt_audio.h"
#include "../dual/bt_source_policy.h"
#include "../dual/scheduling_policy.h"
#include <atomic>
#ifdef USE_NEXTION
#include "../displays/nextion.h"
#endif
Player player;
QueueHandle_t playerQueue;
static std::atomic<TaskHandle_t> audioOwner{nullptr};
static std::atomic<bool> audioTaskStarted{false};
static std::atomic<uint32_t> audioGapMax{0};
static std::atomic<uint32_t> audioGapEventCount{0};
static std::atomic<uint32_t> playbackGenerationCount{0};
// Rotary steps never occupy the five-slot command queue. The audio owner
// drains them together so a fast turn cannot reject station/BT commands.
static std::atomic<int> pendingVolumeSteps{0};
static std::atomic<int> pendingAbsoluteVolume{-1};
static std::atomic<uint32_t> rejectedCommands{0};
// The SD scanner owns the card while the audio task remains responsive to
// stop, BT and source commands. State 2/3 is consumed once by the audio task.
static std::atomic<uint8_t> sdWorkerState{0}; // 0 idle, 1 indexing, 2 ready, 3 failed
static std::atomic<SdPrepareState> sdPrepare{SdPrepareState::Idle};
static void sdIndexTask(void*){
#ifdef USE_SD
  const bool good=sdman.start() && sdman.indexSDPlaylist();
  sdWorkerState.store(good?2:3);
#else
  sdWorkerState.store(3);
#endif
  vTaskDelete(nullptr);
}
static bool owner(){return !audioTaskStarted.load()||audioOwner.load()==xTaskGetCurrentTaskHandle();}
static void audioTask(void*){
  // Publish from the running task, before any command can reach the decoder.
  audioOwner.store(xTaskGetCurrentTaskHandle());
  Serial.printf("[AUDIO-TASK] core=%d priority=3 dma=8x512\n",xPortGetCoreID());
  unsigned currentPriority=3;
  uint32_t previous=micros(),yieldAt=millis();
  for(;;){
    uint32_t now=micros(),gap=now-previous;previous=now;
    if(player.isRunning()){
      if(gap>audioGapMax.load())audioGapMax.store(gap);
      if(gap>100000)audioGapEventCount.fetch_add(1);
    }
    const unsigned desiredPriority=ibtsched::audioPriority(
      ibtsched::active(btaudio::outputSelected(),btaudio::transmitting()));
    if(currentPriority!=desiredPriority){
      vTaskPrioritySet(nullptr,desiredPriority);currentPriority=desiredPriority;
    }
    player.loop();
    // The I2S writer normally blocks naturally. Yield briefly even on fast
    // network/error paths so the core's idle task can run its watchdog.
    if(uint32_t(millis()-yieldAt)>=2){vTaskDelay(1);yieldAt=millis();}
  }
}
void Player::startTask(){
  if(audioTaskStarted.exchange(true))return;
  if(xTaskCreatePinnedToCore(audioTask,"ibt_audio",12288,nullptr,3,nullptr,1)!=pdPASS)
    Serial.println("[AUDIO-TASK] FAIL allocation; playback disabled");
}
bool Player::onAudioTask(){return audioOwner.load()==xTaskGetCurrentTaskHandle();}
bool Player::routeSourceChange(int mode){
  if(!audioTaskStarted.load() || onAudioTask())return false;
  sendCommand({PR_SOURCE,mode});return true;
}
void Player::audioDiagnostics(){
  auto task=audioOwner.load();
  Serial.printf("[AUDIO-TASK] ready=%u core=1 service_core=0 stack_min=%u max_running_gap_us=%lu gap_events_100ms=%lu dma_frames=4096\n",task?1:0,task?unsigned(uxTaskGetStackHighWaterMark(task)):0,(unsigned long)audioGapMax.load(),(unsigned long)audioGapEventCount.load());
}
uint32_t Player::audioGapEvents(){return audioGapEventCount.load();}
uint32_t Player::playbackGeneration() const {return playbackGenerationCount.load();}
void Player::setTone(int8_t b,int8_t m,int8_t t){
  if(owner())Audio::setTone(b,m,t);
  else sendCommand({PR_TONE,int(uint8_t(b))|(int(uint8_t(m))<<8)|(int(uint8_t(t))<<16)});
}
void Player::setBalance(int8_t b){if(owner())Audio::setBalance(b);else sendCommand({PR_BALANCE,b});}
void Player::setVolume(uint8_t v){if(owner())Audio::setVolume(v);else sendCommand({PR_GAIN,v});}
bool Player::setFilePos(uint32_t p){if(owner())return Audio::setFilePos(p);sendCommand({PR_SEEK,int(p)});return true;}


#if VS1053_CS!=255 && !I2S_INTERNAL
  #if VS_HSPI
    Player::Player(): Audio(VS1053_CS, VS1053_DCS, VS1053_DREQ, &SPI2) {}
  #else
    Player::Player(): Audio(VS1053_CS, VS1053_DCS, VS1053_DREQ, &SPI) {}
  #endif
  void ResetChip(){
    pinMode(VS1053_RST, OUTPUT);
    digitalWrite(VS1053_RST, LOW);
    delay(30);
    digitalWrite(VS1053_RST, HIGH);
    delay(100);
  }
#else
  #if !I2S_INTERNAL
    Player::Player() {}
  #else
    Player::Player(): Audio(true, I2S_DAC_CHANNEL_BOTH_EN)  {}
  #endif
#endif


void Player::init() {
  Serial.print("##[BOOT]#\tplayer.init\t");
  Serial.printf("[PLAYER-AUDIO] enabled=%d v48=1\n", (int)FEATURE_AUDIO_OUTPUT); // RADIO_PLAYER_AUDIO_FIX_V48_20260910
  playerQueue=NULL;
  pendingVolumeSteps.store(0);
  pendingAbsoluteVolume.store(-1);
  _resumeFilePos = 0;
  _hasError=false;
  playerQueue = xQueueCreate( 5, sizeof( playerRequestParams_t ) );
  setOutputPins(false);
  delay(50);
#ifdef MQTT_ROOT_TOPIC
  memset(burl, 0, MQTT_BURL_SIZE);
#endif
  if(MUTE_PIN!=255) pinMode(MUTE_PIN, OUTPUT);
  #if I2S_DOUT!=255
    #if !I2S_INTERNAL && FEATURE_AUDIO_OUTPUT
      setPinout(I2S_BCLK, I2S_LRC, I2S_DOUT);
    #elif !FEATURE_AUDIO_OUTPUT
      Serial.println("##[BOOT]#\taudio output disabled (bare touch/Wi-Fi test)");
    #endif
  #else
    SPI.begin();
    if(VS1053_RST>0) ResetChip();
    begin();
  #endif
  setBalance(config.store.balance);
  setTone(config.store.bass, config.store.middle, config.store.trebble);
  setVolume(0);
  _status = STOPPED;
  _volTimer=false;
  //randomSeed(analogRead(0));
  #if PLAYER_FORCE_MONO
    forceMono(true);
  #endif
  _loadVol(config.store.volume);
  setConnectionTimeout(CONNECTION_TIMEOUT, CONNECTION_TIMEOUT_SSL);
  Serial.println("done");
}

bool Player::sendCommand(playerRequestParams_t request){
  if(playerQueue==NULL) return false;
  // Keep room for stop/source/BT requests when a web client sends repeated
  // station commands. The newest user request may be retried; old work is lost.
  const bool expendable=request.type==PR_PLAY||request.type==PR_NEXT||
    request.type==PR_PREV||request.type==PR_TOGGLE||request.type==PR_CHECKSD;
  if(!owner()&&expendable&&uxQueueMessagesWaiting(playerQueue)>=3){
    rejectedCommands.fetch_add(1);
    return false;
  }
  if(xQueueSend(playerQueue, &request, owner()?0:pdMS_TO_TICKS(10))==pdPASS){
    if(request.type==PR_SOURCE && request.payload==PM_SDCARD && sdWorkerState.load()==0)
      sdPrepare.store(SdPrepareState::Idle);
    return true;
  }
  rejectedCommands.fetch_add(1);
  Serial.println("[AUDIO-QUEUE] FULL command rejected");
  return false;
}
unsigned Player::queueDepth() const {return playerQueue?uxQueueMessagesWaiting(playerQueue):0;}
uint32_t Player::commandDrops() const {return rejectedCommands.load();}
SdPrepareState Player::sdPrepareState() const {return sdPrepare.load();}

void Player::resetQueue(){
  if(playerQueue!=NULL) xQueueReset(playerQueue);
  pendingVolumeSteps.store(0);
  pendingAbsoluteVolume.store(-1);
}

void Player::stopInfo() {
  config.setSmartStart(0);
  netserver.requestOnChange(MODE, 0);
}

void Player::setError(){
  _hasError=true;
  config.setTitle(config.tmpBuf);
  telnet.printf("##ERROR#:\t%s\n", config.tmpBuf);
}

void Player::setError(const char *e){
  strlcpy(config.tmpBuf, e, sizeof(config.tmpBuf));
  setError();
}

void Player::_stop(bool alreadyStopped){
  log_i("%s called", __func__);
  if(config.getMode()==PM_SDCARD && !alreadyStopped) config.sdResumePos = player.getFilePos();
  _status = STOPPED;
  setOutputPins(false);
  if(!_hasError) config.setTitle((display.mode()==LOST || display.mode()==UPDATING)?"":LANG::const_PlStopped);
  config.station.bitrate = 0;
  config.setBitrateFormat(BF_UNKNOWN);
  #ifdef USE_NEXTION
    nextion.bitrate(config.station.bitrate);
  #endif
  setDefaults();
  if(!alreadyStopped) stopSong();
  netserver.requestOnChange(BITRATE, 0);
  display.putRequest(DBITRATE);
  display.putRequest(PSTOP);
  //setDefaults();
  //if(!alreadyStopped) stopSong();
  if(!lockOutput) stopInfo();
  if (player_on_stop_play) player_on_stop_play();
  pm.on_stop_play();
}

void Player::initHeaders(const char *file) {
  if(strlen(file)==0 || true) return; //TODO Read TAGs
  connecttoFS(sdman,file);
  eofHeader = false;
  while(!eofHeader) Audio::loop();
  //netserver.requestOnChange(SDPOS, 0);
  setDefaults();
}
void resetPlayer(){
  if(!config.store.watchdog) return;
  player.resetQueue();
  player.sendCommand({PR_STOP, 0});
  player.loop();
}

#ifndef PL_QUEUE_TICKS
  #define PL_QUEUE_TICKS 0
#endif
#ifndef PL_QUEUE_TICKS_ST
  #define PL_QUEUE_TICKS_ST 15
#endif
void Player::loop() {
  if(playerQueue==NULL || !owner()) return;
  static bool inLoop=false;
  if(inLoop)return; // SD indexing must not recursively service decoder commands.
  struct Guard {bool& value;Guard(bool& v):value(v){value=true;}~Guard(){value=false;}} guard(inLoop);
  // Keep reading controls immediately, but combine volume events before
  // updating the decoder, display and web clients at most every 100 ms.
  static uint32_t nextVolumeApply=0;
  const uint32_t volumeNow=millis();
  if(int32_t(volumeNow-nextVolumeApply)>=0 &&
     (pendingVolumeSteps.load()!=0 || pendingAbsoluteVolume.load()>=0)){
    const int absolute=pendingAbsoluteVolume.exchange(-1);
    const int steps=pendingVolumeSteps.exchange(0);
    int next=(absolute>=0?absolute:int(config.store.volume))+steps*max(1,int(config.store.volsteps));
    if(next<0)next=0;
    if(next>254)next=254;
    if(next!=config.store.volume){
      _volTicks=volumeNow;_volTimer=true;
      config.setVolume(uint8_t(next));
      Audio::setVolume(volToI2S(uint8_t(next)));
    }
    nextVolumeApply=volumeNow+100;
  }
  static bool btStarted=false,returnToDac=false,sourcePaused=false;
  static uint32_t returnToDacAt=0;
  static bool sdWanted=false,sdResumeWeb=false,sdKeepBt=false;
  static uint16_t sdWebStation=0;
  static uint32_t sdBtStopAt=0;
  static int deferredBt=-1000,deferredPlay=-1000,deferredSource=-1;
  static bool sourceResumeAfterRetry=false;
  auto applyBt=[&](int mode){
    sourcePaused=false;
    _recovery.cancel();_stop();btStarted=false;
    returnToDac=mode<0;
    if(returnToDac)returnToDacAt=millis();
    btaudio::request(returnToDac?btaudio::Mode::Off:mode==1?btaudio::Mode::In:btaudio::Mode::Out);
    const auto source=config.getMode()==PM_SDCARD?ibtsource::Source::Sd:ibtsource::Source::Web;
    if(source!=ibtsource::afterBt(source,mode))config.changeMode(PM_WEB);
    _loadVol(config.store.volume);
  };
  if(btaudio::takeAutoDacFallback()){
    _recovery.cancel();_stop();btStarted=false;
    returnToDac=true;returnToDacAt=millis();
    btaudio::request(false);
    Serial.println("[BT-LINK] auto_dac=REQUESTED");
  }
  playerRequestParams_t requestP;
  if(xQueueReceive(playerQueue, &requestP, (isRunning()||btaudio::wanted())?PL_QUEUE_TICKS:PL_QUEUE_TICKS_ST)){
    switch (requestP.type){
      case PR_STOP:
        if(sdWorkerState.load()!=0){sdWanted=false;sdResumeWeb=false;sdman.cancelIndex();}
        deferredBt=-1000;deferredPlay=-1000;deferredSource=-1;sourceResumeAfterRetry=false;
        returnToDac=false;btaudio::request(false); _recovery.cancel(); _stop(); break;
      case PR_BT:
        deferredSource=-1;sourceResumeAfterRetry=false;
        if(requestP.payload<0&&!btaudio::wanted()&&btaudio::idle())break;
        if(sdWorkerState.load()!=0){sdWanted=false;sdResumeWeb=false;sdman.cancelIndex();deferredBt=requestP.payload;break;}
        applyBt(requestP.payload);
        break;
      case PR_SOURCE: {
        const auto target=playMode_e(requestP.payload);
        if(target!=PM_WEB&&target!=PM_SDCARD)break;
        // Phone input owns the decoder/output. Source switching is local playback only.
        if(btaudio::inputSelected()){
          Serial.println("[SOURCE-SWITCH] result=DENIED bt_input=1");break;
        }
        returnToDac=false;
        if(sdWorkerState.load()!=0){
          deferredSource=target;
          if(target==PM_WEB){sdWanted=false;sdman.cancelIndex();}
          break;
        }
        if(target==config.getMode())break;
        const bool resume=isRunning()||sourceResumeAfterRetry;
        sourceResumeAfterRetry=false;
        sdKeepBt=btaudio::outputSelected();sourcePaused=!resume;
        _recovery.cancel();_stop();dual::track("");
        if(sdKeepBt)btaudio::flush();
        btStarted=false;
        Serial.printf("[SOURCE-SWITCH] target=%s route=%s resume=%u\n",
          target==PM_SDCARD?"SD":"WEB",sdKeepBt?"BT":"DAC",unsigned(resume));
        if(target==PM_SDCARD){
          sdWebStation=config.lastStation();sdResumeWeb=resume;sdWanted=true;
          sdBtStopAt=millis();
          sdman.clearIndexCancel();sdWorkerState.store(1);sdPrepare.store(SdPrepareState::Indexing);
          if(xTaskCreatePinnedToCore(sdIndexTask,"ibt_sd_index",6144,nullptr,1,nullptr,0)!=pdPASS){
            sdWorkerState.store(3);
            Serial.println("[SD-AUDIO] FAIL index task allocation");
          }else Serial.println("[SD-AUDIO] INDEX=STARTED audio_task=FREE");
        }else{
          config.changeMode(PM_WEB);
          if(resume&&(!btaudio::outputSelected()||btaudio::transmitting())){
            _recovery.begin(config.lastStation());_play(config.lastStation());
            btStarted=btaudio::outputSelected()&&isRunning();
          }
        }
        break;
      }
      case PR_TONE: Audio::setTone(int8_t(requestP.payload),int8_t(requestP.payload>>8),int8_t(requestP.payload>>16));break;
      case PR_BALANCE: Audio::setBalance(int8_t(requestP.payload));break;
      case PR_GAIN: Audio::setVolume(uint8_t(requestP.payload));break;
      case PR_SEEK: Audio::setFilePos(uint32_t(requestP.payload));break;
      case PR_RESTART_LOCAL: {
        if(!ibtsource::canRestartLocal(config.getMode()==PM_SDCARD,
            sdWorkerState.load()!=0,btaudio::inputSelected(),
            btaudio::outputSelected(),btaudio::transmitting())){
          Serial.println("[LOCAL-RESTART] result=DENIED");break;
        }
        const uint16_t track=config.lastStation();
        returnToDac=false;_recovery.cancel();_stop();
        // _stop captures the current file position, so clear it afterwards.
        config.sdResumePos=0;_resumeFilePos=0;
        if(btaudio::outputSelected())btaudio::flush();
        _play(track);
        // The generic BT startup branch must not reopen this file a second time.
        btStarted=btaudio::outputSelected();
        Serial.printf("[LOCAL-RESTART] result=%s station=%u generation=%lu\n",
          isRunning()?"PASS":"FAIL",unsigned(track),(unsigned long)playbackGeneration());
        break;
      }
      case PR_PLAY: {
        deferredSource=-1;sourceResumeAfterRetry=false;
        sourcePaused=false;
        if(sdWorkerState.load()!=0){sdWanted=false;sdResumeWeb=false;sdman.cancelIndex();deferredPlay=requestP.payload;break;}
        if (requestP.payload>0) {
          config.setLastStation((uint16_t)requestP.payload);
        }
        if(btaudio::inputSelected()){btaudio::request(false);returnToDac=true;break;}
        if(btaudio::outputSelected()){
          btaudio::flush();if(!btaudio::transmitting())break;
        }
        _recovery.begin(config.getMode()==PM_WEB?(uint16_t)abs(requestP.payload):0);
        _play((uint16_t)abs(requestP.payload)); 
        if (player_on_station_change) player_on_station_change(); 
        pm.on_station_change();
        break;
      }
      case PR_TOGGLE: {
        deferredSource=-1;sourceResumeAfterRetry=false;
        sourcePaused=false;
        if(sdWorkerState.load()!=0){sdWanted=false;sdResumeWeb=false;sdman.cancelIndex();break;}
        toggle();
        break;
      }
      case PR_VOL: pendingAbsoluteVolume.store(requestP.payload);break;
      #ifdef USE_SD
      case PR_CHECKSD: {
        if(config.getMode()==PM_SDCARD){
          if(!sdman.cardPresent()){
            sdman.stop();
            config.changeMode(PM_WEB);
          }
        }
        break;
      }
      #endif
      case PR_VUTONUS: {
        if(config.vuThreshold>10) config.vuThreshold -=10;
        break;
      }
      case PR_BURL: {
      #ifdef MQTT_ROOT_TOPIC
        if(strlen(burl)>0){
          browseUrl();
        }
      #endif
        break;
      }
          
      default: break;
    }
  }
  bool sourceRetryQueued=false;
  const uint8_t sdDone=sdWorkerState.load();
  if(sdDone>=2 && sdWanted && !sdKeepBt && !btaudio::idle() &&
     uint32_t(millis()-sdBtStopAt)>=10000){
    sdWanted=false;sdResumeWeb=false;
    Serial.println("[SD-AUDIO] FAIL BT teardown timeout; audio remains stopped");
  }
  if(sdDone>=2 && (!sdWanted || sdKeepBt || btaudio::idle())){
    sdWorkerState.store(0);
    bool ready=sdDone==2 && sdWanted;
    if(ready){
      config.changeMode(PM_SDCARD);
      ready=config.getMode()==PM_SDCARD && sdman.catalogReady.load();
    }
    if(ready){
      sdPrepare.store(SdPrepareState::Ready);
      Serial.printf("[SD-AUDIO] INDEX=PASS tracks=%lu\n",(unsigned long)sdman.indexedTracks.load());
      if(sdResumeWeb&&(!btaudio::outputSelected()||btaudio::transmitting())){
        _recovery.begin(0);_play(config.lastStation());
        btStarted=btaudio::outputSelected()&&isRunning();
      }
    }else{
      if(sdman.ready)sdman.stop();
      sdPrepare.store(sdWanted?SdPrepareState::Failed:SdPrepareState::Cancelled);
      Serial.printf("[SD-AUDIO] INDEX=%s\n",sdWanted?"FAIL":"CANCELLED");
      if(deferredBt!=-1000)applyBt(deferredBt);
      else if(deferredPlay!=-1000){
        if(deferredPlay>0)config.setLastStation(uint16_t(deferredPlay));
        _recovery.begin(uint16_t(abs(deferredPlay)));_play(uint16_t(abs(deferredPlay)));
        if(player_on_station_change)player_on_station_change();
        pm.on_station_change();
      }
      else if(deferredSource==PM_SDCARD){
        // WEB then SD during cancellation: wait for the old card owner, then
        // retry the newest source once without reopening the cancelled WEB.
        sourceResumeAfterRetry=sdResumeWeb;
        sourceRetryQueued=sendCommand({PR_SOURCE,PM_SDCARD});
        if(!sourceRetryQueued){sourceResumeAfterRetry=false;sdPrepare.store(SdPrepareState::Failed);Serial.println("[SOURCE-SWITCH] FAIL retry queue full");}
      }
      else if(sdResumeWeb&&(!btaudio::outputSelected()||btaudio::transmitting())){
        _recovery.begin(sdWebStation);_play(sdWebStation);
        btStarted=btaudio::outputSelected()&&isRunning();
      }
    }
    sdWanted=false;sdResumeWeb=false;deferredBt=-1000;deferredPlay=-1000;deferredSource=-1;
    if(sourceRetryQueued)return;
  }
  // The index worker owns SD until it publishes completion. Keep commands
  // responsive, but never reopen the old source through generic BT startup.
  if(sdWorkerState.load()!=0)return;
  if(returnToDac){
    if(!btaudio::idle()&&uint32_t(millis()-returnToDacAt)<10000)return;
    if(!btaudio::idle())Serial.println("[BT-LINK] teardown_timeout=1 DAC_RESTORE=FORCED");
    returnToDac=false;_recovery.begin(config.lastStation());_play(config.lastStation());
  }
  if(btaudio::inputSelected()){
    uint8_t pcm[1024];uint32_t rate=44100;
    auto n=btaudio::pcm(pcm,sizeof(pcm),rate);
    if(n)Audio::writePcm16(pcm,n,rate);
    return;
  }
  if(btaudio::outputSelected()){
    if(sourcePaused)return;
    if(!btaudio::transmitting()){
      if(isRunning())_stop();
      btStarted=false;return; // Free decoder RAM during pairing; no busy decoding.
    }
    if(!btStarted){btStarted=true;_recovery.begin(config.lastStation());_play(config.lastStation());}
  }else btStarted=false;
  Audio::loop();
  if(_recovery.poll(millis(),config.getMode()==PM_WEB,WiFi.status()==WL_CONNECTED,isRunning(),inBufferFilled(),
                    btaudio::transmitting(),btaudio::producedFrames())){
    Serial.printf("[STREAM-RECOVERY] retry reason=%s station=%u buffer=%u produced=%lu\n",
                  _recovery.lastReason==dual::StreamRecovery::Reason::BtNoProduction?"BT_NO_PRODUCTION":"LOW_BUFFER",
                  _recovery.station,(unsigned)inBufferFilled(),(unsigned long)btaudio::producedFrames());
    // The owner of the decoder closes and recreates its own connection.
    // Preserve the user's station and avoid persistent stop/start writes.
    const bool priorLock=lockOutput;lockOutput=true;
    _stop();_play(_recovery.station);lockOutput=priorLock;
  }
  if(!isRunning() && _status==PLAYING) _stop(true);
  if(_volTimer){
    if(!isRunning() && !btaudio::wanted() && (millis()-_volTicks)>3000){
      config.saveVolume();
      _volTimer=false;
    }
  }
  /*
#ifdef MQTT_ROOT_TOPIC
  if(strlen(burl)>0){
    browseUrl();
  }
#endif*/
}

void Player::setOutputPins(bool isPlaying) {
  if(REAL_LEDBUILTIN!=255) digitalWrite(REAL_LEDBUILTIN, LED_INVERT?!isPlaying:isPlaying);
  bool _ml = MUTE_LOCK?!MUTE_VAL:(isPlaying?!MUTE_VAL:MUTE_VAL);
  if(MUTE_PIN!=255) digitalWrite(MUTE_PIN, _ml);
}

void Player::_play(uint16_t stationId) {
  playbackGenerationCount.fetch_add(1);
  log_i("%s called, stationId=%d", __func__, stationId);
  _hasError=false;
  setDefaults();
  _status = STOPPED;
  setOutputPins(false);
  remoteStationName = false;
  
  if(!config.prepareForPlaying(stationId)) return;
  dual::track(config.station.url);
  _loadVol(config.store.volume);
  
  bool isConnected = false;
  if(config.getMode()==PM_SDCARD && SDC_CS!=255){
    // getFilePos() and connecttoFS() both use absolute file offsets.
    isConnected=connecttoFS(sdman,sdman.selectedPath(),config.sdResumePos==0?_resumeFilePos:config.sdResumePos);
  }else {
    config.saveValue(&config.store.play_mode, static_cast<uint8_t>(PM_WEB));
  }
  connproc = false;
  if(config.getMode()==PM_WEB) isConnected=connecttohost(config.station.url);
  if(!isConnected && stationId==65001){
    strlcpy(config.station.url,V026_STREAM_ALT,sizeof(config.station.url));
    Serial.printf("[STREAM-TEST] fallback=%s\n",config.station.url);
    isConnected=connecttohost(config.station.url);
  }
  Serial.printf("[V026-PLAYER] station=%u connect=%d\n",stationId,(int)isConnected);
  connproc = true;
  if(isConnected){
    _status = PLAYING;
    config.configPostPlaying(stationId);
    setOutputPins(true);
    if (player_on_start_play) player_on_start_play();
    pm.on_start_play();
  }else{
    telnet.printf("##ERROR#:\tError connecting to %.128s\n", config.station.url);
    snprintf(config.tmpBuf, sizeof(config.tmpBuf), "Error connecting to %.128s", config.station.url); setError();
    _stop(true);
  };
}

#ifdef MQTT_ROOT_TOPIC
void Player::browseUrl(){
  _hasError=false;
  remoteStationName = true;
  config.setDspOn(1);
  resumeAfterUrl = _status==PLAYING;
  display.putRequest(PSTOP);
  setOutputPins(false);
  config.setTitle(LANG::const_PlConnect);
  if (connecttohost(burl)){
    _status = PLAYING;
    config.setTitle("");
    netserver.requestOnChange(MODE, 0);
    setOutputPins(true);
    display.putRequest(PSTART);
    if (player_on_start_play) player_on_start_play();
    pm.on_start_play();
  }else{
    telnet.printf("##ERROR#:\tError connecting to %.128s\n", burl);
    snprintf(config.tmpBuf, sizeof(config.tmpBuf), "Error connecting to %.128s", burl); setError();
    _stop(true);
  }
  //memset(burl, 0, MQTT_BURL_SIZE);
}
#endif

void Player::prev() {
  uint16_t lastStation = config.lastStation();
  if(config.getMode()==PM_WEB || !config.store.sdsnuffle){
    if (lastStation == 1) config.lastStation(config.playlistLength()); else config.lastStation(lastStation-1);
  }
  sendCommand({PR_PLAY, config.lastStation()});
}

void Player::next() {
  uint16_t lastStation = config.lastStation();
  if(config.getMode()==PM_WEB || !config.store.sdsnuffle){
    if (lastStation == config.playlistLength()) config.lastStation(1); else config.lastStation(lastStation+1);
  }else{
    config.lastStation(random(1, config.playlistLength()));
  }
  sendCommand({PR_PLAY, config.lastStation()});
}

void Player::toggle() {
  if (_status == PLAYING) {
    sendCommand({PR_STOP, 0});
  } else {
    sendCommand({PR_PLAY, config.lastStation()});
  }
}

void Player::stepVol(bool up) {
  int prior=pendingVolumeSteps.load();
  for(;;){
    int next=prior+(up?1:-1);
    if(next>254)next=254;
    if(next<-254)next=-254;
    if(pendingVolumeSteps.compare_exchange_weak(prior,next))return;
  }
}

uint8_t Player::volToI2S(uint8_t volume) {
  int vol = map(volume, 0, 254 - config.station.ovol * 3 , 0, 254);
  if (vol > 254) vol = 254;
  if (vol < 0) vol = 0;
  return vol;
}

void Player::_loadVol(uint8_t volume) {
  setVolume(volToI2S(volume));
}

void Player::setVol(uint8_t volume) {
  pendingAbsoluteVolume.store(volume);
}
