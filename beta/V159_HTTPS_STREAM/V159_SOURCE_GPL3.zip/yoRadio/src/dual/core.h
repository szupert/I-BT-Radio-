#pragma once
#include "logic.h"
namespace dual {
struct Snapshot {
    char device[40]={}; char station[170]={}; char artist[170]={};
    char title[170]={}; char album[170]={}; char ip[20]={};char notice[100]={};
    uint32_t generation=0, elapsed=0, duration=0, sampleRate=0, buffer=0, bufferCapacity=0, freeHeap=0, largestHeap=0, freePsram=0;
    uint32_t queueDrops=0, inputDrops=0, lowBufferEvents=0;
    int rssi=0; uint16_t bitrate=0;uint8_t volume=0;
    int8_t bass=0,middle=0,treble=0,balance=0;
    bool playing=false, sd=false, connected=false, pendingSave=false, ready=false;
    Settings settings;
};
struct WifiPasswordUi {
    char ssid[33]={};
    char password[64]={}; // never rendered or written to a diagnostic log
    char error[48]={};
    uint8_t mode=0;
    bool submitted=false;
};
const WifiPasswordUi& wifiPasswordUi();
char wifiPasswordKeyChar(unsigned mode,unsigned key);
void begin();
void uiLoop();
void bluetoothMode(int mode); // 1 phone input, 0 scan/output, -1 radio DAC
void audioLoop();
void track(const char *path);
void metadataArtist(const char *s);
void metadataAlbum(const char *s);
void metadataTitle(const char *s);
void imageHint(size_t pos,size_t size);
void clockConfigure();
void displayEvent(int type,int payload);
Snapshot snapshot();
bool debugEnabled();
bool uiOverloadActive();
bool sourcePendingSd();
void send(Action action);
enum class R10DiagUiAction : uint8_t { RotCW, RotCCW, Short, Long, Double, Menu };
bool r10DiagUi(R10DiagUiAction action);
bool r10UiSelfcheck(); // exercises the real menu input state machine, without saving settings
bool r10UiStressStart(unsigned actionMs,unsigned drawMs,bool tour=false);
void r10UiStressStop(const char* reason);
void r10UiStressStatus();
bool r10UiStressInfo(uint16_t& actionMs,uint16_t& drawMs,uint32_t& actions,uint32_t& frames);
void r10DiagRecoverHome();
unsigned r10DiagPage();
unsigned r10DiagSelected();
bool favorite(uint16_t station);
unsigned favoritesCount();
uint16_t nextFavorite(uint16_t station,bool forward);
void invalidateFavorites();
const char* stationSearchQuery();
unsigned stationSearchCount();
uint16_t stationSearchResult(unsigned index);
bool stationSearchResultName(unsigned index,char* out,size_t cap);
unsigned stationSearchStatus();
bool preloadStationSearch();
void invalidateStationSearchCache();
unsigned memoryStressStatus();
bool backupRestoreArmed();
}
