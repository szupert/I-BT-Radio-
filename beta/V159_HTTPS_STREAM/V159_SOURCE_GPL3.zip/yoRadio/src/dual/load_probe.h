#pragma once
namespace loadprobe { void sample(); }
