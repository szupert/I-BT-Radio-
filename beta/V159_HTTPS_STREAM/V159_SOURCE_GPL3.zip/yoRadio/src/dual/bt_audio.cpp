#include "../core/options.h"
#include "bt_audio.h"
#include "pcm_ring.h"
#include "pcm_work_queue.h"
#include "audio_path_probe.h"
#include "pcm_resampler.h"
#include "../audioI2S/start_fade.h"
#include <Arduino.h>
#include <esp_bt.h>
#include <esp_bt_main.h>
#include <esp_gap_bt_api.h>
#include <esp_a2dp_api.h>
#include <esp_avrc_api.h>
#include <esp_a2dp_legacy_api.h>
#include <esp_heap_caps.h>
#include <atomic>
#include <algorithm>
#include <new>
#include <Preferences.h>
#include <strings.h>
extern "C" unsigned ibt_btc_task_target_core(void);
extern "C" unsigned ibt_btu_task_target_core(void);
namespace btaudio {
static std::atomic<int> txCallbackCore{-1};
static std::atomic<unsigned> txCallbackTask{0};
static Device devices[12]{};static unsigned devicesUsed=0;
static portMUX_TYPE devicesMux=portMUX_INITIALIZER_UNLOCKED;
static std::atomic<bool> controlReady{false},controlGone{false},controlConnected{false};
static std::atomic<int> pendingKey{-1},controlResult{0};
static std::atomic<bool> keyHeld{false};static int heldKey=-1;static uint32_t releaseAt=0;static uint8_t transaction=0;
enum class Stage : uint8_t { Off, Init, Active, Disconnect, Deinit, Fault, AvrcInit, AvrcDeinit };
static std::atomic<Mode> desired{Mode::Off},active{Mode::Off};
static std::atomic<Stage> stage{Stage::Off};
static std::atomic<bool> streaming{false},ready{false},deinitialized{false},failed{false};
static std::atomic<bool> found{false},discovering{false};
static std::atomic<bool> connectionRejected{false};
static std::atomic<bool> autoDacFallback{false};
static std::atomic<bool> retryRequested{false};
static std::atomic<bool> restartScanRequested{false},reconnectRequested{false},savePeerPending{false};
static std::atomic<bool> savedValid{false};
static std::atomic<int> connection{ESP_A2D_CONNECTION_STATE_DISCONNECTED};
static std::atomic<uint32_t> requestId{0},epoch{0},delivered{0},received{0},dropped{0},underruns{0},rxRate{44100};
static std::atomic<uint32_t> blockFrames{0},txRate{0},sourceRate{0},requestedRate{32000};
static std::atomic<bool> txCodecConfigured{false},codecUnsupported{false};
static std::atomic<bool> mono{false};
// BT OUT keeps enough decoded audio in PSRAM to absorb radio/decode jitter.
static portMUX_TYPE txMux=portMUX_INITIALIZER_UNLOCKED;
static int16_t* txPcm=nullptr;
static constexpr unsigned txFrames=32768,internalReserve=16384;
static unsigned txHead=0,txTail=0,txUsed=0;
static std::atomic<uint32_t> requestedBytes{0},prefillCallbacks{0},rebufferEvents{0};
static std::atomic<PcmRing*> rxRing{nullptr};
static std::atomic<uint32_t> pcmGeneration{0};
static uint32_t consumedGeneration=~0u,consumedEpoch=~0u,legacyRate=0,legacyOutputRate=0,legacyPhase=0;
static int16_t legacyPrevious[2]{};
static esp_bd_addr_t peer{},selectedPeer{};
static esp_bd_addr_t savedPeer{},requestedSavedPeer{};
static portMUX_TYPE peerMux=portMUX_INITIALIZER_UNLOCKED;
static constexpr uint32_t savedHistoryMagic=0x49425431;
static constexpr unsigned savedHistoryCapacity=4;
struct SavedHistory {uint32_t magic;uint8_t count;uint8_t reserved[3];Device entries[savedHistoryCapacity];};
static SavedHistory savedHistory{};
static bool validAddress(const uint8_t* address){
    uint8_t any=0,all=0xff;
    for(unsigned i=0;i<6;++i){any|=address[i];all&=address[i];}
    return any!=0&&all!=0xff;
}
static bool placeholderName(const char* name){
    return !name[0]||!strcmp(name,"Névtelen eszköz")||
        (strlen(name)==20&&!strncmp(name,"BT ",3)&&name[5]==':'&&name[8]==':'&&name[11]==':'&&name[14]==':'&&name[17]==':');
}
static void fallbackName(Device& d){
    if(placeholderName(d.name))strlcpy(d.name,"Névtelen eszköz",sizeof(d.name));
}
static bool initialized=false,attempt=false,connectSent=false,disconnectSent=false,advertised=false;
static std::atomic<bool> cancelSent{false};
static std::atomic<uint32_t> selectedAt{0},scanStoppedAt{0},connectedAt{0},streamAt{0};
static bool scanTimingLogged=false,connectTimingLogged=false,streamTimingLogged=false;
static uint32_t appliedRequest=0,stageAt=0,linkAt=0,lastCheck=0,retryAt=0;
static uint8_t connectAttempts=0;
static PcmResampler resampler;
static int16_t block[512];static unsigned frames=0; // PCM owner only
// One decoder producer, one core0 PCM consumer. Allocations live until reboot.
static std::atomic<bool> pcmWorkerReady{false};
static PcmWorkQueue* pcmJobs=nullptr;
static TaskHandle_t pcmWorkerHandle=nullptr;
static std::atomic<unsigned> pcmWorkerId{0};
static std::atomic<uint32_t> pcmQueuedFrames{0},pcmProcessedFrames{0},pcmCancelledFrames{0};
static std::atomic<uint32_t> pcmQueueLostFrames{0},pcmQueueWaits{0},pcmQueuePeak{0},pcmWorkWallMaxUs{0};
static uint32_t processGeneration=0,processEpoch=0; // PCM owner only
static bool pcmWorkerAttempted=false; // service core only
static uint32_t fallbackGeneration=0,fallbackEpoch=0,fallbackRate=0;
static unsigned fallbackCount=0;
static int16_t fallbackPcm[128]; // decoder owner only, already gained samples
static bool allocatePcmWorker();
static void clearTx(){portENTER_CRITICAL(&txMux);txHead=txTail=txUsed=0;portEXIT_CRITICAL(&txMux);}
void flush(){
    portENTER_CRITICAL(&txMux);
    txHead=txTail=txUsed=0;pcmGeneration.fetch_add(1);epoch.fetch_add(1);
    portEXIT_CRITICAL(&txMux);
}
void request(Mode next){flush();desired.store(next);requestId.fetch_add(1);}
void request(bool enabled){request(enabled?Mode::Out:Mode::Off);}
Mode mode(){return desired.load();}
bool wanted(){return mode()!=Mode::Off;}
bool outputSelected(){return mode()==Mode::Out;}
bool inputSelected(){return mode()==Mode::In;}
bool idle(){return stage.load()==Stage::Off;}
unsigned pcmTaskId(){return pcmWorkerId.load();}
bool setDiagnosticRate(unsigned hz){
    if(!idle()||wanted()||(hz!=16000&&hz!=32000&&hz!=44100&&hz!=48000))return false;
    requestedRate.store(hz);return true;
}
unsigned outputRate(){return requestedRate.load();}
bool setOutputRate(unsigned hz){
    if(hz!=16000&&hz!=32000&&hz!=44100&&hz!=48000)return false;
    if(!idle()||wanted())return false;
    if(requestedRate.load()==hz)return true;
    Preferences p;
    if(!p.begin("ibt-bt-out",false))return false;
    const bool saved=p.putUInt("rate",hz)==sizeof(uint32_t);
    p.end();
    if(!saved)return false;
    requestedRate.store(hz);
    flush();
    Serial.printf("[BT-RATE] selected_hz=%u result=SAVED\n",hz);
    return true;
}
static bool flowing(Mode m){return desired.load()==m&&active.load()==m&&stage.load()==Stage::Active&&streaming.load()&&!failed.load()&&(m!=Mode::Out||txCodecConfigured.load());}
bool transmitting(){return flowing(Mode::Out);}
uint32_t producedFrames(){return blockFrames.load(std::memory_order_relaxed);}
bool connected(){const auto m=desired.load();return m!=Mode::Off&&active.load()==m&&stage.load()==Stage::Active&&connection.load()==ESP_A2D_CONNECTION_STATE_CONNECTED&&!failed.load();}
bool inputPlaying(){return flowing(Mode::In);}
static bool pushTx(const int16_t* samples,unsigned count){
    unsigned done=0;const uint32_t started=millis();
    while(done<count){
        portENTER_CRITICAL(&txMux);
        const bool active=transmitting()&&processGeneration==pcmGeneration.load()&&processEpoch==epoch.load();
        const unsigned n=active?std::min({count-done,txFrames-txUsed,txFrames-txHead}):0;
        if(n){memcpy(txPcm+txHead*2,samples+done*2,n*4);txHead=(txHead+n)%txFrames;txUsed+=n;}
        portEXIT_CRITICAL(&txMux);
        if(!active)return false;
        done+=n;
        if(!n){
            if(millis()-started>=100){dropped.fetch_add((count-done)*4);return false;}
            vTaskDelay(1);
        }
    }
    return true;
}
static void emit(int16_t l,int16_t r){
    block[frames*2]=l;block[frames*2+1]=r;
    if(++frames<64)return;
    pushTx(block,frames);
    frames=0;
}
static void processSample(int16_t l,int16_t r,uint32_t hz){
    if(!transmitting())return;
    const uint32_t generation=processGeneration;
    if(consumedGeneration!=generation||consumedEpoch!=processEpoch){consumedGeneration=generation;consumedEpoch=processEpoch;resampler.reset();frames=0;legacyRate=0;}
    resampler.feed(l,r,hz,txRate.load(),emit);
}
static void processBlock(const int16_t* samples,uint32_t count,unsigned channels,unsigned rate,unsigned volume,int balance){
    if(!samples||!count||!transmitting()||!(channels==1||channels==2)||!(rate==16000||rate==32000||rate==44100||rate==48000))return;
    const uint32_t targetHz=txRate.load();
    if(!targetHz)return;
    sourceRate.store(rate);
    blockFrames.fetch_add(count);
    const uint32_t generation=processGeneration;
    if(consumedGeneration!=generation||consumedEpoch!=processEpoch||legacyRate!=rate||legacyOutputRate!=targetHz){
        consumedGeneration=generation;consumedEpoch=processEpoch;legacyRate=rate;legacyOutputRate=targetHz;legacyPhase=0;frames=0;
        legacyPrevious[0]=samples[0];legacyPrevious[1]=samples[channels==2?1:0];
    }
    const unsigned level=std::min(volume,254u);
    const unsigned leftBalance=unsigned(std::max(0,std::min(16,-balance)));
    const unsigned rightBalance=unsigned(std::max(0,std::min(16,balance)));
    constexpr uint32_t divisor=254u*254u*16u;
    const int32_t leftGainQ15=(uint64_t(level)*level*(16-leftBalance)*32768u+divisor/2)/divisor;
    const int32_t rightGainQ15=(uint64_t(level)*level*(16-rightBalance)*32768u+divisor/2)/divisor;
    int16_t out[128];unsigned pending=0;
    if(rate==targetHz){
        // Native-rate PCM needs gain only.
        for(uint32_t i=0;i<count;++i){
            const int16_t left=samples[i*channels];
            const int16_t right=samples[i*channels+(channels==2?1:0)];
            out[pending*2]=(int32_t(left)*leftGainQ15)/32768;
            out[pending*2+1]=(int32_t(right)*rightGainQ15)/32768;
            if(++pending==64){if(!pushTx(out,pending))return;pending=0;}
        }
        if(pending)pushTx(out,pending);
        legacyPhase=0;
        legacyPrevious[0]=samples[(count-1)*channels];
        legacyPrevious[1]=samples[(count-1)*channels+(channels==2?1:0)];
        return;
    }
    for(uint32_t i=0;i<count;++i){
        const int16_t now[2]={samples[i*channels],samples[i*channels+(channels==2?1:0)]};
        while(legacyPhase<targetHz){
            const int32_t fractionQ15=int32_t((legacyPhase*32768u)/targetHz);
            for(unsigned c=0;c<2;++c){
                // Q15 keeps 16/32/44.1/48 kHz interpolation in signed 32-bit.
                const int32_t value=legacyPrevious[c]+((int32_t(now[c])-legacyPrevious[c])*fractionQ15)/32768;
                out[pending*2+c]=value*(c==0?leftGainQ15:rightGainQ15)/32768;
            }
            legacyPhase+=rate;
            if(++pending==64){if(!pushTx(out,pending))return;pending=0;}
        }
        legacyPhase-=targetHz;legacyPrevious[0]=now[0];legacyPrevious[1]=now[1];
    }
    if(pending)pushTx(out,pending);
}
static void processJob(const PcmWorkQueue::Job& job){
    pathprobe::Scope probe(pathprobe::Worker);probe.units(job.count);
    if(!transmitting()||job.generation!=pcmGeneration.load()||job.epoch!=epoch.load()){
        pcmCancelledFrames.fetch_add(job.count);return;
    }
    processGeneration=job.generation;processEpoch=job.epoch;
    if(job.legacy){
        for(unsigned i=0;i<job.count;++i)processSample(job.pcm[i*2],job.pcm[i*2+1],job.rate);
    }else processBlock(job.pcm,job.count,job.channels,job.rate,job.volume,job.balance);
    pcmProcessedFrames.fetch_add(job.count);
}
static void pcmWorkerTask(void*){
    TaskStatus_t info{};vTaskGetInfo(nullptr,&info,pdFALSE,eInvalid);
    pcmWorkerId.store(unsigned(info.xTaskNumber));
    for(;;){
        const auto* job=pcmJobs->front();
        if(!job){ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(20));continue;}
        const uint32_t started=micros();
        processJob(*job);pcmJobs->release();
        const uint32_t elapsed=micros()-started;
        if(elapsed>pcmWorkWallMaxUs.load())pcmWorkWallMaxUs.store(elapsed);
    }
}
static bool allocatePcmWorker(){
    if(pcmWorkerAttempted)return pcmWorkerReady.load();
    pcmWorkerAttempted=true;
    // Preserve the existing 16KiB reserve plus room for 4KiB stack and TCB.
    if(heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)<internalReserve+6144){
        Serial.println("[BT-PCM] init=INLINE_FALLBACK reason=INTERNAL_RESERVE");return false;
    }
    auto slots=(PcmWorkQueue::Job*)heap_caps_malloc(sizeof(PcmWorkQueue::Job)*PcmWorkQueue::Capacity,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!slots){Serial.println("[BT-PCM] init=INLINE_FALLBACK reason=PSRAM");return false;}
    pcmJobs=new(std::nothrow) PcmWorkQueue(slots);
    if(!pcmJobs){free(slots);Serial.println("[BT-PCM] init=INLINE_FALLBACK reason=QUEUE");return false;}
    if(xTaskCreatePinnedToCore(pcmWorkerTask,"ibt_pcm",4096,nullptr,3,&pcmWorkerHandle,0)!=pdPASS){
        delete pcmJobs;pcmJobs=nullptr;free(slots);pcmWorkerHandle=nullptr;
        Serial.println("[BT-PCM] init=INLINE_FALLBACK reason=TASK");return false;
    }
    pcmWorkerReady.store(true);
    Serial.printf("[BT-PCM] init=PASS core=0 priority=3 psram_bytes=%u stack=4096\n",unsigned(sizeof(PcmWorkQueue::Job)*PcmWorkQueue::Capacity));
    return true;
}
static bool queueBlock(const int16_t* pcm,unsigned count,unsigned channels,unsigned rate,unsigned volume,int balance,uint32_t generation,uint32_t streamEpoch,bool legacy){
    const uint32_t started=millis();bool waited=false;
    for(;;){
        if(!transmitting()||generation!=pcmGeneration.load()||streamEpoch!=epoch.load()){
            pcmCancelledFrames.fetch_add(count);return false;
        }
        if(pcmJobs->push(pcm,count,channels,rate,volume,balance,generation,streamEpoch,legacy)){
            pcmQueuedFrames.fetch_add(count);
            const uint32_t size=pcmJobs->size();if(size>pcmQueuePeak.load())pcmQueuePeak.store(size);
            xTaskNotifyGive(pcmWorkerHandle);return true;
        }
        if(!waited){pcmQueueWaits.fetch_add(1);waited=true;}
        if(uint32_t(millis()-started)>=100){pcmQueueLostFrames.fetch_add(count);return false;}
        vTaskDelay(1);
    }
}
void feedBlock(const int16_t* samples,uint32_t count,unsigned channels,unsigned rate,unsigned volume,int balance){
    if(!samples||!count||!transmitting()||(channels!=1&&channels!=2)||
       !(rate==16000||rate==32000||rate==44100||rate==48000))return;
    const uint32_t generation=pcmGeneration.load(),streamEpoch=epoch.load();
    if(!pcmWorkerReady.load()){
        processGeneration=generation;processEpoch=streamEpoch;
        processBlock(samples,count,channels,rate,volume,balance);return;
    }
    // Flush any complete legacy fragment before switching processing paths.
    if(fallbackCount){
        queueBlock(fallbackPcm,fallbackCount,2,fallbackRate,254,0,fallbackGeneration,fallbackEpoch,true);
        fallbackCount=0;
    }
    for(uint32_t done=0;done<count;){
        const unsigned n=std::min<uint32_t>(PcmWorkQueue::Frames,count-done);
        if(!queueBlock(samples+done*channels,n,channels,rate,volume,balance,generation,streamEpoch,false)){
            if(generation==pcmGeneration.load()&&streamEpoch==epoch.load()&&transmitting())
                pcmQueueLostFrames.fetch_add(count-done-n);
            return;
        }
        done+=n;
    }
}
void sample(int16_t left,int16_t right,uint32_t rate){
    if(!transmitting())return;
    const uint32_t generation=pcmGeneration.load(),streamEpoch=epoch.load();
    if(!pcmWorkerReady.load()){
        processGeneration=generation;processEpoch=streamEpoch;processSample(left,right,rate);return;
    }
    if(fallbackCount&&(fallbackGeneration!=generation||fallbackEpoch!=streamEpoch||fallbackRate!=rate)){
        pcmCancelledFrames.fetch_add(fallbackCount);fallbackCount=0;
    }
    if(!fallbackCount){fallbackGeneration=generation;fallbackEpoch=streamEpoch;fallbackRate=rate;}
    fallbackPcm[fallbackCount*2]=left;fallbackPcm[fallbackCount*2+1]=right;
    if(++fallbackCount==64){
        queueBlock(fallbackPcm,fallbackCount,2,rate,254,0,generation,streamEpoch,true);fallbackCount=0;
    }
}

static int32_t data(uint8_t* bytes,int32_t n){
    if(txCallbackCore.load()<0){
        TaskStatus_t info{};vTaskGetInfo(nullptr,&info,pdFALSE,eInvalid);
        txCallbackTask.store(unsigned(info.xTaskNumber));
        txCallbackCore.store(xPortGetCoreID());
    }
    // Copy exactly as V029: short critical sections, silence on missing input.
    static uint32_t seen=0;
    static bool primed=false;
    static ibtaudio::StartFade startFade; // Owned only by this A2DP callback.
    const uint32_t generation=epoch.load();
    if(n<0){clearTx();primed=false;return 0;}
    if(!bytes||n==0)return 0;
    memset(bytes,0,n);
    requestedBytes.fetch_add(n);
    if(generation!=seen){seen=generation;clearTx();primed=false;}
    if(!primed){
        portENTER_CRITICAL(&txMux);
        primed=txUsed>=std::min<unsigned>(txFrames-1,unsigned(txRate.load()/2));
        portEXIT_CRITICAL(&txMux);
        if(!primed){prefillCallbacks.fetch_add(1);return n;}
        startFade.begin(txRate.load()); // Initial start and each underflow recovery.
    }
    const unsigned wanted=unsigned(n)/4;unsigned done=0;
    while(done<wanted){
        portENTER_CRITICAL(&txMux);
        const unsigned count=txPcm&&transmitting()?std::min({wanted-done,txUsed,64u,txFrames-txTail}):0;
        if(count){memcpy(bytes+done*4,txPcm+txTail*2,count*4);txTail=(txTail+count)%txFrames;txUsed-=count;delivered.fetch_add(count*4);}
        portEXIT_CRITICAL(&txMux);
        if(!count)break;
        done+=count;
    }
    // Fade actual PCM only, after copying and outside the ring critical section.
    // Silence while prebuffering never consumes the fade; steady state is one check.
    if(startFade.active())startFade.apply(bytes,done);
    if(done<wanted){underruns.fetch_add(1);rebufferEvents.fetch_add(1);primed=false;}
    return n;
}

static void sinkData(const uint8_t* bytes,uint32_t n){
    auto q=rxRing.load();if(!q||!flowing(Mode::In))return;
    if(!mono.load()){
        auto accepted=q->push(bytes,n);received.fetch_add(accepted);if(accepted<n)dropped.fetch_add(n-accepted);
    }else{
        // Expand mono SBC in bounded stack chunks. Never write I2S in callback.
        int16_t stereo[128];uint32_t offset=0;
        while(offset+1<n){unsigned count=0;
            while(count<64&&offset+1<n){int16_t v;memcpy(&v,bytes+offset,2);offset+=2;stereo[count*2]=v;stereo[count*2+1]=v;++count;}
            auto accepted=q->push((uint8_t*)stereo,count*4);received.fetch_add(accepted);if(accepted<count*4)dropped.fetch_add(count*4-accepted);
        }
    }
}
size_t pcm(uint8_t* out,size_t capacity,uint32_t& rate){
    static uint32_t seen=0;static bool primed=false;
    auto q=rxRing.load();if(!q)return 0;auto current=epoch.load();
    if(seen!=current){seen=current;q->discard();primed=false;}
    if(!flowing(Mode::In)){q->discard();primed=false;return 0;}
    if(!primed){if(q->size()<32768)return 0;primed=true;}
    rate=rxRate.load();auto n=q->pop(out,capacity);delivered.fetch_add(n);
    if(!n){primed=false;underruns.fetch_add(1);}return n;
}
unsigned deviceCount(){portENTER_CRITICAL(&devicesMux);auto n=devicesUsed;portEXIT_CRITICAL(&devicesMux);return n;}
bool device(unsigned i,Device& out){portENTER_CRITICAL(&devicesMux);bool ok=i<devicesUsed;if(ok)out=devices[i];portEXIT_CRITICAL(&devicesMux);return ok;}
bool scanning(){return discovering.load();}
bool linkFailed(){return failed.load();}
bool connecting(){return outputSelected()&&found.load()&&!streaming.load()&&!failed.load();}
bool takeAutoDacFallback(){return autoDacFallback.exchange(false);}
void loadSavedDevice(){
    uint8_t address[6]{};bool valid=false;uint32_t savedRate=32000;
    SavedHistory loaded{};loaded.magic=savedHistoryMagic;
    Preferences p;
    if(p.begin("ibt-bt-out",true)){
        savedRate=p.getUInt("rate",32000);
        if(p.getBytesLength("history")==sizeof(loaded)){
            SavedHistory disk{};
            if(p.getBytes("history",&disk,sizeof(disk))==sizeof(disk)&&
               disk.magic==savedHistoryMagic&&disk.count<=savedHistoryCapacity){
                bool good=true;
                for(unsigned i=0;i<disk.count;++i)good=good&&validAddress(disk.entries[i].address);
                if(good){loaded=disk;for(unsigned i=0;i<loaded.count;++i){
                    loaded.entries[i].name[sizeof(loaded.entries[i].name)-1]=0;
                    fallbackName(loaded.entries[i]);
                }}
            }
        }
        if(p.getBytesLength("lastmac")==sizeof(address)){
            valid=p.getBytes("lastmac",address,sizeof(address))==sizeof(address);
            valid=valid&&validAddress(address);
        }
        p.end();
    }
    if(!loaded.count&&valid){
        loaded.count=1;memcpy(loaded.entries[0].address,address,6);
        fallbackName(loaded.entries[0]);
    }
    if(savedRate!=16000&&savedRate!=32000&&savedRate!=44100&&savedRate!=48000)savedRate=32000;
    requestedRate.store(savedRate);
    portENTER_CRITICAL(&peerMux);
    savedHistory=loaded;
    if(loaded.count)memcpy(savedPeer,loaded.entries[0].address,6);
    portEXIT_CRITICAL(&peerMux);
    savedValid.store(loaded.count!=0);
}
bool hasSavedDevice(){return savedValid.load();}
unsigned savedDeviceCount(){
    portENTER_CRITICAL(&peerMux);unsigned count=savedHistory.count;portEXIT_CRITICAL(&peerMux);
    return count;
}
bool savedDevice(unsigned index,Device& out){
    portENTER_CRITICAL(&peerMux);
    bool ok=index<savedHistory.count;
    if(ok)out=savedHistory.entries[index];
    portEXIT_CRITICAL(&peerMux);
    if(ok)fallbackName(out);
    return ok;
}
bool connectedDevice(Device& out){
    out=Device{};
    if(!outputSelected()||!connected())return false;
    uint8_t address[6];
    portENTER_CRITICAL(&peerMux);
    memcpy(address,peer,6);
    for(unsigned i=0;i<savedHistory.count;++i)
        if(!memcmp(savedHistory.entries[i].address,address,6)){out=savedHistory.entries[i];break;}
    portEXIT_CRITICAL(&peerMux);
    portENTER_CRITICAL(&devicesMux);
    for(unsigned i=0;i<devicesUsed;++i)
        if(!memcmp(devices[i].address,address,6)&&!placeholderName(devices[i].name)){out=devices[i];break;}
    portEXIT_CRITICAL(&devicesMux);
    memcpy(out.address,address,6);
    fallbackName(out);
    return true;
}
bool connectSavedDevice(unsigned index){
    portENTER_CRITICAL(&peerMux);
    bool ok=index<savedHistory.count;
    if(ok)memcpy(requestedSavedPeer,savedHistory.entries[index].address,6);
    portEXIT_CRITICAL(&peerMux);
    if(ok)reconnectRequested.store(true);
    return ok;
}
bool reconnectSaved(){
    return connectSavedDevice(0);
}
bool restartScan(){
    if(!outputSelected()||active.load()!=Mode::Out||stage.load()!=Stage::Active||
       discovering.load()||deviceCount()!=0||connection.load()!=ESP_A2D_CONNECTION_STATE_DISCONNECTED)return false;
    restartScanRequested.store(true);
    return true;
}
bool selectDevice(unsigned i){
    if(!outputSelected()||active.load()!=Mode::Out||stage.load()!=Stage::Active||(found.load()&&!failed.load()))return false;
    Device chosen;if(!device(i,chosen))return false;
    portENTER_CRITICAL(&peerMux);memcpy(peer,chosen.address,6);memcpy(selectedPeer,chosen.address,6);portEXIT_CRITICAL(&peerMux);
    selectedAt.store(millis());
    if(!discovering.load())scanStoppedAt.store(selectedAt.load());
    bool retry=found.exchange(true);
    if(retry){retryRequested.store(true);return true;}
    // Stop inquiry at selection time. The main loop may be busy with network/UI
    // work; A2DP connect still waits for the GAP stopped callback below.
    if(discovering.load()&&esp_bt_gap_cancel_discovery()==ESP_OK)cancelSent.store(true);
    return true;
}
bool control(unsigned key){
    if(key>3||!inputSelected()||stage.load()!=Stage::Active||!controlConnected.load()){controlResult.store(-1);return false;}
    if(keyHeld.load()){controlResult.store(-2);return false;}
    int empty=-1;bool ok=pendingKey.compare_exchange_strong(empty,int(key));controlResult.store(ok?1:-2);return ok;
}
const char* controlStatus(){return !controlConnected.load()?"Telefon: I-BT-Radio-Audio":controlResult.load()<0?"Vezerles nem elerheto":streaming.load()?"Lejatszas / telefon":"Csatlakozva / szunet";}
static void avrc(esp_avrc_ct_cb_event_t e,esp_avrc_ct_cb_param_t* p){
    if(e==ESP_AVRC_CT_PROF_STATE_EVT){controlReady.store(p->avrc_ct_init_stat.state==ESP_AVRC_INIT_SUCCESS);controlGone.store(p->avrc_ct_init_stat.state==ESP_AVRC_DEINIT_SUCCESS);}
    if(e==ESP_AVRC_CT_CONNECTION_STATE_EVT)controlConnected.store(p->conn_stat.connected);
    if(e==ESP_AVRC_CT_PASSTHROUGH_RSP_EVT)controlResult.store(p->psth_rsp.rsp_code==ESP_AVRC_RSP_ACCEPT?2:-3);
}
static void serviceControl(){
    if(!inputSelected()||stage.load()!=Stage::Active||!controlConnected.load()){
        if(keyHeld.load()&&controlConnected.load())esp_avrc_ct_send_passthrough_cmd(transaction,heldKey,ESP_AVRC_PT_CMD_STATE_RELEASED);
        transaction=(transaction+1)&15;pendingKey.store(-1);keyHeld.store(false);heldKey=-1;return;
    }
    if(keyHeld.load()){
        if(uint32_t(millis()-releaseAt)<40)return;
        auto err=esp_avrc_ct_send_passthrough_cmd(transaction,heldKey,ESP_AVRC_PT_CMD_STATE_RELEASED);
        transaction=(transaction+1)&15;heldKey=-1;keyHeld.store(false);if(err!=ESP_OK)controlResult.store(-3);return;
    }
    int k=pendingKey.exchange(-1);if(k<0)return;
    const uint8_t keys[]={ESP_AVRC_PT_CMD_PLAY,ESP_AVRC_PT_CMD_PAUSE,ESP_AVRC_PT_CMD_BACKWARD,ESP_AVRC_PT_CMD_FORWARD};
    heldKey=keys[k];
    if(esp_avrc_ct_send_passthrough_cmd(transaction,heldKey,ESP_AVRC_PT_CMD_STATE_PRESSED)!=ESP_OK){controlResult.store(-3);heldKey=-1;return;}
    transaction=(transaction+1)&15;releaseAt=millis();keyHeld.store(true);
}
static bool pairingAllowed(const uint8_t* address){
    if(stage.load()!=Stage::Active||mode()!=active.load())return false;
    if(inputSelected())return true; // phone pairing is explicitly enabled in IN mode
    esp_bd_addr_t expected;portENTER_CRITICAL(&peerMux);memcpy(expected,selectedPeer,6);portEXIT_CRITICAL(&peerMux);
    return outputSelected()&&found.load()&&!memcmp(expected,address,6);
}
static void gap(esp_bt_gap_cb_event_t e,esp_bt_gap_cb_param_t* p){
    if(e==ESP_BT_GAP_CFM_REQ_EVT)esp_bt_gap_ssp_confirm_reply(p->cfm_req.bda,pairingAllowed(p->cfm_req.bda));
    if(e==ESP_BT_GAP_PIN_REQ_EVT){esp_bt_pin_code_t code;memset(code,'0',sizeof(code));esp_bt_gap_pin_reply(p->pin_req.bda,pairingAllowed(p->pin_req.bda),p->pin_req.min_16_digit?16:4,code);}
    if(e==ESP_BT_GAP_DISC_STATE_CHANGED_EVT){
        bool running=p->disc_st_chg.state==ESP_BT_GAP_DISCOVERY_STARTED;
        discovering.store(running);
        if(!running&&found.load())scanStoppedAt.store(millis());
    }
    if(e!=ESP_BT_GAP_DISC_RES_EVT||mode()!=Mode::Out||active.load()!=Mode::Out||stage.load()!=Stage::Active||found.load())return;
    Device entry{};memcpy(entry.address,p->disc_res.bda,6);entry.rssi=-127;uint32_t cod=0;bool hasCod=false;
    for(int i=0;i<p->disc_res.num_prop;++i){
        auto& prop=p->disc_res.prop[i];uint8_t len=0;uint8_t* value=nullptr;
        if(prop.type==ESP_BT_GAP_DEV_PROP_COD&&prop.len>=4){memcpy(&cod,prop.val,4);hasCod=true;}
        if(prop.type==ESP_BT_GAP_DEV_PROP_RSSI&&prop.len>=1)memcpy(&entry.rssi,prop.val,1);
        if(prop.type==ESP_BT_GAP_DEV_PROP_BDNAME&&prop.len>0){len=uint8_t(std::min(prop.len,int(sizeof(entry.name)-1)));value=(uint8_t*)prop.val;}
        if(prop.type==ESP_BT_GAP_DEV_PROP_EIR){
            value=esp_bt_gap_resolve_eir_data((uint8_t*)prop.val,ESP_BT_EIR_TYPE_CMPL_LOCAL_NAME,&len);
            if(!value)value=esp_bt_gap_resolve_eir_data((uint8_t*)prop.val,ESP_BT_EIR_TYPE_SHORT_LOCAL_NAME,&len);
        }
        if(value&&len){len=std::min<unsigned>(len,sizeof(entry.name)-1);memcpy(entry.name,value,len);entry.name[len]=0;}
    }
    if(hasCod&&!(esp_bt_gap_get_cod_srvc(cod)&ESP_BT_COD_SRVC_RENDERING))return;
    portENTER_CRITICAL(&devicesMux);
    unsigned at=0;while(at<devicesUsed&&memcmp(devices[at].address,entry.address,6))++at;
    if(at<12){
        // Inquiry RSSI-only updates must not erase an already discovered name.
        if(!entry.name[0]&&at<devicesUsed)memcpy(entry.name,devices[at].name,sizeof(entry.name));
        fallbackName(entry);devices[at]=entry;if(at==devicesUsed)++devicesUsed;
    }
    portEXIT_CRITICAL(&devicesMux);
}
static void event(esp_a2d_cb_event_t e,esp_a2d_cb_param_t* p){
    if(e==ESP_A2D_PROF_STATE_EVT){
        if(p->a2d_prof_stat.init_state==ESP_A2D_INIT_SUCCESS)ready.store(true);
        if(p->a2d_prof_stat.init_state==ESP_A2D_DEINIT_SUCCESS){ready.store(false);deinitialized.store(true);}
    }
    if(e==ESP_A2D_CONNECTION_STATE_EVT){
        portENTER_CRITICAL(&peerMux);memcpy(peer,p->conn_stat.remote_bda,6);portEXIT_CRITICAL(&peerMux);
        connection.store(p->conn_stat.state);
        if(p->conn_stat.state==ESP_A2D_CONNECTION_STATE_CONNECTED){
            connectedAt.store(millis());connectionRejected.store(false);
            if(active.load()==Mode::Out)savePeerPending.store(true);
        }
        else {
            if(p->conn_stat.state==ESP_A2D_CONNECTION_STATE_DISCONNECTED&&mode()==Mode::Out&&found.load())connectionRejected.store(true);
            streaming.store(false);txCodecConfigured.store(false);txRate.store(0);epoch.fetch_add(1);
        }
    }
    if(e==ESP_A2D_AUDIO_STATE_EVT){
        bool playing=p->audio_stat.state==ESP_A2D_AUDIO_STATE_STARTED;
        streaming.store(playing);if(playing)streamAt.store(millis());epoch.fetch_add(1);
    }
    if(e==ESP_A2D_AUDIO_CFG_EVT){
        const auto& codec=p->audio_cfg.mcc;
        const uint8_t frequency=codec.cie.sbc_info.samp_freq;
        if(active.load()==Mode::In){
            mono.store((codec.cie.sbc_info.ch_mode&ESP_A2D_SBC_CIE_CH_MODE_MONO)!=0);
            rxRate.store((frequency&ESP_A2D_SBC_CIE_SF_16K)?16000:(frequency&ESP_A2D_SBC_CIE_SF_32K)?32000:(frequency&ESP_A2D_SBC_CIE_SF_44K)?44100:48000);epoch.fetch_add(1);
        }else if(active.load()==Mode::Out){
            const uint32_t targetHz=requestedRate.load();
            const uint32_t negotiatedHz=frequency==ESP_A2D_SBC_CIE_SF_16K?16000:
                frequency==ESP_A2D_SBC_CIE_SF_32K?32000:
                frequency==ESP_A2D_SBC_CIE_SF_44K?44100:
                frequency==ESP_A2D_SBC_CIE_SF_48K?48000:0;
            const bool accepted=codec.type==ESP_A2D_MCT_SBC&&negotiatedHz!=0;
            txRate.store(accepted?negotiatedHz:0);txCodecConfigured.store(accepted);
            Serial.printf("[BT-CODEC] target_hz=%lu negotiated_hz=%lu negotiated_mask=0x%02x result=%s\n",(unsigned long)targetHz,(unsigned long)negotiatedHz,unsigned(frequency),accepted?(targetHz==negotiatedHz?"PASS":"COMMON_RATE"):"UNSUPPORTED_BT_WAIT");
            if(!accepted){codecUnsupported.store(true);failed.store(true);autoDacFallback.store(true);}
            epoch.fetch_add(1);
        }
    }
    if(e==ESP_A2D_MEDIA_CTRL_ACK_EVT&&mode()==Mode::Out&&stage.load()==Stage::Active&&p->media_ctrl_stat.cmd==ESP_A2D_MEDIA_CTRL_CHECK_SRC_RDY&&p->media_ctrl_stat.status==ESP_A2D_MEDIA_CTRL_ACK_SUCCESS)
        esp_a2d_media_ctrl(ESP_A2D_MEDIA_CTRL_START);
}
static bool allocateRx(){
    auto& target=rxRing;
    if(target.load())return true;
    const uint32_t capacity=131072;
    const uint32_t caps=MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT;
    if(heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)<internalReserve)return false;
    auto bytes=(uint8_t*)heap_caps_malloc(capacity,caps);if(!bytes)return false;
    auto q=new(std::nothrow) PcmRing(bytes,capacity);if(!q){free(bytes);return false;}
    // Do not silently fall back: PCM payload must stay in PSRAM; preserve internal SDK reserve.
    if(heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)<internalReserve){delete q;free(bytes);return false;}
    target.store(q);return true;
}
static bool allocateTx(){
    if(txPcm)return true;
    if(heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)<internalReserve)return false;
    txPcm=(int16_t*)heap_caps_malloc(txFrames*4,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!txPcm)return false;
    // Same internal-RAM reserve as the V092 lifecycle; payload stays in PSRAM.
    if(heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)<internalReserve){free(txPcm);txPcm=nullptr;return false;}
    return true;
}
static bool startStack(){
    if(esp_bt_controller_get_status()==ESP_BT_CONTROLLER_STATUS_IDLE){esp_bt_controller_config_t cfg=BT_CONTROLLER_INIT_CONFIG_DEFAULT();if(esp_bt_controller_init(&cfg)!=ESP_OK)return false;}
    if(esp_bt_controller_get_status()==ESP_BT_CONTROLLER_STATUS_INITED&&esp_bt_controller_enable(ESP_BT_MODE_CLASSIC_BT)!=ESP_OK)return false;
    if(esp_bluedroid_get_status()==ESP_BLUEDROID_STATUS_UNINITIALIZED&&esp_bluedroid_init()!=ESP_OK)return false;
    if(esp_bluedroid_get_status()==ESP_BLUEDROID_STATUS_INITIALIZED&&esp_bluedroid_enable()!=ESP_OK)return false;
    // Allocate after the controller/host so their startup cost precedes the guard.
    // This is an allocation-time reserve, not a guarantee against future SDK use.
    if(!allocateTx()||!allocateRx())return false;
    allocatePcmWorker(); // Logged inline fallback on allocation failure; never half-active.
    if(esp_bt_gap_set_device_name("I-BT-Radio-Audio")!=ESP_OK||esp_bt_gap_register_callback(gap)!=ESP_OK)return false;
    esp_bt_io_cap_t cap=ESP_BT_IO_CAP_NONE;
    if(esp_bt_gap_set_security_param(ESP_BT_SP_IOCAP_MODE,&cap,sizeof(cap))!=ESP_OK)return false;
    esp_bt_pin_code_t pin={'0','0','0','0'};
    if(esp_bt_gap_set_pin(ESP_BT_PIN_TYPE_FIXED,4,pin)!=ESP_OK)return false;
    return esp_a2d_register_callback(event)==ESP_OK&&esp_avrc_ct_register_callback(avrc)==ESP_OK;
}
static void fault(const char* why){failed.store(true);stage.store(Stage::Fault);if(outputSelected())autoDacFallback.store(true);Serial.printf("[BT-AUDIO] lifecycle_fault=%s restart_required=1\n",why);}
static void enter(Stage next){stageAt=millis();stage.store(next);}
static void initProfile(Mode target){
    enter(Stage::Init);
    auto callback=target==Mode::Out?esp_a2d_source_register_data_callback(data):esp_a2d_sink_register_data_callback(sinkData);
    if(callback!=ESP_OK){fault("callback_register");return;}
    if((target==Mode::Out?esp_a2d_source_init():esp_a2d_sink_init())!=ESP_OK)fault("profile_init");
}
static void deinitProfile(Mode current){
    deinitialized.store(false);enter(Stage::Deinit);
    if((current==Mode::Out?esp_a2d_source_deinit():esp_a2d_sink_deinit())!=ESP_OK)fault("profile_deinit");
}
void service(){
    serviceControl();
    auto s=stage.load();auto target=mode();auto current=active.load();uint32_t now=millis();
    if(s==Stage::Fault)return;
    if(s==Stage::Off){
        if(target==Mode::Off)return;
        if(!initialized){initialized=startStack();if(!initialized){fault("stack_init");return;}}
        appliedRequest=requestId.load();active.store(target);ready.store(false);deinitialized.store(false);failed.store(false);
        streaming.store(false);connection.store(ESP_A2D_CONNECTION_STATE_DISCONNECTED);mono.store(false);rxRate.store(44100);txRate.store(0);txCodecConfigured.store(false);sourceRate.store(0);
        attempt=false;connectSent=false;disconnectSent=false;advertised=false;cancelSent.store(false);found.store(false);codecUnsupported.store(false);epoch.fetch_add(1);
        connectionRejected.store(false);retryRequested.store(false);connectAttempts=0;retryAt=0;
        autoDacFallback.store(false);
        selectedAt.store(0);scanStoppedAt.store(0);connectedAt.store(0);streamAt.store(0);
        scanTimingLogged=false;connectTimingLogged=false;streamTimingLogged=false;
        controlConnected.store(false);controlResult.store(0);
        portENTER_CRITICAL(&devicesMux);devicesUsed=0;portEXIT_CRITICAL(&devicesMux);
        if(target==Mode::In){
            controlReady.store(false);controlGone.store(false);enter(Stage::AvrcInit);
            if(esp_avrc_ct_init()!=ESP_OK)fault("avrc_init");
        }else initProfile(target);
        return;
    }
    if(s==Stage::AvrcInit){
        if(controlReady.load())initProfile(current);else if(uint32_t(now-stageAt)>10000)fault("avrc_init_timeout");return;
    }
    if(s==Stage::AvrcDeinit){
        if(controlGone.load())deinitProfile(current);else if(uint32_t(now-stageAt)>10000)fault("avrc_deinit_timeout");return;
    }
    if(s==Stage::Init){
        if(ready.load()){linkAt=now;lastCheck=0;enter(Stage::Active);}
        else if(uint32_t(now-stageAt)>10000)fault("init_timeout");
        return;
    }
    if(s==Stage::Active&&(target!=current||requestId.load()!=appliedRequest)){
        if(esp_bt_gap_set_scan_mode(ESP_BT_NON_CONNECTABLE,ESP_BT_NON_DISCOVERABLE)!=ESP_OK){fault("scan_disable");return;}
        if(discovering.load())esp_bt_gap_cancel_discovery();
        enter(Stage::Disconnect);s=Stage::Disconnect;
        // enter() reads millis() again; use that fresh time for the timeout.
        // The stale value can underflow now-stageAt and fault immediately.
        now=stageAt;
    }
    if(s==Stage::Disconnect){
        if(connection.load()!=ESP_A2D_CONNECTION_STATE_DISCONNECTED&&!disconnectSent){
            esp_bd_addr_t address;portENTER_CRITICAL(&peerMux);memcpy(address,peer,6);portEXIT_CRITICAL(&peerMux);
            disconnectSent=true;
            auto result=current==Mode::Out?esp_a2d_source_disconnect(address):esp_a2d_sink_disconnect(address);
            if(result!=ESP_OK){fault("disconnect");return;}
        }
        if(connection.load()==ESP_A2D_CONNECTION_STATE_DISCONNECTED&&!discovering.load()){
            if(current==Mode::In){controlGone.store(false);enter(Stage::AvrcDeinit);if(esp_avrc_ct_deinit()!=ESP_OK)fault("avrc_deinit");}
            else deinitProfile(current);
        }else if(uint32_t(now-stageAt)>10000)fault("disconnect_timeout");
        return;
    }
    if(s==Stage::Deinit){
        if(deinitialized.load()){active.store(Mode::Off);streaming.store(false);epoch.fetch_add(1);enter(Stage::Off);}
        else if(uint32_t(now-stageAt)>10000)fault("deinit_timeout");
        return;
    }
    if(s!=Stage::Active)return;
    // The CONNECTED callback is the admission event. A quick peer disconnect
    // before the next service tick must not erase this successful connection.
    if(current==Mode::Out&&savePeerPending.exchange(false)){
        uint8_t address[6];SavedHistory next{};
        portENTER_CRITICAL(&peerMux);memcpy(address,peer,6);next=savedHistory;portEXIT_CRITICAL(&peerMux);
        const SavedHistory before=next;
        if(validAddress(address)){
            Device entry{};memcpy(entry.address,address,6);
            portENTER_CRITICAL(&devicesMux);
            for(unsigned i=0;i<devicesUsed;++i)if(!memcmp(devices[i].address,address,6)){
                memcpy(entry.name,devices[i].name,sizeof(entry.name));break;
            }
            portEXIT_CRITICAL(&devicesMux);
            unsigned old=0;while(old<next.count&&memcmp(next.entries[old].address,address,6))++old;
            if(placeholderName(entry.name)&&old<next.count)memcpy(entry.name,next.entries[old].name,sizeof(entry.name));
            fallbackName(entry);
            unsigned count=std::min<unsigned>(next.count+unsigned(old==next.count),savedHistoryCapacity);
            for(unsigned i=count-1;i>0;--i){unsigned from=i<=old?i-1:i;next.entries[i]=next.entries[from];}
            next.entries[0]=entry;next.count=count;next.magic=savedHistoryMagic;
            bool ok=true;
            if(memcmp(&before,&next,sizeof(next))){
                Preferences p;ok=p.begin("ibt-bt-out",false);
                if(ok){ok=p.putBytes("history",&next,sizeof(next))==sizeof(next);p.end();}
            }
            if(ok){portENTER_CRITICAL(&peerMux);savedHistory=next;memcpy(savedPeer,address,6);portEXIT_CRITICAL(&peerMux);savedValid.store(true);}
            Serial.printf("[BT-LINK] saved_peer=%s history_count=%u\n",ok?"PASS":"FAIL",unsigned(next.count));
        }
    }
    if(failed.load()&&!reconnectRequested.load()&&!restartScanRequested.load()){
        if(current!=Mode::Out||!retryRequested.exchange(false))return;
        failed.store(false);connectionRejected.store(false);connectAttempts=0;connectSent=false;retryAt=now;
        connectedAt.store(0);streamAt.store(0);connectTimingLogged=false;streamTimingLogged=false;
        Serial.printf("[BT-LINK] manual_retry=1\n");
    }
    if(current==Mode::In){
        if(!advertised){
            if(esp_bt_gap_set_scan_mode(ESP_BT_CONNECTABLE,ESP_BT_GENERAL_DISCOVERABLE)!=ESP_OK){fault("scan_enable");return;}
            advertised=true;
        }
        return; // Waiting for the phone is not a failure; no scan/reconnect loop.
    }
    if(reconnectRequested.exchange(false)){
        if(savedValid.load()&&connection.load()==ESP_A2D_CONNECTION_STATE_DISCONNECTED){
            portENTER_CRITICAL(&peerMux);memcpy(selectedPeer,requestedSavedPeer,6);memcpy(peer,requestedSavedPeer,6);portEXIT_CRITICAL(&peerMux);
            selectedAt.store(now);scanStoppedAt.store(now);found.store(true);
            attempt=true;discovering.store(false);cancelSent.store(false);
            connectSent=false;connectionRejected.store(false);failed.store(false);connectAttempts=0;retryAt=now;
            scanTimingLogged=false;connectTimingLogged=false;streamTimingLogged=false;
            Serial.println("[BT-LINK] reconnect_saved=REQUESTED scan_skipped=1");
        }
    }
    if(restartScanRequested.exchange(false)){
        if(!discovering.load()&&deviceCount()==0&&connection.load()==ESP_A2D_CONNECTION_STATE_DISCONNECTED){
            attempt=false;found.store(false);cancelSent.store(false);connectSent=false;
            connectionRejected.store(false);failed.store(false);connectAttempts=0;retryAt=0;
            Serial.println("[BT-LINK] empty_scan_restart=REQUESTED");
        }
    }
    if(found.load()&&!streaming.load()&&selectedAt.load()&&uint32_t(now-selectedAt.load())>=90000){
        failed.store(true);autoDacFallback.store(true);
        Serial.printf("[BT-LINK] auto_dac=CONNECT_TIMEOUT attempts=%u elapsed_ms=%lu\n",unsigned(connectAttempts),(unsigned long)(now-selectedAt.load()));
        return;
    }
    if(streaming.load())linkAt=now;
    if(!attempt){
        attempt=true;discovering.store(true);
        if(esp_bt_gap_start_discovery(ESP_BT_INQ_MODE_GENERAL_INQUIRY,10,0)!=ESP_OK){discovering.store(false);failed.store(true);}
    }
    if(found.load()&&discovering.load()&&!cancelSent.load()&&esp_bt_gap_cancel_discovery()==ESP_OK)cancelSent.store(true);
    if(found.load()&&!discovering.load()&&!scanTimingLogged){
        scanTimingLogged=true;
        Serial.printf("[BT-LINK] selected_to_scan_stop_ms=%lu\n",(unsigned long)(scanStoppedAt.load()-selectedAt.load()));
    }
    if(connectionRejected.exchange(false)&&connectSent){
        if(connectAttempts>=9){
            failed.store(true);
            autoDacFallback.store(true);
            Serial.printf("[BT-LINK] failed_after_attempts=%u\n",unsigned(connectAttempts));
            return;
        }
        connectSent=false;
        retryAt=now+uint32_t(connectAttempts)*1500;
        Serial.printf("[BT-LINK] peer_rejected_attempt=%u retry_in_ms=%lu\n",unsigned(connectAttempts),(unsigned long)(retryAt-now));
    }
    if(found.load()&&!discovering.load()&&!connectSent&&int32_t(now-retryAt)>=0){
        esp_bd_addr_t address;portENTER_CRITICAL(&peerMux);memcpy(address,selectedPeer,6);portEXIT_CRITICAL(&peerMux);
        connectSent=true;++connectAttempts;linkAt=now;connection.store(ESP_A2D_CONNECTION_STATE_CONNECTING);
        Serial.printf("[BT-LINK] connect_attempt=%u connect_request_ms=%lu\n",unsigned(connectAttempts),(unsigned long)(now-selectedAt.load()));
        if(esp_a2d_source_connect(address)!=ESP_OK){connection.store(ESP_A2D_CONNECTION_STATE_DISCONNECTED);connectionRejected.store(true);}
    }
    if(connectedAt.load()&&!connectTimingLogged){
        connectTimingLogged=true;
        Serial.printf("[BT-LINK] selected_to_connected_ms=%lu\n",(unsigned long)(connectedAt.load()-selectedAt.load()));
    }
    if(streamAt.load()&&!streamTimingLogged){
        streamTimingLogged=true;
        Serial.printf("[BT-LINK] selected_to_audio_ms=%lu\n",(unsigned long)(streamAt.load()-selectedAt.load()));
    }
    if(connection.load()==ESP_A2D_CONNECTION_STATE_CONNECTED&&!streaming.load()&&uint32_t(now-lastCheck)>=1000){lastCheck=now;esp_a2d_media_ctrl(ESP_A2D_MEDIA_CTRL_CHECK_SRC_RDY);}
}
const char* status(){
    if(stage.load()==Stage::Fault)return "BT switch failed: restart";
    if(stage.load()==Stage::Disconnect||stage.load()==Stage::Deinit||stage.load()==Stage::AvrcDeinit)return "BT switching...";
    if(!wanted())return "BT OFF / DAC";
    if(failed.load())return codecUnsupported.load()?"BT HIBA: nincs kozos hangformatum":"BT HIBA: csatlakozas (9 proba)";
    if(stage.load()!=Stage::Active||mode()!=active.load())return "BT starting...";
    if(inputSelected())return streaming.load()?"BT IN: phone -> DAC":"Pair: I-BT-Radio-Audio";
    return streaming.load()?"BT OUT lejatszas":connection.load()==ESP_A2D_CONNECTION_STATE_CONNECTED?"BT OUT csatlakozva":found.load()?"Csatlakozas...":discovering.load()?"Kereses...":"Valassz eszkozt";
}
void diagnostics(){
    Serial.printf("[BT-PCM] worker=%u core=0 task_id=%u queue_blocks=%u queue_capacity=32 queue_peak=%lu queued_frames=%lu processed_frames=%lu cancelled_frames=%lu lost_frames=%lu waits=%lu work_wall_max_us=%lu stack_min=%u\n",
        unsigned(pcmWorkerReady.load()),pcmWorkerId.load(),pcmJobs?pcmJobs->size():0,
        (unsigned long)pcmQueuePeak.load(),(unsigned long)pcmQueuedFrames.load(),(unsigned long)pcmProcessedFrames.load(),
        (unsigned long)pcmCancelledFrames.load(),(unsigned long)pcmQueueLostFrames.load(),(unsigned long)pcmQueueWaits.load(),
        (unsigned long)pcmWorkWallMaxUs.load(),pcmWorkerHandle?unsigned(uxTaskGetStackHighWaterMark(pcmWorkerHandle)):0);
    Serial.printf("[BT-CORE] btc_target_core=%u pcm_callback_core=%d pcm_task_id=%u decoder_core=1 controller_core=1 btu_target_core=%u\n",
        ibt_btc_task_target_core(),txCallbackCore.load(),txCallbackTask.load(),ibt_btu_task_target_core());
    portENTER_CRITICAL(&txMux);const unsigned buffered=txUsed*4;portEXIT_CRITICAL(&txMux);
    Serial.printf("[BT-AUDIO] direction=%s active=%u stage=%u state=%s delivered_bytes=%lu requested_bytes=%lu received_bytes=%lu dropped_bytes=%lu underruns=%lu prefill_callbacks=%lu rebuffer_events=%lu tx_buffer=%lu rx_buffer=%lu rate=%lu source_rate=%lu codec_ok=%u block_frames=%lu tx_internal=0 tx_capacity=%u tx_prefill=%u tx_prefill_ms=500 target_rate=%lu eq_enabled=0\n",inputSelected()?"IN":outputSelected()?"OUT":"OFF",unsigned(active.load()),unsigned(stage.load()),status(),(unsigned long)delivered.load(),(unsigned long)requestedBytes.load(),(unsigned long)received.load(),(unsigned long)dropped.load(),(unsigned long)underruns.load(),(unsigned long)prefillCallbacks.load(),(unsigned long)rebufferEvents.load(),(unsigned long)buffered,(unsigned long)(rxRing?rxRing.load()->size():0),(unsigned long)(inputSelected()?rxRate.load():txRate.load()),(unsigned long)sourceRate.load(),unsigned(txCodecConfigured.load()),(unsigned long)blockFrames.load(),txFrames*4,(txRate.load()/2)*4,(unsigned long)requestedRate.load());
}
}

extern "C" unsigned ibt_bt_output_rate_hz(void){return btaudio::outputRate();}
