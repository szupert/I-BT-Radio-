#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
namespace dual {
enum class Language : uint8_t { HU, English, DE };
enum class Theme : uint8_t { Dark, Light, Auto };
enum class Action : uint8_t { None, Prev, Next, Toggle, VolDown, VolUp, Source, Menu, Select, RotCW, RotCCW, EncoderDown, EncoderShort, EncoderLong, EqBass, EqMiddle, EqTreble, Balance, SourceWeb, SourceSd, WinampPlay, WinampPause };
enum class Text : uint8_t { Settings, Radio, SD, Language, Theme, Rotation, Rate, Brightness,
    Bluetooth, Disabled, Diagnostics, Back, Source, Playing, Stopped, NoCover, SavePending,
    Artist, Album, Title, Connecting, Count };
struct Settings {
    Language language = Language::HU;
    Theme theme = Theme::Dark;
    uint8_t rotation = 0;
    uint8_t brightness = 70;
    uint16_t menuIdleSeconds = 10; // 0 disables automatic home navigation
    uint16_t maxKbps = 0; // unlimited by default; optional admission limit, never a transcoder
    uint8_t rotaryMode = 1; // 1=volume, 2=station preview/confirm
    uint8_t volumeStep = 1; // 1..10 percentage points per rotary detent
    bool debug = false; // serial diagnostics/reporting; OFF by default
    bool artworkEnabled = true;
    bool cassetteEnabled = true;
    bool bufferIndicator = true;
    bool reelAnimation = false;
    bool wifiIndicator = true;
    bool btQuickScan = true;
    bool winampEnabled = true; // classic two-page player/list; cassette remains available
};
inline bool validMenuIdle(uint16_t s){return s==0||s==10||s==20||s==30||s==60||s==120||s==300;}
inline bool validRate(uint16_t k) { return k==0 || k==64 || k==96 || k==128 || k==192 || k==320; }
inline void sanitize(Settings &s) {
    if (uint8_t(s.language)>2) s.language=Language::HU;
    if (uint8_t(s.theme)>2) s.theme=Theme::Dark;
    if(!validMenuIdle(s.menuIdleSeconds))s.menuIdleSeconds=10;
    s.rotation &= 3;
    if (s.brightness<10 || s.brightness>100) s.brightness=70;
    if (!validRate(s.maxKbps)) s.maxKbps=0;
    if (s.rotaryMode<1 || s.rotaryMode>2) s.rotaryMode=1;
    if (s.volumeStep<1 || s.volumeStep>10) s.volumeStep=1;
}
struct Point { int x, y; };
struct Size { int w, h; };
inline Size logicalSize(Size p, unsigned r) { return (r&1)?Size{p.h,p.w}:p; }
inline Point toPhysical(Point p, Size native, unsigned r) {
    switch(r&3) {
    case 1:return {native.w-1-p.y,p.x};
    case 2:return {native.w-1-p.x,native.h-1-p.y};
    case 3:return {p.y,native.h-1-p.x};
    default:return p;
    }
}
inline Point toLogical(Point p, Size native, unsigned r) {
    switch(r&3) {
    case 1:return {p.y,native.w-1-p.x};
    case 2:return {native.w-1-p.x,native.h-1-p.y};
    case 3:return {native.h-1-p.y,p.x};
    default:return p;
    }
}
inline bool isDark(const Settings &s, int hour, bool validTime) {
    return s.theme==Theme::Dark || (s.theme==Theme::Auto && (!validTime || hour<7 || hour>=19));
}
inline Action adcKey(int mv) {
    const int centres[]={0,595,1055,1650};
    const Action actions[]={Action::Prev,Action::Next,Action::VolDown,Action::VolUp};
    for(unsigned i=0;i<4;i++) if(mv>=centres[i]-180 && mv<=centres[i]+180) return actions[i];
    return Action::None;
}
inline bool repeatable(Action a) { return a==Action::VolDown || a==Action::VolUp; }
class Debounce {
    int raw_=0, stable_=0;
    uint32_t changed_=0;
public:
    int value() const { return stable_; }
    bool update(int raw, uint32_t now, unsigned ms=35) {
        if(raw!=raw_) { raw_=raw; changed_=now; }
        if(raw_!=stable_ && uint32_t(now-changed_)>=ms) { stable_=raw_; return true; }
        return false;
    }
};
class Quadrature {
    uint8_t previous_=3; int8_t sum_=0;
public:
    int update(uint8_t next) {
        static const int8_t t[]={0,-1,1,0,1,0,0,-1,-1,0,0,1,0,1,-1,0};
        next &= 3;
        if((previous_^next)==3) sum_=0;
        else sum_+=t[(previous_<<2)|next];
        previous_=next;
        if(sum_>=4) {sum_=0;return 1;} if(sum_<=-4) {sum_=0;return -1;} return 0;
    }
};
// Strict enough for bounded metadata display; malformed sequences consume at least one byte.
inline uint32_t nextUtf8(const char *&s) {
    unsigned c=uint8_t(*s++); if(c<128) return c;
    unsigned count=(c&0xe0)==0xc0?1:(c&0xf0)==0xe0?2:(c&0xf8)==0xf0?3:0;
    if(!count) return '?';
    uint32_t n=c & ((1u<<(6-count))-1);
    for(unsigned i=0;i<count;i++) {unsigned b=uint8_t(*s);if((b&0xc0)!=0x80)return '?';s++;n=(n<<6)|(b&63);}
    if(n>0x10ffff || (n>=0xd800&&n<=0xdfff) || (count==1&&n<128) || (count==2&&n<2048) || (count==3&&n<65536))return '?';
    return n;
}
inline void textCopy(char *to,size_t capacity,const char *from) {
    if(!capacity)return;
    size_t n=0; const char *s=from?from:"";
    while(*s) {const char *start=s;nextUtf8(s);size_t k=size_t(s-start);if(n+k>=capacity)break;memcpy(to+n,start,k);n+=k;}
    to[n]=0;
}
const char *tr(Language language, Text key);
}
