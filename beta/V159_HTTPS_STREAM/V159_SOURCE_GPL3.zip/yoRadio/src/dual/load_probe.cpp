#include "load_probe.h"
#include "bt_audio.h"
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <algorithm>
#include "../audioI2S/net_prefetch.h"
namespace loadprobe {
static constexpr unsigned capacity=80;
struct Previous { UBaseType_t id; configRUN_TIME_COUNTER_TYPE runtime; };
struct Store { TaskStatus_t tasks[capacity]; Previous previous[capacity]; uint32_t delta[capacity]; };
static Store* store=nullptr;
static unsigned previousCount=0;
static int64_t previousTime=0;
void sample(){
    const auto start=esp_timer_get_time();
    if(previousTime&&start-previousTime<9000000){Serial.println("[LOAD] result=TOO_SOON");return;}
    if(!store)store=static_cast<Store*>(heap_caps_calloc(1,sizeof(Store),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
    if(!store){Serial.println("[LOAD] result=NO_PSRAM");return;}
    configRUN_TIME_COUNTER_TYPE total=0;
    const unsigned count=uxTaskGetSystemState(store->tasks,capacity,&total);
    const auto stamp=esp_timer_get_time();
    if(!count){previousTime=0;previousCount=0;Serial.println("[LOAD] result=TASK_CAPACITY");return;}
    const uint64_t window=previousTime?uint64_t(stamp-previousTime):0;
    int busy[2]={-1,-1};
    for(unsigned i=0;i<count;i++){
        const auto& task=store->tasks[i];store->delta[i]=0;
        bool known=false;
        for(unsigned j=0;j<previousCount;j++)if(store->previous[j].id==task.xTaskNumber){
            store->delta[i]=uint32_t(task.ulRunTimeCounter-store->previous[j].runtime);known=true;break;
        }
        for(unsigned core=0;core<2;core++)if(known&&window&&task.xHandle==xTaskGetIdleTaskHandleForCPU(core))
            busy[core]=1000-int(std::min(uint64_t(1000),uint64_t(store->delta[i])*1000/window));
    }
    Serial.printf("[LOAD] result=%s window_us=%llu core0_permille=%d core1_permille=%d tasks=%u snapshot_us=%llu probe_psram=%u\n",
        window?"OK":"BASELINE",(unsigned long long)window,busy[0],busy[1],count,(unsigned long long)(stamp-start),unsigned(sizeof(Store)));
    if(window)for(unsigned i=0;i<count;++i){const auto& t=store->tasks[i];
        if(t.xTaskNumber==btaudio::pcmTaskId())Serial.printf("[LOAD-PCM] id=%u core=%d cpu_permille=%u\n",unsigned(t.xTaskNumber),int(t.xCoreID),unsigned(uint64_t(store->delta[i])*1000/window));
    }
    // Task IDs avoid dereferencing task-name pointers after tasks have been deleted.
    if(window)for(unsigned rank=0;rank<6&&rank<count;rank++){
        unsigned best=0;for(unsigned i=1;i<count;i++)if(store->delta[i]>store->delta[best])best=i;
        const auto& t=store->tasks[best];
        Serial.printf("[LOAD-TASK] id=%u core=%d priority=%u cpu_permille=%u stack_min_bytes=%u\n",
            unsigned(t.xTaskNumber),int(t.xCoreID),unsigned(t.uxCurrentPriority),unsigned(uint64_t(store->delta[best])*1000/window),unsigned(t.usStackHighWaterMark));
        store->delta[best]=0;
    }
    for(unsigned i=0;i<count;i++)store->previous[i]={store->tasks[i].xTaskNumber,store->tasks[i].ulRunTimeCounter};
    previousCount=count;previousTime=stamp;
    Serial.printf("[LOAD-MEM] internal_free=%u internal_largest=%u internal_min=%u psram_free=%u psram_largest=%u psram_min=%u probe_us=%llu\n",
        unsigned(heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)),unsigned(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)),unsigned(heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)),
        unsigned(heap_caps_get_free_size(MALLOC_CAP_SPIRAM)),unsigned(heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM)),unsigned(heap_caps_get_minimum_free_size(MALLOC_CAP_SPIRAM)),(unsigned long long)(esp_timer_get_time()-start));
    netprefetch::diagnostics();
}
}
