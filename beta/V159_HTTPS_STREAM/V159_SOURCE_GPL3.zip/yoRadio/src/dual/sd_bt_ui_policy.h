#pragma once
namespace ibtsdui {
inline bool classic(bool transmitting,bool local,bool winamp){return transmitting&&local&&winamp;}
inline bool due(bool active,unsigned elapsed){return !active||elapsed>=1000;}
}
