#pragma once
namespace r10diag {
void begin();
void serialPoll();
void tick();
bool active();
}
