#pragma once
#include "resource_policy.h"
namespace ibtlimit {
void publishAudio(bool active, uint32_t buffered, uint32_t now);
void tick();
bool acquire(Job job, size_t cost);
void release(Job job);
bool acquireHttp();
void releaseHttp();
bool acquireWs();
void releaseWs();
bool allowAllocation(size_t cost);
bool allowRedraw();
bool allowArtworkProgress();
void telemetry();
}
