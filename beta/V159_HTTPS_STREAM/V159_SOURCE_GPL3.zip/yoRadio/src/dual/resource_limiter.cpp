#include "resource_limiter.h"
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <freertos/FreeRTOS.h>
namespace ibtlimit {
static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
static Policy policy;
static bool active = false, seenAudio = false;
static uint32_t buffer = 0, audioAt = 0;
static Sample sample() {
    Sample s{};
    s.freeInternal = heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
    s.largestInternal = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
    portENTER_CRITICAL(&mux);
    s.audioActive = active; s.buffer = buffer;
    const bool hadAudio=seenAudio;
    const uint32_t seenAt=audioAt;
    portEXIT_CRITICAL(&mux);
    // Capture time after the producer timestamp: a concurrent audio update
    // between heap reads must not look like an unsigned 49-day-old heartbeat.
    s.now=millis();
    s.audioFresh=!hadAudio || uint32_t(s.now-seenAt)<1500;
    return s;
}
void publishAudio(bool running,uint32_t buffered,uint32_t now) {
    // The audio path never acquires a permit or waits on a background queue.
    portENTER_CRITICAL(&mux);
    active = running; buffer = buffered; audioAt = now; seenAudio = true;
    portEXIT_CRITICAL(&mux);
}
void tick() { auto s=sample(); portENTER_CRITICAL(&mux); policy.observe(s); portEXIT_CRITICAL(&mux); }
bool acquire(Job j,size_t cost) { auto s=sample(); portENTER_CRITICAL(&mux); bool ok=policy.acquire(j,s,cost); portEXIT_CRITICAL(&mux); return ok; }
void release(Job j) { portENTER_CRITICAL(&mux); policy.release(j); portEXIT_CRITICAL(&mux); }
bool acquireHttp() { auto s=sample(); portENTER_CRITICAL(&mux); bool ok=policy.acquireHttp(s); portEXIT_CRITICAL(&mux); return ok; }
void releaseHttp() { portENTER_CRITICAL(&mux); policy.releaseHttp(); portEXIT_CRITICAL(&mux); }
bool acquireWs() { auto s=sample(); portENTER_CRITICAL(&mux); bool ok=policy.acquireWs(s); portEXIT_CRITICAL(&mux); return ok; }
void releaseWs() { portENTER_CRITICAL(&mux); policy.releaseWs(); portEXIT_CRITICAL(&mux); }
bool allowAllocation(size_t cost) { auto s=sample(); portENTER_CRITICAL(&mux); policy.observe(s); bool ok=!policy.pressured&&policy.budget(s,cost); portEXIT_CRITICAL(&mux); return ok; }
bool allowArtworkProgress() {
    const auto s=sample();
    return s.audioFresh && s.freeInternal>=Policy::reserve && (!s.audioActive || s.buffer>=16384);
}
bool allowRedraw() { return allowAllocation(1024); }
void telemetry() {
    auto s=sample(); Policy p;
    portENTER_CRITICAL(&mux); p=policy; portEXIT_CRITICAL(&mux);
    Serial.printf("[R10-LIMITER] version=1 enabled=1 pressure=%u heavy=%u http=%u ws=%u denied=%lu admitted=%lu reserve=%lu audio_fresh=%u free_internal=%lu largest_internal=%lu audio_active=%u audio_buffer=%lu recovery_free=%lu bad_free=%lu\n",p.pressured?1:0,unsigned(p.heavy),p.http,p.ws,(unsigned long)p.denied,(unsigned long)p.admitted,(unsigned long)Policy::reserve,s.audioFresh?1:0,(unsigned long)s.freeInternal,(unsigned long)s.largestInternal,s.audioActive?1:0,(unsigned long)s.buffer,(unsigned long)Policy::recoveryInternal,(unsigned long)Policy::badInternal);
}
}
