#include "audio_path_probe.h"
#include <Arduino.h>
namespace pathprobe {
std::atomic<bool> enabled{false};Counters counters[Count];
std::atomic<uint32_t> lowInput{0},decodedFrames{0};
void diagnostics(){
    const char* names[]={"net_poll","net_read","decode","output_handoff","pcm_worker"};
    Serial.printf("[PATH-TOTAL] enabled=%u low_input=%lu decoded_frames=%lu\n",unsigned(enabled.load()),(unsigned long)lowInput.load(),(unsigned long)decodedFrames.load());
    for(unsigned i=0;i<Count;++i){const auto& c=counters[i];
        Serial.printf("[PATH-STAGE] name=%s calls=%lu wall_us=%lu max_wall_us=%lu units=%lu empty=%lu errors=%lu\n",names[i],(unsigned long)c.calls.load(),(unsigned long)c.us.load(),(unsigned long)c.maxUs.load(),(unsigned long)c.units.load(),(unsigned long)c.empty.load(),(unsigned long)c.errors.load());
    }
}
}
