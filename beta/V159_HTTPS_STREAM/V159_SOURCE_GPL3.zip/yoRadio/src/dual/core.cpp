#include "../core/options.h"
#include "core.h"
#include "sd_bt_ui_policy.h"
#include "bt_audio.h"
#include "resource_limiter.h"
#include "ui_governor.h"
#include "artwork.h"
#include "online_artwork.h"
#include "v027_himem.h"
#include "../boards/hal.h"
#include "../ui/frontend.h"
#include "../ui/content.h"
#if defined(BOARD_CYD28)
#include "../ui/cassette_layout.h"
#endif
#include "../core/config.h"
#include "../core/player.h"
#include "../core/network.h"
#include "../core/display.h"
#include "backup_sd.h"
#include <Preferences.h>
#include "vu_probe.h"
#include <EEPROM.h>
#include <SPIFFS.h>
#include <esp_heap_caps.h>
#include <esp_sntp.h>
#include <esp_wifi.h>
#include <time.h>
#include <ctype.h>
namespace dual {
static portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
static Snapshot state;
static QueueHandle_t commands=nullptr;
static UiGovernor uiGovernor;
static uint32_t settingsVersion=0,savedVersion=0,lastSnapshot=0,lastDiag=0;
static bool initialized=false, frontendOK=false, bitrateRejected=false, low=false;
static bool audioSettingPending=false;
static uint32_t nextAudioCommit=0;
static uint32_t nextSettingsCommit=0;
static uint8_t favoriteBits[60]={}; // 480 playlist rows
static uint32_t favoriteVersion=0,favoriteSaved=0,nextFavoriteCommit=0;
static uint32_t favoritePlaylistHash=0;
static char searchQuery[24]={};
static uint16_t searchResults[480]={};
static uint16_t searchFound=0;
static uint8_t searchState=0; // 0=ready, 1=stop playback, 2=playlist error, 3=no match, 4=radio mode required
static SemaphoreHandle_t searchCacheLock=nullptr;
static char* searchNames=nullptr; // 480 x BUFLEN in PSRAM, one allocation for device lifetime
static uint16_t searchRows=0;
static uint8_t stressState=0; // 0=ready, 1=pass, 2=fail/not-run, 3=limiter denied, 4=stop playback
static unsigned page=0, selected=0;
static uint32_t menuActivityAt=0;
static WifiPasswordUi wifiEntry;
const WifiPasswordUi& wifiPasswordUi(){return wifiEntry;}
char wifiPasswordKeyChar(unsigned mode,unsigned key){
    static const char* const keys[]={
        "abcdefghijklmnopqrstuvwxyz0123456789",
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
        " !@#$%^&*()-_=+[]{};:'\",.<>/?\\|`~"
    };
    if(mode>=3||key>=36||key>=strlen(keys[mode]))return 0;
    return keys[mode][key];
}
static unsigned memoryParent=13, networkParent=9;
static unsigned stationListParent=0;
static playMode_e pendingSourceTarget=PM_WEB;
static uint32_t pendingSourceAt=0;
static bool pendingSourceCancelSent=false;
static volatile bool redraw=true;
static bool shortPending=false, secondDown=false, stationPreview=false;
static void input(Action a);
enum class BtRatePhase : uint8_t { Idle, Stopping, Connecting };
static BtRatePhase btRatePhase=BtRatePhase::Idle;
static uint32_t btRateSince=0,btRateTarget=0;
static uint16_t btRateStation=0;
static bool btRateSawWanted=false;
static void btRateNotice(const char* message){
    portENTER_CRITICAL(&mux);
    strlcpy(state.notice,message,sizeof(state.notice));
    portEXIT_CRITICAL(&mux);
    redraw=true;
}
static void btRateFail(const char* message){
    Serial.printf("[BT-RATE-AB] FAIL reason=%s target=%lu\n",message,(unsigned long)btRateTarget);
    btRatePhase=BtRatePhase::Idle;
    btRateNotice(message);
    player.sendCommand({PR_BT,-1});
}
static void btRateTouch(){
    if(btRatePhase!=BtRatePhase::Idle||!btaudio::transmitting())return;
    if(!btaudio::hasSavedDevice()){
        btRateNotice("BT: nincs mentett eszkoz");return;
    }
    const unsigned rates[]={16000,32000,44100};
    const unsigned current=btaudio::outputRate();
    unsigned next=0;
    while(next<3&&rates[next]!=current)++next;
    btRateTarget=rates[next==3?0:(next+1)%3];
    btRateStation=config.lastStation();
    if(!player.sendCommand({PR_STOP,0})){
        btRateNotice("BT: stop parancs sikertelen");return;
    }
    btRateSawWanted=false;btRateSince=millis();btRatePhase=BtRatePhase::Stopping;
    Serial.printf("[BT-RATE-AB] stop target=%lu\n",(unsigned long)btRateTarget);
}
static void btRateTick(uint32_t now){
    if(btRatePhase==BtRatePhase::Idle)return;
    if(btRatePhase==BtRatePhase::Stopping){
        if(!btaudio::wanted()&&btaudio::idle()&&player.status()==STOPPED){
            if(!btaudio::setOutputRate(btRateTarget)){
                btRateFail("BT: frekvencia mentes hiba");return;
            }
            if(!btaudio::reconnectSaved()||!player.sendCommand({PR_BT,0})){
                btRateFail("BT: ujracsatlakozas hiba");return;
            }
            btRateSawWanted=false;btRateSince=now;btRatePhase=BtRatePhase::Connecting;
            Serial.printf("[BT-RATE-AB] reconnect target=%lu\n",(unsigned long)btRateTarget);
        }else if(uint32_t(now-btRateSince)>15000){
            btRateFail("BT: leallitas idotullepes");
        }
        return;
    }
    if(btaudio::wanted())btRateSawWanted=true;
    if(btRateSawWanted&&!btaudio::wanted()){
        btRatePhase=BtRatePhase::Idle;
        btRateNotice("BT: kapcsolat hiba, DAC");return;
    }
    if(btaudio::transmitting()){
        if(player.sendCommand({PR_PLAY,btRateStation})){
            Serial.printf("[BT-RATE-AB] resume target=%lu\n",(unsigned long)btRateTarget);
            btRatePhase=BtRatePhase::Idle;
        }
    }else if(uint32_t(now-btRateSince)>95000||
             (btaudio::wanted()&&btaudio::linkFailed())){
        btRateFail("BT: kapcsolat hiba, DAC");
    }
}
static bool uiStressActive=false,uiStressInjecting=false;
static uint16_t uiStressActionMs=500,uiStressDrawMs=500;
static uint32_t uiStressActions=0,uiStressFrames=0,uiStressRenderCalls=0,uiStressRenderedActions=0;
static uint32_t uiStressStarted=0,uiStressLastAction=0,uiStressLastCheck=0;
static uint32_t uiStressBaseLow=0,uiStressBaseDrops=0;
static uint32_t uiStressBaseGaps=0;
static char uiStressReason[32]="idle";
static bool uiStressTour=false,uiStressTourRestored=false;
static Settings uiStressOriginalSettings;
static uint8_t uiStressTourStep=0;
static uint32_t uiStressTourVisits=0,uiStressTourEdits=0,uiStressTourCycles=0;
enum : unsigned {
    PAGE_HOME=0, PAGE_MAIN=1, PAGE_MEMORY=2, PAGE_BLUETOOTH=3, PAGE_STATIONS_LIST=4,
    PAGE_ROTARY_DEBUG=5, PAGE_SOUND=6, PAGE_SETTINGS=7, PAGE_STATIONS=8, PAGE_WIFI=9,
    PAGE_DISPLAY=10, PAGE_CONTROLS=11, PAGE_STORAGE=12, PAGE_DIAGNOSTICS=13,
    PAGE_VOLUME_STREAM=14, PAGE_EQ=15, PAGE_OUTPUTS=16, PAGE_WIFI_QR=17, PAGE_NETWORK_INFO=18,
    PAGE_SYSTEM=19, PAGE_FIRMWARE_INFO=20, PAGE_SAVED_WIFI=21, PAGE_BT_INFO=22, PAGE_DAC_INFO=23, PAGE_FS_INFO=24, PAGE_ART_CACHE=25, PAGE_WEB_UPDATE=26, PAGE_BUTTON_MAP=27, PAGE_WIFI_SCAN=28, PAGE_FAVORITES_LIST=29, PAGE_SD_INFO=30, PAGE_STATION_SEARCH=31, PAGE_SEARCH_RESULTS=32, PAGE_PLAYLIST_EDITOR=33, PAGE_MEMORY_STRESS=34, PAGE_BACKUP_MENU=37, PAGE_BACKUP_RESULT=38, PAGE_BT_PLAYER=39, PAGE_BT_SCAN=40, PAGE_SOURCE_PENDING=41, PAGE_WIFI_PASSWORD=42, PAGE_BT_RATE=43, PAGE_BT_SAVED=44, PAGE_IDLE=45, PAGE_VU_TIMER=46
};
void bluetoothMode(int mode){
    if(!player.sendCommand({PR_BT,mode})){redraw=true;return;}
    page=mode==1?PAGE_BT_PLAYER:mode==0?PAGE_BT_SCAN:PAGE_HOME;
    selected=0;redraw=true;
}
static void reconnectDevice(unsigned index){
    btaudio::Device device{};
    if(!btaudio::savedDevice(index,device)||!player.sendCommand({PR_BT,0})||
       !btaudio::connectSavedDevice(index)){redraw=true;return;}
    page=PAGE_BT_SAVED;selected=index;redraw=true;
}
unsigned memoryStressStatus(){return stressState;}
static void runMemoryStress(){
    if(player.isRunning()||player.status()!=STOPPED){stressState=4;redraw=true;return;}
    if(!ibtlimit::acquire(ibtlimit::Job::Diagnostic,4096)){stressState=3;redraw=true;return;}
    v027::testHighMemory();
    ibtlimit::release(ibtlimit::Job::Diagnostic);
    stressState=!strcmp(v027::memoryReport().highResult,"PASS")?1:2;
    redraw=true;
}
const char* stationSearchQuery(){return searchQuery;}
unsigned stationSearchCount(){return searchFound;}
uint16_t stationSearchResult(unsigned index){return index<searchFound?searchResults[index]:0;}
bool stationSearchResultName(unsigned index,char* out,size_t cap){
    if(!out||!cap)return false;
    out[0]=0;
    uint16_t station=stationSearchResult(index);
    if(!station)return false;
    if(searchCacheLock&&xSemaphoreTake(searchCacheLock,pdMS_TO_TICKS(2))==pdTRUE){
        if(searchNames&&station<=searchRows){
            strlcpy(out,searchNames+size_t(station-1)*BUFLEN,cap);
            xSemaphoreGive(searchCacheLock);
            return out[0]!=0;
        }
        xSemaphoreGive(searchCacheLock);
    }
    // The filesystem fallback is safe only after playback has stopped.
    if(player.isRunning()||player.status()!=STOPPED)return false;
    const char* name=config.stationByNum(station);
    if(!name)return false;
    strlcpy(out,name,cap);
    return out[0]!=0;
}
unsigned stationSearchStatus(){return searchState;}
static char searchFold(const unsigned char*& p){
    unsigned char c=*p++;
    if(c<128)return char(toupper(c));
    if(c==0xC3&&*p){
        switch(*p++){
          case 0x81:case 0xA1:return 'A';
          case 0x89:case 0xA9:return 'E';
          case 0x8D:case 0xAD:return 'I';
          case 0x93:case 0xB3:case 0x96:case 0xB6:return 'O';
          case 0x9A:case 0xBA:case 0x9C:case 0xBC:return 'U';
          default:return 0;
        }
    }
    if(c==0xC5&&*p){
        switch(*p++){
          case 0x90:case 0x91:return 'O';
          case 0xB0:case 0xB1:return 'U';
          default:return 0;
        }
    }
    return 0;
}
static bool searchName(const char* name){
    char folded[170];size_t n=0;const unsigned char* p=(const unsigned char*)name;
    while(*p&&n<sizeof(folded)-1){char c=searchFold(p);if(c)folded[n++]=c;}
    folded[n]=0;return strstr(folded,searchQuery)!=nullptr;
}
void invalidateStationSearchCache(){
    if(searchCacheLock)xSemaphoreTake(searchCacheLock,portMAX_DELAY);
    searchRows=0;searchFound=0;
    if(searchCacheLock)xSemaphoreGive(searchCacheLock);
}
bool preloadStationSearch(){
    if(config.getMode()!=PM_WEB||player.isRunning()||player.status()!=STOPPED)return false;
    if(!searchCacheLock||xSemaphoreTake(searchCacheLock,pdMS_TO_TICKS(500))!=pdTRUE)return false;
    if(searchRows){xSemaphoreGive(searchCacheLock);return true;}
    if(!searchNames)searchNames=(char*)heap_caps_malloc(480u*BUFLEN,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
    if(!searchNames){xSemaphoreGive(searchCacheLock);return false;}
    File index=SPIFFS.open(INDEX_PATH,"r"),playlist=SPIFFS.open(PLAYLIST_PATH,"r");
    bool good=index&&playlist&&index.size()>=4&&index.size()%4==0&&index.size()/4<=480;
    uint16_t count=good?uint16_t(index.size()/4):0;
    for(uint16_t i=0;good&&i<count;i++){
        uint32_t pos=0;
        if(index.readBytes((char*)&pos,4)!=4||pos>=playlist.size()||!playlist.seek(pos)){good=false;break;}
        char* dest=searchNames+size_t(i)*BUFLEN;size_t used=0;int c;
        while((c=playlist.read())>=0&&c!='\t'&&c!='\r'&&c!='\n'){
            if(c==0||used>=BUFLEN-1){good=false;break;}
            dest[used++]=char(c);
        }
        if(c!='\t'||!used)good=false;
        dest[used]=0;
    }
    index.close();playlist.close();
    searchRows=good?count:0;
    xSemaphoreGive(searchCacheLock);
    return good;
}
static bool searchCached(){
    if(!searchCacheLock||xSemaphoreTake(searchCacheLock,pdMS_TO_TICKS(2))!=pdTRUE)return false;
    bool ready=searchRows>0;
    if(ready){
        for(uint16_t i=0;i<searchRows;i++)
            if(searchName(searchNames+size_t(i)*BUFLEN))searchResults[searchFound++]=uint16_t(i+1);
    }
    xSemaphoreGive(searchCacheLock);
    return ready;
}
static void executeStationSearch(){
    searchFound=0;searchState=0;
    if(config.getMode()!=PM_WEB){searchState=4;redraw=true;return;}
    if(!searchQuery[0]){searchState=3;redraw=true;return;}
    if(searchCached()){
        searchState=searchFound?0:3;
        if(searchFound){page=PAGE_SEARCH_RESULTS;selected=0;}
        redraw=true;return;
    }
    if(player.isRunning()||player.status()!=STOPPED){searchState=1;redraw=true;return;}
    if(preloadStationSearch()&&searchCached()){
        searchState=searchFound?0:3;
        if(searchFound){page=PAGE_SEARCH_RESULTS;selected=0;}
        redraw=true;return;
    }
    File index=SPIFFS.open(INDEX_PATH,"r");
    File playlist=SPIFFS.open(PLAYLIST_PATH,"r");
    if(!index||!playlist||index.size()<4||index.size()%4){searchState=2;index.close();playlist.close();redraw=true;return;}
    size_t count=index.size()/4;if(count>480)count=480;
    for(size_t i=0;i<count;i++){
        if(player.isRunning()||player.status()!=STOPPED){searchState=1;searchFound=0;break;}
        uint32_t pos=0;
        if(index.readBytes((char*)&pos,4)!=4||pos>=playlist.size()||!playlist.seek(pos)){searchState=2;searchFound=0;break;}
        char name[170];size_t used=0;int c;
        while((c=playlist.read())>=0&&c!='\t'&&c!='\n'&&c!='\r'){
            if(used<sizeof(name)-1)name[used++]=char(c);
        }
        name[used]=0;
        if(searchName(name))searchResults[searchFound++]=uint16_t(i+1);
        if((i&15)==15)vTaskDelay(1);
    }
    index.close();playlist.close();
    if(searchState==0)searchState=searchFound?0:3;
    if(searchFound){page=PAGE_SEARCH_RESULTS;selected=0;}
    redraw=true;
}
static uint32_t playlistHash(){
    File file=SPIFFS.open(PLAYLIST_PATH,"r");if(!file)return 0;
    uint32_t hash=2166136261u;uint8_t buffer[256];
    while(file.available()){
        size_t n=file.read(buffer,sizeof(buffer));if(!n)break;
        for(size_t i=0;i<n;i++){hash^=buffer[i];hash*=16777619u;}
    }
    file.close();return hash?hash:1;
}
bool favorite(uint16_t n){
    if(n<1||n>480)return false;
    portENTER_CRITICAL(&mux);bool yes=(favoriteBits[(n-1)/8]>>(uint8_t((n-1)%8)))&1;portEXIT_CRITICAL(&mux);
    return yes;
}
unsigned favoritesCount(){
    unsigned count=0;portENTER_CRITICAL(&mux);
    for(uint8_t b:favoriteBits){while(b){count+=b&1;b>>=1;}}
    portEXIT_CRITICAL(&mux);return count;
}
uint16_t nextFavorite(uint16_t from,bool forward){
    uint16_t n=from;
    for(unsigned i=0;i<480;i++){
        n=forward?(n>=480?1:n+1):(n<=1?480:n-1);
        if(favorite(n))return n;
    }
    return 0;
}
static void toggleFavorite(uint16_t n){
    if(n<1||n>480)return;
    portENTER_CRITICAL(&mux);favoriteBits[(n-1)/8]^=uint8_t(1u<<((n-1)%8));
    favoriteVersion++;state.pendingSave=true;portEXIT_CRITICAL(&mux);redraw=true;
}
void invalidateFavorites(){
    portENTER_CRITICAL(&mux);memset(favoriteBits,0,sizeof(favoriteBits));
    favoritePlaylistHash=0;favoriteVersion++;state.pendingSave=true;portEXIT_CRITICAL(&mux);redraw=true;
}
void clockConfigure() {
    configTzTime(DUAL_TZ,DUAL_NTP1,DUAL_NTP2);
    sntp_set_sync_interval(6UL*60UL*60UL*1000UL);
}
Snapshot snapshot() {
    Snapshot s;portENTER_CRITICAL(&mux);s=state;portEXIT_CRITICAL(&mux);return s;
}
bool debugEnabled(){portENTER_CRITICAL(&mux);bool v=state.settings.debug;portEXIT_CRITICAL(&mux);return v;}
bool uiOverloadActive(){return uiGovernor.inputOverloadActive(millis());}
bool sourcePendingSd(){return pendingSourceTarget==PM_SDCARD;}
static bool calibrateTouch(bool force=false){
#if defined(BOARD_CYD28)
    if(!frontendOK||(!force&&!board::touchCalibrationNeeded()))return true;const int sx[4]={24,295,295,24},sy[4]={24,24,215,215};Point r[4];Serial.println("[TOUCH] calibration start");
    for(unsigned i=0;i<4;i++){front::calibrationTarget(sx[i],sy[i],i+1);uint32_t deadline=millis()+30000;Point q;while(board::touchRaw(q)&&int32_t(deadline-millis())>0)delay(15);while(!board::touchRaw(q)&&int32_t(deadline-millis())>0)delay(15);if(int32_t(deadline-millis())<=0){front::calibrationDone(false);return false;}int32_t ax=0,ay=0;int n=0;while(board::touchRaw(q)&&n<16){ax+=q.x;ay+=q.y;n++;delay(12);}if(n<3){front::calibrationDone(false);return false;}r[i]={(int)(ax/n),(int)(ay/n)};while(board::touchRaw(q)&&int32_t(deadline-millis())>0)delay(15);}
    int hdx=((r[1].x+r[2].x)-(r[0].x+r[3].x))/2,hdy=((r[1].y+r[2].y)-(r[0].y+r[3].y))/2;bool swap=abs(hdy)>abs(hdx);auto rx=[&](int i){return swap?r[i].y:r[i].x;};auto ry=[&](int i){return swap?r[i].x:r[i].y;};float left=(rx(0)+rx(3))*.5f,right=(rx(1)+rx(2))*.5f,top=(ry(0)+ry(1))*.5f,bottom=(ry(2)+ry(3))*.5f;float x0=left+(left-right)*24.0f/271.0f,x1=right+(right-left)*24.0f/271.0f,y0=top+(top-bottom)*24.0f/191.0f,y1=bottom+(bottom-top)*24.0f/191.0f;board::TouchCalibration c{(int)min(x0,x1),(int)max(x0,x1),(int)min(y0,y1),(int)max(y0,y1),swap,x0>x1,y0>y1};bool ok=board::touchSaveCalibration(c);front::calibrationDone(ok);Serial.printf("[TOUCH] save=%s xmin=%d xmax=%d ymin=%d ymax=%d swap=%d invx=%d invy=%d\n",ok?"PASS":"FAIL",c.xMin,c.xMax,c.yMin,c.yMax,c.swapXY,c.invertX,c.invertY);return ok;
#else
    return true;
#endif
}
void begin() {
    commands=xQueueCreate(12,sizeof(Action));
    if(!searchCacheLock)searchCacheLock=xSemaphoreCreateMutex();
    favoritePlaylistHash=playlistHash();
    Preferences p; if(p.begin("yo-dual-v1",true)) {
        state.settings.menuIdleSeconds=p.getUShort("menuidle",10);
        vuprobe::setRefresh(p.getUShort("vutimer",500));
        state.settings.language=Language(p.getUChar("lang",0));
        state.settings.theme=Theme(p.getUChar("theme",0));
        state.settings.rotation=p.getUChar("rotate",0);
        state.settings.brightness=p.getUChar("bright",70);
        state.settings.maxKbps=p.getUShort("rate",0);
        state.settings.rotaryMode=p.getUChar("rotmode",1);
        state.settings.volumeStep=p.getUChar("volstep",1);
        state.settings.debug=p.getUChar("debug",0)!=0;
        state.settings.artworkEnabled=p.getUChar("artwork",1)!=0;
        state.settings.cassetteEnabled=p.getUChar("cassette",1)!=0;
        state.settings.bufferIndicator=p.getUChar("bufbar",1)!=0;
        state.settings.reelAnimation=p.getUChar("reels",0)!=0;
        state.settings.wifiIndicator=p.getUChar("wifibar",1)!=0;
        state.settings.btQuickScan=p.getUChar("btquick",1)!=0;
        state.settings.winampEnabled=p.getUChar("winamp",1)!=0;
        if(favoritePlaylistHash && p.getUInt("favhash",0)==favoritePlaylistHash && p.getBytesLength("favorites")==sizeof(favoriteBits))p.getBytes("favorites",favoriteBits,sizeof(favoriteBits));
        p.end();
    }
    sanitize(state.settings);
    config.store.volsteps=(uint8_t)max(1,(int(state.settings.volumeStep)*254+50)/100);
    config.store.audioinfo=state.settings.debug;
#if defined(BOARD_CYD28)
    const char *model="SMALL";
#else
    const char *model="BIG";
#endif
    if(strlen(DUAL_DEVICE_NAME))textCopy(state.device,sizeof(state.device),DUAL_DEVICE_NAME);
    else snprintf(state.device,sizeof(state.device),"I-BT-Radio %s %s-%06lX",IBT_FW_VERSION,model,(unsigned long)(ESP.getEfuseMac()&0xffffff));
    // Avoid stale settings from an older firmware enabling expensive legacy features.
    config.store.vumeter=false;config.store.showweather=false;
    config.store.watchdog=false; // use the client's bounded connect; do not kill a task inside TCP/TLS
    config.store.screensaverEnabled=false;config.store.screensaverPlayingEnabled=false;
    artwork::begin();
    btaudio::loadSavedDevice();
    onlineart::begin();
    onlineart::setEnabled(state.settings.artworkEnabled&&!state.settings.winampEnabled,state.generation);
    board::begin();board::brightness(state.settings.brightness);
    frontendOK=front::begin();
    if(frontendOK){front::setRotation(0);calibrateTouch();front::setRotation(state.settings.rotation);}
    initialized=true;
    if(debugEnabled())Serial.printf("[DUAL] %s version=%s UI=%s commands=%s\n",state.device,DUAL_VERSION,frontendOK?"OK":"failed",commands?"OK":"failed");
}
void send(Action a) {
    const bool expendable=a==Action::RotCW||a==Action::RotCCW||
      a==Action::VolDown||a==Action::VolUp;
    if(!commands||(expendable&&uxQueueMessagesWaiting(commands)>=9)||xQueueSend(commands,&a,0)!=pdTRUE){
        portENTER_CRITICAL(&mux);state.queueDrops++;portEXIT_CRITICAL(&mux);
    }
}
// R10 diagnostic UI path: RAM-only by construction; persistent mutation paths are excluded.
bool r10DiagUi(R10DiagUiAction a){
    if(!initialized)return false;
    switch(a){
      case R10DiagUiAction::Menu: page=PAGE_MAIN;selected=0;break;
      case R10DiagUiAction::RotCW:
        if(page!=PAGE_MAIN){page=PAGE_MAIN;selected=0;} else selected=(selected+1)%4;break;
      case R10DiagUiAction::RotCCW:
        if(page!=PAGE_MAIN){page=PAGE_MAIN;selected=3;} else selected=(selected+3)%4;break;
      case R10DiagUiAction::Short:
        if(page==PAGE_MAIN){
          page=selected==0?PAGE_STATIONS:selected==1?PAGE_SOUND:selected==2?PAGE_BLUETOOTH:PAGE_SETTINGS;
          selected=0;
        } else {page=PAGE_MAIN;selected=0;}
        break;
      case R10DiagUiAction::Long:
#if defined(BOARD_CYD28)
        front::skinPreview(-1);
#endif
        page=PAGE_HOME;selected=0;break;
      case R10DiagUiAction::Double: page=(page==PAGE_BLUETOOTH)?PAGE_MEMORY:PAGE_BLUETOOTH;selected=0;break;
    }
    stationPreview=false;shortPending=false;secondDown=false;redraw=true;artwork::redraw(snapshot().generation);return true;
}
void r10DiagRecoverHome(){page=PAGE_HOME;selected=0;stationPreview=false;shortPending=false;secondDown=false;redraw=true;if(!btaudio::transmitting())artwork::redraw(snapshot().generation);}
unsigned r10DiagPage(){return page;}
unsigned r10DiagSelected(){return selected;}
bool r10UiSelfcheck(){
    if(!initialized||network.status==SOFT_AP)return false;
    r10DiagRecoverHome();
    input(Action::Menu);
    const bool opened=page==PAGE_MAIN;
    input(Action::EncoderLong);
    const bool longHome=page==PAGE_HOME;
    input(Action::EncoderShort);
    input(Action::EncoderDown);
    input(Action::EncoderLong);
    const bool comboMenu=page==PAGE_MAIN;
    input(Action::EncoderLong);
    const bool finalHome=page==PAGE_HOME;
    const bool ok=opened&&longHome&&comboMenu&&finalHome;
    Serial.printf("[UI-SELFTEST] result=%s menu=%u long_home=%u short_long_menu=%u final_home=%u\n",
      ok?"PASS":"FAIL",opened?1:0,longHome?1:0,comboMenu?1:0,finalHome?1:0);
    return ok;
}
bool r10UiStressStart(unsigned actionMs,unsigned drawMs,bool tour){
    Snapshot s=snapshot();
    if(uiStressActive||!initialized||!frontendOK||network.status==SOFT_AP||config.getMode()!=PM_WEB||
       btaudio::wanted()||!s.playing||s.buffer<32768||s.freeHeap<32768||
       actionMs<10||actionMs>500||drawMs<10||drawMs>500)return false;
    if(tour&&(actionMs<250||s.pendingSave||settingsVersion!=savedVersion))return false;
#if defined(BOARD_CYD28)
    front::skinPreview(-1);
#endif
    uiStressActive=true;uiStressInjecting=false;
    uiStressTour=tour;uiStressTourRestored=false;
    uiStressOriginalSettings=s.settings;uiStressTourStep=0;
    uiStressTourVisits=0;uiStressTourEdits=0;uiStressTourCycles=0;
    uiStressActionMs=(uint16_t)actionMs;uiStressDrawMs=(uint16_t)drawMs;
    uiStressActions=0;uiStressFrames=0;uiStressRenderCalls=0;uiStressRenderedActions=0;
    uiStressStarted=millis();
    uiStressLastAction=uiStressStarted;uiStressLastCheck=uiStressStarted;
    uiStressBaseLow=s.lowBufferEvents;uiStressBaseDrops=s.queueDrops;
    uiStressBaseGaps=player.audioGapEvents();
    strlcpy(uiStressReason,"running",sizeof(uiStressReason));
    page=PAGE_MAIN;selected=0;redraw=true;
    return true;
}
void r10UiStressStop(const char* reason){
    if(!uiStressActive)return;
    uiStressActive=false;uiStressInjecting=false;
    if(uiStressTour){
        portENTER_CRITICAL(&mux);state.settings=uiStressOriginalSettings;portEXIT_CRITICAL(&mux);
        uiStressTour=false;uiStressTourRestored=true;redraw=true;
    }
    strlcpy(uiStressReason,reason?reason:"stopped",sizeof(uiStressReason));
    r10DiagRecoverHome();
    char notice[sizeof(state.notice)]{};
    snprintf(notice,sizeof(notice),"TEST STOP %s",uiStressReason);
    portENTER_CRITICAL(&mux);
    memcpy(state.notice,notice,sizeof(notice));
    portEXIT_CRITICAL(&mux);
    Serial.printf("[UI-STRESS] stop=%s actions=%lu frames=%lu\n",uiStressReason,
      (unsigned long)uiStressActions,(unsigned long)uiStressFrames);
}
bool r10UiStressInfo(uint16_t& actionMs,uint16_t& drawMs,uint32_t& actions,uint32_t& frames){
    actionMs=uiStressActionMs;drawMs=uiStressDrawMs;actions=uiStressActions;frames=uiStressFrames;
    return uiStressActive;
}
void r10UiStressStatus(){
    Snapshot s=snapshot();
    Serial.printf("[UI-STRESS] active=%u reason=%s action_ms=%u draw_ms=%u actions=%lu frames=%lu render_calls=%lu elapsed_ms=%lu buffer=%lu low_events=%lu heap=%lu queue_drops=%lu gap_events=%lu tour=%u visits=%lu edits=%lu cycles=%lu restored=%u page=%u selected=%u\n",
      uiStressActive?1:0,uiStressReason,unsigned(uiStressActionMs),unsigned(uiStressDrawMs),
      (unsigned long)uiStressActions,(unsigned long)uiStressFrames,(unsigned long)uiStressRenderCalls,
      (unsigned long)(millis()-uiStressStarted),(unsigned long)s.buffer,
      (unsigned long)s.lowBufferEvents,(unsigned long)s.freeHeap,(unsigned long)s.queueDrops,
      (unsigned long)player.audioGapEvents(),
      uiStressTour?1:0,(unsigned long)uiStressTourVisits,(unsigned long)uiStressTourEdits,
      (unsigned long)uiStressTourCycles,uiStressTourRestored?1:0,page,selected);
}
struct UiTourStep {Action action;uint8_t page,sel,nextPage,nextSel,edit;};
static constexpr uint8_t NO_EDIT=255;
static const char* uiTourPageName(unsigned p){
    switch(p){
      case PAGE_HOME:return "HOME";case PAGE_MAIN:return "MAIN";case PAGE_STATIONS:return "STATIONS";
      case PAGE_SOUND:return "SOUND";case PAGE_BLUETOOTH:return "BLUETOOTH";case PAGE_BT_INFO:return "BT_INFO";
      case PAGE_SETTINGS:return "SETTINGS";case PAGE_DISPLAY:return "DISPLAY";default:return "UNKNOWN";
    }
}
static const char* uiTourActionName(Action a){
    switch(a){case Action::Select:return "select";case Action::RotCW:return "rotary_next";
      case Action::RotCCW:return "rotary_prev";case Action::EncoderLong:return "long_press";
      case Action::Menu:return "menu";default:return "other";}
}
static constexpr UiTourStep uiTourSteps[]={
    {Action::Select,PAGE_MAIN,0,PAGE_STATIONS,0,NO_EDIT},
    {Action::RotCW,PAGE_STATIONS,0,PAGE_STATIONS,1,NO_EDIT},
    {Action::RotCW,PAGE_STATIONS,1,PAGE_STATIONS,2,NO_EDIT},
    {Action::EncoderLong,PAGE_STATIONS,2,PAGE_HOME,0,NO_EDIT},
    {Action::Menu,PAGE_HOME,0,PAGE_MAIN,0,NO_EDIT},
    {Action::RotCW,PAGE_MAIN,0,PAGE_MAIN,1,NO_EDIT},
    {Action::Select,PAGE_MAIN,1,PAGE_SOUND,0,NO_EDIT},
    {Action::RotCW,PAGE_SOUND,0,PAGE_SOUND,1,NO_EDIT},
    {Action::RotCW,PAGE_SOUND,1,PAGE_SOUND,2,NO_EDIT},
    {Action::EncoderLong,PAGE_SOUND,2,PAGE_HOME,0,NO_EDIT},
    {Action::Menu,PAGE_HOME,0,PAGE_MAIN,0,NO_EDIT},
    {Action::RotCW,PAGE_MAIN,0,PAGE_MAIN,1,NO_EDIT},
    {Action::RotCW,PAGE_MAIN,1,PAGE_MAIN,2,NO_EDIT},
    {Action::Select,PAGE_MAIN,2,PAGE_BLUETOOTH,0,NO_EDIT},
    {Action::RotCW,PAGE_BLUETOOTH,0,PAGE_BLUETOOTH,1,NO_EDIT},
    {Action::RotCW,PAGE_BLUETOOTH,1,PAGE_BLUETOOTH,2,NO_EDIT},
    {Action::RotCW,PAGE_BLUETOOTH,2,PAGE_BLUETOOTH,3,NO_EDIT},
    {Action::Select,PAGE_BLUETOOTH,3,PAGE_BT_INFO,0,NO_EDIT},
    {Action::EncoderLong,PAGE_BT_INFO,0,PAGE_HOME,0,NO_EDIT},
    {Action::Menu,PAGE_HOME,0,PAGE_MAIN,0,NO_EDIT},
    {Action::RotCW,PAGE_MAIN,0,PAGE_MAIN,1,NO_EDIT},
    {Action::RotCW,PAGE_MAIN,1,PAGE_MAIN,2,NO_EDIT},
    {Action::RotCW,PAGE_MAIN,2,PAGE_MAIN,3,NO_EDIT},
    {Action::Select,PAGE_MAIN,3,PAGE_SETTINGS,0,NO_EDIT},
    {Action::RotCW,PAGE_SETTINGS,0,PAGE_SETTINGS,1,NO_EDIT},
    {Action::Select,PAGE_SETTINGS,1,PAGE_DISPLAY,0,NO_EDIT},
    {Action::RotCW,PAGE_DISPLAY,0,PAGE_DISPLAY,1,NO_EDIT},
    {Action::RotCW,PAGE_DISPLAY,1,PAGE_DISPLAY,2,NO_EDIT},
    {Action::RotCW,PAGE_DISPLAY,2,PAGE_DISPLAY,3,NO_EDIT},
    {Action::RotCW,PAGE_DISPLAY,3,PAGE_DISPLAY,4,NO_EDIT},
    {Action::RotCW,PAGE_DISPLAY,4,PAGE_DISPLAY,5,NO_EDIT},
    {Action::Select,PAGE_DISPLAY,5,PAGE_DISPLAY,5,5},
    {Action::RotCW,PAGE_DISPLAY,5,PAGE_DISPLAY,6,NO_EDIT},
    {Action::Select,PAGE_DISPLAY,6,PAGE_DISPLAY,6,6},
    {Action::RotCW,PAGE_DISPLAY,6,PAGE_DISPLAY,7,NO_EDIT},
    {Action::Select,PAGE_DISPLAY,7,PAGE_DISPLAY,7,7},
    {Action::RotCW,PAGE_DISPLAY,7,PAGE_DISPLAY,8,NO_EDIT},
    {Action::Select,PAGE_DISPLAY,8,PAGE_DISPLAY,8,8},
    {Action::RotCW,PAGE_DISPLAY,8,PAGE_DISPLAY,9,NO_EDIT},
    {Action::Select,PAGE_DISPLAY,9,PAGE_DISPLAY,9,9},
    {Action::RotCW,PAGE_DISPLAY,9,PAGE_DISPLAY,10,NO_EDIT},
    {Action::Select,PAGE_DISPLAY,10,PAGE_SETTINGS,1,NO_EDIT},
    {Action::EncoderLong,PAGE_SETTINGS,1,PAGE_HOME,0,NO_EDIT},
    {Action::Menu,PAGE_HOME,0,PAGE_MAIN,0,NO_EDIT}
};
static bool uiTourFlag(const Settings& s,uint8_t item){
    return item==5?s.bufferIndicator:item==6?s.reelAnimation:
           item==7?s.wifiIndicator:item==8?s.btQuickScan:s.winampEnabled;
}
static void r10UiTourStep(){
    const auto& step=uiTourSteps[uiStressTourStep];
    if(page!=step.page||selected!=step.sel){
        Serial.printf("[UI-TOUR] route=FAIL step=%u page=%u selected=%u\n",uiStressTourStep,page,selected);
        r10UiStressStop("menu_route_fail");return;
    }
    Settings before;
    if(step.edit!=NO_EDIT)before=snapshot().settings;
    uiStressInjecting=true;input(step.action);uiStressInjecting=false;
    if(!uiStressActive||page!=step.nextPage||selected!=step.nextSel){
        Serial.printf("[UI-TOUR] route=FAIL step=%u page=%u selected=%u\n",uiStressTourStep,page,selected);
        r10UiStressStop("menu_route_fail");return;
    }
    if(step.edit!=NO_EDIT){
        Snapshot after=snapshot();
        if(uiTourFlag(before,step.edit)==uiTourFlag(after.settings,step.edit)||after.pendingSave){
            Serial.printf("[UI-TOUR] edit=FAIL item=%u pending_save=%u\n",step.edit,after.pendingSave?1:0);
            r10UiStressStop("menu_edit_fail");return;
        }
        ++uiStressTourEdits;
        Serial.printf("[UI-TOUR] edit=PASS item=%u value=%u ram_only=1\n",
                      step.edit,uiTourFlag(after.settings,step.edit)?1:0);
    }
    Serial.printf("[UI-TOUR] step=%u result=PASS from=%s:%u action=%s to=%s:%u\n",
      unsigned(uiStressTourStep+1),uiTourPageName(step.page),step.sel,uiTourActionName(step.action),
      uiTourPageName(step.nextPage),step.nextSel);
    if(step.page!=step.nextPage)++uiStressTourVisits;
    ++uiStressActions;
    if(++uiStressTourStep>=sizeof(uiTourSteps)/sizeof(uiTourSteps[0])){
        uiStressTourStep=0;++uiStressTourCycles;
        Serial.printf("[UI-TOUR] cycle=PASS count=%lu visits=%lu edits=%lu\n",
                      (unsigned long)uiStressTourCycles,(unsigned long)uiStressTourVisits,
                      (unsigned long)uiStressTourEdits);
    }
}
static void r10UiStressTick(uint32_t now){
    if(!uiStressActive)return;
    if(uint32_t(now-uiStressLastCheck)>=500){
        uiStressLastCheck=now;Snapshot s=snapshot();
        if(!s.playing||s.buffer<16384||s.lowBufferEvents>uiStressBaseLow||
           s.queueDrops>uiStressBaseDrops||s.freeHeap<32768){
            r10UiStressStop("audio_or_memory_guard");return;
        }
        if(player.audioGapEvents()>uiStressBaseGaps){
            r10UiStressStop("audio_gap_guard");return;
        }
    }
    if(uint32_t(now-uiStressLastAction)>=uiStressActionMs){
        uiStressLastAction=now;
        if(uiStressTour)r10UiTourStep();
        else {uiStressInjecting=true;input(Action::RotCW);uiStressInjecting=false;++uiStressActions;}
    }
}
void track(const char *path) {
    portENTER_CRITICAL(&mux);
    state.generation++;state.artist[0]=state.album[0]=state.title[0]=state.notice[0]=0;
    if(path&&*path&&config.getMode()==PM_SDCARD) {
        const char *base=strrchr(path,'/');
        textCopy(state.title,sizeof(state.title),base?base+1:path);
    }
    uint32_t generation=state.generation;
    portEXIT_CRITICAL(&mux);
    bitrateRejected=false;player.eofHeader=false;
    artwork::reset(config.getMode()==PM_SDCARD?path:"",generation);
    onlineart::reset(generation);
    if(config.getMode()==PM_WEB && config.stationArtworkUrl()[0]) onlineart::requestUrl(config.stationArtworkUrl(),generation);
}
static void metadata(char *dest,const char *s) {portENTER_CRITICAL(&mux);textCopy(dest,170,s);portEXIT_CRITICAL(&mux);}
void metadataArtist(const char *s){metadata(state.artist,s);}
void metadataAlbum(const char *s){metadata(state.album,s);}
void metadataTitle(const char *s){metadata(state.title,s);if(config.getMode()==PM_WEB)onlineart::requestTrack(s,snapshot().generation);}
void imageHint(size_t pos,size_t size){artwork::hint(pos,size);}
void displayEvent(int type,int payload) {
    (void)payload;
    if(type==DSP_START){portENTER_CRITICAL(&mux);state.ready=true;portEXIT_CRITICAL(&mux);}
}
static unsigned menuCount(unsigned p){return content::itemCount(p);}
static bool menuEnabled(unsigned p,unsigned item){
    switch(p){
      case PAGE_MAIN:return item<4;
      case PAGE_STATIONS:return item<=2||(FEATURE_SD&&item==3)||item==4||item==5;
      case PAGE_SOUND:return item<=4;
      case PAGE_VOLUME_STREAM:return item<4;
      case PAGE_EQ:return item==4;
      case PAGE_OUTPUTS:return item==0||item==2||item==3||item==4;
      case PAGE_BLUETOOTH:return item<6;
      case PAGE_BT_RATE:return item<5;
      case PAGE_SETTINGS:return item<9;
      case PAGE_VU_TIMER:return item<6;
      case PAGE_IDLE:return item<8;
      case PAGE_WIFI:return item<=4;
      case PAGE_DISPLAY:return item<=10;
      case PAGE_CONTROLS:return item<=2||item==4;
      case PAGE_STORAGE:return item==0||(FEATURE_SD&&item==1)||item==2||item==3||item==4;
      case PAGE_SYSTEM:return item<=3||(FEATURE_SD&&item==4)||item==5;
      case PAGE_BACKUP_MENU:return item<=4;
      case PAGE_DIAGNOSTICS:return item<=5;
      default:return false;
    }
}
static void persistSetting(const Settings &s){
    if(uiStressActive&&uiStressTour&&uiStressInjecting){
        // Exercise the real menu editor in RAM; do not wear flash during a sweep.
        portENTER_CRITICAL(&mux);state.settings=s;portEXIT_CRITICAL(&mux);return;
    }
    portENTER_CRITICAL(&mux);state.settings=s;state.pendingSave=true;settingsVersion++;portEXIT_CRITICAL(&mux);
}
static void editDisplay(unsigned item){
    Settings s=snapshot().settings;
    switch(item){
      case 0:s.theme=Theme((unsigned(s.theme)+1)%3);break;
      case 1:s.rotation=(s.rotation+1)&3;break;
      case 2:s.brightness=s.brightness>=100?10:s.brightness+10;break;
      case 3:s.artworkEnabled=!s.artworkEnabled;break;
      case 4:s.cassetteEnabled=!s.cassetteEnabled;break;
      case 5:s.bufferIndicator=!s.bufferIndicator;break;
      case 6:s.reelAnimation=!s.reelAnimation;break;
      case 7:s.wifiIndicator=!s.wifiIndicator;break;
      case 8:s.btQuickScan=!s.btQuickScan;break;
      case 9:s.winampEnabled=!s.winampEnabled;break;
      default:return;
    }
    persistSetting(s);
    if(item==1&&frontendOK)front::setRotation(s.rotation);
    if(item==2)board::brightness(s.brightness);
    if(item==3||item==9){
        Snapshot current=snapshot();onlineart::setEnabled(s.artworkEnabled&&!s.winampEnabled,current.generation);
        if(s.artworkEnabled&&!s.winampEnabled){
            if(config.stationArtworkUrl()[0])onlineart::requestUrl(config.stationArtworkUrl(),current.generation);
            if(current.title[0])onlineart::requestTrack(current.title,current.generation);
        }
    }
    redraw=true;
}
static void editSystem(unsigned item){
    if(item!=0)return;
    Settings s=snapshot().settings;
    s.language=Language((unsigned(s.language)+1)%3);
    persistSetting(s);redraw=true;
}
static void editControls(unsigned item){
    if(item!=0)return;Settings s=snapshot().settings;s.rotaryMode=s.rotaryMode==1?2:1;persistSetting(s);redraw=true;
}
static void editVolumeStream(unsigned item){
    Settings s=snapshot().settings;
    if(item==0){s.volumeStep=s.volumeStep>=10?1:s.volumeStep+1;persistSetting(s);config.store.volsteps=(uint8_t)max(1,(int(s.volumeStep)*254+50)/100);}
    else if(item==1){const uint16_t values[]={64,96,128,192,320,0};unsigned i=0;while(i<5&&values[i]!=s.maxKbps)i++;s.maxKbps=values[(i+1)%6];persistSetting(s);}
    else return;
    redraw=true;
}
static void editDiagnostics(unsigned item){
    if(item!=0)return;Settings s=snapshot().settings;s.debug=!s.debug;persistSetting(s);config.store.audioinfo=s.debug;redraw=true;
}
static uint32_t shortAt=0;
static uint32_t restartArmedAt=0;
static uint32_t backupArmedAt=0;
static unsigned backupArmedItem=0;
bool backupRestoreArmed(){return page==PAGE_BACKUP_MENU && selected==backupArmedItem && backupArmedAt && uint32_t(millis()-backupArmedAt)<=5000;}
static uint16_t channelCursor=1;

static uint16_t wrapStation(int value) {
    int n=(int)config.playlistLength();
    if(n<1)return 1;
    while(value<1)value+=n;
    while(value>n)value-=n;
    return (uint16_t)value;
}
static void showStationPreview(uint16_t station) {
    const char *name=config.stationByNum(station);
    // UI task owns this scratch buffer. Do filesystem/stdio work before entering
    // the spinlock; a static buffer avoids increasing the small display stack.
    static char preview[sizeof(state.notice)];
    const unsigned count=config.playlistLength();
    snprintf(preview,sizeof(preview),"[%u/%u] %s",station,count,name?name:"");
    portENTER_CRITICAL(&mux);
    memcpy(state.notice,preview,sizeof(state.notice));
    portEXIT_CRITICAL(&mux);
    redraw=true;
}
static void commitStation(uint16_t station) {
    if(!config.playlistLength())return;
    station=wrapStation(station);
    if(!player.sendCommand({PR_PLAY,station})){redraw=true;return;}
    stationPreview=false;
    portENTER_CRITICAL(&mux);state.notice[0]=0;portEXIT_CRITICAL(&mux);
    page=PAGE_HOME;redraw=true;artwork::redraw(snapshot().generation);
}
static void openChannels() {
    stationListParent=page==PAGE_STATIONS?PAGE_STATIONS:PAGE_HOME;
    channelCursor=wrapStation(config.lastStation()?config.lastStation():1);
    selected=channelCursor;page=PAGE_STATIONS_LIST;stationPreview=false;redraw=true;
}
static void openMainMenu() {
    page=PAGE_MAIN;selected=0;stationPreview=false;redraw=true;artwork::redraw(snapshot().generation);
}
static void openFavorites(){
    uint16_t last=config.lastStation();
    selected=favorite(last)?last:nextFavorite(last,true);
    page=PAGE_FAVORITES_LIST;redraw=true;
}
static void goBack(unsigned from);
static void clearWifiPassword(){
    volatile char* p=wifiEntry.password;
    for(size_t i=0;i<sizeof(wifiEntry.password);i++)p[i]=0;
    wifiEntry.ssid[0]=wifiEntry.error[0]=0;
    wifiEntry.mode=0;wifiEntry.submitted=false;
}
static void openWifiPassword(const char* ssid){
    clearWifiPassword();
    strlcpy(wifiEntry.ssid,ssid,sizeof(wifiEntry.ssid));
    page=PAGE_WIFI_PASSWORD;selected=0;redraw=true;
}
static void openSelectedWifiPassword(unsigned index){
    char ssid[WIFI_SSID_CAP]={};
    if(network.scanEntry(index,ssid,sizeof(ssid)))openWifiPassword(ssid);
}
static void chooseScannedWifi(unsigned index){
    char ssid[WIFI_SSID_CAP]={};
    if(!network.scanEntry(index,ssid,sizeof(ssid)))return;
    const int result=network.selectSetupNetwork(index);
    if(result==1){page=PAGE_HOME;selected=0;network.cancelScan();redraw=true;}
    else if(result==2)openWifiPassword(ssid);
}
static void wifiPasswordKeyPress(unsigned key){
    if(wifiEntry.submitted&&!network.setupFailed())return;
    if(wifiEntry.submitted){wifiEntry.submitted=false;strlcpy(wifiEntry.error,"Kapcsolat sikertelen",sizeof(wifiEntry.error));}
    if(key<36){
        const char c=wifiPasswordKeyChar(wifiEntry.mode,key);
        const size_t n=strlen(wifiEntry.password);
        if(c&&n<sizeof(wifiEntry.password)-1){wifiEntry.password[n]=c;wifiEntry.password[n+1]=0;wifiEntry.error[0]=0;}
        else if(c)strlcpy(wifiEntry.error,"Legfeljebb 63 karakter",sizeof(wifiEntry.error));
    }else if(key==36){wifiEntry.mode=(wifiEntry.mode+1)%3;}
    else if(key==37){size_t n=strlen(wifiEntry.password);if(n)wifiEntry.password[n-1]=0;wifiEntry.error[0]=0;}
    else if(key==38){
        const size_t n=strlen(wifiEntry.password);
        if(n&&n<8)strlcpy(wifiEntry.error,"Jelszo: 8-63 karakter",sizeof(wifiEntry.error));
        else if(network.connectScannedNetwork(wifiEntry.ssid,wifiEntry.password)){
            wifiEntry.submitted=true;wifiEntry.error[0]=0;
        }else strlcpy(wifiEntry.error,"Kapcsolodas nem indult",sizeof(wifiEntry.error));
    }else if(key==39){goBack(PAGE_WIFI_PASSWORD);return;}
    redraw=true;
}
static void searchKey(unsigned key){
    if(key<26){
        size_t n=strlen(searchQuery);
        if(n<sizeof(searchQuery)-1){searchQuery[n]=char('A'+key);searchQuery[n+1]=0;}
        searchState=0;
    }else if(key==26){
        size_t n=strlen(searchQuery);
        if(n&&n<sizeof(searchQuery)-1){searchQuery[n]=' ';searchQuery[n+1]=0;}
        searchState=0;
    }else if(key==27){
        size_t n=strlen(searchQuery);if(n)searchQuery[n-1]=0;searchState=0;
    }else if(key==28)executeStationSearch();
    else if(key==29)goBack(PAGE_STATION_SEARCH);
    redraw=true;
}
static uint16_t stationAtTouch(Point raw,unsigned listPage){
    Snapshot s=snapshot();Size native=front::nativeSize();Point q=toLogical(raw,native,s.settings.rotation);
    if(listPage==PAGE_STATIONS_LIST&&btaudio::transmitting()&&!ibtsdui::classic(true,s.sd,s.settings.winampEnabled)){
        if(q.x<15||q.x>=305||q.y<46||q.y>=46+8*22)return 0;
        uint16_t total=config.playlistLength();if(!total)return 0;
        int n=int(selected)-3+(q.y-46)/22;while(n<1)n+=total;while(n>total)n-=total;return uint16_t(n);
    }
    // Match every row edge to the same offline crop transform as the renderer.
    if(listPage==PAGE_STATIONS_LIST&&s.settings.winampEnabled&&q.x>=10&&q.x<300){
        const auto edge=[](int row){return ((24+row*22-2)*240+116)/233;};
        if(q.y>=edge(0)&&q.y<edge(8)){
            uint16_t total=config.playlistLength();if(!total)return 0;
            int row=0;while(row<7&&q.y>=edge(row+1))++row;
            int n=int(selected)-3+row;while(n<1)n+=total;while(n>total)n-=total;return uint16_t(n);
        }
        return 0;
    }
    if(q.y<56||q.y>=56+7*23)return 0;
    int row=(q.y-56)/23;
    if(listPage==PAGE_STATIONS_LIST){
        uint16_t total=config.playlistLength();if(!total)return 0;
        int n=int(selected)-3+row;while(n<1)n+=total;while(n>total)n-=total;return uint16_t(n);
    }
    if(row>=int(favoritesCount())||!selected)return 0;
    uint16_t n=uint16_t(selected);
    while(row-->0)n=nextFavorite(n,true);
    return n;
}
static void goBack(unsigned from){
    backupArmedAt=0;
    restartArmedAt=0;
    switch(from){
      case PAGE_STATIONS:page=PAGE_MAIN;selected=0;break;
      case PAGE_SOUND:page=PAGE_MAIN;selected=1;break;
      case PAGE_BLUETOOTH:page=PAGE_MAIN;selected=2;break;
      case PAGE_IDLE:page=PAGE_SETTINGS;selected=6;break;
      case PAGE_VU_TIMER:page=PAGE_SETTINGS;selected=7;break;
      case PAGE_SETTINGS:page=PAGE_MAIN;selected=3;break;
      case PAGE_WIFI:page=PAGE_SETTINGS;selected=0;break;
      case PAGE_DISPLAY:page=PAGE_SETTINGS;selected=1;break;
      case PAGE_CONTROLS:page=PAGE_SETTINGS;selected=2;break;
      case PAGE_STORAGE:page=PAGE_SETTINGS;selected=3;break;
      case PAGE_SYSTEM:page=PAGE_SETTINGS;selected=4;break;
      case PAGE_DIAGNOSTICS:page=PAGE_SETTINGS;selected=5;break;
      case PAGE_VOLUME_STREAM:page=PAGE_SOUND;selected=0;break;
      case PAGE_EQ:page=PAGE_SOUND;selected=1;break;
      case PAGE_OUTPUTS:page=PAGE_SOUND;selected=2;break;
      case PAGE_FIRMWARE_INFO:page=PAGE_SYSTEM;selected=1;break;
      case PAGE_MEMORY:page=memoryParent;selected=memoryParent==PAGE_STORAGE?0:1;break;
      case PAGE_ROTARY_DEBUG:page=PAGE_DIAGNOSTICS;selected=3;break;
      case PAGE_NETWORK_INFO:page=networkParent;selected=networkParent==PAGE_WIFI?0:2;break;
      case PAGE_SAVED_WIFI:page=PAGE_WIFI;selected=2;break;
      case PAGE_WIFI_SCAN:page=network.status==SOFT_AP?PAGE_HOME:PAGE_WIFI;selected=network.status==SOFT_AP?0:3;network.cancelScan();break;
      case PAGE_WIFI_PASSWORD:clearWifiPassword();page=PAGE_WIFI_SCAN;selected=0;break;
      case PAGE_FAVORITES_LIST:page=PAGE_STATIONS;selected=1;break;
      case PAGE_STATIONS_LIST:page=stationListParent;selected=0;break;
      case PAGE_SOURCE_PENDING:
        if(pendingSourceTarget==PM_WEB)return;
        if(pendingSourceTarget==PM_SDCARD &&
           player.sdPrepareState()!=SdPrepareState::Failed &&
           player.sdPrepareState()!=SdPrepareState::Cancelled &&
           !player.sendCommand({PR_SOURCE,PM_WEB}))return;
        page=PAGE_STATIONS;selected=pendingSourceTarget==PM_SDCARD?3:0;break;
      case PAGE_SD_INFO:page=PAGE_STORAGE;selected=1;break;
      case PAGE_STATION_SEARCH:page=PAGE_STATIONS;selected=2;break;
      case PAGE_SEARCH_RESULTS:page=PAGE_STATION_SEARCH;selected=28;break;
      case PAGE_PLAYLIST_EDITOR:page=PAGE_STATIONS;selected=4;break;
      case PAGE_MEMORY_STRESS:page=PAGE_DIAGNOSTICS;selected=4;break;
      case PAGE_BACKUP_MENU:page=PAGE_SYSTEM;selected=4;break;
      case PAGE_BACKUP_RESULT:page=PAGE_BACKUP_MENU;selected=0;break;
      case PAGE_BT_INFO:page=PAGE_BLUETOOTH;selected=3;break;
      case PAGE_BT_RATE:page=PAGE_BLUETOOTH;selected=4;break;
      case PAGE_BT_PLAYER:page=PAGE_BLUETOOTH;selected=0;break;
      case PAGE_BT_SCAN:player.sendCommand({PR_BT,-1});page=PAGE_BT_SAVED;selected=4;break;
      case PAGE_BT_SAVED:page=PAGE_BLUETOOTH;selected=1;break;
      case PAGE_DAC_INFO:page=PAGE_OUTPUTS;selected=0;break;
      case PAGE_FS_INFO:page=PAGE_STORAGE;selected=3;break;
      case PAGE_ART_CACHE:page=PAGE_STORAGE;selected=2;break;
      case PAGE_WEB_UPDATE:page=PAGE_SYSTEM;selected=2;break;
      case PAGE_BUTTON_MAP:page=PAGE_CONTROLS;selected=2;break;
      default:page=PAGE_HOME;selected=0;break;
    }
    redraw=true;
}
static void activateMenu(unsigned p,unsigned item){
    if(p!=PAGE_SYSTEM||item!=3)restartArmedAt=0;
    if(p!=PAGE_BACKUP_MENU || (item!=1 && item!=3))backupArmedAt=0;
    if(!menuEnabled(p,item)){redraw=true;return;}
    if(p==PAGE_MAIN){page=item==0?PAGE_STATIONS:item==1?PAGE_SOUND:item==2?PAGE_BLUETOOTH:PAGE_SETTINGS;selected=0;redraw=true;return;}
    if(p==PAGE_STATIONS){
        if(item==0){
            if(config.getMode()==PM_SDCARD){
                if(player.sendCommand({PR_SOURCE,PM_WEB})){
                    pendingSourceTarget=PM_WEB;pendingSourceAt=millis();pendingSourceCancelSent=false;
                    page=PAGE_SOURCE_PENDING;selected=0;redraw=true;
                }
            }else openChannels();
        }
        else if(item==1)openFavorites();
        else if(item==2){searchQuery[0]=0;searchFound=0;searchState=0;page=PAGE_STATION_SEARCH;selected=0;redraw=true;}
        else if(item==3&&FEATURE_SD){
            if(config.getMode()==PM_SDCARD)openChannels();
            else if(player.sendCommand({PR_SOURCE,PM_SDCARD})){
                pendingSourceTarget=PM_SDCARD;pendingSourceAt=millis();pendingSourceCancelSent=false;
                page=PAGE_SOURCE_PENDING;selected=0;redraw=true;
            }
        }
        else if(item==4){page=PAGE_PLAYLIST_EDITOR;selected=0;redraw=true;}
        else goBack(p);return;
    }
    if(p==PAGE_SOUND){if(item==0)page=PAGE_VOLUME_STREAM;else if(item==1)page=PAGE_EQ;else if(item==2)page=PAGE_OUTPUTS;else if(item==3)page=PAGE_BLUETOOTH;else {goBack(p);return;}selected=0;redraw=true;return;}
    if(p==PAGE_BLUETOOTH){
        if(item==0){bluetoothMode(1);return;}
        if(item==1){page=PAGE_BT_SAVED;selected=btaudio::savedDeviceCount()?0:4;redraw=true;return;}
        if(item==2){bluetoothMode(-1);return;}
        if(item==3){page=PAGE_BT_INFO;selected=0;redraw=true;return;}
        if(item==4){page=PAGE_BT_RATE;selected=0;redraw=true;return;}
        goBack(p);return;}
    if(p==PAGE_BT_RATE){
        if(item<4){static const unsigned rates[]={16000,32000,44100,48000};
            if(player.isRunning()||player.status()!=STOPPED||!btaudio::setOutputRate(rates[item])){
                portENTER_CRITICAL(&mux);
                strlcpy(state.notice,"Allitsd le a lejatszast a BT beallitashoz",sizeof(state.notice));
                portEXIT_CRITICAL(&mux);
            }
            redraw=true;
        }else goBack(p);
        return;
    }
    if(p==PAGE_VU_TIMER){
        if(item<5){vuprobe::setRefresh(vuprobe::refreshOptions[item]);persistSetting(snapshot().settings);}
        goBack(p);redraw=true;return;
    }
    if(p==PAGE_IDLE){
        if(item<7){
            static const uint16_t seconds[]={10,20,30,60,120,300,0};
            Settings s=snapshot().settings;s.menuIdleSeconds=seconds[item];persistSetting(s);
            goBack(p);
        }else goBack(p);
        redraw=true;return;
    }
    if(p==PAGE_SETTINGS){
        if(item==0)page=PAGE_WIFI;else if(item==1)page=PAGE_DISPLAY;else if(item==2)page=PAGE_CONTROLS;
        else if(item==3)page=PAGE_STORAGE;else if(item==4)page=PAGE_SYSTEM;else if(item==5)page=PAGE_DIAGNOSTICS;else if(item==6)page=PAGE_IDLE;else if(item==7)page=PAGE_VU_TIMER;
        else {goBack(p);return;}
        selected=0;redraw=true;return;
    }
    if(p==PAGE_BACKUP_MENU){
        if(item<4){
            if(item==1 || item==3){
                uint32_t now=millis();
                if(!backupArmedAt || backupArmedItem!=item || uint32_t(now-backupArmedAt)>5000){
                    backupArmedAt=now;backupArmedItem=item;redraw=true;return;
                }
                if(uint32_t(now-backupArmedAt)<300)return;
            }
            backupArmedAt=0;
            backupsd::run(backupsd::Operation(item));
            page=PAGE_BACKUP_RESULT;selected=0;redraw=true;
        }else goBack(p);
        return;
    }
    if(p==PAGE_WIFI){
        if(item==0){networkParent=PAGE_WIFI;page=PAGE_NETWORK_INFO;selected=0;redraw=true;return;}
        if(item==1){network.startSetup();page=PAGE_HOME;selected=0;redraw=true;return;}
        if(item==2){page=PAGE_SAVED_WIFI;selected=0;redraw=true;return;}
        if(item==3){page=PAGE_WIFI_SCAN;selected=0;network.requestScan();redraw=true;return;}
        goBack(p);return;
    }
    if(p==PAGE_DISPLAY){if(item<=9)editDisplay(item);else goBack(p);return;}
    if(p==PAGE_CONTROLS){
        if(item==0)editControls(item);
        else if(item==1){
            if(player.isRunning())return;
            uint8_t rotation=state.settings.rotation;
            front::setRotation(0);calibrateTouch(true);front::setRotation(rotation);
            redraw=true;
        }else if(item==2){page=PAGE_BUTTON_MAP;selected=0;redraw=true;}else goBack(p);return;
    }
    if(p==PAGE_STORAGE){if(item==0){memoryParent=PAGE_STORAGE;page=PAGE_MEMORY;selected=0;redraw=true;}else if(item==1&&FEATURE_SD){page=PAGE_SD_INFO;selected=0;redraw=true;}else if(item==2||item==3){page=item==2?PAGE_ART_CACHE:PAGE_FS_INFO;selected=0;redraw=true;}else goBack(p);return;}
    if(p==PAGE_SYSTEM){
        if(item==0)editSystem(item);
        else if(item==1){page=PAGE_FIRMWARE_INFO;selected=0;redraw=true;}
        else if(item==2){page=PAGE_WEB_UPDATE;selected=0;redraw=true;}
        else if(item==4){page=PAGE_BACKUP_MENU;selected=0;redraw=true;}
        else if(item==3){
            if(player.isRunning()||snapshot().pendingSave||audioSettingPending){restartArmedAt=0;return;}
            uint32_t now=millis();
            if(!restartArmedAt||uint32_t(now-restartArmedAt)>5000){restartArmedAt=now;return;}
            ESP.restart();
        }else goBack(p);return;
    }
    if(p==PAGE_DIAGNOSTICS){
        if(item==0)editDiagnostics(item);
        else if(item==1){memoryParent=PAGE_DIAGNOSTICS;page=PAGE_MEMORY;selected=0;redraw=true;}
        else if(item==2){networkParent=PAGE_DIAGNOSTICS;page=PAGE_NETWORK_INFO;selected=0;redraw=true;}
        else if(item==3){page=PAGE_ROTARY_DEBUG;selected=0;redraw=true;}
        else if(item==4){page=PAGE_MEMORY_STRESS;selected=0;stressState=0;redraw=true;}
        else goBack(p);
        return;
    }
    if(p==PAGE_VOLUME_STREAM){if(item<=1)editVolumeStream(item);else if(item==2)send(Action::Balance);else goBack(p);return;}
    if(p==PAGE_EQ){if(item<3)send(item==0?Action::EqBass:item==1?Action::EqMiddle:Action::EqTreble);else goBack(p);return;}
    if(p==PAGE_OUTPUTS){if(item==0){player.sendCommand({PR_BT,-1});page=PAGE_DAC_INFO;selected=0;redraw=true;}else if(item==2||item==3){page=PAGE_BLUETOOTH;selected=item==2?1:0;redraw=true;}else goBack(p);return;}
}
static void btPlayerKey(unsigned key){
    if(key==0)btaudio::control(2);
    else if(key==1)btaudio::control(0);
    else if(key==2)btaudio::control(3);
    else if(key==3)send(Action::VolDown);
    else if(key==4)btaudio::control(1);
    else if(key==5)send(Action::VolUp);
    redraw=true;
}
static void doShortPress() {
    if(page==PAGE_BT_SAVED){if(selected==4)bluetoothMode(0);else reconnectDevice(selected);return;}
    if(page==PAGE_BT_SCAN){
        if(btaudio::deviceCount())btaudio::selectDevice(selected);
        else if(!btaudio::scanning())btaudio::restartScan();
        return;
    }
    if(page==PAGE_BT_PLAYER){btaudio::control(btaudio::inputPlaying()?1:0);return;}
    if(page==PAGE_STATIONS_LIST){commitStation((uint16_t)selected);return;}
    if(page==PAGE_FAVORITES_LIST){if(selected)commitStation((uint16_t)selected);else goBack(page);return;}
    if(page==PAGE_STATION_SEARCH){searchKey(selected);return;}
    if(page==PAGE_SEARCH_RESULTS){uint16_t n=stationSearchResult(selected);if(n)commitStation(n);else goBack(page);return;}
    if(page==PAGE_MEMORY_STRESS){runMemoryStress();return;}
    if(menuCount(page)){activateMenu(page,selected);return;}
    if(page!=PAGE_HOME){goBack(page);return;}
    // On the main screen a short rotary press toggles playback.
    send(Action::Toggle);
}
static void input(Action a) {
    if(a!=Action::None)menuActivityAt=millis();
    if(uiStressActive&&!uiStressInjecting)r10UiStressStop("user_input");
    if(!uiStressInjecting){
        const bool critical=a==Action::EncoderDown||a==Action::EncoderShort||a==Action::EncoderLong||
          a==Action::Menu||a==Action::Toggle||a==Action::Prev||a==Action::Next||
          a==Action::WinampPlay||a==Action::WinampPause||
          a==Action::Source||a==Action::SourceWeb||a==Action::SourceSd;
        const bool rotary=a==Action::RotCW||a==Action::RotCCW||a==Action::VolUp||a==Action::VolDown;
        if(!uiGovernor.admit(millis(),critical?UiGovernor::Kind::Critical:
              rotary?UiGovernor::Kind::Rotary:UiGovernor::Kind::Other,player.isRunning())){
            portENTER_CRITICAL(&mux);state.inputDrops++;portEXIT_CRITICAL(&mux);
            return;
        }
    }
    if(a==Action::EncoderLong){
        if(page==PAGE_WIFI_PASSWORD)clearWifiPassword();
        if(page==PAGE_SOURCE_PENDING && pendingSourceTarget==PM_SDCARD)
            player.sendCommand({PR_SOURCE,PM_WEB});
        // A short press followed by a held second press is a distinct gesture.
        if(page==PAGE_HOME&&shortPending&&secondDown&&network.status!=SOFT_AP&&!btaudio::transmitting()){
            shortPending=false;secondDown=false;stationPreview=false;
            openMainMenu();return;
        }
#if defined(BOARD_CYD28)
        front::skinPreview(-1);
#endif
        if(page==PAGE_HOME && network.status!=SOFT_AP){
            shortPending=false;secondDown=false;
            openChannels();return;
        }
        r10DiagRecoverHome();return;
    }
#if defined(BOARD_CYD28)
    if(front::skinPreviewInput(a)){shortPending=false;secondDown=false;redraw=true;return;}
#endif
    uint32_t now=millis();
    if(page==PAGE_WIFI_PASSWORD){
        if(a==Action::RotCW||a==Action::VolUp||a==Action::Next){selected=(selected+1)%40;redraw=true;}
        else if(a==Action::RotCCW||a==Action::VolDown||a==Action::Prev){selected=(selected+39)%40;redraw=true;}
        else if(a==Action::Select||a==Action::Toggle||a==Action::EncoderShort)wifiPasswordKeyPress(selected);
        else if(a==Action::Menu)goBack(page);
        return;
    }
    if(page==PAGE_WIFI_SCAN){
        const unsigned count=network.scanCount();
        if((a==Action::RotCW||a==Action::VolUp||a==Action::Next)&&count){selected=(selected+1)%count;redraw=true;}
        else if((a==Action::RotCCW||a==Action::VolDown||a==Action::Prev)&&count){selected=(selected+count-1)%count;redraw=true;}
        else if(a==Action::Menu&&count)openSelectedWifiPassword(selected);
        else if(a==Action::Select||a==Action::Toggle||a==Action::EncoderShort){
            if(count)chooseScannedWifi(selected);
            else if(network.scanStatus()!=1){network.requestScan();redraw=true;}
        }
        return;
    }
    if(network.status==SOFT_AP){
        if(a==Action::EncoderShort||a==Action::Select||a==Action::Toggle||a==Action::Menu){page=page==PAGE_WIFI_QR?PAGE_HOME:PAGE_WIFI_QR;selected=0;redraw=true;}
        else if(a==Action::EncoderLong){page=PAGE_HOME;selected=0;redraw=true;}
        return;
    }
    if(a==Action::EncoderDown) {
        if(page==PAGE_HOME && shortPending && uint32_t(now-shortAt)<=500) secondDown=true;
        return;
    }
    if(a==Action::EncoderShort) {
        if(page!=PAGE_HOME){doShortPress();return;}
        if(secondDown){doShortPress();shortPending=false;secondDown=false;return;}
        shortPending=true;shortAt=now;return;
    }
    if(a==Action::Menu){if(!btaudio::transmitting())openMainMenu();return;}
    if(page==PAGE_BT_PLAYER){
        if(a==Action::RotCW||a==Action::VolUp)send(Action::VolUp);
        else if(a==Action::RotCCW||a==Action::VolDown)send(Action::VolDown);
        else if(a==Action::Next)btaudio::control(3);
        else if(a==Action::Prev)btaudio::control(2);
        else if(a==Action::Select||a==Action::Toggle)btaudio::control(btaudio::inputPlaying()?1:0);
        return;
    }
    if(page==PAGE_BT_SCAN){
        unsigned n=btaudio::deviceCount();
        if(n){
            if(a==Action::RotCW||a==Action::VolUp||a==Action::Next)selected=(selected+1)%n;
            else if(a==Action::RotCCW||a==Action::VolDown||a==Action::Prev)selected=(selected+n-1)%n;
            else if(a==Action::Select||a==Action::Toggle)btaudio::selectDevice(selected);
        }else if((a==Action::Select||a==Action::Toggle)&&!btaudio::scanning())btaudio::restartScan();
        return;
    }
    if(page==PAGE_BT_SAVED){
        unsigned n=btaudio::savedDeviceCount();
        if(a==Action::RotCW||a==Action::VolUp||a==Action::Next)
            selected=selected==4?(n?0:4):selected+1<n?selected+1:4;
        else if(a==Action::RotCCW||a==Action::VolDown||a==Action::Prev)
            selected=selected==4?(n?n-1:4):selected?selected-1:4;
        else if(a==Action::Select||a==Action::Toggle){if(selected==4)bluetoothMode(0);else reconnectDevice(selected);}
        redraw=true;
        return;
    }
    if(page==PAGE_STATION_SEARCH){
        if(a==Action::RotCW||a==Action::VolUp||a==Action::Next)selected=(selected+1)%30;
        else if(a==Action::RotCCW||a==Action::VolDown||a==Action::Prev)selected=(selected+29)%30;
        else if(a==Action::Select||a==Action::Toggle)searchKey(selected);
        redraw=true;return;
    }
    if(page==PAGE_SEARCH_RESULTS){
        if(searchFound){
            if(a==Action::RotCW||a==Action::VolUp||a==Action::Next)selected=(selected+1)%searchFound;
            else if(a==Action::RotCCW||a==Action::VolDown||a==Action::Prev)selected=(selected+searchFound-1)%searchFound;
            else if(a==Action::Select||a==Action::Toggle)commitStation(stationSearchResult(selected));
        }
        redraw=true;return;
    }
    if(page==PAGE_MEMORY_STRESS){
        if(a==Action::Select||a==Action::Toggle)runMemoryStress();
        return;
    }
    if(page==PAGE_STATIONS_LIST||page==PAGE_FAVORITES_LIST) {
        bool favPage=page==PAGE_FAVORITES_LIST;
        if(a==Action::RotCW||a==Action::VolUp||a==Action::Next) selected=favPage?nextFavorite((uint16_t)selected,true):wrapStation(int(selected)+1);
        else if(a==Action::RotCCW||a==Action::VolDown||a==Action::Prev) selected=favPage?nextFavorite((uint16_t)selected,false):wrapStation(int(selected)-1);
        else if((a==Action::Select||a==Action::Toggle)&&selected)commitStation((uint16_t)selected);
        redraw=true;return;
    }
    unsigned count=menuCount(page);
    if(count) {
        if(a==Action::RotCW||a==Action::VolUp||a==Action::Next||a==Action::RotCCW||a==Action::VolDown||a==Action::Prev){
            bool forward=a==Action::RotCW||a==Action::VolUp||a==Action::Next;
            for(unsigned i=0;i<count;i++){
                selected=forward?(selected+1)%count:(selected+count-1)%count;
                if(menuEnabled(page,selected))break;
            }
            restartArmedAt=0;redraw=true;
        }
        else if(a==Action::Select||a==Action::Toggle)activateMenu(page,selected);
        return;
    }
    if(page!=PAGE_HOME){
        if(a==Action::Select||a==Action::Toggle)goBack(page);
        return;
    }
    if(a==Action::RotCW||a==Action::RotCCW) {
        Settings s=snapshot().settings;
        if(s.rotaryMode==1) send(a==Action::RotCW?Action::VolUp:Action::VolDown);
        else {
            if(!stationPreview){channelCursor=wrapStation(config.lastStation()?config.lastStation():1);stationPreview=true;}
            channelCursor=wrapStation(int(channelCursor)+(a==Action::RotCW?1:-1));
            showStationPreview(channelCursor);
        }
        return;
    }
    send(a==Action::Select?Action::Toggle:a);
}
void uiLoop() {
    if(!initialized)return;
    const uint32_t pressureNow=millis();
    const bool beforePressure=uiGovernor.active(pressureNow);
    uint32_t pressureBuffer,pressureHeap,pressureDrops;
    portENTER_CRITICAL(&mux);
    pressureBuffer=state.buffer;pressureHeap=state.freeHeap;pressureDrops=state.queueDrops;
    portEXIT_CRITICAL(&mux);
    uiGovernor.observe(pressureNow,player.isRunning(),pressureBuffer,pressureHeap,
      commands?uxQueueMessagesWaiting(commands):0,player.queueDepth(),player.audioGapEvents(),
      pressureDrops,player.commandDrops());
    if(beforePressure!=uiGovernor.active(pressureNow))redraw=true;
    board::poll(input);
    btRateTick(millis());
    if(pendingSourceAt){
        const auto status=player.sdPrepareState();
        if(pendingSourceTarget==PM_SDCARD){
            if(status==SdPrepareState::Ready && config.getMode()==PM_SDCARD){
                pendingSourceAt=0;if(page==PAGE_SOURCE_PENDING){page=PAGE_HOME;selected=0;redraw=true;}
            }else if(uint32_t(millis()-pendingSourceAt)>52000 &&
                     status!=SdPrepareState::Failed && status!=SdPrepareState::Cancelled &&
                     !pendingSourceCancelSent){
                pendingSourceCancelSent=player.sendCommand({PR_SOURCE,PM_WEB});redraw=true;
            }
        }else if(config.getMode()==PM_WEB && status!=SdPrepareState::Indexing){
            pendingSourceAt=0;if(page==PAGE_SOURCE_PENDING){page=PAGE_HOME;selected=0;redraw=true;}
        }
    }
    if((page==PAGE_BT_SCAN||page==PAGE_BT_SAVED)&&btaudio::transmitting()){
        page=PAGE_HOME;selected=0;redraw=true;
    }
    if(page==PAGE_WIFI_PASSWORD&&wifiEntry.submitted&&network.status!=SOFT_AP){
        clearWifiPassword();page=PAGE_HOME;selected=0;redraw=true;
    }
    uint32_t now=millis();
    r10UiStressTick(now);
    // Keep controls responsive, but leave the display bus idle briefly after
    // a long audio-service gap so the decoder/network path can recover first.
    static uint32_t seenAudioGaps=0,quietUiUntil=0;
    const uint32_t audioGaps=player.audioGapEvents();
    if(audioGaps!=seenAudioGaps){seenAudioGaps=audioGaps;quietUiUntil=now+2000;}
    // The main network loop owns Wi-Fi scan APIs; UI only requests/cancels.
    if(page!=PAGE_WIFI_SCAN && network.scanStatus()==1)network.cancelScan();
    if(page==PAGE_WIFI_SCAN && network.status!=SOFT_AP &&
       (player.isRunning()||player.status()==PLAYING))network.cancelScan();
    if(network.status!=SOFT_AP && page==PAGE_WIFI_QR){page=PAGE_HOME;selected=0;redraw=true;}
    if(shortPending && !secondDown && uint32_t(now-shortAt)>500){shortPending=false;doShortPress();}
    static bool down=false,longPress=false;static uint32_t pressed=0;static Point start;
    Point p;bool nowDown=board::touch(p);
    if(nowDown||down)menuActivityAt=now;
    if(nowDown&&!down){pressed=now;start=p;longPress=false;}
    if(nowDown&&down&&!longPress&&uint32_t(now-pressed)>=800) {
        longPress=true;
        input(Action::EncoderLong);
    }
    if(!nowDown&&down&&!longPress&&uint32_t(now-pressed)>=40) {
        Snapshot snap=snapshot();Size native=front::nativeSize();Size dim=logicalSize(native,snap.settings.rotation);
        Point q=toLogical(start,native,snap.settings.rotation);
        bool essentialTouch=q.y<40||
            (page==PAGE_HOME&&btaudio::transmitting()&&q.y>=116&&q.y<148&&q.x>=20&&q.x<300)||
            (page==PAGE_HOME&&snap.settings.winampEnabled&&dim.w==320&&dim.h==240&&
             q.y>=89&&q.y<112&&(q.x<158||(q.x>=185&&q.x<247)));
#if defined(BOARD_CYD28)
        if(page==PAGE_HOME && cassette::hit(dim,q)==Action::Toggle)essentialTouch=true;
#endif
        if(!uiStressInjecting && !uiGovernor.admit(now,essentialTouch?UiGovernor::Kind::Critical:
              UiGovernor::Kind::Touch,player.isRunning())){
            portENTER_CRITICAL(&mux);state.inputDrops++;portEXIT_CRITICAL(&mux);
        }else{
#if defined(BOARD_CYD28)
        if(front::skinPreviewActive()){
            input(q.x>=dim.w-52&&q.y>=dim.h-52?Action::Menu:q.x<dim.w/2?Action::Prev:Action::Next);
        } else
#endif
        if(page==PAGE_WIFI_PASSWORD){
            if(q.y<24)goBack(page);
            else if(q.x>=8&&q.x<8+8*((dim.w-16)/8)&&q.y>=91&&q.y<91+5*((dim.h-99)/5)){
                const unsigned key=unsigned((q.y-91)/((dim.h-99)/5))*8+unsigned((q.x-8)/((dim.w-16)/8));
                if(key<40){selected=key;wifiPasswordKeyPress(key);}
            }
        } else if(network.status==SOFT_AP){
            if(page==PAGE_WIFI_QR){if(q.y>=dim.h-48){page=PAGE_HOME;redraw=true;}}
            else if(page==PAGE_WIFI_SCAN){
                if(q.y<36){if(q.x>=dim.w-90)network.requestScan();else goBack(page);redraw=true;}
                else if(q.y>=39&&q.y<39+6*26){
                    const unsigned count=network.scanCount(),rows=6;
                    unsigned first=selected>=rows/2?selected-rows/2:0;
                    if(count>rows&&first>count-rows)first=count-rows;
                    unsigned index=first+unsigned((q.y-39)/26);
                    if(index<count){selected=index;chooseScannedWifi(index);redraw=true;}
                }else if(q.y>=dim.h-40&&q.x<120&&network.scanCount())openSelectedWifiPassword(selected);
            }
            else if(q.x>=dim.w-92&&q.y<36){page=PAGE_WIFI_SCAN;selected=0;network.requestScan();redraw=true;}
            else if(q.x>=dim.w-84&&q.y>=dim.h-54){page=PAGE_WIFI_QR;selected=0;redraw=true;}
        } else if(page==PAGE_WIFI_SCAN){
            if(q.y<36){goBack(page);}
            else if(q.y>=46&&q.y<46+5*28){
                unsigned count=network.scanCount(),rows=5;
                unsigned first=selected>=rows/2?selected-rows/2:0;
                if(count>rows&&first>count-rows)first=count-rows;
                unsigned index=first+unsigned((q.y-46)/28);if(index<count){selected=index;chooseScannedWifi(index);redraw=true;}
            }else if(q.y>=dim.h-40&&q.x<120&&network.scanCount())openSelectedWifiPassword(selected);
        } else if(page==PAGE_STATIONS_LIST||page==PAGE_FAVORITES_LIST){
            if(q.y<(page==PAGE_STATIONS_LIST&&snap.settings.winampEnabled?23:40))goBack(page);
            else {uint16_t n=stationAtTouch(start,page);if(n){selected=n;commitStation(n);}}
        } else if(page==PAGE_BT_SAVED){
            if(q.y<36)goBack(page);
            else if(q.y<36+5*30){unsigned i=unsigned((q.y-36)/30);
                if(i==4){selected=4;bluetoothMode(0);}
                else if(i<btaudio::savedDeviceCount()){selected=i;reconnectDevice(i);}}
        } else if(page==PAGE_BT_SCAN){
            unsigned n=btaudio::deviceCount(),rows=unsigned((dim.h-36)/26);
            unsigned first=selected>=rows/2?selected-rows/2:0;
            if(n>rows&&first>n-rows)first=n-rows;
            if(q.y<36&&q.x<dim.w-32)goBack(page);
            else if(q.y>=36&&q.y<36+int(rows)*26){unsigned i=first+unsigned((q.y-36)/26);if(i<n){selected=i;btaudio::selectDevice(i);}
                else if(!n&&!btaudio::scanning())btaudio::restartScan();}
        } else if(page==PAGE_BT_PLAYER){
            int cw=(dim.w-16)/3,ch=(dim.h-80)/2;
            if(q.x>=8&&q.x<8+3*cw&&q.y>=70&&q.y<70+2*ch)btPlayerKey(unsigned((q.y-70)/ch)*3+unsigned((q.x-8)/cw));
        } else if(page==PAGE_STATION_SEARCH){
            if(q.y<40)goBack(page);
            else if(q.x>=10&&q.y>=65){
                int keyW=(dim.w-20)/6,keyH=(dim.h-90)/5;
                if(keyW>0&&keyH>0&&q.x<10+keyW*6&&q.y<65+keyH*5){
                    unsigned key=unsigned((q.y-65)/keyH)*6+unsigned((q.x-10)/keyW);
                    if(key<30){selected=key;searchKey(key);}
                }
            }
        } else if(page==PAGE_SEARCH_RESULTS){
            if(q.y<40||q.y>=dim.h-34)goBack(page);
            else if(q.y>=56&&q.y<56+6*23){
                unsigned first=selected>=2?selected-2:0;
                if(searchFound>6&&first>searchFound-6)first=searchFound-6;
                unsigned i=first+unsigned((q.y-56)/23);
                uint16_t n=stationSearchResult(i);if(n){selected=i;commitStation(n);}
            }
        } else if(page==PAGE_MEMORY_STRESS){
            if(q.y<40||q.y>=dim.h-40)goBack(page);
            else if(q.y>=70&&q.y<150)runMemoryStress();
        } else {
            unsigned count=menuCount(page);
            if(count){
                unsigned first=page==PAGE_DISPLAY&&selected>=4?selected-4:0;
                if(page==PAGE_DISPLAY&&first+8>count)first=count-8;
                int rowHeight=page==PAGE_DISPLAY?23:(dim.h-52)/int(count);
                int row=(q.y-44)/rowHeight;
                if(q.y>=44&&row>=0&&row<int(page==PAGE_DISPLAY?8:count)){selected=first+(unsigned)row;activateMenu(page,selected);}
            } else if(page!=PAGE_HOME){goBack(page);}
            else {
#if defined(BOARD_CYD28)
                if(btaudio::transmitting()&&!ibtsdui::classic(true,snap.sd,snap.settings.winampEnabled)&&q.y>=116&&q.y<148&&q.x>=20&&q.x<300){
                    if(q.x<155){
                        btRatePhase=BtRatePhase::Idle;
                        if(player.sendCommand({PR_BT,-1}))
                            Serial.println("[BT-UI] BT_OFF=REQUESTED DAC_RESTORE=YES");
                        else btRateNotice("BT: kilepes parancs sikertelen");
                    }else btRateTouch();
                }else if(btaudio::transmitting()&&!ibtsdui::classic(true,snap.sd,snap.settings.winampEnabled)&&q.y>=181&&q.y<204&&q.x>=20&&q.x<=300){
                    const int target=constrain((q.x-20)*254/280,0,254);
                    if(player.sendCommand({PR_VOL,target}))redraw=true;
                }else if(snap.settings.winampEnabled&&dim.w==320&&dim.h==240){
                    if(q.y>=61&&q.y<75&&q.x>=124&&q.x<=199){
                        const int target=constrain((q.x-124)*254/61,0,254);
                        if(player.sendCommand({PR_VOL,target}))redraw=true;
                    }else if(q.y>=90&&q.y<112){
                        if(q.x<37)input(Action::Prev);
                        else if(q.x<67)input(Action::WinampPlay);
                        else if(q.x<97)input(Action::WinampPause);
                        else if(q.x<126){player.sendCommand({PR_STOP,0});redraw=true;}
                        else if(q.x<157)input(Action::Next);
                        else if(q.x<185)openChannels();
                        else if(q.x<247){page=PAGE_BT_SAVED;selected=btaudio::savedDeviceCount()?0:4;redraw=true;}
                        else if(q.x>=279)openMainMenu();
                    }
                }
                else if(snap.settings.cassetteEnabled&&snap.settings.btQuickScan&&
                   front::cassetteReady()&&!btaudio::connected()&&cassette::btQuickHit(dim,q))
                    bluetoothMode(0);
                else {Action a=cassette::hit(dim,q);if(a!=Action::None)input(a);}
#else
                if(q.y>=dim.h-44){int col=q.x*5/dim.w;const Action actions[]={Action::Prev,Action::Toggle,Action::Next,Action::Source,Action::Menu};if(col>=0&&col<5)input(actions[col]);}
#endif
            }
        }
        } // accepted touch
    }
    down=nowDown;
    // Inactivity navigation never issues stop, source-change or BT disconnect.
    static unsigned idlePage=PAGE_HOME;
    if(page!=idlePage){idlePage=page;menuActivityAt=now;}
    uint16_t idleSeconds;
    portENTER_CRITICAL(&mux);idleSeconds=state.settings.menuIdleSeconds;portEXIT_CRITICAL(&mux);
    if(page==PAGE_HOME)menuActivityAt=now;
    else if(idleSeconds&&!uiStressActive&&uint32_t(now-menuActivityAt)>=uint32_t(idleSeconds)*1000u){
        backupArmedAt=0;restartArmedAt=0;
        if(page==PAGE_WIFI_PASSWORD&&!wifiEntry.submitted)clearWifiPassword();
        r10DiagRecoverHome();idlePage=PAGE_HOME;menuActivityAt=now;
    }
    static uint32_t renderAt=0,btRenderAt=0;
    static bool btMinimalUi=false;
    const bool sdBtClassic=ibtsdui::classic(btaudio::transmitting(),config.getMode()==PM_SDCARD,snapshot().settings.winampEnabled);
    if(frontendOK&&btaudio::transmitting()&&!sdBtClassic){
        if(!btMinimalUi||uint32_t(now-btRenderAt)>=1000){
            btRenderAt=now;Snapshot s=snapshot();
            front::renderBtMinimal(s,page==PAGE_STATIONS_LIST?4:0,selected,!btMinimalUi);
            btMinimalUi=true;redraw=false;
        }
        return;
    }
    if(btMinimalUi){btMinimalUi=false;front::invalidate();redraw=true;}
    if(frontendOK&&ibtsdui::due(sdBtClassic,uint32_t(now-renderAt))&&(!player.isRunning()||int32_t(now-quietUiUntil)>=0)&&
       (uiStressActive?uint32_t(now-renderAt)>=uiStressDrawMs:
        (redraw||uint32_t(now-renderAt)>=(vuprobe::dacEnabled.load(std::memory_order_relaxed)?unsigned(vuprobe::refreshMs.load(std::memory_order_relaxed)):250u)))) {
        renderAt=now;Snapshot s=snapshot();front::render(s,page,selected,redraw);redraw=false;
        if(uiStressActive){
            ++uiStressRenderCalls;
            if(uiStressActions!=uiStressRenderedActions){++uiStressFrames;uiStressRenderedActions=uiStressActions;}
        }
        if(network.status!=SOFT_AP&&!btaudio::wanted()){
            if(s.settings.cassetteEnabled&&!s.settings.winampEnabled){
                if(s.sd)artwork::uiTick(s.generation,page==0);
                else onlineart::uiTick(s.generation,page==0);
            }
        }
    }
    if(frontendOK)front::service();
}
void audioLoop() {
    if(!initialized)return;
    Action a;
    if(commands&&xQueueReceive(commands,&a,0)==pdTRUE) {
        switch(a) {
        case Action::Prev:player.prev();break;
        case Action::Next:player.next();break;
        case Action::Toggle:player.toggle();break;
        case Action::WinampPlay:
            if(player.status()!=PLAYING)player.toggle();
            break;
        case Action::WinampPause:
            if(player.status()==PLAYING)player.toggle();
            break;
        case Action::VolDown:player.stepVol(false);break;
        case Action::VolUp:player.stepVol(true);break;
        case Action::Source:
        case Action::SourceWeb:
        case Action::SourceSd:
#if FEATURE_SD
            {
                auto target=a==Action::SourceWeb?PM_WEB:a==Action::SourceSd?PM_SDCARD:
                    (config.getMode()==PM_WEB?PM_SDCARD:PM_WEB);
                if(target!=config.getMode())player.sendCommand({PR_SOURCE,int(target)});
            }
#endif
            break;
        case Action::EqBass:
        case Action::EqMiddle:
        case Action::EqTreble: {
            int8_t* value=a==Action::EqBass?&config.store.bass:a==Action::EqMiddle?&config.store.middle:&config.store.trebble;
            int8_t next=*value>=6?-12:*value+2;
            config.saveValue(value,next,false);
            player.setTone(config.store.bass,config.store.middle,config.store.trebble);
            audioSettingPending=true;redraw=true;break;
        }
        case Action::Balance: {
            int8_t next=config.store.balance>=16?-16:config.store.balance+2;
            config.saveValue(&config.store.balance,next,false);
            player.setBalance(config.store.balance);
            audioSettingPending=true;redraw=true;break;
        }
        default:break;
        }
    }
    // Publish handled volume immediately instead of waiting for the500ms telemetry snapshot.
    portENTER_CRITICAL(&mux);
    if(state.volume!=config.store.volume){state.volume=config.store.volume;redraw=true;}
    portEXIT_CRITICAL(&mux);
    uint32_t now=millis();bool running=player.isRunning()||btaudio::wanted();
    // Source changes are serialized by the audio owner, after stopping playback.
    uint32_t buffered=player.inBufferFilled();
    ibtlimit::publishAudio(running||player.status()==PLAYING,buffered,now);
    if(!btaudio::wanted())artwork::audioTick(running,player.eofHeader||player.getAudioDataStartPos()>0,buffered);
    if(uint32_t(now-lastSnapshot)>=500) {
        lastSnapshot=now;Snapshot s=snapshot();
        s.playing=running;s.sd=config.getMode()==PM_SDCARD;
        s.bitrate=config.station.bitrate;s.volume=config.store.volume;
        s.bass=config.store.bass;s.middle=config.store.middle;s.treble=config.store.trebble;s.balance=config.store.balance;
        s.sampleRate=player.getSampleRate();s.elapsed=player.getAudioCurrentTime();s.duration=player.getAudioFileDuration();
        s.buffer=buffered;s.bufferCapacity=buffered+player.inBufferFree();s.freeHeap=heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
        s.largestHeap=heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
        s.freePsram=ESP.getFreePsram();s.connected=WiFi.status()==WL_CONNECTED;s.rssi=s.connected?WiFi.RSSI():0;
        textCopy(s.station,sizeof(s.station),config.station.name);
        if(s.sd)snprintf(s.station,sizeof(s.station),"SD / %u",config.lastStation());
        if(!s.sd)textCopy(s.title,sizeof(s.title),config.station.title);
        IPAddress ip=s.connected?WiFi.localIP():WiFi.softAPIP();
        snprintf(s.ip,sizeof(s.ip),"%u.%u.%u.%u",unsigned(ip[0]),unsigned(ip[1]),unsigned(ip[2]),unsigned(ip[3]));
        // Explicit radio admission policy. It cannot lower bitrate at the transmitting station.
        if(running&&!s.sd&&s.settings.maxKbps&&s.bitrate>s.settings.maxKbps&&!bitrateRejected) {
            bitrateRejected=true;player.sendCommand({PR_STOP,0});
            snprintf(s.notice,sizeof(s.notice),"%u > %u kbit/s. Lower bitrate URL required.",s.bitrate,s.settings.maxKbps);
        }
        if(!btaudio::wanted()&&btaudio::linkFailed())textCopy(s.notice,sizeof(s.notice),"BT hiba: 9 proba utan DAC");
        if(btaudio::wanted()){
            if(btaudio::inputSelected())textCopy(s.station,sizeof(s.station),"Bluetooth IN");
            // OUT retains station metadata.
            textCopy(s.title,sizeof(s.title),btaudio::status());
        }
        bool nextLow=player.isRunning()&&buffered<1600;
        if(nextLow&&!low)s.lowBufferEvents++;low=nextLow;
        portENTER_CRITICAL(&mux);
        // Audio metadata callbacks run on this core; only UI settings can change here.
        s.settings=state.settings;s.pendingSave=state.pendingSave;s.queueDrops=state.queueDrops;
        s.inputDrops=state.inputDrops;state=s;
        portEXIT_CRITICAL(&mux);
        const bool vuOn=s.settings.winampEnabled&&running&&!btaudio::wanted();
        vuprobe::dacEnabled.store(vuOn,std::memory_order_relaxed);
        if(!vuOn){vuprobe::dacLeft.store(0,std::memory_order_relaxed);
            vuprobe::dacRight.store(0,std::memory_order_relaxed);}
    }
    // Flash commits run only with playback stopped; no UI-triggered flash stall during audio.
    portENTER_CRITICAL(&mux);
    bool needsSave=settingsVersion!=savedVersion;
    portEXIT_CRITICAL(&mux);
    if(!running&&player.status()==STOPPED&&needsSave&&int32_t(now-nextSettingsCommit)>=0) {
        Settings s;uint32_t version;
        portENTER_CRITICAL(&mux);s=state.settings;version=settingsVersion;portEXIT_CRITICAL(&mux);
        Preferences p;bool ok=p.begin("yo-dual-v1",false);
        if(ok){ok=p.putUChar("lang",unsigned(s.language))==1 && p.putUChar("theme",unsigned(s.theme))==1
          &&p.putUChar("rotate",s.rotation)==1&&p.putUChar("bright",s.brightness)==1&&p.putUShort("rate",s.maxKbps)==2
          &&p.putUChar("rotmode",s.rotaryMode)==1&&p.putUChar("volstep",s.volumeStep)==1
          &&p.putUChar("debug",s.debug?1:0)==1&&p.putUChar("artwork",s.artworkEnabled?1:0)==1
          &&p.putUChar("cassette",s.cassetteEnabled?1:0)==1
          &&p.putUChar("bufbar",s.bufferIndicator?1:0)==1
          &&p.putUChar("reels",s.reelAnimation?1:0)==1
          &&p.putUChar("wifibar",s.wifiIndicator?1:0)==1
          &&p.putUChar("btquick",s.btQuickScan?1:0)==1
          &&p.putUChar("winamp",s.winampEnabled?1:0)==1&&p.putUShort("menuidle",s.menuIdleSeconds)==2&&p.putUShort("vutimer",vuprobe::refreshMs.load(std::memory_order_relaxed))==2;p.end();}
        if(ok){portENTER_CRITICAL(&mux);savedVersion=version;state.pendingSave=settingsVersion!=savedVersion||favoriteVersion!=favoriteSaved;portEXIT_CRITICAL(&mux);}
        else nextSettingsCommit=now+5000;
    }
    portENTER_CRITICAL(&mux);bool favoritesNeedSave=favoriteVersion!=favoriteSaved;portEXIT_CRITICAL(&mux);
    if(!running&&player.status()==STOPPED&&favoritesNeedSave&&int32_t(now-nextFavoriteCommit)>=0){
        uint8_t bits[sizeof(favoriteBits)];uint32_t version,hash;
        portENTER_CRITICAL(&mux);memcpy(bits,favoriteBits,sizeof(bits));version=favoriteVersion;hash=favoritePlaylistHash;portEXIT_CRITICAL(&mux);
        if(!hash)hash=playlistHash();
        Preferences p;bool ok=p.begin("yo-dual-v1",false);
        if(ok){ok=p.putBytes("favorites",bits,sizeof(bits))==sizeof(bits)&&p.putUInt("favhash",hash)==4;p.end();}
        if(ok){portENTER_CRITICAL(&mux);favoriteSaved=version;if(favoriteVersion==version)favoritePlaylistHash=hash;state.pendingSave=settingsVersion!=savedVersion||favoriteVersion!=favoriteSaved;portEXIT_CRITICAL(&mux);}
        else nextFavoriteCommit=now+5000;
    }
    if(!running&&player.status()==STOPPED&&audioSettingPending&&int32_t(now-nextAudioCommit)>=0){
        if(EEPROM.commit())audioSettingPending=false;else nextAudioCommit=now+5000;
    }
    if(debugEnabled() && uint32_t(now-lastDiag)>=10000) {
        lastDiag=now;Snapshot s=snapshot();
        Serial.printf("[DUAL] play=%u heap=%lu largest=%lu psram=%lu input=%lu low=%lu drop=%lu rate=%u\n",s.playing,(unsigned long)s.freeHeap,(unsigned long)s.largestHeap,(unsigned long)s.freePsram,(unsigned long)s.buffer,(unsigned long)s.lowBufferEvents,(unsigned long)s.queueDrops,s.bitrate);
    }
}
}
