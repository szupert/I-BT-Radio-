#pragma once
#include <stdint.h>
namespace dual {
// Time-based radio recovery. Explicit Stop or source changes cancel the intent.
class StreamRecovery {
public:
    enum class Reason : uint8_t { None, LowBuffer, BtNoProduction };
    uint16_t station=0;
    Reason lastReason=Reason::None;
    void begin(uint16_t id){station=id;stalled=false;healthy=false;attempts=0;lastBuffer=0;progressSeen=false;progressHealthy=false;lastReason=Reason::None;}
    void cancel(){begin(0);}
    bool poll(uint32_t now,bool web,bool connected,bool running,uint32_t buffered,
              bool btProduction=false,uint32_t produced=0){
        if(!web){cancel();return false;}
        if(!station)return false;
        if(!connected){stalled=false;healthy=false;progressSeen=false;progressHealthy=false;return false;}
        // Only BT OUT has an existing PCM-production counter. A full input buffer
        // alone cannot prove that the decoder is still producing audible frames.
        if(btProduction&&running&&buffered>=4096){
            if(!progressSeen || produced!=lastProduced){
                lastProduced=produced;progressAt=now;progressSeen=true;
                if(!progressHealthy){progressHealthy=true;progressHealthyAt=now;}
                if(uint32_t(now-progressHealthyAt)>=30000)attempts=0;
            }else if(uint32_t(now-progressAt)>=uint32_t(12000+(attempts<3?attempts:3)*10000)){
                lastReason=Reason::BtNoProduction;
                progressAt=now;progressHealthy=false;
                if(attempts<3)++attempts;
                stalled=false;healthy=false;
                return true;
            }
        }else{progressSeen=false;progressHealthy=false;}
        // A small but advancing buffer is not the observed stuck-tail failure.
        if(running&&buffered&&buffered!=lastBuffer)stalled=false;
        lastBuffer=buffered;
        if(running&&buffered>=4096){
            stalled=false;
            if(!healthy){healthy=true;healthyAt=now;}
            if(!btProduction && uint32_t(now-healthyAt)>=30000)attempts=0;
            return false;
        }
        healthy=false;
        if(!stalled){stalled=true;stalledAt=now;return false;}
        const uint32_t delay=attempts==0?8000:attempts==1?10000:attempts==2?20000:30000;
        if(uint32_t(now-stalledAt)<delay)return false;
        stalled=false;if(attempts<3)++attempts;
        lastReason=Reason::LowBuffer;
        return true;
    }
private:
    uint32_t stalledAt=0,healthyAt=0,lastBuffer=0;
    uint32_t progressAt=0,progressHealthyAt=0,lastProduced=0;
    uint8_t attempts=0;
    bool stalled=false,healthy=false,progressSeen=false,progressHealthy=false;
};
}
