#pragma once
#include <atomic>
#include <stdint.h>
#include <esp_timer.h>
namespace pathprobe {
enum Stage { Poll, Read, Decode, Output, Worker, Count };
struct Counters { std::atomic<uint32_t> calls{0},us{0},maxUs{0},units{0},empty{0},errors{0}; };
extern std::atomic<bool> enabled;
extern Counters counters[Count];
extern std::atomic<uint32_t> lowInput,decodedFrames;
// Elapsed wall time includes preemption and blocking; it is never labelled CPU time.
class Scope {
    Counters* c;uint32_t start;
public:
    explicit Scope(Stage s):c(enabled.load(std::memory_order_relaxed)?&counters[s]:nullptr),start(c?uint32_t(esp_timer_get_time()):0){}
    void units(int32_t n){if(c){if(n>0)c->units.fetch_add(uint32_t(n),std::memory_order_relaxed);else if(n==0)c->empty.fetch_add(1,std::memory_order_relaxed);else c->errors.fetch_add(1,std::memory_order_relaxed);}}
    ~Scope(){if(c){uint32_t elapsed=uint32_t(esp_timer_get_time())-start;
        c->calls.fetch_add(1,std::memory_order_relaxed);c->us.fetch_add(elapsed,std::memory_order_relaxed);
        if(elapsed>c->maxUs.load(std::memory_order_relaxed))c->maxUs.store(elapsed,std::memory_order_relaxed);}}
};
inline void low(){if(enabled.load(std::memory_order_relaxed))lowInput.fetch_add(1,std::memory_order_relaxed);}
inline void frames(unsigned n){if(enabled.load(std::memory_order_relaxed))decodedFrames.fetch_add(n,std::memory_order_relaxed);}
void diagnostics();
}
