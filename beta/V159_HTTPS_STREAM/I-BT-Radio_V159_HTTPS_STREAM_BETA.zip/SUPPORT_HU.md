# Támogatás

Ha hasznosnak találod a fejlesztést, önkéntesen támogathatod:

- **ETH:** `0xf044db3277a1b880713e81d66b6E507F65450EE6`
- **BTC:** `3KLgXnbCs1WCD3igiVErxdy2CAH7QWchLs`

A támogatás nem vásárlás, nem előrendelés és nem jelent működési vagy terméktámogatási ígéretet. A projekt jelenleg BETA, tesztelésre szolgál.
