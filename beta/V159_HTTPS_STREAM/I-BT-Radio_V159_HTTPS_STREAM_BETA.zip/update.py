"""I-BT-Radio BETA application-only updater; preserves Wi-Fi, SPIFFS and partitions."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import threading
import queue
import codecs

ROOT=Path(__file__).resolve().parent

def _safe_log_line(raw):
    text=raw.decode('utf-8','replace') if isinstance(raw,bytes) else str(raw)
    text=re.sub(r'\b(?:\d{1,3}\.){3}\d{1,3}\b','<IP-redacted>',text)
    text=re.sub(r'(?i)\b(ssid|password|passwd)\b.*$',r'\1=<redacted>',text)
    return text.encode('utf-8')

def verify():
    manifest=json.loads((ROOT/'PACKAGE.json').read_text(encoding='utf-8'))
    for name, expected in manifest['files'].items():
        d=(ROOT/name).read_bytes()
        if hashlib.sha256(d).hexdigest()!=expected['sha256'] or len(d)!=expected['bytes']:
            raise RuntimeError('Package mismatch: '+name)
    d=(ROOT/'firmware.bin').read_bytes()
    if b'V153-R10' not in d or d[0]!=0xe9 or d[3]>>4!=4 or len(d)>=0x600000:
        raise RuntimeError('Firmware identity or size mismatch')
    print('[BETA] PACKAGE HASH PASS',flush=True)

def run_live(cmd, log, timeout):
    """Mirror real esptool output immediately, including CR progress, with a deadline."""
    proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    chunks=queue.Queue(); captured=[]
    def reader():
        try:
            while True:
                data=proc.stdout.read1(1024)
                if not data:break
                chunks.put(data)
        finally:chunks.put(None)
    thread=threading.Thread(target=reader,daemon=True);thread.start()
    decoder=codecs.getincrementaldecoder('utf-8')('replace')
    started=time.monotonic();last_notice=started
    try:
        while True:
            now=time.monotonic()
            if now-started>=timeout:raise TimeoutError('A muvelet idotullepes miatt megallt.')
            try:data=chunks.get(timeout=min(1,timeout-(now-started)))
            except queue.Empty:
                if time.monotonic()-last_notice>=5:
                    print(f'\nVarakozas a keszulek valaszara... {int(time.monotonic()-started)} s',flush=True)
                    last_notice=time.monotonic()
                continue
            if data is None:break
            text=decoder.decode(data);captured.append(text)
            log.write(text);log.flush();sys.stdout.write(text);sys.stdout.flush()
        tail=decoder.decode(b'',final=True)
        if tail:captured.append(tail);log.write(tail);sys.stdout.write(tail);sys.stdout.flush()
        code=proc.wait(timeout=max(.1,timeout-(time.monotonic()-started)))
        return code,''.join(captured)
    finally:
        if proc.poll() is None:proc.kill();proc.wait()
        thread.join(timeout=2);proc.stdout.close();log.flush()

def detect_port(explicit=None,wait_seconds=60):
    from serial.tools.list_ports import comports
    print('[COM] USB-soros portok felismerese...',flush=True)
    deadline=time.monotonic()+wait_seconds
    announced=False
    while True:
        ports=[p.device for p in comports() if p.vid in (0x10c4,0x1a86,0x0403,0x303a)]
        if explicit:
            match=next((p for p in ports if p.casefold()==explicit.casefold()),None)
            if match:
                print('[COM] Felismert es kivalasztott port: '+match,flush=True);return match
            if time.monotonic()>=deadline:raise RuntimeError('A megadott COM port nem jelent meg: '+explicit)
            if not announced:
                print('[COM] Var a megadott eszkoz csatlakozasara: '+explicit,flush=True);announced=True
            time.sleep(1);continue
        if len(ports)==1:
            print('[COM] Felismert port: '+ports[0],flush=True);return ports[0]
        if len(ports)>1:
            print('[COM] Több eszköz található; válaszd ki a rádió portját:',flush=True)
            for i,name in enumerate(ports,1):print(f'  {i}. {name}',flush=True)
            choice=input('COM-sorszám vagy portnév: ').strip()
            if choice.isdigit() and 1<=int(choice)<=len(ports):choice=ports[int(choice)-1]
            match=next((p for p in ports if p.casefold()==choice.casefold()),None)
            if not match:raise RuntimeError('Érvénytelen portválasztás; semmi nem lett feltöltve.')
            print('[COM] Kivalasztott port: '+match,flush=True);return match
        if not announced:
            print('[COM] Var a csatlakozasra... Csatlakoztasd az USB-kabelt (maximum 60 s).',flush=True);announced=True
        if time.monotonic()>=deadline:raise RuntimeError('Nem jelent meg USB-soros port.')
        time.sleep(1)

def verify_boot(port, out, seconds=180):
    """Require exact CAPS plus setup completion; CAPS alone is sent before Wi-Fi initialization."""
    import serial
    deadline=time.monotonic()+seconds
    connection=None
    pending=b''
    log_pending=b''
    next_query=0
    next_notice=0
    with (out/'boot.log').open('wb') as log:
        try:
            while time.monotonic()<deadline:
                if connection is None:
                    try:
                        connection=serial.Serial()
                        connection.port=port
                        connection.baudrate=115200
                        connection.timeout=.25
                        connection.dtr=False
                        connection.rts=False
                        connection.open()
                        print('[BOOT] Soros kapcsolat nyitva, BETA firmware valaszra var...',flush=True)
                    except (serial.SerialException,OSError):
                        connection=None
                        time.sleep(.5)
                        continue
                if time.monotonic()>=next_notice:
                    print('[BOOT] Var a teljes setup befejezesere... maximum 180 s',flush=True)
                    next_notice=time.monotonic()+5
                if time.monotonic()>=next_query:
                    connection.write(b'r10 caps\n')
                    next_query=time.monotonic()+2
                chunk=connection.read(1024)
                if not chunk:continue
                log_pending+=chunk
                while b'\n' in log_pending:
                    line,log_pending=log_pending.split(b'\n',1)
                    log.write(_safe_log_line(line)+b'\n')
                log.flush()
                pending=(pending+chunk)[-8192:]
                if b'esp_timer: Not enough memory' in pending or b'abort() was called' in pending or b'Guru Meditation Error' in pending:
                    raise RuntimeError('Firmware boot failure; see boot.log')
                if re.search(rb'\[R10-CAPS\][^\r\n]*firmware=V153-R10\b',pending) and re.search(rb'\[BOOT-READY\] firmware=V153-R10 setup=1\b',pending):
                    print('[BOOT] V153-R10 BETA verzio es setup befejezes PASS',flush=True)
                    return True
        finally:
            if log_pending:log.write(_safe_log_line(log_pending));log.flush()
            if connection is not None:connection.close()
    raise RuntimeError('V153 setup completion not verified within 180 s; see boot.log')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--verify-only',action='store_true');parser.add_argument('--port');parser.add_argument('--recovery',action='store_true');a=parser.parse_args()
    print("[1/5] BETA csomag es firmware ellenorzese...",flush=True)
    verify()
    if a.verify_only:return 0
    port=detect_port(a.port)
    out=ROOT/'RETURN_TO_EVA'/datetime.now(timezone.utc).strftime('UPDATE_%Y%m%d_%H%M%S');out.mkdir(parents=True)
    result={'release':'V159-HTTPS-MENU-SELFTEST-BETA','firmware':'V153-R10','result':'FAIL_PRECHECK','application_only':True,'transport':'ROM_115200_RAW' if a.recovery else 'STUB_1500000'}
    def call(action,args,after='no-reset',timeout=180):
        cmd=[sys.executable,'-u','-X','utf8','-m','esptool','--chip','esp32','--port',port,'--baud',str(115200 if action!='write-flash' or a.recovery else 1500000),'--before','no-reset','--connect-attempts','3',*(['--no-stub'] if action!='write-flash' or a.recovery else []),'--after',after,action,*args]
        with (out/'esptool.log').open('a',encoding='utf-8') as log:
            log.write(subprocess.list2cmdline(cmd)+'\n');log.flush()
            code,text=run_live(cmd,log,timeout)
        if code:raise RuntimeError(action+' failed; see esptool.log. BOOT + short EN/RESET may be required.')
        return text
    try:
        print('[2/5] Var a bootloader csatlakozasra (115200 baud). BOOT nyomva + rovid EN/RESET, majd BOOT elenged.',flush=True)
        info=call('flash-id',[])
        if not re.search(r'Detected flash size:\s*16MB',info):raise RuntimeError('16MB not detected')
        print('[3/5] Flash azonositva: 16 MB. Particiok ellenorzese...',flush=True)
        call('read-flash',['0x8000','0x1000',str(out/'partitions-read.bin')])
        actual=(out/'partitions-read.bin').read_bytes();expected=(ROOT/'partitions.bin').read_bytes()
        if len(actual)!=4096 or actual[:len(expected)]!=expected:raise RuntimeError('Unexpected partitions; no write allowed')
        result['result']='FAIL_WRITE'
        print('[4/5] BETA feltoltes: '+('HELYREALLITAS, ROM 115200 baud, tomorites nelkul' if a.recovery else 'GYORS, RAM stub, 1500000 baud')+'. Elo szazalek alabb. USB maradjon bedugva.',flush=True)
        text=call('write-flash',['--flash-size','16MB','--flash-mode','keep','--flash-freq','keep',('--no-compress' if a.recovery else '--compress'),'0x10000',str(ROOT/'firmware.bin')],after='hard-reset',timeout=900)
        if 'Hash of data verified.' not in text:raise RuntimeError('Write verification not confirmed')
        print('[5/5] Flash hash PASS. Indulas es BETA firmware-verzio ellenorzese...',flush=True)
        result['result']='FAIL_BOOT'
        verify_boot(port,out)
        result['result']='PASS_FLASH_HASH_BOOT'
        print('[5/5] V153 setup befejezes PASS. Most hallgasd meg a radio indulasi hangjat; lasd README_HU.txt.',flush=True)
        return 0
    except Exception as e:
        result['error']=str(e);print('\nHIBA: '+str(e),flush=True);return 2
    finally:
        print('Naplók: '+str(out),flush=True)
        (out/'RESULT.json').write_text(json.dumps(result,indent=2),encoding='utf-8')

if __name__=='__main__':sys.exit(main())

