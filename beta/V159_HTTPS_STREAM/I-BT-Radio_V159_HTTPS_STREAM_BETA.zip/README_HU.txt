I-BT-RADIO BETA — V159 HTTPS menü-önteszt csomag

FIGYELEM: korlátozottan működő BETA. KIZÁRÓLAG TESZTELÉSRE; beépítésre,
mindennapos vagy felügyelet nélküli használatra nem ajánlott. A Bluetoothos
internetrádió hangfolytonossága még nincs igazolva. A firmware-jelölés belül
V153-R10; a BETA és a tesztcsomag azonosítója V159-HTTPS-MENU-SELFTEST-BETA.
Az internetes MP3/AAC/FLAC URL-ek HTTP és HTTPS protokollt is használhatnak;
HLS továbbra sem támogatott. A meglévő TLS kliens nem ellenőrzi a szerver
tanúsítványát, ezért a HTTPS titkosít, de a szerver hitelességét nem igazolja.

Telepítés:
1. Csomagold ki a ZIP-et egy helyi mappába.
2. A firmware feltöltőhöz Python 3.9+ szükséges; indítsd el a START_BETA_INSTALLER.bat fájlt.
3. Ha több USB-s COM-port látszik, válaszd ki a rádióét. A feltöltő 115200
   baudon ellenőrzi a 16 MB flash-t és a meglévő partíciót, majd 1500000
   baudon írja csak az alkalmazást. A Wi-Fi-beállításokat és partíciót megtartja.
4. Ha a rádió nem lép bootloader módba, tartsd nyomva a BOOT gombot, röviden
   nyomd meg az EN/RESET gombot, majd engedd el a BOOT-ot.
5. A konzol mutatja a valós feltöltési százalékot és az ellenőrzött befejezést.

Menü-önteszt:
1. Az induló rádión indíts internetes rádiót a belső DAC/jack kimeneten.
2. A BT OUT legyen kikapcsolva; a teszt BT mellett nem indul el.
3. Futtasd a START_MENU_SELFTEST.bat fájlt. A menüteszt Windows PowerShellt
   használ, külön Python-telepítés nem kell. Válaszd ki a rádió COM-portját.
4. A program egyszer végigjárja a menüútvonalat. A képernyőt közben figyeld,
   a fizikai rotaryt pedig külön ellenőrizd a MANUAL_CHECK.txt alapján.
5. Küldd vissza a teljes RETURN_TO_EVA/MENU_SELFTEST_*/ mappát.

A menüteszt RAM-ban kapcsol át néhány kijelzőbeállítást, majd visszaállítja az
eredeti értékeket. Nem indít Bluetooth-kapcsolatot, Wi-Fi-keresést, flash- vagy
SD-törlést. A teszt audio/puffer/heap/input őrre leáll; ez nem hangstabilitási
PASS. A soros napló IP-címét és SSID/jelszó adatát a mentés előtt kitakarja.

Visszajelzéshez add meg a csomag- és firmware-SHA256-ot (PACKAGE.json), a
Yellow Board revízióját, a MANUAL_CHECK eredményét, és csatold a naplómappát.
Ne csatolj Wi-Fi-jelszót, tokent, fiókadatot vagy személyes hangfájlt.
