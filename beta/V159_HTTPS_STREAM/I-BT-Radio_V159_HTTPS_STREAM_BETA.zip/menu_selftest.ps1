﻿param([switch]$SelfTest)

$ErrorActionPreference = 'Stop'
$script:Saved = New-Object System.Collections.Generic.List[string]
$script:Serial = $null

function Protect-Line([string]$Text) {
    $Text = [regex]::Replace($Text, '\b(?:\d{1,3}\.){3}\d{1,3}\b', '<IP-redacted>')
    $Text = [regex]::Replace($Text, '(?i)\b(ssid|password|passwd)\b.*$', '$1=<redacted>')
    return $Text.TrimEnd("`r", "`n")
}

function Read-SerialFor([int]$Seconds, [switch]$StopOnCycle) {
    $end = [DateTime]::UtcNow.AddSeconds($Seconds)
    $cycle = $false
    while ([DateTime]::UtcNow -lt $end) {
        try {
            $line = Protect-Line $script:Serial.ReadLine()
            if ($line.Length -eq 0) { continue }
            $script:Saved.Add($line)
            Write-Host $line
            if ($line.Contains('[UI-TOUR] cycle=PASS count=1')) {
                $cycle = $true
                if ($StopOnCycle) { return $true }
            }
        }
        catch [System.TimeoutException] { }
    }
    return $cycle
}

function Send-RadioCommand([string]$Text) {
    $script:Serial.Write($Text + "`n")
}

if ($SelfTest) {
    $sample = Protect-Line '[TEST] ip=192.168.4.1 ssid=secret password=secret'
    if ($sample -ne '[TEST] ip=<IP-redacted> ssid=<redacted>') { throw "redaction failure: $sample" }
    Write-Host 'PASS: PowerShell runner loads and redacts IP/SSID/password; no COM port opened.'
    exit 0
}

$result = 'FAIL_RUNNER'
$portName = ''
$steps = 0
$edits = 0
$outDir = $null
$logPath = $null
$baud = 115200
$tourTimeoutSeconds = 120

try {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $outDir = Join-Path (Join-Path $PSScriptRoot 'RETURN_TO_EVA') ('MENU_SELFTEST_' + $stamp)
    New-Item -ItemType Directory -Path $outDir -ErrorAction Stop | Out-Null
    $logPath = Join-Path $outDir 'serial.log'

    $ports = @([System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object)
    if ($ports.Count -eq 0) { throw 'Nincs COM-port; csatlakoztasd a radiont.' }
    Write-Host 'Elérhető COM-portok:'
    for ($i = 0; $i -lt $ports.Count; $i++) { Write-Host ('  {0}. {1}' -f ($i + 1), $ports[$i]) }
    $answer = Read-Host 'Válaszd ki a rádió COM-portjának sorszámát'
    $choice = 0
    if (-not [int]::TryParse($answer, [ref]$choice) -or $choice -lt 1 -or $choice -gt $ports.Count) {
        throw 'Érvénytelen COM-port választás.'
    }
    $portName = $ports[$choice - 1]

    $script:Serial = New-Object -TypeName System.IO.Ports.SerialPort
    $script:Serial.PortName = $portName
    $script:Serial.BaudRate = $baud
    $script:Serial.Parity = [System.IO.Ports.Parity]::None
    $script:Serial.DataBits = 8
    $script:Serial.StopBits = [System.IO.Ports.StopBits]::One
    $script:Serial.Handshake = [System.IO.Ports.Handshake]::None
    $script:Serial.DtrEnable = $false
    $script:Serial.RtsEnable = $false
    $script:Serial.ReadTimeout = 150
    $script:Serial.WriteTimeout = 2000
    $script:Serial.NewLine = "`n"
    $script:Serial.Encoding = [System.Text.Encoding]::UTF8
    Write-Host ("Kapcsolódás: {0} @ {1}; firmware-flash nem történik." -f $portName, $baud)
    $script:Serial.Open()
    Start-Sleep -Milliseconds 500
    $script:Serial.DiscardInBuffer()

    Write-Host 'Indítási feltétel: internetes rádió szóljon a DAC-on; BT-kimenet legyen kikapcsolva.'
    Send-RadioCommand 'r10 ui stress start action=500 draw=500 tour=1'
    $startEnd = [DateTime]::UtcNow.AddSeconds(10)
    $started = $false
    while ([DateTime]::UtcNow -lt $startEnd) {
        [void](Read-SerialFor 1)
        if (@($script:Saved | Where-Object { $_.Contains('[UI-STRESS] start=PASS') }).Count -gt 0) { $started = $true; break }
        if (@($script:Saved | Where-Object { $_.Contains('[UI-STRESS] start=DENIED') }).Count -gt 0) { break }
    }

    if (-not $started) {
        if (@($script:Saved | Where-Object { $_.Contains('start=DENIED') }).Count -gt 0) { $result = 'NOT_RUN' }
        else { $result = 'FAIL_NO_START_RESPONSE' }
    }
    else {
        $gotCycle = Read-SerialFor $tourTimeoutSeconds -StopOnCycle
        if ($gotCycle) {
            Send-RadioCommand 'r10 ui stress stop'
            [void](Read-SerialFor 5)
            Send-RadioCommand 'r10 ui stress status'
            [void](Read-SerialFor 2)
            if (@($script:Saved | Where-Object { $_.Contains('restored=1') -and $_.Contains('active=0') }).Count -gt 0) { $result = 'PASS_ROUTE' }
            else { $result = 'FAIL_RESTORE_UNCONFIRMED' }
        }
        else {
            Send-RadioCommand 'r10 ui stress stop'
            [void](Read-SerialFor 5)
            $result = 'FAIL_OR_TIMEOUT'
        }
    }
}
catch {
    $kind = $_.Exception.GetType().Name
    $script:Saved.Add('[RUNNER] exception=' + $kind)
    Write-Host ('HIBA: soros kapcsolat vagy teszt megszakadt: ' + $kind)
    $result = 'FAIL_RUNNER'
}
finally {
    if ($null -ne $script:Serial -and $script:Serial.IsOpen) { $script:Serial.Close() }
}

if ($null -eq $outDir) {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $outDir = Join-Path (Join-Path $PSScriptRoot 'RETURN_TO_EVA') ('MENU_SELFTEST_' + $stamp)
    New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    $logPath = Join-Path $outDir 'serial.log'
}
$logText = if ($script:Saved.Count -gt 0) { ($script:Saved -join "`n") + "`n" } else { '' }
$utf8 = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($logPath, $logText, $utf8)
$steps = @($script:Saved | Where-Object { $_.Contains('[UI-TOUR] step=') -and $_.Contains('result=PASS') }).Count
$edits = @($script:Saved | Where-Object { $_.Contains('[UI-TOUR] edit=PASS') }).Count
$cycleComplete = @($script:Saved | Where-Object { $_.Contains('[UI-TOUR] cycle=PASS count=1') }).Count -gt 0
$restoreConfirmed = @($script:Saved | Where-Object { $_.Contains('restored=1') -and $_.Contains('active=0') }).Count -gt 0
$sha = [System.Security.Cryptography.SHA256]::Create()
try { $logHash = ([BitConverter]::ToString($sha.ComputeHash([System.IO.File]::ReadAllBytes($logPath)))).Replace('-', '').ToLowerInvariant() }
finally { $sha.Dispose() }
$report = [ordered]@{
    test = 'I-BT-Radio automatic RAM-only menu route tour'
    result = $result
    firmware_internal_version = 'V153-R10 (beta branding build)'
    port = $portName
    baud = $baud
    route_steps_passed = $steps
    ram_only_settings_edits_passed = $edits
    cycle_complete = $cycleComplete
    restore_confirmed = $restoreConfirmed
    physical_visual_check = 'PENDING_USER'
    physical_rotary_check = 'NOT_TESTED_BY_AUTOMATION'
    flash_performed = $false
    serial_log = 'serial.log'
    serial_log_sha256 = $logHash
    privacy = 'IPv4 addresses and SSID/password fields redacted from saved serial log'
}
[System.IO.File]::WriteAllText((Join-Path $outDir 'RESULT.json'), ($report | ConvertTo-Json -Depth 5) + "`n", $utf8)
Write-Host ("Eredmény: {0}; {1} útvonallépés; napló: {2}" -f $result, $steps, $logPath)
if ($result -eq 'PASS_ROUTE') { exit 0 } else { exit 1 }
