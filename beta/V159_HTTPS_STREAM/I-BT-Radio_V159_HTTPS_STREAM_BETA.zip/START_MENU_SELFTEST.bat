@echo off
setlocal
title I-BT-Radio BETA menu selftest
cd /d "%~dp0"
echo I-BT-Radio BETA - menuteszt
echo Nem tolt firmware-t a radion.
echo Elotte indits internet radiot DAC kimeneten; BT OUT legyen kikapcsolva.
echo A teszt Windows PowerShellt hasznal, Python nem kell hozza.
echo A teszt egy RAM-only menukort futtat es naplot ment a RETURN_TO_EVA mappaba.
echo.
where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo HIBA: Windows PowerShell nem talalhato. Windows 10/11 PowerShell szukseges.
  goto failed
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0menu_selftest.ps1" -SelfTest
if errorlevel 1 goto failed
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0menu_selftest.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo A teszt hibaval vagy idotullepessel allt meg. A RETURN_TO_EVA naplot ellenorizd.
pause
exit /b %RC%

:failed
echo.
echo A teszt nem indult el. Ellenorizd a fenti hibauzenetet.
pause
exit /b 2
