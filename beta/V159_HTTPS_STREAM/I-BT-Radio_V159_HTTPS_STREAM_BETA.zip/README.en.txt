I-BT-Radio BETA — V159 HTTPS menu self-test package

WARNING: limited BETA build for testing only. Not recommended for integration,
daily use, or unattended playback. Internet-radio Bluetooth audio continuity
has not been verified. Internal firmware ID: V153-R10. Package ID:
V159-HTTPS-MENU-SELFTEST-BETA.
Direct internet MP3/AAC/FLAC URLs may use HTTP or HTTPS. HLS remains disabled.
The existing TLS client does not validate server certificates: HTTPS encrypts
the connection but does not authenticate the server.

Install:
1. Extract the ZIP to a local folder.
2. Run START_BETA_INSTALLER.bat. Python 3.9+ is required; the installer adds
   pinned esptool and pyserial dependencies if missing.
3. Select the radio's COM port if more than one USB serial device is present.
   The updater checks 16 MB flash and the existing partition table at 115200
   baud, then writes only the app at 1500000 baud. Wi-Fi settings and partitions
   are preserved. Real esptool output and percentage progress are shown.
4. If needed, hold BOOT, tap EN/RESET, then release BOOT.

Menu self-test:
Start an Internet radio station through the DAC, turn BT OUT off, and run
START_MENU_SELFTEST.bat. It uses Windows PowerShell; Python is not required.
It traverses 44 expected firmware menu routes using RAM-only setting changes, restores the original settings, and saves a sanitized
serial log under RETURN_TO_EVA. Watch the display and check the physical rotary
separately using MANUAL_CHECK.txt. The test is not a Bluetooth audio stability
pass and stops if its audio/buffer/heap/input guards detect a regression.

Send the complete MENU_SELFTEST_* folder with the board revision and the
firmware/package SHA256 values from PACKAGE.json. Do not send Wi-Fi credentials,
account tokens, or personal audio files.

Optional support:
- ETH: 0xf044db3277a1b880713e81d66b6E507F65450EE6
- BTC: 3KLgXnbCs1WCD3igiVErxdy2CAH7QWchLs
