# R352 tesztfirmware

Azonos állomás/szám és generáció nézetváltásakor az egyetlen, érvényesített borítóolvasó megmarad. Új állomás, előadó, generáció, fájlkulcs vagy tárolóváltás továbbra is új, védett megnyitást igényel. Minden mérési újrarajzolás friss forráshash-ellenőrzést végez. A 75%/1500ms megnyitási, 50% olvasási, BT120ms és CPU950 hangvédelmek változatlanok.

Az óra melletti97x97 kép a tárolt160x120 változat középső120x120 részéből készül. A nagy320x240 kép kitölti a szélességet, aránytartó kivágással; régi fekete keretek CRC-ellenőrzött tartalmi kivágása megmarad. ROM tartalék64x64, nincs új képpuffer vagy csomagméret.

R351 történeti eredmények: natív megállított kis és nagy kép forrásCRC/rendercomplete PASS; fizikai képpont/hallás nem ellenőrzött. Poly0/6: az első kör nézetváltás után nem kapott friss teljes képet. Teljes27/live nem futott. SD37 független MP3 kvalifikáció PASS. Állomás3 és4 HTTP200 után DATA/NO_TCP_DATA megállás; hálózati végső ok nem bizonyított, ez a javítás nem állítja helyre bizonyítottan a hálózatot. Állomás131 HTTP403 külön hiba.

R352 fizikai feltöltés, kép, hang, Poly és teljes kör még NEM FUTOTT. Új BOOT/EN átadás csak ellenőrzött csomag után, egy adatmegőrző feltöltés, egy soros tulajdonos. Hangerő15. Hiba esetén nincs vak újrapróbálás vagy reset. Dropbox kikapcsolva.
