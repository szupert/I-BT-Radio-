"""Strict PC-only telemetry records. Never repair numbers or suppress radio faults."""
import collections,hashlib,re
NUMBERS={
 'R10-TELEM':'heap_internal heap_largest heap_min psram_free',
 'R10-STACK':'stack_free dsp_stack_hwm mem_checks mem_errors',
 'AUDIO-TASK':'ready stack_min stack_alloc core',
 'BT-AUDIO':'active delivered_bytes requested_bytes received_bytes dropped_bytes underruns block_frames tx_buffer rx_buffer rate source_rate',
 'ART-BENCH':'selection batch order station emitted height source_w source_h source_reads lcd_calls max_rows_per_slice draw_us max_slice_us elapsed_ms canonical_verified buffers frame_buffer budget_us complete',
 'PATH-STATE':'active restoring profile web playing station volume route idle rate saved scanning connected transmitting input_buffer source_rate vu_ms player sbc_busy decoded play_seconds generation bt_failed bt_pending',
 'PATH-SOURCE':'local codec generation',
 'MEDIA-PROGRESS':'generation running local position size elapsed_s duration_s sampled_ms no_io',
 'LOAD':'window_us core0_permille core1_permille tasks probe_internal window_id generation route_state cached age_us end_us'
}
PATTERN=re.compile(r'\[('+'|'.join(map(re.escape,NUMBERS))+r')\]')
PAIR=re.compile(r'([A-Za-z_][A-Za-z0-9_]*)=([^\s]+)')
def valid_values(tag,values):
 required=NUMBERS[tag].split()
 if tag=='LOAD' and values.get('result')!='OK':
  if values.get('result','').startswith('OK'):return False
  required=[k for k in required if k in values]
 for key in required:
  value=values.get(key,'')
  if not re.fullmatch(r'[0-9]+',value) or int(value)>2**64-1:return False
 if tag in ('R10-TELEM','R10-STACK','AUDIO-TASK') and values.get('unit')!='bytes':return False
 if tag=='R10-TELEM' and values.get('snapshot')!='PER_LINE':return False
 if tag=='ART-BENCH' and not re.fullmatch(r'[0-9a-fA-F]{8}',values.get('source_hash','')):return False
 return True
def decode(line):
 match=PATTERN.search(line)
 if not match:return None,None,None
 tag=match[1]
 if not line.lstrip().startswith('['+tag+']') or len(PATTERN.findall(line))!=1:return tag,None,'INTERLEAVED_TAG'
 if re.search(r'(?:^|\s)[EWIDV]\s+\([0-9]+\)',line):return tag,None,'INTERLEAVED_SDK_LOG'
 pairs=PAIR.findall(line);values=dict(pairs)
 if len(values)!=len(pairs):return tag,None,'DUPLICATE_FIELD'
 if not valid_values(tag,values):return tag,None,'INCOMPLETE_OR_NONNUMERIC'
 return tag,values,None
class TelemetryMixin:
 # The original pump processes the unmodified raw line and native fault gates
 # first. Only measurement-facing copies are filtered; serial.log is untouched.
 def pump(self,seconds):
  m=self.telemetry_module
  if not hasattr(self,'_record_cache'):self._record_cache=collections.OrderedDict()
  def checked(line):
   cache=self._record_cache
   if line not in cache:
    item=decode(line);cache[line]=item
    if item[2]:
     counts=self.state.setdefault('discarded_telemetry_records',{});key=item[0]+':'+item[2];counts[key]=counts.get(key,0)+1
     self.state['last_discarded_telemetry_sha256']=hashlib.sha256(line.encode('utf8')).hexdigest()
    if len(cache)>2400:cache.popitem(last=False)
   return cache[line]
  original=m.fields
  def fields(line):
   tag,values,reason=checked(line)
   if reason:return {'_discarded_telemetry':reason}
   return values if tag else original(line)
  m.fields=fields
  try:return super().pump(seconds)
  finally:
   m.fields=original
   self.lines=[(stamp,line) for stamp,line in self.lines if not checked(line)[2]]
   if self.phase:
    samples=self.phase.get('samples',[])
    self.phase['samples']=[row for row in samples if '_discarded_telemetry' not in row.get('values',{})]
