import r352_telemetry_records as telemetry
"""Standalone opt-in single-cycle selftest. No HTTP dependency, flash, reset or recovery loop.
Only launching this file/its BAT starts logging. Importing it performs no I/O.
"""
from pathlib import Path
from r352_panic_capture import capture_tail,FATAL
import argparse,datetime as dt,hashlib,json,os,re,sys,time,uuid,codecs
from r352_selftest_policy import PHASES,fields,fault,command_allowed,actual_play,delta,verified
FW='V166-R352'
class Stop(Exception):pass
class Deadline(Exception):pass
def utc():return dt.datetime.now(dt.timezone.utc).isoformat()
def redact(s):return re.sub(r'(?i)\b(?:[0-9a-f]{2}:){5}[0-9a-f]{2}\b|\b(?:\d{1,3}\.){3}\d{1,3}\b','<private>',s)
def write(path,value,replace=None,sleep=None,deadline_seconds=3):
 replace=replace or os.replace;sleep=sleep or time.sleep
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_name(path.name+'.'+str(os.getpid())+'.'+uuid.uuid4().hex+'.tmp')
 tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')
 end=time.monotonic()+deadline_seconds
 while True:
  try:replace(tmp,path);return
  except PermissionError as error:
   if getattr(error,'winerror',None) not in (None,5,32,33) or time.monotonic()>=end:raise
   sleep(.05)

def package(home):
 m=json.loads((home/'SELFTEST_MANIFEST.json').read_text(encoding='utf8'));assert m['firmware']==FW
 for rel,h in m['files'].items():
  p=(home/rel).resolve();assert home.resolve() in p.parents and p.is_file();assert hashlib.sha256(p.read_bytes()).hexdigest()==h
 return m
def receipt_for(manifest,explicit=None):
 paths=[Path(explicit)] if explicit else sorted(Path('C:/esp32/SYSTEM/LOGS/UPLOAD').glob('UPDATE_*/RESULT.json'),key=lambda p:p.stat().st_mtime,reverse=True)
 for p in paths:
  try:r=json.loads(p.read_text(encoding='utf-8-sig'))
  except (OSError,ValueError):continue
  if verified(r,manifest):return str(p)
 raise RuntimeError('Nincs igazolt R352 feltöltés ehhez a csomaghoz. COM nem nyílt meg.')
class Test:
 def __init__(self,home,manifest,args,receipt):
  self.home=home;self.manifest=manifest;self.args=args;self.receipt=receipt
  self.root=home/'RETURN_TO_EVA'/('FULL_R352_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);self.root.mkdir(parents=True)
  self.stop=self.root/'STOP_REQUEST';self.s=None;self.lock=None;self.locked=False;self.raw=None;self.pending='';self.lines=[];self.hazard=None;self.phase=None;self.ui=False;self.path_owned=False;self.bypass=None
  self.end=time.monotonic()+args.max_minutes*60;self.original={};self.config=[];self.tube=[]
  self.state=dict(result='PREPARING',firmware=FW,receipt=receipt,pid=os.getpid(),root=str(self.root),started=utc(),COM_closed=True,flash=False,reset=False,hearing='NOT_AUTOMATIC',physical_touch_pixels_rotary='NOT_RUN',WebUI='NOT_RUN_SEPARATE_NETWORK_USER_CONSTRAINT',BT_IN_PHONE_AUDIO='NOT_RUN_NO_PHONE_SOURCE',WiFi_BT='DEFERRED_NOT_IN_THIS_MATRIX',cases=[])
 def save(self):
  self.state['updated']=utc();write(self.root/'RUN_STATUS.json',self.state);write(self.home/'RETURN_TO_EVA/SELFTEST_ACTIVE.json',self.state)
 def gate(self):
  for marker in [self.stop,self.home/'RETURN_TO_EVA/STOP_SELFTEST']:
   if marker.exists():raise Stop(marker.read_text(encoding='utf-8-sig',errors='replace')[:256].strip() or 'USER_STOP')
  if time.monotonic()>=self.end:raise Deadline()
  if self.hazard:raise RuntimeError(self.hazard)
 def open(self):
  import msvcrt,serial
  from serial.tools import list_ports
  lock=Path('C:/esp32/USER/I-BT-Radio_LATEST/RETURN_TO_EVA/.upload_test.lock');lock.parent.mkdir(parents=True,exist_ok=True)
  self.lock=lock.open('a+b');self.lock.seek(0,2)
  if not self.lock.tell():self.lock.write(b'0');self.lock.flush()
  self.lock.seek(0);msvcrt.locking(self.lock.fileno(),msvcrt.LK_NBLCK,1);self.locked=True
  ports=[p.device for p in list_ports.comports() if (p.vid,p.pid)==(0x1a86,0x7523)]
  port=self.args.port or (ports[0] if len(ports)==1 else None)
  if not port:raise RuntimeError('USB hiányzik vagy több azonos eszköz van. Add meg: --port COMx')
  self.s=serial.Serial(port=None,baudrate=115200,timeout=.04,write_timeout=2);self.s.dtr=False;self.s.rts=False;self.s.port=port;self.s.open()
  self.state.update(COM_closed=False,port=port);self.raw=(self.root/'serial.log').open('w',encoding='utf8');self.save()
 def pump(self,seconds):
  until=time.monotonic()+seconds
  while time.monotonic()<until:
   self.gate();data=self.s.read(max(1,min(self.s.in_waiting,8192)));self.decoder=getattr(self,'decoder',None) or codecs.getincrementaldecoder('utf8')('replace');self.pending+=self.decoder.decode(data)
   while '\n' in self.pending:
    line,self.pending=self.pending.split('\n',1);line=line.rstrip('\r');self.lines.append((time.monotonic(),line));self.lines=self.lines[-1200:]
    self.raw.write(redact(line)+'\n')
    problem=fault(line)
    if problem:self.hazard=redact(problem)
    if '[MONO-DSP-CONFIG]' in line:
     v=fields(line).get('overload_bypasses')
     if v is not None:
      value=int(v)
      if self.bypass is not None and value!=self.bypass:self.hazard='CPU_GUARD_BYPASS_CHANGED_NO_FORCE_ON'
      self.bypass=value
    _,_,discard=telemetry.decode(line)
    if discard:
     self.lines.pop();self.state['discarded_telemetry_records']=self.state.get('discarded_telemetry_records',0)+1
     continue
    if self.phase:
     for tag in ['R10-TELEM','R10-STACK','AUDIO-TASK','BUFFER-PROFILE','BT-AUDIO','BT-TX-TIMING','LOAD','UI-STRESS','UI-MENU-SCAN','IR-STATE','STREAM-REQUEST','STREAM-HEADER','STREAM-HTTP','STREAM-TRANSPORT','STREAM-MEM','STREAM-OPEN','TLS-RECORD','LOCAL-ART','LOCAL-ART-MODE','LOCAL-ART-SETTINGS','VU-STATE','DAC-I2S']:
      if '['+tag+']' in line:self.phase.setdefault('samples',[]).append(dict(utc=utc(),tag=tag,values=fields(line)))
   if len(self.pending)>32768:raise RuntimeError('SERIAL_REPLY_OVERFLOW')
  if self.raw:self.raw.flush()
 def send(self,cmd):
  self.gate();assert command_allowed(cmd),cmd
  self.s.write((cmd+'\n').encode('ascii'));self.s.flush()
  if self.phase:self.phase.setdefault('commands',[]).append(dict(utc=utc(),command=cmd))
 def req(self,cmd,tag,seconds=6,readonly=True):
  for attempt in range(3 if readonly else 1):
   start=time.monotonic();self.send(cmd)
   while time.monotonic()-start<seconds:
    self.pump(.05)
    for t,line in reversed(self.lines):
     if t>=start and tag in line:return line
   if not readonly:raise RuntimeError('UNKNOWN_COMMAND_OUTCOME_NO_RETRY '+cmd)
  raise RuntimeError('NO_REPLY_AFTER_BOUNDED_READS '+cmd)
 def path(self):
  for attempt in range(3):
   try:return self.path_once()
   except AssertionError as error:
    self.state.setdefault('readonly_incomplete_replies',[]).append(dict(utc=utc(),attempt=attempt+1,keys=sorted(error.args[0]) if error.args and isinstance(error.args[0],dict) else []))
    if attempt==2:raise RuntimeError('INCOMPLETE_PATH_STATE_AFTER_3_READS') from error
    self.pump(.35)
 def path_once(self):
  start=time.monotonic();p=fields(self.req('r10 path status','[PATH-STATE]'));self.pump(.2)
  for t,line in reversed(self.lines):
   if t>=start and '[PATH-SOURCE]' in line:
    src=fields(line)
    if src.get('generation')==p.get('generation'):p.update(source_codec=src.get('codec'),source_local=src.get('local'));break
  assert all(k in p for k in ['generation','playing','decoded','route','web','idle','volume']),p
  return p
 def wait(self,predicate,seconds,reason):
  end=time.monotonic()+seconds
  while time.monotonic()<end:
   p=self.path()
   if predicate(p):return p
   self.pump(.3)
  raise RuntimeError(reason)
 def ack(self,command):
  line=self.req('r10 path '+command,'[PATH-ACK]',readonly=False)
  if 'result=PASS' not in line:raise RuntimeError('PATH_REJECTED '+line)
 def stop_audio(self):self.send('stop');self.wait(lambda p:p['playing']=='0',25,'STOP_NOT_ACTUAL')
 def mono_config_values(self):
  # SDK and application serial writes may interleave inside a CSV token.
  # Retry only this readonly status; never repeat the preceding mutation.
  for attempt in range(3):
   line=self.req('r10 mono status','[MONO-DSP-CONFIG]')
   token=fields(line).get('values','')
   if re.fullmatch(r'-?\d+(?:,-?\d+){10}',token):return [int(x) for x in token.split(',')]
   self.state.setdefault('readonly_incomplete_mono_replies',[]).append(dict(utc=utc(),attempt=attempt+1,fields=len(token.split(','))))
   if attempt<2:self.pump(.25)
  raise RuntimeError('INCOMPLETE_MONO_CONFIG_AFTER_3_READS_NO_MUTATION_RETRY')
 def dsp(self,param,value):
  if param in (9,10):assert value==1
  if param in (4,6,7,8):assert value<=0 or value==self.config[param]
  line=self.req(f'r10 mono set {param} {value}','[MONO-DSP-ACK]',readonly=False)
  if 'result=ACCEPTED' not in line:raise RuntimeError('DSP_DENIED_NO_FORCE_ON')
  if param<11:actual=self.mono_config_values()[param]
  else:actual=int(fields(self.req('r10 mono status','[TUBE-DSP]'))[['enabled','drive','even','odd','mix','tone_hz','trim_tenth_db'][param-11]])
  if actual!=value:raise RuntimeError('DSP_READBACK_MISMATCH')
  if self.path_owned:self.path()
 def profile(self,value):
  self.stop_audio()
  r=self.req('r10 buffer set '+str(value),'[BUFFER-ACK]',readonly=False)
  if 'result=ACCEPTED' not in r:raise RuntimeError('BUFFER_PROFILE_REJECTED')
  b=fields(self.req('r10 buffer status','[BUFFER-PROFILE]'))
  if b.get('requested')!=str(value):raise RuntimeError('BUFFER_PROFILE_READBACK')
  self.pump(2)
  b=fields(self.req('r10 buffer status','[BUFFER-PROFILE]'))
  if b.get('pending_save')!='0' or b.get('save_ok')!='1':raise RuntimeError('BUFFER_NVS_READBACK_NOT_CONFIRMED')
 def dac(self):
  if self.ui:self.req('r10 ui stress stop','[UI-STRESS]',readonly=False);self.ui=False
  self.stop_audio();p=self.path()
  if p['route']!='0' or p['idle']!='1':self.send('r10 bt off');self.wait(lambda p:p['route']=='0' and p['idle']=='1',65,'BT_DAC_RETURN_TIMEOUT')
 def select(self,web,flac=False):
  self.dac();self.dsp(0,0)
  if self.path()['web']!=str(int(web)):
   self.ack('sourceweb' if web else 'sourcesd');self.wait(lambda p:p['web']==str(int(web)),35,'SOURCE_TIMEOUT');self.stop_audio()
  before=self.path()['generation'];track=self.args.wifi_station if web else self.args.sd_flac if flac else self.args.sd_mp3
  self.ack(('webtrack=' if web else 'sdtrack=')+str(track))
  p=self.wait(lambda p:p['generation']!=before and actual_play(p,web,codec=5 if flac else 2) and p.get('source_local')==str(int(not web)),90 if web else 45,'NEW_SOURCE_DECODE_TIMEOUT')
  self.phase['source_start']=p
 def menu(self):
  self.ui=True # A late/missing ACK must still cancel the tour on host failure.
  r=self.req('r10 ui stress start action=500 draw=500 tour=2','[UI-STRESS] start=',readonly=False)
  if 'start=PASS' not in r:raise RuntimeError('MENU_TOUR_REJECTED')
  self.ui=True
 def bt_out(self):
  self.select(False)
  start=time.monotonic();self.req('r10 path devices','[PATH-DEVICES-END]');saved=[]
  for t,line in self.lines:
   match=re.search(r'\[PATH-DEVICE\] kind=saved index=(\d+) name=(.*)',line)
   if t>=start and match and re.search(self.args.bt_name,match[2],re.I):saved.append(int(match[1]))
  if len(saved)==1:
   self.ack('saved='+str(saved[0]));self.wait(lambda p:actual_play(p,False,True,2),65,'SAVED_SD_BTOUT_ACTUAL_AUDIO_TIMEOUT');return
  self.ack('scan');self.pump(3);end=time.monotonic()+40
  while time.monotonic()<end:
   start=time.monotonic();self.req('r10 path devices','[PATH-DEVICES-END]');peers=[]
   for t,line in self.lines:
    match=re.search(r'\[PATH-DEVICE\] kind=(scan|saved) index=(\d+) name=(.*)',line)
    if t>=start and match and re.search(self.args.bt_name,match[3],re.I):peers.append((match[1],int(match[2])))
   chosen=[p for p in peers if p[0]=='scan']
   if len(chosen)==1:
    kind,index=chosen[0];self.ack(('select=' if kind=='scan' else 'saved=')+str(index))
    self.wait(lambda p:actual_play(p,False,True,2),60,'SD_BTOUT_ACTUAL_AUDIO_TIMEOUT');return
   self.path();self.pump(2) # renew the existing path lease, never redundantly restart
  raise RuntimeError('NOT_RUN_NO_UNAMBIGUOUS_BT_PEER')
 def observe(self,seconds,web,bt=False,tour=False):
  if tour:self.menu()
  began=time.monotonic();until=began+seconds;first=None;last=None;bt_first=None;bt_last=None;cpu={}
  while time.monotonic()<until:
   p=self.path()
   if not actual_play(p,web,bt):raise RuntimeError('ACTUAL_AUDIO_LOST')
   if p['volume']!=self.original['volume']:raise RuntimeError('UNEXPECTED_VOLUME_CHANGE')
   if first is None:first=p
   last=p
   self.req('r10 heap','[DAC-I2S]',seconds=8);self.send('r10 load');self.pump(.3);self.req('r10 buffer status','[BUFFER-PROFILE]')
   if bt:
    b=fields(self.req('r10 bt status','[BT-AUDIO]'))
    if bt_first is None:bt_first=b
    bt_last=b
   expected_route=int(p['route'])|(256 if p.get('transmitting')=='1' else 0)
   for stamp,line in self.lines:
    if stamp<began or '[LOAD] result=OK' not in line:continue
    row=fields(line);window=int(row.get('window_us',0));age=int(row.get('age_us',0))
    if window>=9000000 and row.get('generation')==p['generation'] and int(row.get('route_state',-1))==expected_route and (stamp-began)*1000000>=window+age:
     cpu[(row['generation'],row['route_state'],row['window_id'])]=row
   self.pump(min(4,max(0,until-time.monotonic())))
  if first is None or last['generation']!=first['generation'] or int(last['play_seconds'])<=int(first['play_seconds']):raise RuntimeError('NO_SAME_GENERATION_AUDIO_PROGRESS')
  if bt:
   for key in ['delivered_bytes','block_frames']:
    if not delta(bt_first[key],bt_last[key]):raise RuntimeError('BT_NO_ACTUAL_PROGRESS '+key)
   if delta(bt_first['underruns'],bt_last['underruns']):raise RuntimeError('BT_STEADY_UNDERRUN_DURING_OBSERVATION')
   if 'dropped_bytes' in bt_first and delta(bt_first['dropped_bytes'],bt_last['dropped_bytes']):raise RuntimeError('BT_NEW_DROPPED_BYTES_DURING_OBSERVATION')
  if self.ui:
   self.req('r10 ui stress drain','[UI-STRESS]',readonly=False);self.pump(2)
   requested=set();rendered=set()
   for sample in self.phase['samples']:
    if sample['tag']!='UI-MENU-SCAN':continue
    v=sample['values']
    if 'page' in v and 'item' in v:
     pair=(int(v['page']),int(v['item']))
     if v.get('result')=='RENDER_REQUESTED':requested.add(pair)
     if v.get('result')=='RENDERED':rendered.add(pair)
   if not any(x['tag']=='UI-MENU-SCAN' and x['values'].get('cycle')=='REQUESTED' for x in self.phase['samples']) or requested-rendered or not all((88,i) in rendered for i in range(9)) or not all((87,i) in rendered for i in range(9)):raise RuntimeError('MENU_RENDER_ACK_OR_NEW_PAGE_COVERAGE_MISSING')
   self.phase['menu_unique_rendered']=len(rendered)
   self.req('r10 ui stress stop','[UI-STRESS]',readonly=False);self.ui=False
  weight=sum(int(r['window_us']) for r in cpu.values())
  if seconds>=30 and not weight:raise RuntimeError('NOT_RUN_NO_COMPLETE_CPU_WINDOW')
  self.phase['cpu_unique_windows']=list(cpu.values())
  self.phase['cpu_time_weighted_percent']=[sum(int(r['window_us'])*int(r['core%d_permille'%i]) for r in cpu.values())/weight/10 for i in range(2)] if weight else None
  self.phase['cpu_scope']='WHOLE_UNIQUE_9S_WINDOWS_TOTAL_CORE_LOAD_NOT_DSP_ONLY'
  self.phase.update(audio_start=first,audio_end=last,bt_start=bt_first,bt_end=bt_last)
 def run_case(self,name,seconds):
  self.phase=dict(name=name,result='RUNNING',started=utc(),samples=[]);self.state['current']=name;self.save();print(utc(),name,flush=True)
  try:
   web=name.startswith('WIFI') or name=='RETURN_WIFI';bt=name.startswith('SD_BTOUT')
   self.dsp(0,0);self.dsp(11,0)
   if 'BUFFER_' in name:self.profile(int(name.rsplit('_',1)[1]))
   if bt:self.bt_out()
   else:self.select(web,name=='SD_FLAC')
   if '_DSP_' in name:
    mode=name.rsplit('_',1)[1]
    if mode!='OFF':
     self.dsp(1,3 if mode=='STEREO' else 0)
     if mode=='TUBE':self.dsp(11,1)
     self.send('r10 load');self.pump(10);self.dsp(0,1)
     if mode=='RANGE':
      for param,limits in [(2,(40,200)),(3,(80,300)),(4,(-60,0)),(5,(250,1000)),(6,(-60,0)),(7,(-30,0)),(8,(-30,0))]:
       for value in limits:self.dsp(param,value);self.observe(6,web)
       self.dsp(param,self.config[param])
   if name.endswith('STOP_START'):
    for _ in range(3):
     self.stop_audio();self.pump(2);self.ack(('webtrack=' if web else 'sdtrack=')+str(self.args.wifi_station if web else self.args.sd_mp3));self.wait(lambda p:actual_play(p,web,codec=2),50,'STOP_START_NO_ACTUAL_AUDIO')
   self.observe(max(seconds,180) if name=='WIFI_BUFFER_0' else seconds,web,bt,tour=name=='SD_MENU' or name=='WIFI_BUFFER_0')
   if getattr(self.args,'ir_confirmed',False):self.phase['IR_state']=fields(self.req('r10 ir status','[IR-STATE]'))
   self.phase['result']='PASS_NATIVE_AUDIO_WINDOW'
  except BaseException as error:self.phase.update(result='INCOMPLETE' if isinstance(error,(Stop,Deadline,KeyboardInterrupt)) else 'FAIL_OR_NOT_RUN',error=str(error));raise
  finally:
   self.phase['ended']=utc();self.state['cases'].append(self.phase);write(self.root/('TEST_%02d_%s.json'%(len(self.state['cases']),name)),self.phase);self.phase=None;self.save()
 def initialize(self):
  identity=fields(self.req('r10 identity','[R352-IDENTITY]'))
  if identity.get('firmware')!=FW or identity.get('elf_sha256')!=self.manifest['app_elf_sha256']:raise RuntimeError('CURRENT_FIRMWARE_IDENTITY_MISMATCH_NO_MUTATION')
  self.state.update(identity_verified=identity,initialization='IDENTITY_PASS');self.save()
  self.req('r10 caps','[R10-CAPS]');self.original=fields(self.req('r10 test state','[SELFTEST-STATE]'));self.original['path']=self.path()
  self.config=self.mono_config_values()
  self.tube=fields(self.req('r10 mono status','[TUBE-DSP]'))
  if self.config[9:11]!=[1,1]:raise RuntimeError('PROTECTION_NOT_ENABLED_NO_TEST_MUTATION')
  if self.original['path']['route']!='0':raise RuntimeError('START_FROM_DAC_REQUIRED_NO_MUTATION')
  if getattr(self.args,'ir_confirmed',False):
   self.stop_audio()
   reply=self.req('r10 ir enable confirm=GPIO16_ISOLATED','[IR-ENABLE]',seconds=12,readonly=False)
   if 'result=PASS' not in reply:raise RuntimeError('IR_ENABLE_DENIED_NO_FORCE')
   self.state['IR_initial']=fields(self.req('r10 ir status','[IR-STATE]'))
   if self.state['IR_initial'].get('enabled')!='1':raise RuntimeError('IR_ENABLE_READBACK_FAILED')
  if self.path()['playing']!='1':self.send('start');self.wait(lambda p:actual_play(p),60,'INITIAL_AUDIO_REQUIRED')
  answer=self.req('r10 path begin','[PATH-BEGIN]',readonly=False)
  if 'result=PASS' not in answer:raise RuntimeError('PATH_SESSION_DENIED')
  self.path_owned=True
  if not self.args.wifi_station:
   start=time.monotonic();self.req('list','##CLI.LIST#',seconds=12)
   candidates=[]
   for stamp,line in self.lines:
    match=re.search(r'#CLI.LISTNUM#:\s*(\d+): (.*)',line)
    if stamp>=start and match and re.search(r'(?:Budapest|BDPST)\s*Rock',match[2],re.I):candidates.append(int(match[1]))
   self.args.wifi_station=candidates[0] if candidates else int(self.original['web_station'])
  self.state['IR_during_path_session']='DECODE_AND_COUNT_ACTIONS_SUPPRESSED'
  self.state.update(result='RUNNING',identity_verified=identity,original=self.original,original_dsp=self.config,original_tube=self.tube);self.save()
 def restore(self):
  self.dac();self.dsp(0,0)
  for i,value in enumerate(self.config[1:],1):self.dsp(i,value)
  for i,key in enumerate(['enabled','drive','even','odd','mix','tone_hz','trim_tenth_db'],11):self.dsp(i,int(self.tube[key]))
  self.profile(int(self.original['buffer']))
  web=self.original['mode']=='0';self.ack('sourceweb' if web else 'sourcesd');self.wait(lambda p:p['web']==str(int(web)),35,'RESTORE_SOURCE_TIMEOUT');self.stop_audio()
  track=self.original['web_station' if web else 'sd_station'];self.ack(('webtrack=' if web else 'sdtrack=')+track)
  self.wait(lambda p:actual_play(p,web),90,'RESTORE_AUDIO_TIMEOUT')
  if self.config[0]:self.send('r10 load');self.pump(10);self.dsp(0,1)
  if self.original['path']['playing']=='0':self.stop_audio()
  if self.original['path']['playing']=='0':self.send('smartstart '+self.original['smartstart']);self.pump(.5)
  self.req('r10 path end','[PATH-RESTORE]',readonly=False);self.path_owned=False
  self.wait(lambda p:p['route']=='0' and p['idle']=='1',60,'NORMAL_RESTORE_DAC_ACK')
  final=fields(self.req('r10 test state','[SELFTEST-STATE]'))
  if any(final[k]!=self.original[k] for k in ['volume','mode','buffer','web_station','sd_station','smartstart']):raise RuntimeError('ORIGINAL_STATE_READBACK_MISMATCH')
  self.state['restored']=final
  if getattr(self.args,'ir_confirmed',False):self.state['IR_final']=fields(self.req('r10 ir status','[IR-STATE]'))
 def close(self,stop_only=False):
  fatal=bool(self.hazard and FATAL.search(str(self.hazard)))
  if self.s and fatal:
   with (self.root/'panic_tail.raw').open('wb') as output:
    if self.pending:output.write(self.pending.encode('utf-8',errors='replace'));self.pending=''
    self.state['panic_tail']=capture_tail(self.s,output,self.hazard)
  # STOP cancels only the test's autonomous read-only menu tour. No mode/setting/audio restore.
  if self.ui and self.s and not fatal:
   try:self.s.write(b'r10 ui stress stop\n');self.s.flush()
   except OSError:pass
  closed=True;close_errors=[]
  if self.s:
   try:self.s.close()
   except Exception as error:closed=False;close_errors.append('SERIAL_CLOSE '+str(error))
  if self.raw:
   try:self.raw.close()
   except Exception as error:close_errors.append('LOG_CLOSE '+str(error))
  if self.lock:
   import msvcrt
   try:
    if self.locked:self.lock.seek(0);msvcrt.locking(self.lock.fileno(),msvcrt.LK_UNLCK,1);self.locked=False
   except Exception as error:close_errors.append('LOCK_RELEASE '+str(error))
   finally:self.lock.close();self.lock=None
  if close_errors:self.state.update(result='WAIT_USER_CLOSE_FAILURE',close_errors=close_errors)
  self.state.update(COM_closed=closed,ended=utc());self.save();write(self.root/'RESULT.json',self.state)
def main(argv=None):
 ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--stop',action='store_true');ap.add_argument('--port');ap.add_argument('--receipt');ap.add_argument('--ir-confirmed',action='store_true');ap.add_argument('--sd-mp3',type=int);ap.add_argument('--sd-flac',type=int,default=2);ap.add_argument('--wifi-station',type=int,default=0);ap.add_argument('--bt-name',default='VFOCUS|POLY');ap.add_argument('--max-minutes',type=float,default=90);a=ap.parse_args(argv)
 home=Path(__file__).resolve().parent.parent
 if a.stop:
  active=json.loads((home/'RETURN_TO_EVA/SELFTEST_ACTIVE.json').read_text(encoding='utf8'));root=Path(active['root']).resolve();assert (home/'RETURN_TO_EVA').resolve() in root.parents
  if active.get('COM_closed'):print('A teszt már lezárult.');return 0
  (root/'STOP_REQUEST').write_text('USER_STOP');print('Leállítás kérve.');return 0
 m=package(home)
 if a.verify_only:print('PASS_PACKAGE_ONLY_NO_COM_NO_SELFTEST');return 0
 if a.sd_mp3 is None:raise RuntimeError('NATIVE_VERIFIED_MP3_INDEX_REQUIRED_NO_COM')
 assert 15<=a.max_minutes<=720 and min(a.sd_mp3,a.sd_flac)>0 and a.wifi_station>=0
 receipt=receipt_for(m,a.receipt);t=Test(home,m,a,receipt)
 try:
  t.open();t.initialize()
  for name,seconds in PHASES:t.run_case(name,seconds)
  t.restore();t.state['result']='PASS_AUTOMATED_MATRIX_PHYSICAL_HEARING_TOUCH_AND_WEBUI_NOT_RUN'
 except Stop as error:
  reason=str(error);t.state.update(result='USER_STOP_INCOMPLETE' if reason=='USER_STOP' else 'SUPERVISOR_STOP_INCOMPLETE',stop_reason=reason)
 except KeyboardInterrupt:t.state.update(result='USER_STOP_INCOMPLETE',stop_reason='KEYBOARD_INTERRUPT')
 except Deadline:t.state['result']='DEADLINE_INCOMPLETE'
 except Exception as error:t.state.update(result='WAIT_USER_FAIL_OR_MISSING_REQUIRED_EVIDENCE',error=redact(str(error)))
 finally:t.close(stop_only=t.state['result'] in ['USER_STOP_INCOMPLETE','SUPERVISOR_STOP_INCOMPLETE','DEADLINE_INCOMPLETE'])
 print(t.state['result'],str(t.root),flush=True);return 0 if t.state['result'].startswith('PASS_') else 2
if __name__=='__main__':sys.exit(main())
