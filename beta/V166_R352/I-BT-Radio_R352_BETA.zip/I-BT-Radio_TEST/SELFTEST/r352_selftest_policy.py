"""Pure gates shared by the standalone, opt-in R352 full selftest and its host tests."""
import re
PHASES=[('SD_MENU',180),('SD_FLAC',90),('SD_DSP_RANGE',90)]+[(f'SD_DSP_{m}',60) for m in ['OFF','MONO','STEREO','TUBE']]+[(f'SD_BUFFER_{m}',60) for m in range(4)]+[('SD_STOP_START',60)]+[(f'WIFI_BUFFER_{m}',120) for m in range(4)]+[(f'WIFI_DSP_{m}',60) for m in ['OFF','MONO','STEREO','TUBE']]+[('WIFI_STOP_START',60)]+[(f'SD_BTOUT_BUFFER_{m}',90) for m in range(4)]+[('RETURN_WIFI',120),('RETURN_SD',90)]
# Recheck the exact failed WiFi profile, then the requested physical BT route.
# Every remaining phase is still mandatory on the new firmware; no R303 PASS transfer.
_first=['WIFI_BUFFER_3']+[f'SD_BTOUT_BUFFER_{i}' for i in range(4)]
PHASES=[next(p for p in PHASES if p[0]==name) for name in _first]+[p for p in PHASES if p[0] not in _first]
def fields(line):return dict(re.findall(r'(\w+)=([^\s]+)',line))
def fault(line):
 if re.search(r'\[STREAM-HEADER\].*result=FAIL|\[STREAM-REQUEST\].*ok=0|\[STREAM-MEM\].*phase=AFTER_FINAL_HEADER.*ok=0',line):return 'HTTP_SETUP_FAULT '+line
 if re.search(r'^E \(\d+\) rmt:',line):return 'IR_RMT_SDK_FAULT '+line
 if re.search(r'\[TLS-IO\].*result=FAIL|\[STREAM-CLOSED\]|\[STREAM-RECOVERY\].*TRANSPORT_CLOSED|\[STREAM-TRANSPORT\].*ok=0|\[E\]\[(?:ssl_client|NetworkClientSecure)\.cpp',line):return 'TLS_TRANSPORT_FAULT '+line
 if re.search(r'Guru Meditation|CORRUPT HEAP|assert failed|stack overflow|Stack canary|Task watchdog|Memory allocation failed|calloc failed|malloc failed|NO_MEM|CMD_ERROR|unknown command|network_quiescence_timeout|lifecycle_fault=',line,re.I):return line
 if re.search(r'\bmem_errors=[1-9]|\[BT-STARTUP\].*rollback=|\[PREBUFFER\] FAIL|\[PATH-RESTORE\].*FAIL',line):return line
 if 'rst:0x' in line or '[BOOT-RESET]' in line:return 'UNEXPECTED_RESET '+line
 return None
def command_allowed(cmd):
 return bool(re.fullmatch(r'r10 (?:artwork (?:retries(?: (?:0|5|10|15|20))?|status|storage|download|[0-2]|bench (?:off|(?:1|2|4|8|16|32|64|128) [01]))|ir status|ir enable confirm=GPIO16_ISOLATED|identity|caps|test state|heap|load|status|sd status|bt status|bt off|buffer status|buffer set [0-3]|mono status|mono set \d+ -?\d+|ui stress (?:start action=500 draw=500 tour=2|status|drain|stop)|path (?:status|begin|end|devices|sourceweb|sourcesd|dac|scan|select=\d+|saved=\d+|(?:sd|web)track=\d+))|stop|start|list|mode [01]|smartstart [0-2]',cmd))
def actual_play(path,web=None,bt=False,codec=None):
 return path.get('playing')=='1' and path.get('decoded')=='1' and (web is None or path.get('web')==str(int(web))) and (not bt or (path.get('connected')=='1' and path.get('transmitting')=='1')) and (codec is None or path.get('source_codec')==str(codec))
def delta(before,after):return (int(after)-int(before))&0xffffffff
def verified(receipt,manifest):
 return receipt.get('result')=='PASS_FLASH_HASH_BOOT' and receipt.get('firmware')==manifest['firmware'] and receipt.get('profile_id')=='lite4' and receipt.get('selected_firmware_sha256')==manifest['firmware_sha256']
