"""Finite SD bootstrap, independent of an unrelated saved WiFi station.

Only existing normal STOP/source/start commands; no reset, flash, credentials,
volume change or retry. Restore the pre-bootstrap source/play state on success.
"""
from r352_selftest_policy import fields,actual_play

def prepare(t):
 identity=fields(t.req('r10 identity','[R352-IDENTITY]'))
 if identity.get('firmware')!='V166-R352' or identity.get('elf_sha256')!=t.manifest['app_elf_sha256']:
  raise RuntimeError('BOOTSTRAP_IDENTITY_MISMATCH_NO_MUTATION')
 t.state.update(identity_verified=identity,initialization='BOOTSTRAP_IDENTITY_PASS');t.save()
 original=fields(t.req('r10 test state','[SELFTEST-STATE]'))
 config=fields(t.req('r10 mono status','[MONO-DSP-CONFIG]'))['values'].split(',')
 if config[9:11]!=['1','1']:raise RuntimeError('BOOTSTRAP_PROTECTION_NOT_ENABLED')
 before=t.path()
 if before['route']!='0' or before['idle']!='1':raise RuntimeError('BOOTSTRAP_DAC_NOT_IDLE_NO_MUTATION')
 saved_track=original.get('sd_station','')
 if not saved_track.isdigit() or not 1<=int(saved_track)<=32767:raise RuntimeError('BOOTSTRAP_SAVED_SD_INDEX_INVALID_NO_MUTATION')
 original['path']=before
 intent=t.state.get('bootstrap_restore_intent')
 if intent:
  for key in ['volume','buffer','web_station','smartstart']:
   if intent.get(key)!=original.get(key):raise RuntimeError('BOOTSTRAP_RESTORE_INTENT_CHANGED_NO_MUTATION '+key)
  t.state['bootstrap_fresh_state']=original;original=intent
 t.state['bootstrap_original']=original;t.save()
 t.stop_audio()
 if before['web']!='0':
  t.send('mode 1');t.wait(lambda p:p['web']=='0',35,'BOOTSTRAP_SD_SOURCE_NOT_VERIFIED')
 # Do not depend on a saved unsupported FLAC. Select the known test MP3 once;
 # its saved selection is explicitly restored below, with readback.
 t.stop_audio();t.bootstrap_play(t.args.sd_mp3)
 def track_ready(p):return actual_play(p,False,codec=2) and p.get('source_local')=='1' and p.get('station')==str(t.args.sd_mp3)
 t.wait(track_ready,45,'BOOTSTRAP_SD_AUDIO_NOT_VERIFIED')
 t.state['bootstrap_SD_actual_audio']=t.path();t.save()
 return original

def restore(t,original):
 t.stop_audio()
 # Base runner returned to the bootstrap SD source. Restore the saved SD
 # selection before leaving SD; no decoded-audio claim for that old file.
 current=fields(t.req('r10 test state','[SELFTEST-STATE]'))
 if current['sd_station']!=original['sd_station']:
  if t.path()['web']!='0':raise RuntimeError('BOOTSTRAP_SD_SELECTION_RESTORE_WRONG_SOURCE')
  t.bootstrap_play(int(original['sd_station']))
  t.wait(lambda p:p.get('station')==original['sd_station'],10,'BOOTSTRAP_SAVED_SD_SELECTION_NOT_VERIFIED')
  t.stop_audio()
 web=original['mode']=='0'
 if t.path()['web']!=str(int(web)):
  t.send('mode '+original['mode']);t.wait(lambda p:p['web']==str(int(web)),35,'BOOTSTRAP_RESTORE_SOURCE_NOT_VERIFIED')
 if original['path']['playing']=='1':
  if not actual_play(t.path(),web):
   t.send('start');t.wait(lambda p:actual_play(p,web),180 if web else 45,'BOOTSTRAP_ORIGINAL_AUDIO_NOT_VERIFIED')
 else:t.stop_audio()
 final=fields(t.req('r10 test state','[SELFTEST-STATE]'))
 for key in ['volume','mode','buffer','web_station','sd_station','smartstart']:
  if final.get(key)!=original.get(key):raise RuntimeError('BOOTSTRAP_RESTORE_READBACK_MISMATCH '+key)
 t.state['bootstrap_original_restored']=final;t.save()
