"""Bounded passive panic-tail collection. Never sends device commands or resets."""
import re,time
FATAL=re.compile(r'Guru Meditation|panic.ed|assert failed|Stack canary|stack overflow|Task watchdog',re.I)
def capture_tail(serial,output,hazard,seconds=2.0,clock=time.monotonic):
 if not FATAL.search(str(hazard)):return dict(result='NOT_FATAL_NO_DRAIN',bytes=0)
 assert 0<seconds<=3
 start=clock();total=0
 try:
  while clock()-start<seconds:
   block=serial.read(max(1,min(serial.in_waiting,8192)))
   if block:output.write(block);total+=len(block)
  output.flush()
  return dict(result='PASS_PASSIVE_FATAL_TAIL_CAPTURE',bytes=total,elapsed_seconds=clock()-start,commands_sent=0)
 except Exception as error:
  return dict(result='PARTIAL_PASSIVE_FATAL_TAIL_CAPTURE',bytes=total,error=str(error),commands_sent=0)
