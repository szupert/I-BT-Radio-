"""Detached R352 Poly-only retry. No firmware/package modification or reset.

Measure CPU throughout guarded redraws, allowing one slow frame to complete;
never require a second 180s frame inside a fixed 60s observation window.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time
HOME=Path('C:/esp32/USER/I-BT-Radio_TEST')
sys.path.insert(0,str(HOME/'SELFTEST'))
import r352_full_selftest as m
from r352_target_then_full import Owner
from r352_artwork_selftest import mode

ORDER=[128,32,8]
COHORT=['source','station','source_hash','source_w','source_h','buffers']

def check_bt(first,last):
 for k in ['underruns','dropped_bytes']:
  if k not in first or k not in last:raise RuntimeError('MISSING_BT_COUNTER '+k)
  if m.delta(first[k],last[k]):raise RuntimeError('NEW_POLY_RENDER_'+k.upper())

def folders_status(t):
 for attempt in range(3):
  values=m.fields(t.req('r10 sd status','[SD-FOLDERS-STATUS]'))
  keys=['checked','ok','created','reused','failed']
  if all(values.get(k,'').isdigit() for k in keys) and values.get('source')=='CACHED_OWNER_RESULT':return values
  t.state.setdefault('readonly_incomplete_folder_status',[]).append(dict(attempt=attempt+1))
  if attempt<2:t.pump(.25)
 raise RuntimeError('INCOMPLETE_FOLDER_STATUS_AFTER_3_READS')

def completed(v,ack):
 return (v.get('selection')==ack.get('selection') and v.get('batch')==ack.get('rows')
         and v.get('order')==ack.get('order') and v.get('complete')=='1'
         and v.get('emitted')==v.get('height') and v.get('height')=='240')

def source_observation(v):
 if v.get('source')=='DEFAULT_FLASH' and v.get('source_hash')=='00000000' and all(v.get(k)=='0' for k in ['emitted','source_reads','lcd_calls','complete','canonical_verified']):return None
 return tuple(v[k] for k in COHORT)

def cpu_row(row,stamp,began,path):
 window=int(row.get('window_us',0));age=int(row.get('age_us',0))
 return (window>=9000000 and row.get('generation')==path['generation']
         and int(row.get('route_state',-1))==257
         and (stamp-began)*1000000>=window+age)

class PolyOwner(Owner):
 def send(self,cmd):
  if cmd=='wifi.status':
   self.gate()
   if self.transport_evidence.pending:raise RuntimeError('READONLY_BOOTSTRAP_WITH_PENDING_TCP')
   self.s.write(b'wifi.status\n');self.s.flush();return
  return super().send(cmd)
 def bootstrap_play(self,index):
  # Exact telnet.cpp gate; the LIGHT compact heap record has no IP field.
  start=time.monotonic();stable=0
  while time.monotonic()-start<180:
   values=m.fields(self.req('wifi.status','[WIFI-SETUP-STATE]'))
   ready=values.get('status')=='0' # network.h enum CONNECTED=0
   stable=stable+1 if ready else 0
   self.state['bootstrap_cli_readiness']={'legacy_connected':ready,'stable_samples':stable,'elapsed_seconds':time.monotonic()-start,'native_status':values.get('status'),'mutation_replayed':False};self.save()
   if stable>=2:break
   self.pump(.75)
  else:raise RuntimeError('LEGACY_CLI_NETWORK_NOT_READY_NO_PLAY_MUTATION')
  return super().bootstrap_play(index)
 def restore(self):
  # Restore the verified MP3/path baseline. Do not replay an unrelated saved
  # FLAC or WiFi station after their known allocation failures.
  m.Test.restore(self)
  self.state['pre_bootstrap_user_restore']='PENDING_NOT_REPLAYED_KNOWN_FLAC_WIFI_ALLOCATION_FAILURES'

def request(t,rows,order):
 a=m.fields(t.req(f'r10 artwork bench {rows} {order}','[ART-BENCH-ACK]',readonly=False))
 if a.get('result')!='PASS' or a.get('rows')!=str(rows) or a.get('order')!=str(order) or 'selection' not in a:
  raise RuntimeError('UNKNOWN_OR_DENIED_BENCH_SETTING_NO_RETRY')
 return a

def measure(t,rows,order):
 t.dsp(0,0);t.dsp(11,0);t.bt_out()
 path0=t.path();bt0=m.fields(t.req('r10 bt status','[BT-AUDIO]'))
 if not m.actual_play(path0,False,True,2):raise RuntimeError('POLY_MP3_NOT_ACTUAL')
 mode(t,2);ack=request(t,rows,order)
 began=time.monotonic();deadline=began+240;frames={};cpu={};cohorts=set();lastsave=began;btlast=bt0
 while time.monotonic()<deadline:
  p=t.path()
  if p['generation']!=path0['generation'] or p['route']!=path0['route'] or not m.actual_play(p,False,True,2):
   raise RuntimeError('POLY_GENERATION_ROUTE_OR_AUDIO_LOST')
  if p['volume']!=t.original['volume']:raise RuntimeError('UNEXPECTED_VOLUME_CHANGE')
  if int(p['play_seconds'])>=300:raise RuntimeError('NOT_RUN_SONG_END_DRAIN_GUARD')
  art=m.fields(t.req('r10 artwork status','[ART-BENCH]',seconds=8))
  btlast=m.fields(t.req('r10 bt status','[BT-AUDIO]'));check_bt(bt0,btlast)
  t.req('r10 heap','[DAC-I2S]');t.req('r10 buffer status','[BUFFER-PROFILE]');t.send('r10 load');t.pump(.3)
  if art.get('selection')==ack['selection'] and all(k in art for k in COHORT):
   observed=source_observation(art)
   if observed is not None:cohorts.add(observed)
  for stamp,line in t.lines:
   if stamp<began or '[LOAD] result=OK' not in line:continue
   v=m.fields(line)
   if cpu_row(v,stamp,began,p):cpu[(v['generation'],v['route_state'],v['window_id'])]=v
  if completed(art,ack):
   frames[art['selection']]=art
   if time.monotonic()-began<60:
    old=ack['selection'];ack=request(t,rows,order)
    if old==ack['selection']:raise RuntimeError('REDRAW_SELECTION_NOT_NEW')
  t.phase.update(render_frames=list(frames.values()),last_artwork=art,bt_start=bt0,bt_end=btlast,
                 audio_start=path0,audio_end=p,elapsed_seconds=time.monotonic()-began,
                 cpu_unique_windows=list(cpu.values()),observed_source_cohorts=[list(c) for c in sorted(cohorts)])
  if time.monotonic()-lastsave>=10:
   t.state['phase_progress']={k:t.phase[k] for k in ['last_artwork','bt_start','bt_end','elapsed_seconds','observed_source_cohorts']}
   t.state['phase_progress']['completed_frames']=len(frames);t.state['phase_progress']['cpu_windows']=len(cpu)
   t.save();lastsave=time.monotonic()
  if time.monotonic()-began>=60 and frames:break
  t.pump(.5)
 if not frames:raise RuntimeError('NOT_RUN_POLY_RENDER_240S_GUARD_TIMEOUT')
 weight=sum(int(v['window_us']) for v in cpu.values())
 if not weight:raise RuntimeError('NOT_RUN_NO_COMPLETE_RENDER_CPU_WINDOW')
 for k in ['delivered_bytes','block_frames']:
  if not m.delta(bt0[k],btlast[k]):raise RuntimeError('POLY_NO_DATA_PROGRESS '+k)
 t.phase['cpu_time_weighted_percent']=[sum(int(v['window_us'])*int(v[f'core{i}_permille']) for v in cpu.values())/weight/10 for i in range(2)]
 t.phase['cpu_scope']='UNIQUE_FULL_9S_WINDOWS_GUARDED_DRAW_AND_QUERY_OVERHEAD_FIXED_MP3_DSP_OFF'
 ram=[v['values'] for v in t.phase['samples'] if v['tag']=='R10-TELEM']
 if not ram:raise RuntimeError('MISSING_MEMORY_EVIDENCE')
 t.phase['memory_min']={k:min(int(v[k]) for v in ram if k in v) for k in ['heap_internal','heap_largest']}
 t.phase['comparison_cohort']=['SD_POLY']+list(next(iter(cohorts))) if len(cohorts)==1 else None
 t.phase['result']='PASS_GUARDED_POLY_DRAW_NOT_HUMAN_HEARING' if len(cohorts)==1 else 'NOT_COMPARABLE_SOURCE_CHANGED_AUDIO_WINDOW_PASSED'

def run(t):
 original=m.fields(t.req('r10 artwork status','[LOCAL-ART-SETTINGS]'));t.state['artwork_original']=original
 for i,(rows,order) in enumerate([(r,o) for r in ORDER for o in [0,1]],1):
  name=f'SD_POLY_ONLY_R{rows}_O{order}'
  t.phase=dict(name=name,result='RUNNING',started=m.utc(),samples=[])
  t.state.update(current=name,progress_cases=i-1,total_cases=len(ORDER)*2);t.state.pop('phase_progress',None);t.save()
  print(m.utc(),name,f'{i}/{len(ORDER)*2}',flush=True)
  try:
   measure(t,rows,order)
   if not t.phase.get('render_frames') or any(f.get('source')!='SD_PACK' for f in t.phase['render_frames']):raise RuntimeError('NOT_RUN_REAL_SD_COVER_IO_GENERIC_FALLBACK_IS_NOT_COVER_PASS')
  except BaseException as e:t.phase.update(result='FAIL_OR_NOT_RUN',error=str(e));raise
  finally:
   t.phase['ended']=m.utc();t.state['cases'].append(t.phase);m.write(t.root/f'POLY_{i:02d}_{name}.json',t.phase);t.phase=None;t.save()
 t.req('r10 artwork bench off','[ART-BENCH-ACK]',readonly=False);mode(t,int(original['mode']));t.restore()
 t.state.update(progress_cases=len(ORDER)*2,result='COMPLETED_WITH_NONCOMPARABLE_CASES' if any(c['result'].startswith('NOT_COMPARABLE') for c in t.state['cases']) else 'PASS_POLY_RENDER_MATRIX_HEARING_AND_ORIGINAL_USER_RESTORE_REVIEW_REQUIRED')

def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--sd-mp3',type=int,required=True);a=p.parse_args();assert 1<=a.sd_mp3<=65535
 if not a.execute:raise SystemExit('NO_COM_WITHOUT_EXPLICIT_EXECUTE')
 pointer=Path('C:/esp32/SYSTEM/LOGS/REPORTS/RADIO_CONTINUOUS_ACTIVE.json');previous=json.loads(pointer.read_text(encoding='utf-8-sig')) if pointer.exists() else {}
 manifest=m.package(HOME);args=argparse.Namespace(port='COM4',ir_confirmed=False,sd_mp3=a.sd_mp3,sd_flac=2,wifi_station=6,bt_name='VFOCUS|POLY',max_minutes=120)
 t=PolyOwner(HOME,manifest,args,m.receipt_for(manifest))
 t.state.update(scope='R352_AUTO_POLY_FAST_CANDIDATES_240S_RENDER_GUARD_300S_SONG_DRAIN',
   previous_root=previous.get('root'),
   host_script=str(Path(__file__).resolve()),host_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
   GitHub_published=False,known_failures_preserved=['R321_MONO_CSV_RESTORE_HOST_FAIL','R320_120S_RENDER_TIMEOUT','R319_FLAC_INPUT','WIFI_TLS_INPUT'],original_WEB9_smartstart0_restore='PENDING')
 try:
  t.open();t.initialize()
  folders=folders_status(t)
  t.state['SD_work_folders']=folders;t.save()
  if folders.get('checked')!='1' or folders.get('ok')!='1':raise RuntimeError('SD_WORK_FOLDERS_NOT_PREPARED_NO_FORCE_OR_RETRY')
  run(t)
 except m.Stop as e:t.state.update(result='USER_STOP_INCOMPLETE' if str(e)=='USER_STOP' else 'SUPERVISOR_MAINTENANCE_INCOMPLETE',stop_reason=str(e))
 except (KeyboardInterrupt,m.Deadline):t.state['result']='STOP_OR_DEADLINE_INCOMPLETE'
 except Exception as e:t.state.update(result='WAIT_USER_POLY_RETEST_FAIL_OR_MISSING_EVIDENCE',error=m.redact(str(e)))
 finally:t.close(stop_only=not t.state['result'].startswith('PASS_'))
 print(t.state['result'],str(t.root),flush=True);return 0 if t.state['result'].startswith('PASS_') else 2
if __name__=='__main__':sys.exit(main())
