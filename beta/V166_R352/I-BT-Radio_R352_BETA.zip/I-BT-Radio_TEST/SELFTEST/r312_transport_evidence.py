"""Observe the firmware's existing single TCP-open retry, without requesting one.

The SDK error precedes STREAM-TRANSPORT/STREAM-OPEN. Keep the raw attempt,
but do not close UART before its bounded, owner-reported final outcome.
"""
import re,time

class TransportEvidence:
 def __init__(self,base_fault):
  self.base_fault=base_fault;self.pending=None;self.deadline=0;self.attempts=[];self.recovered=[]
 def check(self):
  if self.pending and time.monotonic()>=self.deadline:
   raise RuntimeError('TCP_OPEN_OUTCOME_MISSING_NO_RECOVERY '+self.pending['line'])
 def fault(self,line):
  # Only SDK's exact pre-handshake generic -1 is provisional. OOM, TLS,
  # HTTP, EOF, heap, CPU guard and all other SDK failures remain immediate.
  if re.search(r'\[E\]\[NetworkClientSecure\.cpp:\d+\] connect\(\): start_ssl_client: connect failed: -1$',line):
   if self.pending and self.pending.get('retry'):
    return 'TCP_OPEN_RETRY_EXHAUSTED '+line
   self.pending={'line':line,'retry':False,'timeout_verified':False};self.attempts.append(self.pending)
   self.deadline=time.monotonic()+10;return None
  if self.pending and '[STREAM-TRANSPORT] phase=TCP_TLS_INIT ' in line:
   v=dict(re.findall(r'(\w+)=([^\s]+)',line))
   if v.get('ok')=='0':
    if v.get('code')!='-1' or int(v.get('timeout_ms','0'))<=0 or int(v.get('elapsed_ms','0'))<int(v['timeout_ms']):
     return 'TCP_OPEN_NOT_TIMEOUT '+line
    self.pending['timeout_verified']=True;return None
  if self.pending and '[STREAM-OPEN]' in line:
   v=dict(re.findall(r'(\w+)=([^\s]+)',line))
   if v.get('ok')=='0':
    if v.get('retry')!='1' or not self.pending['timeout_verified'] or self.pending['retry']:
     return 'TCP_OPEN_FINAL_FAILURE '+line
    self.pending['retry']=True;self.deadline=time.monotonic()+150;return None
  if self.pending and '[STREAM-TRANSPORT] phase=TLS_HANDSHAKE ok=1 ' in line:
   if not self.pending['retry']:return 'TCP_OPEN_UNEXPLAINED_SUCCESS '+line
   self.pending['outcome']='EXISTING_NATIVE_RETRY_TLS_CONNECTED';self.recovered.append(self.pending);self.pending=None
  return self.base_fault(line)
