"""Single-owner R352 artwork A/B test. Explicit execute, no flash/reset/recovery."""
from pathlib import Path
import argparse,hashlib,json,sys,time
HOME=Path('C:/esp32/USER/I-BT-Radio_TEST');sys.path.insert(0,str(HOME/'SELFTEST'))
import r352_full_selftest as m
from r352_target_then_full import Owner

def mode(t,value):
 t.req('r10 path status','[PATH-STATE]',seconds=2)
 began=time.monotonic();line=t.req('r10 artwork '+str(value),'[LOCAL-ART-MODE] applied=',seconds=8,readonly=False)
 ack_seconds=time.monotonic()-began
 if m.fields(line).get('applied')!=str(value):raise RuntimeError('ARTWORK_APPLY_MISMATCH')
 t.req('r10 path status','[PATH-STATE]',seconds=2)
 state=m.fields(t.req('r10 artwork status','[LOCAL-ART-SETTINGS]',seconds=8))
 if state.get('mode')!=str(value) or state.get('vu_allowed')!=str(int(value==0)):raise RuntimeError('ARTWORK_EXCLUSION_READBACK_FAILED')
 if t.phase is not None:t.phase.setdefault('mode_transitions',[]).append(dict(mode=value,command_to_ack_seconds=ack_seconds,command_to_verified_readback_seconds=time.monotonic()-began,scope='SERIAL_CONTROL_AND_NATIVE_READBACK_NOT_TOUCH_OR_PIXEL_LATENCY'))
 return state

def rendered_for_mode(values,selected,station,begins):
 # UI snapshot generation and player playback generation are independent.
 return (values.get('mode')==str(selected) and values.get('station')==str(station)
         and values.get('generation') in begins and int(values.get('row',0))==(240 if selected==2 else 64))

def run(t,seconds):
 original=m.fields(t.req('r10 artwork status','[LOCAL-ART-SETTINGS]',seconds=8));t.state['artwork_original']=original
 t.stop_audio();t.state['SD_filesystem_storage']=m.fields(t.req('r10 artwork storage','[ART-STORAGE] result=',seconds=45,readonly=False));t.save()
 for route in ['SD_DAC','SD_POLY','WIFI_DAC']:
  preparation=dict(name=route+'_PREPARE',result='RUNNING',started=m.utc(),samples=[])
  t.phase=preparation;t.state['current']=preparation['name'];t.save()
  try:
   t.dsp(0,0);t.dsp(11,0)
   if route=='SD_POLY':t.bt_out()
   else:t.select(route=='WIFI_DAC',False)
   preparation['result']='PASS_ROUTE_ACTUAL_AUDIO_PREPARATION'
  except BaseException as error:
   preparation.update(result='FAIL_OR_NOT_RUN',error=str(error));raise
  finally:
   preparation['ended']=m.utc();t.state.setdefault('route_preparations',[]).append(preparation)
   m.write(t.root/(route+'_PREPARE.json'),preparation);t.phase=None;t.save()
  for selected in range(3):
   name=route+'_ARTWORK_'+str(selected);t.phase=dict(name=name,result='RUNNING',started=m.utc(),samples=[]);t.state['current']=name;t.save()
   try:
    before=t.path();mode_started=time.monotonic();dac_start=m.fields(t.req('r10 heap','[DAC-I2S]',seconds=8));t.phase['mode']=mode(t,selected);t.pump(1)
    if selected:
     deadline=time.monotonic()+75;rendered=False
     while time.monotonic()<deadline:
      lease=m.fields(t.req('r10 path status','[PATH-STATE]',seconds=2))
      if lease.get('route')!=before['route'] or lease.get('generation')!=before['generation'] or lease.get('playing')!='1' or lease.get('decoded')!='1':raise RuntimeError('RENDER_WAIT_AUDIO_OR_ROUTE_LOST')
      line=t.req('r10 artwork status','[LOCAL-ART] mode=',seconds=8);v=m.fields(line)
      begins={m.fields(line).get('generation') for stamp,line in t.lines if stamp>=mode_started and '[LOCAL-ART] begin=1 ' in line and m.fields(line).get('mode')==str(selected)}
      if rendered_for_mode(v,selected,before['station'],begins):rendered=True;break
      t.pump(1)
     if not rendered:raise RuntimeError('NOT_RUN_ARTWORK_RENDER_BLOCKED_BY_GUARD')
     t.phase['render_readback']=v
     t.phase['mode_to_render_verified_seconds']=time.monotonic()-mode_started
     t.phase['external_station_asset_test']='PASS_SD_ROW_READER' if v.get('source')=='SD_PACK' else 'NOT_RUN_DEFAULT_FLASH_ONLY'
    t.observe(seconds,route=='WIFI_DAC',route=='SD_POLY')
    after=t.path();dac_end=m.fields(t.req('r10 heap','[DAC-I2S]',seconds=8))
    t.phase['DAC_observed_delta']={k:m.delta(dac_start[k],dac_end[k]) for k in ['calls','accepted','short','zero','errors']}
    if t.phase['DAC_observed_delta']['errors']:raise RuntimeError('NEW_DAC_ERROR_DURING_ARTWORK_AB')
    t.phase['DAC_gap_limit']='LIFETIME_MAX_NOT_FRESH_AUDIBLE_PROOF'
    if after['generation']!=before['generation']:raise RuntimeError('ARTWORK_CHANGED_AUDIO_GENERATION')
    state=m.fields(t.req('r10 artwork status','[LOCAL-ART-SETTINGS]',seconds=8))
    if state.get('mode')!=str(selected) or state.get('vu_allowed')!=str(int(selected==0)):raise RuntimeError('ARTWORK_MODE_CHANGED')
    ram=[x['values'] for x in t.phase['samples'] if x['tag']=='R10-TELEM']
    t.phase['memory_observed_min']={key:min(int(x[key]) for x in ram if key in x) for key in ['heap_internal','heap_largest']} if ram else None
    t.phase['result']='PASS_NATIVE_ARTWORK_AUDIO_WINDOW_NOT_HUMAN_HEARING'
   except BaseException as error:t.phase.update(result='FAIL_OR_NOT_RUN',error=str(error));raise
   finally:
    t.phase['ended']=m.utc();t.state['cases'].append(t.phase);m.write(t.root/('ART_%02d_%s.json'%(len(t.state['cases']),name)),t.phase);t.phase=None;t.save()
 mode(t,int(original['mode']));t.state['artwork_mode_restored']=m.fields(t.req('r10 artwork status','[LOCAL-ART-SETTINGS]'))
 t.restore();t.state.update(result='PASS_AUTOMATED_ARTWORK_AB_MANUAL_PIXEL_HEARING_NOT_RUN',full_result='NOT_RUN_FULL_MATRIX_SEPARATE',GitHub_published=False)

def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--sd-mp3',type=int,required=True);p.add_argument('--receipt');p.add_argument('--seconds',type=int,default=90);a=p.parse_args()
 if not a.execute:raise SystemExit('NO_COM_WITHOUT_EXPLICIT_EXECUTE')
 if a.seconds<60:raise SystemExit('At least 60 seconds per A/B window')
 manifest=m.package(HOME);receipt=m.receipt_for(manifest,a.receipt);args=argparse.Namespace(port='COM4',ir_confirmed=False,sd_mp3=a.sd_mp3,sd_flac=2,wifi_station=6,bt_name='VFOCUS|POLY',max_minutes=90)
 t=Owner(HOME,manifest,args,receipt);t.state.update(scope='ARTWORK_VU_EXCLUSIVE_AB_SD_DAC_SD_POLY_WIFI_DAC',host_script=str(Path(__file__).resolve()),host_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),GitHub_published=False)
 try:t.open();t.initialize();run(t,a.seconds)
 except m.Stop as e:t.state.update(result='USER_STOP_INCOMPLETE' if str(e)=='USER_STOP' else 'SUPERVISOR_MAINTENANCE_INCOMPLETE',stop_reason=str(e))
 except (KeyboardInterrupt,m.Deadline):t.state['result']='STOP_OR_DEADLINE_INCOMPLETE'
 except Exception as e:t.state.update(result='WAIT_USER_ARTWORK_FAIL_OR_MISSING_EVIDENCE',error=m.redact(str(e)))
 finally:t.close(stop_only=not t.state['result'].startswith('PASS_'))
 print(t.state['result'],str(t.root),flush=True);return 0 if t.state['result'].startswith('PASS_') else 2
if __name__=='__main__':sys.exit(main())
