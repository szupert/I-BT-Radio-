"""External control only: every search/download/save/render runs on the radio."""
from pathlib import Path
import argparse,hashlib,sys,time,json
HOME=Path('C:/esp32/USER/I-BT-Radio_TEST')
sys.path.insert(0,str(HOME/'SELFTEST'))
import r352_full_selftest as m
POINTER=Path('C:/esp32/SYSTEM/LOGS/REPORTS/RADIO_CONTINUOUS_ACTIVE.json')
class Probe(m.Test):
 def pump(self,seconds):
  super().pump(seconds)
  # Keep radio diagnostics and commit evidence beyond the sliding UART window.
  cursor=getattr(self,'evidence_cursor',float('-inf'))
  for stamp,line in self.lines:
   if stamp<=cursor:continue
   if any(tag in line for tag in ['[ART-PEER]','[ART-TRANSPORT-ERROR]','[ART-FAILOVER]','[ART-RETRY]','[ART-NET-WAIT]','[ART-WORKER-GUARD]','[ART-PROVIDER]','[ART-PROVIDER-NEXT]','[ART-IMAGE-FALLBACK]']):
    rows=self.state.setdefault('radio_transport',[]);rows.append(line)
    if len(rows)>512:del rows[:-512]
   if '[SD-COVER-META]' in line or '[SD-COVER-TRACK]' in line:
    rows=self.state.setdefault('radio_metadata',[]);rows.append(line)
    if len(rows)>512:del rows[:-512]
    if '[SD-COVER-META]' in line:
     reason=m.fields(line).get('reason','UNKNOWN');counts=self.state.setdefault('radio_metadata_reasons',{});counts[reason]=counts.get(reason,0)+1
   if '[MANUAL-ART-VERIFY]' in line or '[MANUAL-ART-FILE]' in line:
    rows=self.state.setdefault('radio_file_verification',[])
    if line not in rows:rows.append(line)
  if self.lines:self.evidence_cursor=max(cursor,self.lines[-1][0])
 def save(self):
  super().save();m.write(POINTER,{k:self.state.get(k) for k in ['firmware','root','pid','result','started','updated','COM_closed','current','host_source_sha256']})
 def send(self,cmd):
  if cmd in ['r10 artwork sd start','r10 artwork sd status','r10 artwork sd cancel']:
   self.gate();self.s.write((cmd+'\n').encode());self.s.flush();self.state.setdefault('native_cover_commands',[]).append(dict(utc=m.utc(),command=cmd));self.save();return
  return super().send(cmd)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--max-minutes',type=int,default=0);args=ap.parse_args()
 if not args.execute:raise SystemExit('NO_COM_WITHOUT_EXECUTE')
 previous=json.loads(POINTER.read_text(encoding='utf-8-sig')) if POINTER.exists() else {}
 manifest=m.package(HOME);receipt=m.receipt_for(manifest);t=Probe(HOME,manifest,argparse.Namespace(port='COM4',max_minutes=max(5,args.max_minutes+2)),receipt)
 if args.max_minutes<0:raise RuntimeError('INVALID_TEST_TIME_LIMIT')
 if args.max_minutes==0:t.end=float('inf')
 t.state.update(previous_root=previous.get('root'),previous_result=previous.get('result'))
 t.state.update(scope='NATIVE_RADIO_SD_COVER_BATCH_STORAGE_NOT_AUDIO_PASS',current='IDENTITY_STOPPED_PREPARATION',result='RUNNING',host_script=str(Path(__file__).resolve()),host_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),PC_image_download=False)
 try:
  t.open();identity=m.fields(t.req('r10 identity','[R352-IDENTITY]'))
  if identity.get('firmware')!=m.FW or identity.get('elf_sha256')!=manifest['app_elf_sha256']:raise RuntimeError('IDENTITY_MISMATCH_NO_MUTATION')
  t.state['identity_verified']=identity;values=t.mono_config_values()
  if len(values)!=11 or values[9:11]!=[1,1]:raise RuntimeError('INCOMPLETE_PROTECTION_READBACK_NO_START')
  t.state['original_path']=t.path();t.state['heap_before']=m.fields(t.req('r10 heap','[R10-TELEM]'));t.state['current']='WAIT_NATIVE_WORKER_IDLE';t.save();deadline=time.monotonic()+120;idleReads=0;existing_cancel_sent=False
  while idleReads<2:
   status=m.fields(t.req('r10 artwork status','[MANUAL-ART-STATUS]',seconds=10));idleReads=idleReads+1 if status.get('busy')=='0' else 0
   if status.get('busy')=='1' and not existing_cancel_sent:
    t.req('r10 artwork sd cancel','[SD-COVER-BATCH] cancel=',readonly=False);existing_cancel_sent=True
    t.state['preparation_cancel']='NORMAL_NATIVE_ARTWORK_CANCEL_FOR_REQUESTED_SD_TEST_NOT_USER_STOP';t.save()
   if time.monotonic()>=deadline:raise RuntimeError('EXISTING_NATIVE_WORKER_NOT_IDLE_NO_BATCH_START')
   if idleReads<2:t.pump(1.6)
  t.dac()
  t.state['retry_settings_unchanged']=m.fields(t.req('r10 artwork retries','[ART-RETRY-SETTINGS]'));t.save()
  t.state['radio_file_verification']=[];t.evidence_cursor=t.lines[-1][0] if t.lines else time.monotonic();t.state['current']='RADIO_BATCH';t.save();began=time.monotonic()
  ack=t.req('r10 artwork sd start','[SD-COVER-BATCH] request=',readonly=False)
  if 'request=QUEUED' not in ack:raise RuntimeError('BATCH_NOT_QUEUED_NO_RETRY')
  terminal=None;last=0
  while args.max_minutes==0 or time.monotonic()-began<args.max_minutes*60:
   t.pump(.25)
   terminal=next((line for stamp,line in reversed(t.lines) if stamp>=began and '[SD-COVER-BATCH] state=' in line),None)
   if terminal:break
   if time.monotonic()-last>=10:
    t.req('r10 artwork sd status','[SD-COVER-STATUS] row=6',seconds=10);t.req('r10 heap','[R10-TELEM]');last=time.monotonic();t.save()
  if not terminal:
   t.send('r10 artwork sd cancel');until=time.monotonic()+30
   while time.monotonic()<until and not terminal:
    t.pump(.25);terminal=next((line for stamp,line in reversed(t.lines) if stamp>=began and '[SD-COVER-BATCH] state=' in line),None)
   if not terminal:raise RuntimeError('CANCEL_OUTCOME_NOT_OBSERVED_NO_RETRY')
  t.state['native_batch_terminal']=m.fields(terminal);t.state['file_verification']=t.state.get('radio_file_verification',[]);t.state['heap_after']=m.fields(t.req('r10 heap','[R10-TELEM]'));t.state['path_after']=t.path();v=t.state['native_batch_terminal']
  if v.get('state')=='7':
   t.state.update(result='PARTIAL_NATIVE_BATCH_PROVIDER_UNAVAILABLE_AUDIO_NOT_RUN',current='CLOSED',original_user_restore='PENDING_REVIEW_NOT_CLAIMED');t.save();return 2
  if v.get('state')!='4':raise RuntimeError('NATIVE_BATCH_FAIL_OR_CANCEL_PRESERVED')
  count=int(v.get('saved','0'))
  if count and not all(any(tag in line and 'result=PASS' in line for line in t.state['file_verification']) for tag in ['[MANUAL-ART-VERIFY]','[MANUAL-ART-FILE]']):raise RuntimeError('MISSING_REOPEN_HASH_AND_FINAL_RENAME_PROOF')
  t.state.update(result='PASS_NATIVE_COVER_BATCH_STORE_AUDIO_NOT_RUN' if count else 'PASS_CACHE_REUSE_DOWNLOAD_AND_AUDIO_NOT_RUN' if int(v.get('cached','0')) else 'COMPLETED_NO_COVERS_PHYSICAL_DOWNLOAD_NOT_RUN',current='CLOSED',original_user_restore='PENDING_REVIEW_NOT_CLAIMED')
 except m.Stop as error:
  # STOP cancels the native job as well; no restore/playback commands follow.
  if t.s is not None:
   try:t.s.write(b'r10 artwork sd cancel\n');t.s.flush();t.pump(1)
   except Exception:pass
  t.state.update(result='USER_STOP_INCOMPLETE' if str(error)=='USER_STOP' else 'MAINTENANCE_INCOMPLETE',stop_reason=str(error))
 except Exception as error:t.state.update(result='WAIT_USER_NATIVE_COVER_FAIL_OR_MISSING_EVIDENCE',error=m.redact(str(error)))
 finally:t.close(stop_only=True)
 print(t.state['result'],str(t.root),flush=True)
 return 0 if t.state['result'].startswith('PASS_') else 2
if __name__=='__main__':sys.exit(main())
