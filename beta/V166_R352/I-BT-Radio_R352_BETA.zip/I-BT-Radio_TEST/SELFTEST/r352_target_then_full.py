"""One COM owner: targeted WiFi/TLS gate, then one complete native matrix. No flash/reset."""
from pathlib import Path
import argparse,hashlib,json,sys
HOME=Path('C:/esp32/USER/I-BT-Radio_TEST')
sys.path.insert(0,str(HOME/'SELFTEST'))
import r352_full_selftest as m
from r312_transport_evidence import TransportEvidence
import r352_sd_bootstrap
POINTER=Path('C:/esp32/SYSTEM/LOGS/REPORTS/RADIO_CONTINUOUS_ACTIVE.json')
TARGET=[('SD_BTOUT_BUFFER_'+str(i),90) for i in range(4)]+[('WIFI_BUFFER_3',120),('WIFI_STOP_START',60),('RETURN_WIFI',120)]
FULL=[p for p in m.PHASES if p[0].startswith('SD_BTOUT')]+[p for p in m.PHASES if not p[0].startswith('SD_BTOUT')]
def run_gated(test):
 test.state.update(stage='TARGET_WIFI_TLS',target_result='RUNNING',full_result='NOT_RUN_TARGET_GATE');test.save()
 for name,seconds in TARGET:test.run_case(name,seconds)
 assert all(c['result']=='PASS_NATIVE_AUDIO_WINDOW' for c in test.state['cases']), 'TARGET_MISSING_PASS'
 test.state.update(target_result='PASS_NATIVE_POST_BT_WIFI_TLS_WINDOWS',stage='FULL_MATRIX',full_result='RUNNING');test.save()
 for name,seconds in FULL:test.run_case(name,seconds)
 test.restore()
 test.state.update(full_result='PASS_AUTOMATED_NATIVE_MATRIX',result='PASS_AUTOMATED_TARGET_AND_FULL_MATRIX_MANUAL_EVIDENCE_NOT_RUN')
class Owner(m.Test):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.transport_evidence=TransportEvidence(m.fault)
  self.state['host_dependencies']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(r352_sd_bootstrap.__file__),Path(__file__).with_name('r312_transport_evidence.py')]}
 def initialize(self):
  self.bootstrap_original=r352_sd_bootstrap.prepare(self)
  super().initialize()
 def restore(self):
  super().restore()
  r352_sd_bootstrap.restore(self,self.bootstrap_original)
 def bootstrap_play(self,index):
  self.gate();index=int(index)
  permitted={int(self.args.sd_mp3),int(self.state['bootstrap_original']['sd_station'])}
  if index not in permitted or not 1<=index<=32767 or self.transport_evidence.pending:
   raise RuntimeError('BOOTSTRAP_PLAY_NOT_ALLOWED')
  cmd='play '+str(index)
  self.s.write((cmd+'\n').encode('ascii'));self.s.flush()
  self.state.setdefault('bootstrap_selection_commands',[]).append(dict(utc=m.utc(),command=cmd))
  self.save()
 def gate(self):
  super().gate();self.transport_evidence.check()
 def pump(self,seconds):
  original=m.fault;m.fault=self.transport_evidence.fault
  try:return super().pump(seconds)
  finally:m.fault=original
 def send(self,cmd):
  if self.transport_evidence.pending and cmd not in ['r10 path status','r10 heap','r10 load','r10 buffer status']:
   raise RuntimeError('NO_MUTATION_WITH_PENDING_TCP_OPEN '+cmd)
  return super().send(cmd)
 def wait(self,predicate,seconds,reason):
  # SDK TLS handshake permits120s; add DNS/TCP/owner-readback margin. A host
  # deadline must not masquerade as a proven firmware TLS failure at60/90s.
  phase=getattr(self,'phase',None) or {}
  wifi=phase.get('name','').startswith('WIFI') or phase.get('name')=='RETURN_WIFI'
  if reason=='INITIAL_AUDIO_REQUIRED' or (wifi and reason in ['NEW_SOURCE_DECODE_TIMEOUT','STOP_START_NO_ACTUAL_AUDIO']):seconds=max(seconds,180)
  return super().wait(predicate,seconds,reason)
 def save(self):
  if hasattr(self,'transport_evidence'):
   self.state['TCP_open_attempts']=self.transport_evidence.attempts
   self.state['TCP_open_recovered_native_retries']=self.transport_evidence.recovered
  super().save()
  m.write(POINTER,{k:self.state.get(k) for k in ['firmware','root','pid','result','started','updated','COM_closed','current','stage','target_result','full_result','host_source_sha256']})
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--receipt');ap.add_argument('--bootstrap-restore-from');ap.add_argument('--execute',action='store_true');ap.add_argument('--sd-mp3',type=int,required=True);a=ap.parse_args()
 if not a.execute:raise SystemExit('NO_COM_WITHOUT_EXPLICIT_EXECUTE')
 manifest=m.package(HOME);receipt=m.receipt_for(manifest,a.receipt)
 args=argparse.Namespace(port='COM4',ir_confirmed=False,sd_mp3=a.sd_mp3,sd_flac=2,wifi_station=6,bt_name='VFOCUS|POLY',max_minutes=90)
 t=Owner(HOME,manifest,args,receipt)
 t.state.update(scope='TARGET_WIFI_TLS_THEN_FULL_ONLY_ON_PASS',host_script=str(Path(__file__).resolve()),host_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),target_result='NOT_RUN',full_result='NOT_RUN_TARGET_GATE',GitHub_published=False)
 if a.bootstrap_restore_from:
  previous=Path(a.bootstrap_restore_from).resolve()
  if (HOME/'RETURN_TO_EVA').resolve() not in previous.parents:raise RuntimeError('INVALID_BOOTSTRAP_RESTORE_ROOT_NO_COM')
  prior=json.loads((previous/'RUN_STATUS.json').read_text(encoding='utf8'))
  identity=prior.get('identity_verified',{})
  if not identity:
   # Older bootstrap recorded its verified identity in serial, before it
   # saved the bootstrap-original state. Read exact tagged evidence only.
   lines=(previous/'serial.log').read_text(encoding='utf8').splitlines()
   identities=[m.fields(line) for line in lines if line.startswith('[R352-IDENTITY] ')]
   identity=identities[-1] if identities else {}
  if identity.get('firmware')!='V166-R352' or identity.get('elf_sha256')!=manifest['app_elf_sha256'] or not prior.get('COM_closed'):raise RuntimeError('UNVERIFIED_BOOTSTRAP_RESTORE_ROOT_NO_COM')
  t.state.update(bootstrap_restore_intent=prior['bootstrap_original'],bootstrap_restore_from=str(previous))
 try:
  t.open();t.initialize();run_gated(t)
 except m.Stop as error:t.state.update(result='USER_STOP_INCOMPLETE',stop_reason=str(error))
 except KeyboardInterrupt:t.state.update(result='USER_STOP_INCOMPLETE',stop_reason='KEYBOARD_INTERRUPT')
 except m.Deadline:t.state['result']='DEADLINE_INCOMPLETE'
 except Exception as error:
  t.state.update(result='WAIT_USER_FAIL_OR_MISSING_REQUIRED_EVIDENCE',error=m.redact(str(error)))
  if t.state.get('target_result')!='PASS_NATIVE_POST_BT_WIFI_TLS_WINDOWS':t.state.update(target_result='FAIL_OR_INCOMPLETE',full_result='NOT_RUN_TARGET_FAILED')
 finally:
  # A failed/closed full matrix must never retain a RUNNING sub-result.
  # Keep the original exception/result; no device recovery is performed here.
  if t.state.get('full_result')=='RUNNING' and not t.state['result'].startswith('PASS_'):
   t.state['full_result']={'USER_STOP_INCOMPLETE':'INCOMPLETE_USER_STOP','DEADLINE_INCOMPLETE':'INCOMPLETE_DEADLINE'}.get(t.state['result'],'FAIL_OR_INCOMPLETE')
  t.close(stop_only=t.state['result'] in ['USER_STOP_INCOMPLETE','DEADLINE_INCOMPLETE'])
 print(t.state['result'],str(t.root),flush=True)
 return 0 if t.state['result'].startswith('PASS_') else 2
if __name__=='__main__':sys.exit(main())
