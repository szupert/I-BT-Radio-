"""Console tee around the unchanged checked updater; no serial access here."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,subprocess,sys,uuid

EXPECTED='V166-R352'
FW_SHA='fcc624caabba0c7c29745eafa34ab113e178e508028e63b56a9029e0456e3e9a'

def tee(command,log):
    child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,bufsize=0)
    try:
        while True:
            data=os.read(child.stdout.fileno(),4096)
            if not data:break
            log.write(data);log.flush()
            sys.stdout.buffer.write(data);sys.stdout.buffer.flush()
        return child.wait()
    except KeyboardInterrupt:
        # The console delivers Ctrl+C to the original updater too. Never retry.
        print('\nUSER_STOP: a feltolto kilepesere varok.',flush=True)
        child.wait()
        return 130
    finally:
        child.stdout.close()

def validate_receipt(value):
    return (value.get('result')=='PASS_FLASH_HASH_BOOT' and
            value.get('firmware')==EXPECTED and value.get('profile_id')=='lite4' and
            value.get('selected_firmware_sha256')==FW_SHA)

def new_receipt(root,before):
    found=[]
    for p in root.glob('UPDATE_*/RESULT.json'):
        if str(p) in before:continue
        try:
            value=json.loads(p.read_text(encoding='utf8'))
            if validate_receipt(value):found.append((p,value))
        except (OSError,ValueError):continue
    if len(found)!=1:return None
    return found[0]

def run(root,verify_only=False):
    logs=Path('C:/esp32/SYSTEM/LOGS/UPLOAD')
    package=root/'INSTALLER/VARIANTS'
    entry=root/'INSTALLER/LIGHT4_AUTO/run_upload.py'
    ident=datetime.datetime.now(datetime.timezone.utc).strftime('LAUNCH_R352_%Y%m%d_%H%M%S_')+uuid.uuid4().hex[:8]
    out=root/'RETURN_TO_EVA'/ident
    out.mkdir(parents=True,exist_ok=False)
    proof=dict(expected=EXPECTED,mode='VERIFY_ONLY' if verify_only else 'INSTALL',entry=str(entry),
               start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),result='STARTED')
    (out/'START.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
    before={str(p) for p in logs.glob('UPDATE_*/RESULT.json')}
    rc=2
    with (out/'console.log').open('wb') as log:
        def say(message):
            data=(message+'\n').encode('utf8');log.write(data);log.flush()
            sys.stdout.buffer.write(data);sys.stdout.buffer.flush()
        say('[R352] NAPLOZOTT FELTOLTO - '+proof['mode'])
        say('[NAPLO] '+str(out))
        say('[INFO] A "csomag PASS; COM nem nyilt meg" csak eloellenorzes.')
        say('[INFO] Feltoltesi sikerhez uj R352 irasi/hash/boot naplo szukseges.')
        try:
            manifest=json.loads((package/'4MB_PSRAM_NELKUL/INSTALLER/PACKAGE.json').read_text(encoding='utf8'))
            binary=package/'4MB_PSRAM_NELKUL/INSTALLER/firmware.bin'
            if manifest.get('firmware')!=EXPECTED or hashlib.sha256(binary.read_bytes()).hexdigest()!=FW_SHA:
                raise RuntimeError('Nem az elvart R352 csomag van az indito mellett. Nincs feltoltes.')
            import importlib.metadata
            requirements=root/'INSTALLER/LIGHT4_AUTO/INSTALLER/requirements.txt'
            try:
                deps=importlib.metadata.version('esptool')=='5.3.0' and importlib.metadata.version('pyserial')=='3.5'
            except importlib.metadata.PackageNotFoundError:deps=False
            if not deps:
                say('[FUGGOSEG] Az eredeti csomag Python-fuggosegeinek telepitese.')
                if tee([sys.executable,'-m','pip','install','-r',str(requirements)],log):
                    raise RuntimeError('A fuggosegek telepitese nem sikerult. Nincs feltoltes.')
            rc=tee([sys.executable,'-B','-X','utf8','-u',str(entry)]+(['--verify-only'] if verify_only else []),log)
            proof['child_exit']=rc
            if rc!=0:proof['result']='USER_STOP' if rc==130 else 'UPDATER_FAILED'
            elif verify_only:proof['result']='PACKAGE_CHECK_ONLY_NO_FLASH'
            else:
                receipt=new_receipt(logs,before)
                if receipt:
                    proof.update(result='PASS_FLASH_HASH_BOOT',receipt=str(receipt[0]),firmware=EXPECTED,firmware_sha256=FW_SHA)
                else:
                    proof['result']='NO_FRESH_R352_RECEIPT';rc=2
                    say('[HIBA] Nem igazolhato uj R352 feltoltes. A csomagellenorzes nem eleg.')
        except Exception as error:
            proof.update(result='LAUNCH_FAILED',error=str(error));rc=2
            say('[HIBA] '+str(error))
        proof['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        proof['console_sha256']=hashlib.sha256((out/'console.log').read_bytes()).hexdigest()
        say('[VEGEREDMENY] '+proof['result'])
        say('[NAPLO] '+str(out))
    # Hash includes the final visible result too.
    proof['console_sha256']=hashlib.sha256((out/'console.log').read_bytes()).hexdigest()
    (out/'RESULT.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf8')
    return rc

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--verify-only',action='store_true')
    args=parser.parse_args()
    home=Path(__file__).resolve().parent
    root=home.parent if home.name.upper()=='INSTALLER' else home
    sys.exit(run(root,args.verify_only))
