# R315 TLS RX reservation

Local candidate, physical NOT_RUN. R314 post-BT TLS alloc16725/-32512 remains original FAIL.

The full native RX block is reserved after closing the previous TLS context and before the SDK TCP/TLS setup can fragment the heap with smaller context allocations. An unadopted reservation is owned by a stack RAII guard and freed on every early return, cancellation or setup failure. After successful setup it is adopted by exactly that fresh SDK context, retains the native16384-byte content bound, and uses the SDK STATIC buffer state only during handshake. SDK close frees adopted storage. After successful handshake, native dynamic-cache and partial-message guards decide whether the buffer may shrink. There is no shared pool, additional task, record-capacity reduction, TLS/HTTP replay or OOM recovery loop.

Host: actual SDK allocator/state/cleanup code with fragmented simulated heap, 8 allocation/lifetime cases PASS. Prior fragmented-header35 and old dangling-header32 cases PASS. Host crypto is NOT_TESTED; the original physical failure sequence must still pass.

Single-owner target gate now runs four SD–Poly profiles BEFORE WiFi_BUFFER3/StopStart3/RETURN_WIFI, each complete actual-audio window required. Only all seven PASS opens full27. Independent target/old results are preserved. Hearing/IR learning/physical controls/WebUI/BT-IN are separately scoped, not autoPASS.

R315 also retains the prepared HU/EN/DE language fix and partial title translations. No GitHub publication until a complete relevant physical review PASS.
