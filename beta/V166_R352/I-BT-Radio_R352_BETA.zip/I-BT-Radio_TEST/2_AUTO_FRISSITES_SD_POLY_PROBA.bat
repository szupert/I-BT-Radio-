@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "IBT_PY=C:\esp32\SYSTEM\TOOLS\platformio\core\penv\Scripts\python.exe"
if exist "%IBT_PY%" (
 "%IBT_PY%" -B -X utf8 -u SELFTEST\r352_poly_focus_probe.py --execute %*
) else (
 py -3 -B -X utf8 -u SELFTEST\r352_poly_focus_probe.py --execute %*
)
set "IBT_EXIT=%ERRORLEVEL%"
echo.
echo Befejezes, kod: %IBT_EXIT%
pause
exit /b %IBT_EXIT%
